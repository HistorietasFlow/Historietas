"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import type { ChangeEvent, CSSProperties } from "react";
import { supabase } from "../../lib/supabase/client";
import { historietasThemeCss, useHistorietasTheme } from "../../lib/historietasTheme";
import { criarSlugBase, formatarTamanhoArquivo, normalizarTexto } from "../../lib/utils";
import { useHistorietasLanguage } from "../../components/HistorietasLanguageProvider";
import type { HistorietasLanguage } from "../../lib/i18n";

type CapituloLocal = {
  id: string;
  titulo: string;
  texto: string;
  curtiu: boolean;
  salvo: boolean;
  comentario: string;
  criadoEm: string;
  lido: boolean;
  lidoEm: string;
};

type ArquivoObraLocal = {
  nome: string;
  tipo: string;
  tamanho: number;
  conteudo: string;
  categoria: "texto" | "documento" | "imagem" | "outro";
  criadoEm: string;
};

type ObraLocal = {
  id: string;
  titulo: string;
  autor: string;
  autorId?: string;
  genero: string;
  formato: string;
  classificacaoIndicativa: string;
  sinopse: string;
  tags: string[];
  capa: string;
  capaNome: string;
  arquivoObra?: ArquivoObraLocal | null;
  publicado: boolean;
  capitulos: CapituloLocal[];
  criadaEm: string;
  ultimoCapituloLidoId: string;
  ultimaLeituraEm: string;
  progressoLeitura: number;
  visualizacoes: number;
  totalCurtidas: number;
  totalComentarios: number;
  totalSalvos: number;
  totalLidos: number;
  slug: string;
  link: string;
};

type CapituloSalvo = Partial<CapituloLocal> & Record<string, unknown>;

type ObraSalva = Partial<ObraLocal> & {
  capitulos?: CapituloSalvo[];
} & Record<string, unknown>;

type ArquivoStoragePublicar = {
  bucket: "capas-obras" | "arquivos-obras";
  caminho: string;
  publicUrl: string;
};

const STORAGE_KEY = "historietas-obras";
const FILE_BACKUP_STORAGE_KEY = "historietas-arquivos-obras-backup";
const TAMANHO_MAXIMO_CAPA = 2 * 1024 * 1024;
const TAMANHO_MAXIMO_ARQUIVO_TEXTO = 900 * 1024;
const TAMANHO_MAXIMO_ARQUIVO_OBRA = 5 * 1024 * 1024;
const EXTENSOES_IMAGEM_ACEITAS = [
  ".png",
  ".jpg",
  ".jpeg",
  ".webp",
  ".gif",
] as const;
const TIPOS_MIME_IMAGEM_ACEITOS = new Set([
  "image/png",
  "image/jpeg",
  "image/webp",
  "image/gif",
]);

const OUTRO_FORMATO_VALUE = "__outro_formato__";
const OUTRO_GENERO_VALUE = "__outro_genero__";
const OUTRA_TAG_VALUE = "__outra_tag__";
const LIMITE_CARACTERES_FORMATO_GENERO_PERSONALIZADO = 14;
const LIMITE_CARACTERES_TAG_PERSONALIZADA = 10;

const LIMITE_TAGS_OBRA = 1;
const OPCOES_FORMATO_OBRA = [
  "Webnovel",
  "Light novel",
  "Romance",
  "Conto",
  "Poesia",
  "HQ",
  "Mangá",
  "Fanfic",
] as const;

const OPCOES_GENERO_OBRA = [
  "Fantasia",
  "Terror",
  "Ficção",
  "Romance",
  "Drama",
  "Ação",
  "Mistério",
  "Suspense",
  "Aventura",
  "Comédia",
] as const;

const OPCOES_TAGS_OBRA = [
  "Sombria",
  "Psicológico",
  "Sci-fi",
  "Cyberpunk",
  "Espacial",
  "Isekai",
  "Distopia",
  "Apocalipse",
  "Escolar",
  "Máfia",
  "Investigação",
  "Religioso",
  "Mitologia",
  "Folclore",
  "Vampiro",
  "Lobisomem",
  "Zumbi",
  "Super-herói",
  "Magia",
  "Guerra",
  "Família",
  "Amizade",
  "Traição",
  "Vingança",
  "Sobrevivência",
] as const;

const CLASSIFICACOES_INDICATIVAS_OBRA = [
  "Livre",
  "10+",
  "12+",
  "14+",
  "16+",
  "18+",
] as const;


type ChaveTextoPublicar = keyof (typeof TEXTOS_PUBLICAR)["pt-BR"];

const TEXTOS_PUBLICAR = {
  "pt-BR": {
    voltarHome: "Voltar para a Home",
    novaObra: "NOVA OBRA",
    notificacoes: "Notificações",
    notificacoesNaoLidas: "não lidas",
    ajusteNecessario: "Ajuste necessário:",
    capaSelecionada: "Capa selecionada",
    adicionarCapa: "Adicionar capa",
    dicaCapa: "Imagem vertical. Tamanho máximo: 2 MB.",
    escolherImagem: "Escolher imagem",
    remover: "Remover",
    tituloObra: "Título da obra",
    dicaTitulo: "Mínimo 3 letras ou números.",
    nomeAutor: "Nome do autor",
    dicaAutor: "Pode ser nome, nickname ou estúdio.",
    formato: "Formato",
    escolherFormato: "Escolha o formato",
    outroFormato: "Outro formato",
    digiteFormato: "Digite o formato",
    generoPrincipal: "Gênero principal",
    escolherGenero: "Escolha um gênero",
    outroGenero: "Outro gênero",
    digiteGenero: "Digite o gênero",
    tag: "Tag",
    escolherTag: "Escolha uma tag",
    outraTag: "Outra tag",
    digiteTag: "Digite a tag",
    classificacaoIndicativa: "Classificação indicativa",
    escolherClassificacao: "Escolha a classificação",
    sinopse: "Sinopse",
    resumoChamativo: "Escreva um resumo chamativo de sua história...",
    minimoSinopse: "Mínimo 20 letras ou números.",
    palavras: "palavras",
    adicionarConteudoArquivo: "Adicionar conteúdo por arquivo",
    opcional: "Opcional",
    comoUsarArquivo: "Como deseja usar este arquivo?",
    arquivoCompletoAnexado: "Arquivo completo anexado",
    primeiroCapituloImportado: "Primeiro capítulo importado",
    enviarArquivo: "Enviar PDF, texto ou imagem",
    dicaArquivoPendente: "Arquivos TXT e MD podem ser anexados como obra completa ou transformados no primeiro capítulo.",
    dicaArquivo: "PDF e imagens serão anexados. Arquivos TXT e MD permitem escolher entre anexo completo ou primeiro capítulo. Máximo: 5 MB.",
    texto: "Texto",
    primeiroCapitulo: "Primeiro capítulo",
    transformarCapitulo: "Transformar em capítulo",
    anexarArquivoCompleto: "Anexar arquivo completo",
    cancelar: "Cancelar",
    trocarArquivo: "Trocar arquivo",
    escolherArquivo: "Escolher arquivo",
    anexadoObra: "anexado à obra",
    titulo: "Título",
    salvando: "Salvando...",
    criarObra: "Criar obra",
    progresso: "Progresso",
    previaObra: "PRÉVIA DA OBRA",
    obraSemTitulo: "Obra sem título",
    classificacao: "Classificação",
    por: "Por",
    autorNaoInformado: "Autor não informado",
    capituloAbreviado: "cap.",
    capituloPronto: "1 cap. pronto",
    semCapitulo: "sem capítulo",
    primeiroCapituloMaiusculo: "PRIMEIRO CAPÍTULO",
    minLeitura: "min de leitura",
    genero: "Gênero",
    previa: "Prévia",
    previaAqui: "A prévia aparece aqui",
    dicaPrevia: "Preencha título, autor, gênero e capa para ver como a obra vai ficar.",
    imagem: "Imagem",
    arquivo: "Arquivo",
    livre: "Livre",
  },
  en: {
    voltarHome: "Back to Home",
    novaObra: "NEW WORK",
    notificacoes: "Notifications",
    notificacoesNaoLidas: "unread",
    ajusteNecessario: "Action required:",
    capaSelecionada: "Cover selected",
    adicionarCapa: "Add cover",
    dicaCapa: "Vertical image. Maximum size: 2 MB.",
    escolherImagem: "Choose image",
    remover: "Remove",
    tituloObra: "Work title",
    dicaTitulo: "At least 3 letters or numbers.",
    nomeAutor: "Author name",
    dicaAutor: "It may be a name, nickname, or studio.",
    formato: "Format",
    escolherFormato: "Choose the format",
    outroFormato: "Other format",
    digiteFormato: "Enter the format",
    generoPrincipal: "Main genre",
    escolherGenero: "Choose a genre",
    outroGenero: "Other genre",
    digiteGenero: "Enter the genre",
    tag: "Tag",
    escolherTag: "Choose a tag",
    outraTag: "Other tag",
    digiteTag: "Enter the tag",
    classificacaoIndicativa: "Age rating",
    escolherClassificacao: "Choose the age rating",
    sinopse: "Synopsis",
    resumoChamativo: "Write an engaging summary of your story...",
    minimoSinopse: "At least 20 letters or numbers.",
    palavras: "words",
    adicionarConteudoArquivo: "Add content from a file",
    opcional: "Optional",
    comoUsarArquivo: "How would you like to use this file?",
    arquivoCompletoAnexado: "Full file attached",
    primeiroCapituloImportado: "First chapter imported",
    enviarArquivo: "Upload PDF, text, or image",
    dicaArquivoPendente: "TXT and MD files can be attached as a full work or turned into the first chapter.",
    dicaArquivo: "PDFs and images will be attached. TXT and MD files let you choose between a full attachment or a first chapter. Maximum: 5 MB.",
    texto: "Text",
    primeiroCapitulo: "First chapter",
    transformarCapitulo: "Turn into chapter",
    anexarArquivoCompleto: "Attach full file",
    cancelar: "Cancel",
    trocarArquivo: "Change file",
    escolherArquivo: "Choose file",
    anexadoObra: "attached to the work",
    titulo: "Title",
    salvando: "Saving...",
    criarObra: "Create work",
    progresso: "Progress",
    previaObra: "WORK PREVIEW",
    obraSemTitulo: "Untitled work",
    classificacao: "Age rating",
    por: "By",
    autorNaoInformado: "Author not provided",
    capituloAbreviado: "ch.",
    capituloPronto: "1 ch. ready",
    semCapitulo: "no chapter",
    primeiroCapituloMaiusculo: "FIRST CHAPTER",
    minLeitura: "min read",
    genero: "Genre",
    previa: "Preview",
    previaAqui: "The preview appears here",
    dicaPrevia: "Fill in the title, author, genre, and cover to see how the work will look.",
    imagem: "Image",
    arquivo: "File",
    livre: "All ages",
  },
  es: {
    voltarHome: "Volver al inicio",
    novaObra: "NUEVA OBRA",
    notificacoes: "Notificaciones",
    notificacoesNaoLidas: "sin leer",
    ajusteNecessario: "Ajuste necesario:",
    capaSelecionada: "Portada seleccionada",
    adicionarCapa: "Añadir portada",
    dicaCapa: "Imagen vertical. Tamaño máximo: 2 MB.",
    escolherImagem: "Elegir imagen",
    remover: "Eliminar",
    tituloObra: "Título de la obra",
    dicaTitulo: "Mínimo 3 letras o números.",
    nomeAutor: "Nombre del autor",
    dicaAutor: "Puede ser un nombre, apodo o estudio.",
    formato: "Formato",
    escolherFormato: "Elige el formato",
    outroFormato: "Otro formato",
    digiteFormato: "Escribe el formato",
    generoPrincipal: "Género principal",
    escolherGenero: "Elige un género",
    outroGenero: "Otro género",
    digiteGenero: "Escribe el género",
    tag: "Etiqueta",
    escolherTag: "Elige una etiqueta",
    outraTag: "Otra etiqueta",
    digiteTag: "Escribe la etiqueta",
    classificacaoIndicativa: "Clasificación por edad",
    escolherClassificacao: "Elige la clasificación",
    sinopse: "Sinopsis",
    resumoChamativo: "Escribe un resumen atractivo de tu historia...",
    minimoSinopse: "Mínimo 20 letras o números.",
    palavras: "palabras",
    adicionarConteudoArquivo: "Añadir contenido desde un archivo",
    opcional: "Opcional",
    comoUsarArquivo: "¿Cómo deseas usar este archivo?",
    arquivoCompletoAnexado: "Archivo completo adjunto",
    primeiroCapituloImportado: "Primer capítulo importado",
    enviarArquivo: "Subir PDF, texto o imagen",
    dicaArquivoPendente: "Los archivos TXT y MD pueden adjuntarse como obra completa o convertirse en el primer capítulo.",
    dicaArquivo: "Los PDF y las imágenes se adjuntarán. Los archivos TXT y MD permiten elegir entre un adjunto completo o el primer capítulo. Máximo: 5 MB.",
    texto: "Texto",
    primeiroCapitulo: "Primer capítulo",
    transformarCapitulo: "Convertir en capítulo",
    anexarArquivoCompleto: "Adjuntar archivo completo",
    cancelar: "Cancelar",
    trocarArquivo: "Cambiar archivo",
    escolherArquivo: "Elegir archivo",
    anexadoObra: "adjunto a la obra",
    titulo: "Título",
    salvando: "Guardando...",
    criarObra: "Crear obra",
    progresso: "Progreso",
    previaObra: "VISTA PREVIA DE LA OBRA",
    obraSemTitulo: "Obra sin título",
    classificacao: "Clasificación",
    por: "Por",
    autorNaoInformado: "Autor no informado",
    capituloAbreviado: "cap.",
    capituloPronto: "1 cap. listo",
    semCapitulo: "sin capítulo",
    primeiroCapituloMaiusculo: "PRIMER CAPÍTULO",
    minLeitura: "min de lectura",
    genero: "Género",
    previa: "Vista previa",
    previaAqui: "La vista previa aparece aquí",
    dicaPrevia: "Completa el título, autor, género y portada para ver cómo quedará la obra.",
    imagem: "Imagen",
    arquivo: "Archivo",
    livre: "Todo público",
  },
} as const;

const ROTULOS_FORMATO_PUBLICAR: Record<HistorietasLanguage, Record<string, string>> = {
  "pt-BR": {
    Webnovel: "Webnovel",
    "Light novel": "Light novel",
    Romance: "Romance",
    Conto: "Conto",
    Poesia: "Poesia",
    HQ: "HQ",
    Mangá: "Mangá",
    Fanfic: "Fanfic",
  },
  en: {
    Webnovel: "Web novel",
    "Light novel": "Light novel",
    Romance: "Novel",
    Conto: "Short story",
    Poesia: "Poetry",
    HQ: "Comic",
    Mangá: "Manga",
    Fanfic: "Fanfic",
  },
  es: {
    Webnovel: "Webnovela",
    "Light novel": "Novela ligera",
    Romance: "Novela",
    Conto: "Cuento",
    Poesia: "Poesía",
    HQ: "Cómic",
    Mangá: "Manga",
    Fanfic: "Fanfic",
  },
};

const ROTULOS_GENERO_PUBLICAR: Record<HistorietasLanguage, Record<string, string>> = {
  "pt-BR": {
    Fantasia: "Fantasia",
    Terror: "Terror",
    Ficção: "Ficção",
    Romance: "Romance",
    Drama: "Drama",
    Ação: "Ação",
    Mistério: "Mistério",
    Suspense: "Suspense",
    Aventura: "Aventura",
    Comédia: "Comédia",
  },
  en: {
    Fantasia: "Fantasy",
    Terror: "Horror",
    Ficção: "Fiction",
    Romance: "Romance",
    Drama: "Drama",
    Ação: "Action",
    Mistério: "Mystery",
    Suspense: "Thriller",
    Aventura: "Adventure",
    Comédia: "Comedy",
  },
  es: {
    Fantasia: "Fantasía",
    Terror: "Terror",
    Ficção: "Ficción",
    Romance: "Romance",
    Drama: "Drama",
    Ação: "Acción",
    Mistério: "Misterio",
    Suspense: "Suspenso",
    Aventura: "Aventura",
    Comédia: "Comedia",
  },
};

const ROTULOS_TAG_PUBLICAR: Record<HistorietasLanguage, Record<string, string>> = {
  "pt-BR": {
    Sombria: "Sombria",
    Psicológico: "Psicológico",
    "Sci-fi": "Sci-fi",
    Cyberpunk: "Cyberpunk",
    Espacial: "Espacial",
    Isekai: "Isekai",
    Distopia: "Distopia",
    Apocalipse: "Apocalipse",
    Escolar: "Escolar",
    Máfia: "Máfia",
    Investigação: "Investigação",
    Religioso: "Religioso",
    Mitologia: "Mitologia",
    Folclore: "Folclore",
    Vampiro: "Vampiro",
    Lobisomem: "Lobisomem",
    Zumbi: "Zumbi",
    "Super-herói": "Super-herói",
    Magia: "Magia",
    Guerra: "Guerra",
    Família: "Família",
    Amizade: "Amizade",
    Traição: "Traição",
    Vingança: "Vingança",
    Sobrevivência: "Sobrevivência",
  },
  en: {
    Sombria: "Dark",
    Psicológico: "Psychological",
    "Sci-fi": "Sci-fi",
    Cyberpunk: "Cyberpunk",
    Espacial: "Space",
    Isekai: "Isekai",
    Distopia: "Dystopia",
    Apocalipse: "Apocalypse",
    Escolar: "School",
    Máfia: "Mafia",
    Investigação: "Investigation",
    Religioso: "Religious",
    Mitologia: "Mythology",
    Folclore: "Folklore",
    Vampiro: "Vampire",
    Lobisomem: "Werewolf",
    Zumbi: "Zombie",
    "Super-herói": "Superhero",
    Magia: "Magic",
    Guerra: "War",
    Família: "Family",
    Amizade: "Friendship",
    Traição: "Betrayal",
    Vingança: "Revenge",
    Sobrevivência: "Survival",
  },
  es: {
    Sombria: "Oscura",
    Psicológico: "Psicológico",
    "Sci-fi": "Sci-fi",
    Cyberpunk: "Cyberpunk",
    Espacial: "Espacial",
    Isekai: "Isekai",
    Distopia: "Distopía",
    Apocalipse: "Apocalipsis",
    Escolar: "Escolar",
    Máfia: "Mafia",
    Investigação: "Investigación",
    Religioso: "Religioso",
    Mitologia: "Mitología",
    Folclore: "Folclore",
    Vampiro: "Vampiro",
    Lobisomem: "Hombre lobo",
    Zumbi: "Zombi",
    "Super-herói": "Superhéroe",
    Magia: "Magia",
    Guerra: "Guerra",
    Família: "Familia",
    Amizade: "Amistad",
    Traição: "Traición",
    Vingança: "Venganza",
    Sobrevivência: "Supervivencia",
  },
};

const MENSAGENS_ERRO_PUBLICAR: Record<HistorietasLanguage, Record<string, string>> = {
  "pt-BR": {},
  en: {
    "O título precisa ter pelo menos 3 letras ou números. Não pode ser só ponto.": "The title must contain at least 3 letters or numbers. It cannot consist only of punctuation.",
    "O nome do autor precisa ter pelo menos 2 letras ou números.": "The author name must contain at least 2 letters or numbers.",
    "O formato personalizado precisa ter 3 a 14 caracteres, sem vírgula, emoji ou símbolo estranho.": "The custom format must contain 3 to 14 characters, without commas, emojis, or unsupported symbols.",
    "Escolha o formato da obra.": "Choose the work format.",
    "O gênero personalizado precisa ter 3 a 14 caracteres, sem vírgula, emoji ou símbolo estranho.": "The custom genre must contain 3 to 14 characters, without commas, emojis, or unsupported symbols.",
    "Escolha o gênero principal da obra.": "Choose the work's main genre.",
    "A tag personalizada precisa ter 2 a 10 caracteres, sem vírgula, emoji ou símbolo estranho, e não pode repetir gênero ou formato.": "The custom tag must contain 2 to 10 characters, without commas, emojis, or unsupported symbols, and cannot repeat the genre or format.",
    "Escolha a classificação indicativa da obra.": "Choose the work's age rating.",
    "A sinopse precisa ter pelo menos 20 letras ou números.": "The synopsis must contain at least 20 letters or numbers.",
    "O arquivo importado precisa ter pelo menos 20 letras ou números para virar o primeiro capítulo.": "The imported file must contain at least 20 letters or numbers to become the first chapter.",
    "Escolha um arquivo de imagem válido.": "Choose a valid image file.",
    "A capa precisa ter no máximo 2 MB.": "The cover must be no larger than 2 MB.",
    "Não consegui carregar essa imagem.": "I couldn't load this image.",
    "Não consegui carregar esse arquivo.": "I couldn't load this file.",
    "Para virar capítulo, o arquivo de texto precisa ter no máximo 900 KB. Você ainda pode anexá-lo como arquivo completo.": "To become a chapter, the text file must be no larger than 900 KB. You can still attach it as a full file.",
    "Esse arquivo tem pouco texto para virar um capítulo.": "This file does not contain enough text to become a chapter.",
    "Não consegui ler esse arquivo.": "I couldn't read this file.",
    "Escolha PDF, TXT, MD ou imagem em PNG, JPG, WEBP ou GIF.": "Choose a PDF, TXT, MD, or an image in PNG, JPG, WEBP, or GIF format.",
    "O arquivo precisa ter no máximo 5 MB.": "The file must be no larger than 5 MB.",
    "Entre na sua conta antes de publicar uma obra.": "Sign in before publishing a work.",
    "Não consegui encontrar um nome de autor válido no seu perfil. Atualize seu perfil ou preencha o nome do autor.": "I couldn't find a valid author name in your profile. Update your profile or enter the author name.",
    "O navegador recusou salvar dados locais porque o armazenamento está cheio.": "The browser couldn't save local data because its storage is full.",
    "Não consegui salvar a obra agora. Tente novamente.": "I couldn't save the work right now. Try again.",
    "A obra foi publicada, mas não consegui abrir o Painel do Autor. Acesse o painel antes de tentar publicar novamente.": "The work was published, but I couldn't open the Author Dashboard. Open the dashboard before trying to publish again.",
  },
  es: {
    "O título precisa ter pelo menos 3 letras ou números. Não pode ser só ponto.": "El título debe tener al menos 3 letras o números. No puede contener solamente signos.",
    "O nome do autor precisa ter pelo menos 2 letras ou números.": "El nombre del autor debe tener al menos 2 letras o números.",
    "O formato personalizado precisa ter 3 a 14 caracteres, sem vírgula, emoji ou símbolo estranho.": "El formato personalizado debe tener entre 3 y 14 caracteres, sin comas, emojis ni símbolos no admitidos.",
    "Escolha o formato da obra.": "Elige el formato de la obra.",
    "O gênero personalizado precisa ter 3 a 14 caracteres, sem vírgula, emoji ou símbolo estranho.": "El género personalizado debe tener entre 3 y 14 caracteres, sin comas, emojis ni símbolos no admitidos.",
    "Escolha o gênero principal da obra.": "Elige el género principal de la obra.",
    "A tag personalizada precisa ter 2 a 10 caracteres, sem vírgula, emoji ou símbolo estranho, e não pode repetir gênero ou formato.": "La etiqueta personalizada debe tener entre 2 y 10 caracteres, sin comas, emojis ni símbolos no admitidos, y no puede repetir el género ni el formato.",
    "Escolha a classificação indicativa da obra.": "Elige la clasificación por edad de la obra.",
    "A sinopse precisa ter pelo menos 20 letras ou números.": "La sinopsis debe tener al menos 20 letras o números.",
    "O arquivo importado precisa ter pelo menos 20 letras ou números para virar o primeiro capítulo.": "El archivo importado debe tener al menos 20 letras o números para convertirse en el primer capítulo.",
    "Escolha um arquivo de imagem válido.": "Elige un archivo de imagen válido.",
    "A capa precisa ter no máximo 2 MB.": "La portada debe tener como máximo 2 MB.",
    "Não consegui carregar essa imagem.": "No pude cargar esta imagen.",
    "Não consegui carregar esse arquivo.": "No pude cargar este archivo.",
    "Para virar capítulo, o arquivo de texto precisa ter no máximo 900 KB. Você ainda pode anexá-lo como arquivo completo.": "Para convertirse en capítulo, el archivo de texto debe tener como máximo 900 KB. También puedes adjuntarlo como archivo completo.",
    "Esse arquivo tem pouco texto para virar um capítulo.": "Este archivo no tiene suficiente texto para convertirse en un capítulo.",
    "Não consegui ler esse arquivo.": "No pude leer este archivo.",
    "Escolha PDF, TXT, MD ou imagem em PNG, JPG, WEBP ou GIF.": "Elige un PDF, TXT, MD o una imagen en formato PNG, JPG, WEBP o GIF.",
    "O arquivo precisa ter no máximo 5 MB.": "El archivo debe tener como máximo 5 MB.",
    "Entre na sua conta antes de publicar uma obra.": "Inicia sesión antes de publicar una obra.",
    "Não consegui encontrar um nome de autor válido no seu perfil. Atualize seu perfil ou preencha o nome do autor.": "No pude encontrar un nombre de autor válido en tu perfil. Actualiza tu perfil o escribe el nombre del autor.",
    "O navegador recusou salvar dados locais porque o armazenamento está cheio.": "El navegador no pudo guardar datos locales porque el almacenamiento está lleno.",
    "Não consegui salvar a obra agora. Tente novamente.": "No pude guardar la obra ahora. Inténtalo de nuevo.",
    "A obra foi publicada, mas não consegui abrir o Painel do Autor. Acesse o painel antes de tentar publicar novamente.": "La obra fue publicada, pero no pude abrir el Panel del Autor. Abre el panel antes de intentar publicar nuevamente.",
  },
};

function obterTextoPublicar(
  idioma: HistorietasLanguage,
  chave: ChaveTextoPublicar,
) {
  return TEXTOS_PUBLICAR[idioma][chave] || TEXTOS_PUBLICAR["pt-BR"][chave];
}

function traduzirFormatoPublicar(idioma: HistorietasLanguage, formato: string) {
  return ROTULOS_FORMATO_PUBLICAR[idioma][formato] || formato;
}

function traduzirGeneroPublicar(idioma: HistorietasLanguage, genero: string) {
  return ROTULOS_GENERO_PUBLICAR[idioma][genero] || genero;
}

function traduzirTagPublicar(idioma: HistorietasLanguage, tag: string) {
  return ROTULOS_TAG_PUBLICAR[idioma][tag] || tag;
}

function traduzirClassificacaoPublicar(
  idioma: HistorietasLanguage,
  classificacao: string,
) {
  return classificacao === "Livre"
    ? obterTextoPublicar(idioma, "livre")
    : classificacao;
}

function traduzirMensagemPublicar(
  idioma: HistorietasLanguage,
  mensagem: string,
): string {
  if (!mensagem || idioma === "pt-BR") {
    return mensagem;
  }

  const mensagemExata = MENSAGENS_ERRO_PUBLICAR[idioma][mensagem];

  if (mensagemExata) {
    return mensagemExata;
  }

  const prefixos = idioma === "en"
    ? [
        ["Erro ao enviar ", "Error uploading "],
        ["Não consegui preparar o endereço da obra: ", "I couldn't prepare the work address: "],
        ["Não consegui salvar a obra agora: ", "I couldn't save the work: "],
        ["Não consegui salvar o capítulo inicial: ", "I couldn't save the first chapter: "],
        ["A obra foi preparada, mas não pôde ser publicada: ", "The work was prepared but couldn't be published: "],
      ]
    : [
        ["Erro ao enviar ", "Error al subir "],
        ["Não consegui preparar o endereço da obra: ", "No pude preparar la dirección de la obra: "],
        ["Não consegui salvar a obra agora: ", "No pude guardar la obra: "],
        ["Não consegui salvar o capítulo inicial: ", "No pude guardar el primer capítulo: "],
        ["A obra foi preparada, mas não pôde ser publicada: ", "La obra fue preparada, pero no pudo publicarse: "],
      ];

  for (const [prefixoOriginal, prefixoTraduzido] of prefixos) {
    if (mensagem.startsWith(prefixoOriginal)) {
      return `${prefixoTraduzido}${mensagem.slice(prefixoOriginal.length)}`;
    }
  }

  const sufixoParcial =
    " A publicação parcial não pôde ser removida automaticamente. Confira o Painel do Autor antes de tentar novamente.";

  if (mensagem.endsWith(sufixoParcial)) {
    const base = mensagem.slice(0, -sufixoParcial.length);
    const baseTraduzida: string = traduzirMensagemPublicar(idioma, base);

    return idioma === "en"
      ? `${baseTraduzida} The partial publication couldn't be removed automatically. Check the Author Dashboard before trying again.`
      : `${baseTraduzida} La publicación parcial no pudo eliminarse automáticamente. Revisa el Panel del Autor antes de intentarlo de nuevo.`;
  }

  return mensagem;
}

function criarStorageKeyUsuarioPublicar(chave: string, userId: string) {
  const userIdLimpo = userId.trim();

  return userIdLimpo ? `${chave}:${userIdLimpo}` : "";
}

function lerStorageUsuarioPublicar(chave: string, userId: string) {
  const userIdLimpo = userId.trim();

  if (typeof window === "undefined" || !userIdLimpo) {
    return null;
  }

  try {
    const chaveStorage = criarStorageKeyUsuarioPublicar(chave, userIdLimpo);

    return chaveStorage ? localStorage.getItem(chaveStorage) : null;
  } catch {
    return null;
  }
}

function salvarJsonStorageUsuarioPublicar(
  chave: string,
  userId: string,
  valor: unknown
) {
  const userIdLimpo = userId.trim();

  if (typeof window === "undefined" || !userIdLimpo) {
    return;
  }

  try {
    const chaveStorage = criarStorageKeyUsuarioPublicar(chave, userIdLimpo);

    if (!chaveStorage) {
      return;
    }

    localStorage.setItem(chaveStorage, JSON.stringify(valor));
  } catch {
    // localStorage é fallback; a publicação principal fica no Supabase.
  }
}

function normalizarClassificacaoIndicativaPublicar(valor: string) {
  const valorLimpo = valor.trim();
  const valorNormalizado = normalizarTexto(valorLimpo);

  if (valorNormalizado === "livre" || valorNormalizado === "l") {
    return "Livre";
  }

  const classificacaoEncontrada = CLASSIFICACOES_INDICATIVAS_OBRA.find(
    (classificacao) =>
      normalizarTexto(classificacao) === valorNormalizado ||
      normalizarTexto(classificacao.replace("+", "")) === valorNormalizado,
  );

  return classificacaoEncontrada || "";
}


function gerarUuidFallback() {
  const bytes = new Uint8Array(16);
  const cryptoGlobal =
    typeof globalThis !== "undefined" && "crypto" in globalThis
      ? globalThis.crypto
      : null;

  if (cryptoGlobal && typeof cryptoGlobal.getRandomValues === "function") {
    cryptoGlobal.getRandomValues(bytes);
  } else {
    for (let index = 0; index < bytes.length; index += 1) {
      bytes[index] = Math.floor(Math.random() * 256);
    }
  }

  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;

  const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0"));

  return `${hex[0]}${hex[1]}${hex[2]}${hex[3]}-${hex[4]}${hex[5]}-${hex[6]}${hex[7]}-${hex[8]}${hex[9]}-${hex[10]}${hex[11]}${hex[12]}${hex[13]}${hex[14]}${hex[15]}`;
}

function criarUuidSeguro() {
  const cryptoGlobal =
    typeof globalThis !== "undefined" && "crypto" in globalThis
      ? globalThis.crypto
      : null;

  if (cryptoGlobal && typeof cryptoGlobal.randomUUID === "function") {
    return cryptoGlobal.randomUUID();
  }

  return gerarUuidFallback();
}

function criarId() {
  return criarUuidSeguro();
}

function limparNomeArquivoStorage(nomeArquivo: string) {
  const partes = nomeArquivo.split(".");
  const extensao =
    partes.length > 1 ? `.${partes[partes.length - 1].toLowerCase()}` : "";
  const nomeBase = partes
    .slice(0, partes.length > 1 ? -1 : partes.length)
    .join(".")
    .trim();

  const nomeSeguro =
    normalizarTexto(nomeBase)
      .replace(/[^a-z0-9-]/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "") || "arquivo";

  return `${nomeSeguro}${extensao}`;
}

async function enviarArquivoStorage(
  bucket: "capas-obras" | "arquivos-obras",
  userId: string,
  arquivo: File
): Promise<ArquivoStoragePublicar> {
  const caminho = `${userId}/${Date.now()}-${criarId()}-${limparNomeArquivoStorage(
    arquivo.name
  )}`;

  const { error } = await supabase.storage.from(bucket).upload(caminho, arquivo, {
    cacheControl: "3600",
    upsert: false,
  });

  if (error) {
    throw new Error(`Erro ao enviar ${arquivo.name}: ${error.message}`);
  }

  const publicUrl =
    bucket === "capas-obras"
      ? supabase.storage.from(bucket).getPublicUrl(caminho).data.publicUrl
      : "";

  return {
    bucket,
    caminho,
    publicUrl,
  };
}

async function removerArquivosStoragePublicar(
  arquivos: ArquivoStoragePublicar[]
) {
  const arquivosUnicos = Array.from(
    new Map(
      arquivos.map((arquivo) => [
        `${arquivo.bucket}:${arquivo.caminho}`,
        arquivo,
      ])
    ).values()
  );

  await Promise.allSettled(
    arquivosUnicos.map(async (arquivo) => {
      try {
        await supabase.storage
          .from(arquivo.bucket)
          .remove([arquivo.caminho]);
      } catch {
        // Limpeza de arquivo órfão é uma proteção extra.
      }
    })
  );
}

async function desfazerPublicacaoParcialPublicar(
  obraId: string,
  arquivos: ArquivoStoragePublicar[]
) {
  const obraIdLimpo = obraId.trim();
  let obraRemovida = !obraIdLimpo;

  if (obraIdLimpo) {
    try {
      await supabase.from("capitulos").delete().eq("obra_id", obraIdLimpo);

      const { error: erroRemoverObra } = await supabase
        .from("obras")
        .delete()
        .eq("id", obraIdLimpo);

      obraRemovida = !erroRemoverObra;
    } catch {
      obraRemovida = false;
    }
  }

  if (obraRemovida) {
    await removerArquivosStoragePublicar(arquivos);
  }

  return obraRemovida;
}

async function criarSlugUnicoSupabase(
  titulo: string,
  obrasExistentes: ObraLocal[]
) {
  const slugLocal = criarSlugUnico(titulo, obrasExistentes);
  const slugBase = criarSlugBase(slugLocal);
  let contador = 1;

  while (contador <= 20) {
    const slugAtual = contador === 1 ? slugBase : `${slugBase}-${contador}`;

    const { data, error } = await supabase
      .from("obras")
      .select("id")
      .eq("slug", slugAtual)
      .limit(1)
      .maybeSingle();

    if (error) {
      throw new Error(`Não consegui preparar o endereço da obra: ${error.message}`);
    }

    if (!data) {
      return slugAtual;
    }

    contador += 1;
  }

  return `${slugBase}-${Date.now().toString(36)}`;
}

function criarLoginHrefPublicar() {
  const params = new URLSearchParams({
    redirectTo: "/publicar",
  });

  return `/login?${params.toString()}`;
}

function obterNomeMetadataPublicar(usuario: {
  email?: string | null;
  user_metadata?: Record<string, unknown> | null;
}) {
  const metadata = usuario.user_metadata || {};
  const nomesPossiveis = [
    metadata.nome,
    metadata.name,
    metadata.full_name,
    metadata.username,
    metadata.user_name,
    metadata.preferred_username,
  ];

  const nomeMetadata = nomesPossiveis.find((valor): valor is string => {
    return typeof valor === "string" && Boolean(valor.trim());
  });

  if (nomeMetadata?.trim()) {
    return nomeMetadata.trim();
  }

  const email = typeof usuario.email === "string" ? usuario.email.trim() : "";

  return email ? email.split("@")[0] || "" : "";
}

async function carregarNomePerfilPublicar(userId: string, fallback = "") {
  const fallbackLimpo = fallback.trim();

  if (!userId.trim()) {
    return fallbackLimpo;
  }

  try {
    const { data, error } = await supabase
      .from("profiles")
      .select("nome")
      .eq("user_id", userId)
      .limit(1)
      .maybeSingle();

    const nome = typeof data?.nome === "string" ? data.nome.trim() : "";

    if (!error && nome) {
      return nome;
    }
  } catch {
    // O nome manual/metadata continua disponível se profiles falhar.
  }

  try {
    const { data, error } = await supabase
      .from("profiles")
      .select("nome")
      .eq("id", userId)
      .limit(1)
      .maybeSingle();

    const nome = typeof data?.nome === "string" ? data.nome.trim() : "";

    if (!error && nome) {
      return nome;
    }
  } catch {
    // Alguns bancos usam user_id no profiles; esse fallback cobre tabelas antigas.
  }

  return fallbackLimpo;
}

function criarSlugUnico(titulo: string, obrasExistentes: ObraLocal[]) {
  const slugBase = criarSlugBase(titulo);
  const slugsUsados = new Set(
    obrasExistentes
      .map((obra) => obra.slug || criarSlugBase(obra.titulo))
      .filter(Boolean)
  );

  if (!slugsUsados.has(slugBase)) {
    return slugBase;
  }

  let contador = 2;
  let slugFinal = `${slugBase}-${contador}`;

  while (slugsUsados.has(slugFinal)) {
    contador += 1;
    slugFinal = `${slugBase}-${contador}`;
  }

  return slugFinal;
}

function calcularProgressoLeitura(capitulos: CapituloLocal[]) {
  if (capitulos.length === 0) {
    return 0;
  }

  const capitulosLidos = capitulos.filter((capitulo) => capitulo.lido).length;

  return Math.round((capitulosLidos / capitulos.length) * 100);
}

function identificarCategoriaArquivo(arquivo: File): ArquivoObraLocal["categoria"] {
  const nome = arquivo.name.toLowerCase();

  if (arquivo.type.startsWith("image/")) {
    return "imagem";
  }

  if (
    nome.endsWith(".txt") ||
    nome.endsWith(".md") ||
    arquivo.type.startsWith("text/")
  ) {
    return "texto";
  }

  if (nome.endsWith(".pdf") || arquivo.type === "application/pdf") {
    return "documento";
  }

  return "outro";
}

function arquivoTemExtensao(
  nomeArquivo: string,
  extensoes: readonly string[],
) {
  const nome = nomeArquivo.toLowerCase();

  return extensoes.some((extensao) => nome.endsWith(extensao));
}

function arquivoImagemAceito(arquivo: File) {
  return (
    arquivoTemExtensao(arquivo.name, EXTENSOES_IMAGEM_ACEITAS) ||
    TIPOS_MIME_IMAGEM_ACEITOS.has(arquivo.type.toLowerCase())
  );
}

function arquivoObraAceito(arquivo: File) {
  const nome = arquivo.name.toLowerCase();

  return (
    nome.endsWith(".pdf") ||
    nome.endsWith(".txt") ||
    nome.endsWith(".md") ||
    arquivoImagemAceito(arquivo) ||
    arquivo.type === "application/pdf"
  );
}

function normalizarArquivoObra(valor: unknown): ArquivoObraLocal | null {
  if (!valor || typeof valor !== "object" || Array.isArray(valor)) {
    return null;
  }

  const arquivo = valor as Partial<ArquivoObraLocal>;

  if (
    typeof arquivo.nome !== "string" ||
    !arquivo.nome.trim() ||
    typeof arquivo.conteudo !== "string" ||
    !arquivo.conteudo.trim()
  ) {
    return null;
  }

  let categoria: ArquivoObraLocal["categoria"] = "outro";

  if (
    arquivo.categoria === "texto" ||
    arquivo.categoria === "documento" ||
    arquivo.categoria === "imagem" ||
    arquivo.categoria === "outro"
  ) {
    categoria = arquivo.categoria;
  }

  return {
    nome: arquivo.nome,
    tipo: typeof arquivo.tipo === "string" ? arquivo.tipo : "",
    tamanho:
      typeof arquivo.tamanho === "number" && Number.isFinite(arquivo.tamanho)
        ? arquivo.tamanho
        : 0,
    conteudo: arquivo.conteudo,
    categoria,
    criadoEm: typeof arquivo.criadoEm === "string" ? arquivo.criadoEm : "",
  };
}

function normalizarObraSalva(obra: ObraSalva, obraIndex: number): ObraLocal {
  const capitulosNormalizados: CapituloLocal[] = Array.isArray(obra.capitulos)
    ? obra.capitulos.map((capitulo, capituloIndex) => ({
        ...capitulo,
        id:
          typeof capitulo.id === "string" && capitulo.id.trim()
            ? capitulo.id
            : `capitulo-${obraIndex + 1}-${capituloIndex + 1}`,
        titulo:
          typeof capitulo.titulo === "string" && capitulo.titulo.trim()
            ? capitulo.titulo
            : "Capítulo sem título",
        texto: typeof capitulo.texto === "string" ? capitulo.texto : "",
        curtiu: Boolean(capitulo.curtiu),
        salvo: Boolean(capitulo.salvo),
        comentario:
          typeof capitulo.comentario === "string" ? capitulo.comentario : "",
        criadoEm:
          typeof capitulo.criadoEm === "string" ? capitulo.criadoEm : "",
        lido: Boolean(capitulo.lido),
        lidoEm: typeof capitulo.lidoEm === "string" ? capitulo.lidoEm : "",
      }))
    : [];

  return {
    id:
      typeof obra.id === "string" && obra.id.trim()
        ? obra.id
        : `obra-${obraIndex + 1}`,
    titulo:
      typeof obra.titulo === "string" && obra.titulo.trim()
        ? obra.titulo
        : "Obra sem título",
    autor:
      typeof obra.autor === "string" && obra.autor.trim()
        ? obra.autor
        : "Autor não informado",
    autorId:
      typeof obra.autorId === "string" && obra.autorId.trim()
        ? obra.autorId.trim()
        : typeof obra.user_id === "string" && obra.user_id.trim()
        ? obra.user_id.trim()
        : typeof obra.userId === "string" && obra.userId.trim()
        ? obra.userId.trim()
        : "",
    genero:
      typeof obra.genero === "string" && obra.genero.trim()
        ? obra.genero
        : "Não informado",
    formato:
      typeof obra.formato === "string" && obra.formato.trim()
        ? obra.formato
        : "Não informado",
    classificacaoIndicativa:
      typeof obra.classificacaoIndicativa === "string" &&
      obra.classificacaoIndicativa.trim()
        ? obra.classificacaoIndicativa
        : "Não informada",
    sinopse:
      typeof obra.sinopse === "string" && obra.sinopse.trim()
        ? obra.sinopse
        : "Nenhuma sinopse informada.",
    tags: Array.isArray(obra.tags)
      ? obra.tags.filter((tag): tag is string => typeof tag === "string")
      : ["sem tags"],
    capa: typeof obra.capa === "string" ? obra.capa : "",
    capaNome: typeof obra.capaNome === "string" ? obra.capaNome : "",
    arquivoObra: normalizarArquivoObra(obra.arquivoObra),
    publicado: Boolean(obra.publicado),
    capitulos: capitulosNormalizados,
    criadaEm: typeof obra.criadaEm === "string" ? obra.criadaEm : "",
    ultimoCapituloLidoId:
      typeof obra.ultimoCapituloLidoId === "string"
        ? obra.ultimoCapituloLidoId
        : "",
    ultimaLeituraEm:
      typeof obra.ultimaLeituraEm === "string" ? obra.ultimaLeituraEm : "",
    progressoLeitura: calcularProgressoLeitura(capitulosNormalizados),
    visualizacoes: 0,
    totalCurtidas: 0,
    totalComentarios: 0,
    totalSalvos: 0,
    totalLidos: 0,
    slug:
      typeof obra.slug === "string" && obra.slug.trim()
        ? obra.slug
        : criarSlugBase(
            typeof obra.titulo === "string" && obra.titulo.trim()
              ? obra.titulo
              : `obra-${obraIndex + 1}`
          ),
    link:
      typeof obra.link === "string" && obra.link.trim()
        ? obra.link
        : `/obra/${
            typeof obra.slug === "string" && obra.slug.trim()
              ? obra.slug
              : criarSlugBase(
                  typeof obra.titulo === "string" && obra.titulo.trim()
                    ? obra.titulo
                    : `obra-${obraIndex + 1}`
                )
          }`,
  };
}


function ehDataUrl(valor: string) {
  return valor.startsWith("data:");
}

function prepararObraParaLocalStorage(obra: ObraLocal): ObraLocal {
  return {
    ...obra,
    capa: ehDataUrl(obra.capa) ? "" : obra.capa,
    arquivoObra: obra.arquivoObra
      ? {
          ...obra.arquivoObra,
          conteudo: ehDataUrl(obra.arquivoObra.conteudo)
            ? ""
            : obra.arquivoObra.conteudo,
        }
      : null,
  };
}

function criarStorageUsuarioPublicarKey(userId: string) {
  return criarStorageKeyUsuarioPublicar(STORAGE_KEY, userId);
}

function obterAutorIdObraPublicar(obra: Pick<ObraLocal, "autorId">) {
  return typeof obra.autorId === "string" ? obra.autorId.trim() : "";
}

function obraPertenceAoUsuarioPublicar(
  obra: Pick<ObraLocal, "autorId">,
  userId: string,
) {
  const userIdLimpo = userId.trim();

  return Boolean(userIdLimpo && obterAutorIdObraPublicar(obra) === userIdLimpo);
}

function obterChavesBackupArquivoPublicar(
  obra: Pick<ObraLocal, "id" | "slug" | "titulo" | "link">,
) {
  return Array.from(
    new Set(
      [
        `id:${obra.id}`,
        `slug:${obra.slug || criarSlugBase(obra.titulo)}`,
        `titulo:${normalizarTexto(obra.titulo)}`,
        obra.link ? `link:${obra.link}` : "",
      ].filter((chave) => Boolean(chave.trim())),
    ),
  );
}

function carregarBackupArquivosPublicar(userId = "") {
  if (!userId.trim()) {
    return {} as Record<string, ArquivoObraLocal>;
  }

  try {
    const backupTexto = lerStorageUsuarioPublicar(
      FILE_BACKUP_STORAGE_KEY,
      userId
    );
    const backupJson: unknown = backupTexto ? JSON.parse(backupTexto) : {};

    if (!backupJson || typeof backupJson !== "object" || Array.isArray(backupJson)) {
      return {} as Record<string, ArquivoObraLocal>;
    }

    return Object.entries(backupJson as Record<string, unknown>).reduce<
      Record<string, ArquivoObraLocal>
    >((backup, [chave, arquivo]) => {
      const arquivoNormalizado = normalizarArquivoObra(arquivo);

      if (chave.trim() && arquivoNormalizado) {
        backup[chave] = arquivoNormalizado;
      }

      return backup;
    }, {});
  } catch {
    return {} as Record<string, ArquivoObraLocal>;
  }
}

function sincronizarBackupArquivoPublicar(
  obrasParaSalvar: ObraLocal[],
  userId = ""
) {
  if (!userId.trim()) {
    return;
  }

  try {
    const backupAtual = carregarBackupArquivosPublicar(userId);

    obrasParaSalvar.forEach((obra) => {
      const arquivo = normalizarArquivoObra(obra.arquivoObra);

      if (!arquivo) {
        return;
      }

      obterChavesBackupArquivoPublicar(obra).forEach((chave) => {
        backupAtual[chave] = arquivo;
      });
    });

    salvarJsonStorageUsuarioPublicar(
      FILE_BACKUP_STORAGE_KEY,
      userId,
      backupAtual
    );
  } catch {
    // Backup local é camada de proteção. Não bloqueia a publicação.
  }
}

function salvarObrasLocalmente(obrasParaSalvar: ObraLocal[], userId = "") {
  const userIdLimpo = userId.trim();

  if (!userIdLimpo) {
    return;
  }

  const obrasSemArquivosPesados = obrasParaSalvar.map(prepararObraParaLocalStorage);
  const obrasParaStorage = userIdLimpo
    ? obrasSemArquivosPesados.filter((obra) =>
        obraPertenceAoUsuarioPublicar(obra, userIdLimpo),
      )
    : obrasSemArquivosPesados;

  salvarJsonStorageUsuarioPublicar(
    STORAGE_KEY,
    userIdLimpo,
    obrasParaStorage
  );

  sincronizarBackupArquivoPublicar(obrasParaSalvar, userIdLimpo);
}

async function registrarDiarioPublicacao({
  userId,
  obraId,
  capituloId = null,
  tipo,
  tituloObra,
  tituloCapitulo = "",
  criadaEm,
}: {
  userId: string;
  obraId: string;
  capituloId?: string | null;
  tipo: "publicou_obra" | "publicou_capitulo";
  tituloObra: string;
  tituloCapitulo?: string;
  criadaEm: string;
}) {
  try {
    const payload = {
      user_id: userId,
      tipo,
      obra_id: obraId,
      capitulo_id: capituloId,
      texto: "",
      visibilidade: "publico",
      metadata: {
        obra_titulo: tituloObra,
        titulo_obra: tituloObra,
        capitulo_titulo: tituloCapitulo,
      },
      criado_em: criadaEm,
      atualizado_em: criadaEm,
    };

    const { error } = await supabase.from("diario_atividades").insert(payload);

    if (!error) {
      return;
    }

    await supabase.from("diario_atividades").insert({
      user_id: userId,
      tipo,
      obra_id: obraId,
      capitulo_id: capituloId,
      texto: "",
      visibilidade: "publico",
      criado_em: criadaEm,
    });
  } catch (error) {
    console.warn("Não consegui registrar a publicação no Diário:", error);
  }
}

function contarCaracteresValidos(texto: string) {
  return texto.match(/[\p{L}\p{N}]/gu)?.length || 0;
}

function limparTextoPersonalizado(texto: string, limite: number) {
  return texto
    .replace(/[^\p{L}\p{N}\s-]/gu, "")
    .replace(/\s+/g, " ")
    .trimStart()
    .slice(0, limite);
}

function textoPersonalizadoValido(texto: string, minimo: number, limite: number) {
  const textoLimpo = texto.trim().replace(/\s+/g, " ");

  if (textoLimpo.length > limite) {
    return false;
  }

  if (contarCaracteresValidos(textoLimpo) < minimo) {
    return false;
  }

  return /^[\p{L}\p{N}][\p{L}\p{N}\s-]*$/u.test(textoLimpo);
}


function campoValido(texto: string, minimo: number) {
  return contarCaracteresValidos(texto.trim()) >= minimo;
}

function contarPalavras(texto: string) {
  return texto.trim().split(/\s+/).filter(Boolean).length;
}

function calcularMinutosLeitura(texto: string) {
  const palavras = contarPalavras(texto);

  return palavras > 0 ? Math.max(1, Math.ceil(palavras / 220)) : 0;
}

function nomeArquivoParaTitulo(nomeArquivo: string) {
  return nomeArquivo
    .replace(/\.(txt|md)$/i, "")
    .replace(/[-_]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function arquivoTextoAceito(arquivo: File) {
  const nome = arquivo.name.toLowerCase();

  return nome.endsWith(".txt") || nome.endsWith(".md");
}

function criarPreviewCoverStyle(capa: string): CSSProperties {
  if (!capa) {
    return previewCoverStyle;
  }

  return {
    ...previewCoverStyle,
    background: "var(--historietas-publicar-bg-deep, #04000A)",
    backgroundImage: `url(${capa})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
  };
}

function criarCoverUploadIconBoxStyle(capaAtual: string): CSSProperties {
  if (!capaAtual) {
    return chapterImportIconBoxStyle;
  }

  return {
    ...chapterImportIconBoxStyle,
    background: "var(--historietas-publicar-bg-deep, #04000A)",
    backgroundImage: `url(${capaAtual})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
  };
}

function criarDecoracaoPaginaStyle(_index: number): CSSProperties {
  return {
    display: "none",
  };
}

function criarDecoracaoPublicarStyle(_index: number): CSSProperties {
  return {
    display: "none",
  };
}

export default function PublicarPage() {
  const router = useRouter();

  const [titulo, setTitulo] = useState("");
  const [autor, setAutor] = useState("");
  const [genero, setGenero] = useState("");
  const [generoPersonalizado, setGeneroPersonalizado] = useState("");
  const [formato, setFormato] = useState("");
  const [formatoPersonalizado, setFormatoPersonalizado] = useState("");
  const [classificacaoIndicativa, setClassificacaoIndicativa] = useState("");
  const [sinopse, setSinopse] = useState("");
  const [tags, setTags] = useState("");
  const [tagPersonalizada, setTagPersonalizada] = useState("");
  const [usarTagPersonalizada, setUsarTagPersonalizada] = useState(false);
  const [capa, setCapa] = useState("");
  const [capaNome, setCapaNome] = useState("");
  const [capaArquivo, setCapaArquivo] = useState<File | null>(null);
  const [capaErro, setCapaErro] = useState("");
  const [arquivoObra, setArquivoObra] = useState<ArquivoObraLocal | null>(null);
  const [arquivoObraArquivo, setArquivoObraArquivo] = useState<File | null>(null);
  const [arquivoObraErro, setArquivoObraErro] = useState("");
  const [arquivoCapituloNome, setArquivoCapituloNome] = useState("");
  const [arquivoCapituloTitulo, setArquivoCapituloTitulo] = useState("");
  const [arquivoCapituloTexto, setArquivoCapituloTexto] = useState("");
  const [arquivoCapituloErro, setArquivoCapituloErro] = useState("");
  const [arquivoTextoPendente, setArquivoTextoPendente] = useState<File | null>(null);
  const [processando, setProcessando] = useState(false);
  const [erro, setErro] = useState("");
  const [verificandoAutenticacao, setVerificandoAutenticacao] = useState(true);
  const [usuarioIdLogado, setUsuarioIdLogado] = useState("");
  const [isDesktop, setIsDesktop] = useState(false);
  const { pageThemeStyle } = useHistorietasTheme(pageStyle);
  const { language: idioma } = useHistorietasLanguage();
  const t = (chave: ChaveTextoPublicar) => obterTextoPublicar(idioma, chave);

  useEffect(() => {
    let cancelado = false;

    async function verificarAutenticacaoPublicacao() {
      try {
        const { data, error } = await supabase.auth.getUser();

        if (cancelado) {
          return;
        }

        if (error || !data.user) {
          window.setTimeout(() => {
            if (!cancelado) {
              setUsuarioIdLogado("");
            }
          }, 0);
          router.replace(criarLoginHrefPublicar());
          return;
        }

        window.setTimeout(() => {
          if (!cancelado) {
            setUsuarioIdLogado(data.user.id);
          }
        }, 0);

        const nomeFallback = obterNomeMetadataPublicar({
          email: data.user.email || "",
          user_metadata: data.user.user_metadata || {},
        });
        const nomePerfil = await carregarNomePerfilPublicar(
          data.user.id,
          nomeFallback
        );

        if (cancelado) {
          return;
        }

        window.setTimeout(() => {
          if (!cancelado) {
            if (nomePerfil) {
              setAutor((autorAtual) =>
                autorAtual.trim() ? autorAtual : nomePerfil
              );
            }

            setVerificandoAutenticacao(false);
          }
        }, 0);
      } catch {
        if (!cancelado) {
          router.replace(criarLoginHrefPublicar());
        }
      }
    }

    void verificarAutenticacaoPublicacao();

    return () => {
      cancelado = true;
    };
  }, [router]);

  useEffect(() => {
    const mediaQuery = window.matchMedia("(min-width: 1024px)");

    const atualizarModoDesktop = () => {
      setIsDesktop(mediaQuery.matches);
    };

    const atualizarModoDesktopTimer = window.setTimeout(
      atualizarModoDesktop,
      0
    );

    if (typeof mediaQuery.addEventListener === "function") {
      mediaQuery.addEventListener("change", atualizarModoDesktop);

      return () => {
        window.clearTimeout(atualizarModoDesktopTimer);
        mediaQuery.removeEventListener("change", atualizarModoDesktop);
      };
    }

    mediaQuery.addListener(atualizarModoDesktop);

    return () => {
      window.clearTimeout(atualizarModoDesktopTimer);
      mediaQuery.removeListener(atualizarModoDesktop);
    };
  }, []);

  const jaSalvouRef = useRef(false);
  const capaInputRef = useRef<HTMLInputElement | null>(null);
  const arquivoConteudoInputRef = useRef<HTMLInputElement | null>(null);

  const tagsDaObra = useMemo(() => {
    return tags
      .split(",")
      .map((tag) => tag.trim())
      .filter(Boolean)
      .slice(0, LIMITE_TAGS_OBRA);
  }, [tags]);

  const tagsPreview = tagsDaObra.length > 0 ? tagsDaObra : ["sem tags"];
  const formatoEhPersonalizado = formato === OUTRO_FORMATO_VALUE;
  const generoEhPersonalizado = genero === OUTRO_GENERO_VALUE;
  const formatoFinal = formatoEhPersonalizado
    ? formatoPersonalizado.trim().replace(/\s+/g, " ")
    : formato.trim();
  const generoFinal = generoEhPersonalizado
    ? generoPersonalizado.trim().replace(/\s+/g, " ")
    : genero.trim();
  const tagPersonalizadaFinal = tagPersonalizada.trim().replace(/\s+/g, " ");
  const formatoPersonalizadoValido =
    !formatoEhPersonalizado ||
    textoPersonalizadoValido(
      formatoPersonalizado,
      3,
      LIMITE_CARACTERES_FORMATO_GENERO_PERSONALIZADO
    );
  const generoPersonalizadoValido =
    !generoEhPersonalizado ||
    textoPersonalizadoValido(
      generoPersonalizado,
      3,
      LIMITE_CARACTERES_FORMATO_GENERO_PERSONALIZADO
    );
  const tagPersonalizadaValida =
    !usarTagPersonalizada ||
    (textoPersonalizadoValido(
      tagPersonalizada,
      2,
      LIMITE_CARACTERES_TAG_PERSONALIZADA
    ) &&
      normalizarTexto(tagPersonalizadaFinal) !== normalizarTexto(formatoFinal) &&
      normalizarTexto(tagPersonalizadaFinal) !== normalizarTexto(generoFinal));

  const tituloValido = campoValido(titulo, 3);
  const autorValido = campoValido(autor, 2);
  const generoValido = Boolean(generoFinal) && generoPersonalizadoValido;
  const formatoValido = Boolean(formatoFinal) && formatoPersonalizadoValido;
  const classificacaoFinal = normalizarClassificacaoIndicativaPublicar(
    classificacaoIndicativa,
  );
  const classificacaoValida = Boolean(classificacaoFinal);
  const sinopseValida = campoValido(sinopse, 20);

  const sinopseCaracteresValidos = contarCaracteresValidos(sinopse);
  const sinopsePalavras = contarPalavras(sinopse);
  const temArquivoObra = Boolean(arquivoObra);
  const arquivoObraTamanhoTexto = arquivoObra
    ? formatarTamanhoArquivo(arquivoObra.tamanho)
    : "";
  const arquivoObraTipoTexto = arquivoObra
    ? arquivoObra.categoria === "imagem"
      ? t("imagem")
      : arquivoObra.categoria === "documento"
      ? "PDF"
      : arquivoObra.categoria === "texto"
      ? t("texto")
      : t("arquivo")
    : "";
  const arquivoTextoPendenteTamanhoTexto = arquivoTextoPendente
    ? formatarTamanhoArquivo(arquivoTextoPendente.size)
    : "";
  const temCapituloImportado = Boolean(arquivoCapituloTexto.trim());
  const temConteudoPorArquivo = Boolean(arquivoObra || temCapituloImportado);
  const arquivoCapituloPalavras = contarPalavras(arquivoCapituloTexto);
  const arquivoCapituloMinutos = calcularMinutosLeitura(arquivoCapituloTexto);
  const arquivoCapituloCaracteresValidos = contarCaracteresValidos(
    arquivoCapituloTexto
  );
  const arquivoCapituloValido =
    !temCapituloImportado || arquivoCapituloCaracteresValidos >= 20;

  const progresso = useMemo(() => {
    const camposValidos = [
      tituloValido,
      autorValido,
      generoValido,
      formatoValido,
      classificacaoValida,
      sinopseValida,
    ].filter(Boolean).length;

    return Math.round((camposValidos / 6) * 100);
  }, [
    tituloValido,
    autorValido,
    generoValido,
    formatoValido,
    classificacaoValida,
    sinopseValida,
  ]);

  const previewTemConteudo = Boolean(
    titulo.trim() ||
      autor.trim() ||
      generoFinal ||
      formatoFinal ||
      classificacaoIndicativa.trim() ||
      sinopse.trim() ||
      tags.trim() ||
      capa ||
      temArquivoObra ||
      temCapituloImportado
  );

  function validarFormulario() {
    if (!tituloValido) {
      return "O título precisa ter pelo menos 3 letras ou números. Não pode ser só ponto.";
    }

    if (!autorValido) {
      return "O nome do autor precisa ter pelo menos 2 letras ou números.";
    }

    if (!formatoValido) {
      return formatoEhPersonalizado
        ? "O formato personalizado precisa ter 3 a 14 caracteres, sem vírgula, emoji ou símbolo estranho."
        : "Escolha o formato da obra.";
    }

    if (!generoValido) {
      return generoEhPersonalizado
        ? "O gênero personalizado precisa ter 3 a 14 caracteres, sem vírgula, emoji ou símbolo estranho."
        : "Escolha o gênero principal da obra.";
    }

    if (!tagPersonalizadaValida) {
      return "A tag personalizada precisa ter 2 a 10 caracteres, sem vírgula, emoji ou símbolo estranho, e não pode repetir gênero ou formato.";
    }

    if (!classificacaoValida) {
      return "Escolha a classificação indicativa da obra.";
    }

    if (!sinopseValida) {
      return "A sinopse precisa ter pelo menos 20 letras ou números.";
    }

    if (temCapituloImportado && !arquivoCapituloValido) {
      return "O arquivo importado precisa ter pelo menos 20 letras ou números para virar o primeiro capítulo.";
    }

    return "";
  }

  function selecionarCapa(event: ChangeEvent<HTMLInputElement>) {
    const arquivo = event.target.files?.[0];

    setCapaErro("");
    setErro("");

    if (!arquivo) {
      return;
    }

    if (!arquivoImagemAceito(arquivo)) {
      setCapaErro("Escolha um arquivo de imagem válido.");
      event.target.value = "";
      return;
    }

    if (arquivo.size > TAMANHO_MAXIMO_CAPA) {
      setCapaErro("A capa precisa ter no máximo 2 MB.");
      event.target.value = "";
      return;
    }

    const leitor = new FileReader();

    leitor.onload = () => {
      const resultado = typeof leitor.result === "string" ? leitor.result : "";

      if (!resultado) {
        setCapaErro("Não consegui carregar essa imagem.");
        return;
      }

      setCapa(resultado);
      setCapaNome(arquivo.name);
      setCapaArquivo(arquivo);
    };

    leitor.onerror = () => {
      setCapaErro("Não consegui carregar essa imagem.");
    };

    leitor.readAsDataURL(arquivo);
  }

  function removerCapa() {
    setCapa("");
    setCapaNome("");
    setCapaArquivo(null);
    setCapaErro("");

    if (capaInputRef.current) {
      capaInputRef.current.value = "";
    }
  }

  function limparArquivoAnexado() {
    setArquivoObra(null);
    setArquivoObraArquivo(null);
    setArquivoObraErro("");
  }

  function limparCapituloImportado() {
    setArquivoCapituloNome("");
    setArquivoCapituloTitulo("");
    setArquivoCapituloTexto("");
    setArquivoCapituloErro("");
  }

  function limparSelecaoConteudoArquivo() {
    limparArquivoAnexado();
    limparCapituloImportado();
    setArquivoTextoPendente(null);

    if (arquivoConteudoInputRef.current) {
      arquivoConteudoInputRef.current.value = "";
    }
  }

  function anexarArquivoCompleto(arquivo: File) {
    setArquivoObraErro("");
    setArquivoCapituloErro("");
    setErro("");

    const leitor = new FileReader();

    leitor.onload = () => {
      const resultado = typeof leitor.result === "string" ? leitor.result : "";

      if (!resultado) {
        setArquivoObraErro("Não consegui carregar esse arquivo.");
        return;
      }

      limparCapituloImportado();
      setArquivoObra({
        nome: arquivo.name,
        tipo: arquivo.type || "application/octet-stream",
        tamanho: arquivo.size,
        conteudo: resultado,
        categoria: identificarCategoriaArquivo(arquivo),
        criadoEm: new Date().toISOString(),
      });
      setArquivoObraArquivo(arquivo);
      setArquivoTextoPendente(null);

      if (arquivoConteudoInputRef.current) {
        arquivoConteudoInputRef.current.value = "";
      }
    };

    leitor.onerror = () => {
      setArquivoObraErro("Não consegui carregar esse arquivo.");
    };

    leitor.readAsDataURL(arquivo);
  }

  function transformarArquivoTextoEmCapitulo(arquivo: File) {
    setArquivoObraErro("");
    setArquivoCapituloErro("");
    setErro("");

    if (arquivo.size > TAMANHO_MAXIMO_ARQUIVO_TEXTO) {
      setArquivoCapituloErro(
        "Para virar capítulo, o arquivo de texto precisa ter no máximo 900 KB. Você ainda pode anexá-lo como arquivo completo."
      );
      return;
    }

    const leitor = new FileReader();

    leitor.onload = () => {
      const resultado = typeof leitor.result === "string" ? leitor.result : "";
      const textoImportado = resultado.replace(/\r\n/g, "\n").trim();

      if (contarCaracteresValidos(textoImportado) < 20) {
        setArquivoCapituloErro(
          "Esse arquivo tem pouco texto para virar um capítulo."
        );
        return;
      }

      limparArquivoAnexado();
      setArquivoCapituloNome(arquivo.name);
      setArquivoCapituloTitulo(nomeArquivoParaTitulo(arquivo.name));
      setArquivoCapituloTexto(textoImportado);
      setArquivoTextoPendente(null);

      if (arquivoConteudoInputRef.current) {
        arquivoConteudoInputRef.current.value = "";
      }
    };

    leitor.onerror = () => {
      setArquivoCapituloErro("Não consegui ler esse arquivo.");
    };

    leitor.readAsText(arquivo, "UTF-8");
  }

  function cancelarEscolhaArquivoTexto() {
    setArquivoTextoPendente(null);
    setArquivoObraErro("");
    setArquivoCapituloErro("");

    if (arquivoConteudoInputRef.current) {
      arquivoConteudoInputRef.current.value = "";
    }
  }

  function selecionarConteudoArquivo(event: ChangeEvent<HTMLInputElement>) {
    const arquivo = event.target.files?.[0];

    setArquivoObraErro("");
    setArquivoCapituloErro("");
    setErro("");

    if (!arquivo) {
      return;
    }

    if (!arquivoObraAceito(arquivo)) {
      setArquivoObraErro(
        "Escolha PDF, TXT, MD ou imagem em PNG, JPG, WEBP ou GIF."
      );
      event.target.value = "";
      return;
    }

    if (arquivo.size > TAMANHO_MAXIMO_ARQUIVO_OBRA) {
      setArquivoObraErro("O arquivo precisa ter no máximo 5 MB.");
      event.target.value = "";
      return;
    }

    if (arquivoTextoAceito(arquivo)) {
      setArquivoTextoPendente(arquivo);
      return;
    }

    anexarArquivoCompleto(arquivo);
  }

  function tagEstaSelecionada(tag: string) {
    return tagsDaObra.some((tagAtual) => {
      return normalizarTexto(tagAtual) === normalizarTexto(tag);
    });
  }

  function atualizarTagPersonalizada(valor: string) {
    const textoLimpo = limparTextoPersonalizado(
      valor,
      LIMITE_CARACTERES_TAG_PERSONALIZADA
    );

    setTagPersonalizada(textoLimpo);
    setTags(
      textoPersonalizadoValido(
        textoLimpo,
        2,
        LIMITE_CARACTERES_TAG_PERSONALIZADA
      )
        ? textoLimpo.trim().replace(/\s+/g, " ")
        : ""
    );
    setErro("");
  }

  function adicionarTagSelecionada(tag: string) {
    if (!tag) {
      return;
    }

    if (tag === OUTRA_TAG_VALUE) {
      setUsarTagPersonalizada(true);
      setTags(
        textoPersonalizadoValido(
          tagPersonalizada,
          2,
          LIMITE_CARACTERES_TAG_PERSONALIZADA
        )
          ? tagPersonalizada.trim().replace(/\s+/g, " ")
          : ""
      );
      setErro("");
      return;
    }

    if (tagEstaSelecionada(tag)) {
      return;
    }

    setUsarTagPersonalizada(false);
    setTagPersonalizada("");
    setTags(tag);
    setErro("");
  }

  async function salvarObra(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const mensagemErro = validarFormulario();

    if (mensagemErro) {
      setErro(mensagemErro);

      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });

      return;
    }

    if (jaSalvouRef.current) {
      return;
    }

    setErro("");
    jaSalvouRef.current = true;
    setProcessando(true);

    const arquivosEnviados: ArquivoStoragePublicar[] = [];
    let obraCriadaId = "";
    let publicacaoConcluida = false;

    try {
      const { data: dadosUsuario, error: erroUsuario } =
        await supabase.auth.getUser();

      if (erroUsuario || !dadosUsuario.user) {
        throw new Error("Entre na sua conta antes de publicar uma obra.");
      }

      const userId = dadosUsuario.user.id;
      const autorFallbackPublicacao =
        autor.trim() ||
        obterNomeMetadataPublicar({
          email: dadosUsuario.user.email || "",
          user_metadata: dadosUsuario.user.user_metadata || {},
        });
      const autorFinalPublicacao = await carregarNomePerfilPublicar(
        userId,
        autorFallbackPublicacao
      );

      if (!campoValido(autorFinalPublicacao, 2)) {
        throw new Error(
          "Não consegui encontrar um nome de autor válido no seu perfil. Atualize seu perfil ou preencha o nome do autor."
        );
      }

      setAutor(autorFinalPublicacao);

      const obrasSalvasTexto = lerStorageUsuarioPublicar(STORAGE_KEY, userId);
      let obrasSalvasJson: unknown = [];

      if (obrasSalvasTexto) {
        try {
          obrasSalvasJson = JSON.parse(obrasSalvasTexto);
        } catch {
          obrasSalvasJson = [];
        }
      }

      const obrasSalvas: ObraLocal[] = Array.isArray(obrasSalvasJson)
        ? (obrasSalvasJson as ObraSalva[]).map((obra, index) =>
            normalizarObraSalva(obra, index)
          )
        : [];

      const obraId = criarUuidSeguro();
      const slug = await criarSlugUnicoSupabase(titulo.trim(), obrasSalvas);
      const criadaEm = new Date().toISOString();
      const capituloId = temCapituloImportado ? criarUuidSeguro() : "";
      const capitulosIniciais: CapituloLocal[] = temCapituloImportado
        ? [
            {
              id: capituloId,
              titulo: arquivoCapituloTitulo.trim() || "Capítulo 1",
              texto: arquivoCapituloTexto.trim(),
              curtiu: false,
              salvo: false,
              comentario: "",
              criadoEm: criadaEm,
              lido: false,
              lidoEm: "",
            },
          ]
        : [];

      const capaEnviada = capaArquivo
        ? await enviarArquivoStorage("capas-obras", userId, capaArquivo)
        : null;

      if (capaEnviada) {
        arquivosEnviados.push(capaEnviada);
      }

      const arquivoObraEnviado =
        arquivoObra && arquivoObraArquivo
          ? await enviarArquivoStorage(
              "arquivos-obras",
              userId,
              arquivoObraArquivo
            )
          : null;

      if (arquivoObraEnviado) {
        arquivosEnviados.push(arquivoObraEnviado);
      }

      const capaUrlSupabase = capaEnviada?.publicUrl || "";
      const arquivoObraReferenciaSupabase =
        arquivoObraEnviado?.caminho || "";
      const link = `/obra/${slug}`;

      const { error: erroObra } = await supabase.from("obras").insert({
        id: obraId,
        user_id: userId,
        titulo: titulo.trim(),
        autor: autorFinalPublicacao,
        genero: generoFinal,
        formato: formatoFinal,
        classificacao_indicativa: classificacaoFinal,
        sinopse: sinopse.trim(),
        tags: tagsDaObra.length > 0 ? tagsDaObra : ["sem tags"],
        capa_url: capaUrlSupabase,
        capa_nome: capaNome,
        arquivo_url: arquivoObraReferenciaSupabase,
        arquivo_nome: arquivoObra?.nome || "",
        arquivo_tipo: arquivoObra?.tipo || "",
        arquivo_tamanho: arquivoObra?.tamanho || 0,
        arquivo_categoria: arquivoObra?.categoria || "outro",
        publicado: false,
        visualizacoes: 0,
        slug,
        link,
        criada_em: criadaEm,
        atualizado_em: criadaEm,
      });

      if (erroObra) {
        throw new Error(`Não consegui salvar a obra agora: ${erroObra.message}`);
      }

      obraCriadaId = obraId;

      if (capitulosIniciais.length > 0) {
        const { error: erroCapitulo } = await supabase.from("capitulos").insert(
          capitulosIniciais.map((capitulo, index) => ({
            id: capitulo.id,
            obra_id: obraId,
            user_id: userId,
            titulo: capitulo.titulo,
            texto: capitulo.texto,
            ordem: index + 1,
            publicado: true,
            criado_em: criadaEm,
            atualizado_em: criadaEm,
          }))
        );

        if (erroCapitulo) {
          throw new Error(
            `Não consegui salvar o capítulo inicial: ${erroCapitulo.message}`
          );
        }
      }

      const { data: obraPublicada, error: erroPublicarObra } = await supabase
        .from("obras")
        .update({
          publicado: true,
          atualizado_em: criadaEm,
        })
        .eq("id", obraId)
        .eq("user_id", userId)
        .select("id, publicado")
        .maybeSingle();

      if (
        erroPublicarObra ||
        !obraPublicada?.id ||
        obraPublicada.publicado !== true
      ) {
        const detalheErro =
          erroPublicarObra?.message ||
          "a atualização não confirmou a publicação da obra.";

        throw new Error(
          `A obra foi preparada, mas não pôde ser publicada: ${detalheErro}`
        );
      }

      const novaObra: ObraLocal = {
        id: obraId,
        titulo: titulo.trim(),
        autor: autorFinalPublicacao,
        autorId: userId,
        genero: generoFinal,
        formato: formatoFinal,
        classificacaoIndicativa: classificacaoFinal,
        sinopse: sinopse.trim(),
        tags: tagsDaObra.length > 0 ? tagsDaObra : ["sem tags"],
        capa: capaUrlSupabase,
        capaNome,
        arquivoObra: arquivoObra
          ? {
              ...arquivoObra,
              conteudo: arquivoObraReferenciaSupabase,
              criadoEm: criadaEm,
            }
          : null,
        publicado: true,
        capitulos: capitulosIniciais,
        criadaEm,
        ultimoCapituloLidoId: "",
        ultimaLeituraEm: "",
        progressoLeitura: calcularProgressoLeitura(capitulosIniciais),
        visualizacoes: 0,
        totalCurtidas: 0,
        totalComentarios: 0,
        totalSalvos: 0,
        totalLidos: 0,
        slug,
        link,
      };

      await registrarDiarioPublicacao({
        userId,
        obraId,
        tipo: "publicou_obra",
        tituloObra: novaObra.titulo,
        criadaEm,
      });

      if (capituloId) {
        await registrarDiarioPublicacao({
          userId,
          obraId,
          capituloId,
          tipo: "publicou_capitulo",
          tituloObra: novaObra.titulo,
          tituloCapitulo: capitulosIniciais[0]?.titulo || "Capítulo 1",
          criadaEm,
        });
      }

      const obrasSalvasDoUsuario = obrasSalvas.filter((obra) =>
        obraPertenceAoUsuarioPublicar(obra, userId),
      );
      const novasObrasDoUsuario = [
        novaObra,
        ...obrasSalvasDoUsuario.filter((obra) => obra.id !== novaObra.id),
      ];

      salvarObrasLocalmente(novasObrasDoUsuario, userId);

      publicacaoConcluida = true;
      router.replace("/painel-autor");
      router.refresh();
    } catch (erroDesconhecido) {
      const publicacaoDesfeita = publicacaoConcluida
        ? false
        : await desfazerPublicacaoParcialPublicar(
            obraCriadaId,
            arquivosEnviados
          );

      jaSalvouRef.current = publicacaoConcluida || !publicacaoDesfeita;
      setProcessando(false);

      const mensagemBase =
        erroDesconhecido instanceof Error &&
        erroDesconhecido.name === "QuotaExceededError"
          ? "O navegador recusou salvar dados locais porque o armazenamento está cheio."
          : erroDesconhecido instanceof Error
          ? erroDesconhecido.message
          : "Não consegui salvar a obra agora. Tente novamente.";
      const mensagem = publicacaoConcluida
        ? "A obra foi publicada, mas não consegui abrir o Painel do Autor. Acesse o painel antes de tentar publicar novamente."
        : publicacaoDesfeita
        ? mensagemBase
        : `${mensagemBase} A publicação parcial não pôde ser removida automaticamente. Confira o Painel do Autor antes de tentar novamente.`;

      setErro(mensagem);

      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
    }
  }

  if (verificandoAutenticacao) {
    return (
      <main style={pageThemeStyle}>
        <style>{`${historietasThemeCss}${publicarPageCss}`}</style>

        {isDesktop && <div style={desktopTopWaterFadeStyle} aria-hidden="true" />}
        {!isDesktop && <div style={mobileTopWaterFadeStyle} aria-hidden="true" />}
      </main>
    );
  }

  return (
    <main style={pageThemeStyle}>
      <style>{`${historietasThemeCss}${publicarPageCss}`}</style>

      <div style={pageDecorationLayerStyle} aria-hidden="true">
        {["✦", "◇", "+"].map((decoracao, index) => (
          <span key={`${decoracao}-${index}`} style={criarDecoracaoPaginaStyle(index)}>
            {decoracao}
          </span>
        ))}
      </div>

      {isDesktop && <div style={desktopTopWaterFadeStyle} aria-hidden="true" />}
      {!isDesktop && <div style={mobileTopWaterFadeStyle} aria-hidden="true" />}

      <section style={isDesktop ? desktopContainerStyle : containerStyle}>
        <header style={isDesktop ? desktopTitleHeaderStyle : titleHeaderStyle}>
          <Link
            href="/"
            style={isDesktop ? desktopHeaderTitleLinkStyle : headerTitleLinkStyle}
            aria-label={t("voltarHome")}
          >
            <span
              className="historietas-theme-title"
              style={isDesktop ? desktopHeaderTitleTextStyle : headerTitleTextStyle}
            >
              {t("novaObra")}
            </span>
          </Link>

        </header>

        <section style={isDesktop ? desktopMainGridSingleStyle : mainGridStyle}>
          <form onSubmit={salvarObra} style={isDesktop ? desktopFormPanelStyle : formPanelStyle}>
            {erro && (
              <div style={isDesktop ? desktopFullWidthErrorBoxStyle : errorBoxStyle}>
                <strong style={safeTextStyle}>{t("ajusteNecessario")}</strong>
                <span style={safeTextStyle}>{traduzirMensagemPublicar(idioma, erro)}</span>
              </div>
            )}


            <div style={isDesktop ? desktopFullWidthFieldStyle : fieldGroupStyle}>
              <input
                ref={capaInputRef}
                type="file"
                accept=".png,.jpg,.jpeg,.webp,.gif,image/png,image/jpeg,image/webp,image/gif"
                onChange={selecionarCapa}
                style={hiddenInputStyle}
              />

              <div style={isDesktop ? desktopChapterImportBoxStyle : chapterImportBoxStyle}>
                <div
                  style={
                    isDesktop
                      ? {
                          ...criarCoverUploadIconBoxStyle(capa),
                          ...desktopCoverUploadIconBoxStyle,
                        }
                      : criarCoverUploadIconBoxStyle(capa)
                  }
                >
                  {!capa && <span style={chapterImportIconStyle}>+</span>}
                </div>

                <div style={isDesktop ? desktopChapterImportContentStyle : chapterImportContentStyle}>
                  <strong style={chapterImportTitleStyle}>
                    {capa ? t("capaSelecionada") : t("adicionarCapa")}
                  </strong>

                  <span style={hintStyle}>
                    {t("dicaCapa")}
                  </span>

                  {capaNome && <span style={fileNameStyle}>{capaNome}</span>}

                  {capaErro && (
                    <span style={coverErrorStyle}>
                      {traduzirMensagemPublicar(idioma, capaErro)}
                    </span>
                  )}

                  <div style={isDesktop ? desktopCoverButtonsStyle : coverButtonsStyle}>
                    <button
                      type="button"
                      onClick={() => capaInputRef.current?.click()}
                      style={isDesktop ? desktopCoverButtonStyle : coverButtonStyle}
                    >
                      {t("escolherImagem")}
                    </button>

                    {capa && (
                      <button
                        type="button"
                        onClick={removerCapa}
                        style={isDesktop ? desktopRemoveCoverButtonStyle : removeCoverButtonStyle}
                      >
                        {t("remover")}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>


            <div style={isDesktop ? desktopHalfFieldStyle : fieldGroupStyle}>
              <label style={labelStyle}>{t("tituloObra")}</label>

              <input
                value={titulo}
                onChange={(event) => {
                  setTitulo(event.target.value);
                  setErro("");
                }}
                style={inputStyle}
                placeholder="Ex: Shadow Eclipse"
                type="text"
              />

              <span style={hintStyle}>{t("dicaTitulo")}</span>
            </div>

            <div style={isDesktop ? desktopHalfFieldStyle : fieldGroupStyle}>
              <label style={labelStyle}>{t("nomeAutor")}</label>

              <input
                value={autor}
                onChange={(event) => {
                  setAutor(event.target.value);
                  setErro("");
                }}
                style={inputStyle}
                placeholder="Ex: Historietas Studio"
                type="text"
              />

              <span style={hintStyle}>{t("dicaAutor")}</span>
            </div>

            <div style={isDesktop ? desktopFullWidthDoubleFieldStyle : doubleFieldStyle}>
              <div style={fieldGroupStyle}>
                <label style={labelStyle}>{t("formato")}</label>

                <select
                  value={formato}
                  onChange={(event) => {
                    const novoFormato = event.target.value;

                    setFormato(novoFormato);

                    if (novoFormato !== OUTRO_FORMATO_VALUE) {
                      setFormatoPersonalizado("");
                    }

                    setErro("");
                  }}
                  style={inputStyle}
                >
                  <option value="">{t("escolherFormato")}</option>
                  {OPCOES_FORMATO_OBRA.map((opcao) => (
                    <option key={opcao} value={opcao}>
                      {traduzirFormatoPublicar(idioma, opcao)}
                    </option>
                  ))}
                  <option value={OUTRO_FORMATO_VALUE}>{t("outroFormato")}</option>
                </select>

                {formatoEhPersonalizado && (
                  <input
                    value={formatoPersonalizado}
                    onChange={(event) => {
                      setFormatoPersonalizado(
                        limparTextoPersonalizado(
                          event.target.value,
                          LIMITE_CARACTERES_FORMATO_GENERO_PERSONALIZADO
                        )
                      );
                      setErro("");
                    }}
                    style={inputStyle}
                    placeholder={t("digiteFormato")}
                    maxLength={LIMITE_CARACTERES_FORMATO_GENERO_PERSONALIZADO}
                    type="text"
                  />
                )}
              </div>

              <div style={fieldGroupStyle}>
                <label style={labelStyle}>{t("generoPrincipal")}</label>

                <select
                  value={genero}
                  onChange={(event) => {
                    const novoGenero = event.target.value;

                    setGenero(novoGenero);

                    if (novoGenero !== OUTRO_GENERO_VALUE) {
                      setGeneroPersonalizado("");
                    }

                    setErro("");
                  }}
                  style={inputStyle}
                >
                  <option value="">{t("escolherGenero")}</option>
                  {OPCOES_GENERO_OBRA.map((opcao) => (
                    <option key={opcao} value={opcao}>
                      {traduzirGeneroPublicar(idioma, opcao)}
                    </option>
                  ))}
                  <option value={OUTRO_GENERO_VALUE}>{t("outroGenero")}</option>
                </select>

                {generoEhPersonalizado && (
                  <input
                    value={generoPersonalizado}
                    onChange={(event) => {
                      setGeneroPersonalizado(
                        limparTextoPersonalizado(
                          event.target.value,
                          LIMITE_CARACTERES_FORMATO_GENERO_PERSONALIZADO
                        )
                      );
                      setErro("");
                    }}
                    style={inputStyle}
                    placeholder={t("digiteGenero")}
                    maxLength={LIMITE_CARACTERES_FORMATO_GENERO_PERSONALIZADO}
                    type="text"
                  />
                )}
              </div>
            </div>

            <div style={isDesktop ? desktopHalfFieldStyle : fieldGroupStyle}>
              <label style={labelStyle}>{t("tag")}</label>

              <select
                value={usarTagPersonalizada ? OUTRA_TAG_VALUE : tagsDaObra[0] || ""}
                onChange={(event) => {
                  const novaTag = event.target.value;

                  if (!novaTag) {
                    setUsarTagPersonalizada(false);
                    setTagPersonalizada("");
                    setTags("");
                    setErro("");
                    return;
                  }

                  adicionarTagSelecionada(novaTag);
                }}
                style={inputStyle}
              >
                <option value="">{t("escolherTag")}</option>

                {OPCOES_TAGS_OBRA.map((tag) => (
                  <option key={tag} value={tag}>
                    {traduzirTagPublicar(idioma, tag)}
                  </option>
                ))}

                <option value={OUTRA_TAG_VALUE}>{t("outraTag")}</option>
              </select>

              {usarTagPersonalizada && (
                <input
                  value={tagPersonalizada}
                  onChange={(event) => atualizarTagPersonalizada(event.target.value)}
                  style={inputStyle}
                  placeholder={t("digiteTag")}
                  maxLength={LIMITE_CARACTERES_TAG_PERSONALIZADA}
                  type="text"
                />
              )}
            </div>

            <div style={isDesktop ? desktopHalfFieldStyle : fieldGroupStyle}>
              <label style={labelStyle}>{t("classificacaoIndicativa")}</label>

              <select
                value={classificacaoIndicativa}
                onChange={(event) => {
                  setClassificacaoIndicativa(event.target.value);
                  setErro("");
                }}
                style={inputStyle}
              >
                <option value="">{t("escolherClassificacao")}</option>
                <option value="Livre">{t("livre")}</option>
                <option>10+</option>
                <option>12+</option>
                <option>14+</option>
                <option>16+</option>
                <option>18+</option>
              </select>
            </div>

            <div style={isDesktop ? desktopFullWidthFieldStyle : fieldGroupStyle}>
              <div style={labelRowStyle}>
                <label style={labelStyle}>{t("sinopse")}</label>

                <span
                  style={
                    sinopseValida ? miniCounterOkStyle : miniCounterWarningStyle
                  }
                >
                  {sinopseCaracteresValidos}/20
                </span>
              </div>

              <textarea
                value={sinopse}
                onChange={(event) => {
                  setSinopse(event.target.value);
                  setErro("");
                }}
                style={textareaStyle}
                placeholder={`${t("resumoChamativo")}\n${t("minimoSinopse")} ${sinopsePalavras} ${t("palavras")}.`}
              />
            </div>


            <div style={isDesktop ? desktopFullWidthFieldStyle : fieldGroupStyle}>
              <div style={fileUploadLabelRowStyle}>
                <label style={labelStyle}>{t("adicionarConteudoArquivo")}</label>
                <span style={fileOptionalBadgeStyle}>{t("opcional")}</span>
              </div>

              <input
                ref={arquivoConteudoInputRef}
                type="file"
                accept=".pdf,.txt,.md,.png,.jpg,.jpeg,.webp,.gif,application/pdf,text/plain,text/markdown,image/png,image/jpeg,image/webp,image/gif"
                onChange={selecionarConteudoArquivo}
                style={hiddenInputStyle}
              />

              <div
                style={
                  isDesktop
                    ? desktopFullWidthArquivoObraBoxStyle
                    : chapterImportBoxStyle
                }
              >
                <div
                  style={
                    isDesktop
                      ? { ...chapterImportIconBoxStyle, ...desktopFileUploadIconBoxStyle }
                      : chapterImportIconBoxStyle
                  }
                >
                  <span style={chapterImportIconStyle}>
                    {temCapituloImportado ? "⇧" : "▣"}
                  </span>
                </div>

                <div
                  style={
                    isDesktop
                      ? desktopFullWidthArquivoObraContentStyle
                      : chapterImportContentStyle
                  }
                >
                  <strong style={chapterImportTitleStyle}>
                    {arquivoTextoPendente
                      ? t("comoUsarArquivo")
                      : arquivoObra
                        ? t("arquivoCompletoAnexado")
                        : temCapituloImportado
                          ? t("primeiroCapituloImportado")
                          : t("enviarArquivo")}
                  </strong>

                  <span style={hintStyle}>
                    {arquivoTextoPendente
                      ? t("dicaArquivoPendente")
                      : t("dicaArquivo")}
                  </span>

                  {arquivoTextoPendente && (
                    <span style={fileNameStyle}>
                      {arquivoTextoPendente.name} • {t("texto")} •{" "}
                      {arquivoTextoPendenteTamanhoTexto}
                    </span>
                  )}

                  {arquivoObra && !arquivoTextoPendente && (
                    <span style={fileNameStyle}>
                      {arquivoObra.nome} • {arquivoObraTipoTexto} •{" "}
                      {arquivoObraTamanhoTexto}
                    </span>
                  )}

                  {temCapituloImportado && !arquivoTextoPendente && (
                    <span style={fileNameStyle}>
                      {arquivoCapituloNome} • {t("primeiroCapitulo")}
                    </span>
                  )}

                  {arquivoObraErro && (
                    <span style={coverErrorStyle}>
                      {traduzirMensagemPublicar(idioma, arquivoObraErro)}
                    </span>
                  )}

                  {arquivoCapituloErro && (
                    <span style={coverErrorStyle}>
                      {traduzirMensagemPublicar(idioma, arquivoCapituloErro)}
                    </span>
                  )}

                  {arquivoTextoPendente ? (
                    <div
                      style={
                        isDesktop ? desktopCoverButtonsStyle : coverButtonsStyle
                      }
                    >
                      <button
                        type="button"
                        onClick={() =>
                          transformarArquivoTextoEmCapitulo(arquivoTextoPendente)
                        }
                        style={
                          isDesktop
                            ? desktopCoverButtonStyle
                            : coverButtonStyle
                        }
                      >
                        {t("transformarCapitulo")}
                      </button>

                      <button
                        type="button"
                        onClick={() =>
                          anexarArquivoCompleto(arquivoTextoPendente)
                        }
                        style={
                          isDesktop
                            ? desktopCoverButtonStyle
                            : coverButtonStyle
                        }
                      >
                        {t("anexarArquivoCompleto")}
                      </button>

                      <button
                        type="button"
                        onClick={cancelarEscolhaArquivoTexto}
                        style={
                          isDesktop
                            ? desktopRemoveCoverButtonStyle
                            : removeCoverButtonStyle
                        }
                      >
                        {t("cancelar")}
                      </button>
                    </div>
                  ) : (
                    <div
                      style={
                        isDesktop ? desktopCoverButtonsStyle : coverButtonsStyle
                      }
                    >
                      <button
                        type="button"
                        onClick={() => arquivoConteudoInputRef.current?.click()}
                        style={
                          isDesktop
                            ? desktopCoverButtonStyle
                            : coverButtonStyle
                        }
                      >
                        {temConteudoPorArquivo
                          ? t("trocarArquivo")
                          : t("escolherArquivo")}
                      </button>

                      {temConteudoPorArquivo && (
                        <button
                          type="button"
                          onClick={limparSelecaoConteudoArquivo}
                          style={
                            isDesktop
                              ? desktopRemoveCoverButtonStyle
                              : removeCoverButtonStyle
                          }
                        >
                          {t("remover")}
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {arquivoObra && !arquivoTextoPendente && (
                <div style={chapterImportStatsStyle}>
                  <span style={inlineStatStyle}>{arquivoObraTipoTexto}</span>
                  <span style={inlineStatStyle}>{arquivoObraTamanhoTexto}</span>
                  <span style={inlineStatStyle}>{t("anexadoObra")}</span>
                </div>
              )}

              {temCapituloImportado && !arquivoTextoPendente && (
                <div style={chapterImportStatsStyle}>
                  <span style={inlineStatStyle}>
                    {t("titulo")}: {arquivoCapituloTitulo || `${t("primeiroCapitulo")} 1`}
                  </span>
                  <span style={inlineStatStyle}>
                    {arquivoCapituloPalavras} {t("palavras")}
                  </span>
                  <span style={inlineStatStyle}>
                    {arquivoCapituloMinutos} min
                  </span>
                </div>
              )}
            </div>

            <div style={isDesktop ? desktopButtonAreaStyle : buttonAreaStyle}>
              <Link href="/" style={secondaryButtonStyle}>
                {t("cancelar")}
              </Link>

              <button
                type="submit"
                style={processando ? disabledButtonStyle : primaryButtonStyle}
                disabled={processando}
              >
                {processando ? t("salvando") : t("criarObra")}
              </button>
            </div>

            <div
              style={
                isDesktop
                  ? { ...desktopProgressBoxStyle, width: "100%" }
                  : { ...progressBoxStyle, width: "100%" }
              }
            >
              <div style={progressTopStyle}>
                <span style={progressLabelStyle}>{t("progresso")}</span>
                <strong style={progressNumberStyle}>{progresso}%</strong>
              </div>

              <div style={progressTrackStyle}>
                <div style={{ ...progressFillStyle, width: `${progresso}%` }} />
              </div>
            </div>
          </form>

          <aside style={isDesktop ? desktopPreviewPanelStyle : previewPanelStyle}>
            <div style={previewHeaderStyle}>
              <span style={previewMiniTitleStyle}>{t("previaObra")}</span>
            </div>

            {previewTemConteudo ? (
              <article style={isDesktop ? desktopPreviewCardStyle : previewCardStyle}>
                <div style={criarPreviewCoverStyle(capa)}>
                  <div style={previewCoverGlowStyle} />

                </div>

                <div style={previewContentStyle}>
                  <div style={previewTopRowStyle}>
                    <h3 style={previewObraTitleStyle}>
                      {titulo.trim() || t("obraSemTitulo")}
                    </h3>

                    <div style={previewBadgesStyle}>
                      <span style={previewBadgeStyle}>
                        {formatoFinal ? traduzirFormatoPublicar(idioma, formatoFinal) : t("formato")}
                      </span>

                      <span style={previewRatingBadgeStyle}>
                        {classificacaoFinal ? traduzirClassificacaoPublicar(idioma, classificacaoFinal) : t("classificacao")}
                      </span>
                    </div>
                  </div>

                  <p style={previewAuthorStyle}>
                    {t("por")} {autor.trim() || t("autorNaoInformado")}
                  </p>

                  <div style={previewStatsStyle}>
                    <span style={previewStatItemStyle}>
                      <span style={previewStatIconStyle}>👁</span>
                      <span style={previewStatValueStyle}>0</span>
                    </span>

                    <span style={previewStatItemStyle}>
                      <span style={previewStatHeartIconStyle}>♥</span>
                      <span style={previewStatValueStyle}>0</span>
                    </span>

                    <span style={previewStatItemStyle}>
                      <span style={previewStatIconStyle}>💬</span>
                      <span style={previewStatValueStyle}>0</span>
                    </span>

                    <span style={previewStatItemStyle}>
                      <span style={previewStatIconStyle}>📚</span>
                      <span style={previewStatValueStyle}>
                        {temCapituloImportado ? `1 ${t("capituloAbreviado")}` : `0 ${t("capituloAbreviado")}`}
                      </span>
                    </span>
                  </div>

                  <div style={previewProgressCompactStyle}>
                    <div style={previewProgressTrackStyle}>
                      <div
                        style={{
                          ...previewProgressFillStyle,
                          width: temCapituloImportado ? "100%" : "0%",
                        }}
                      />
                    </div>

                    <span style={previewProgressTextStyle}>
                      {temCapituloImportado ? t("capituloPronto") : t("semCapitulo")}
                    </span>
                  </div>


                  {temCapituloImportado && (
                    <div style={previewImportedChapterStyle}>
                      <span style={previewImportedMiniStyle}>
                        {t("primeiroCapituloMaiusculo")}
                      </span>

                      <strong style={previewImportedTitleStyle}>
                        {arquivoCapituloTitulo || `${t("primeiroCapitulo")} 1`}
                      </strong>

                      <span style={previewImportedTextStyle}>
                        {arquivoCapituloPalavras} {t("palavras")} • {arquivoCapituloMinutos} {t("minLeitura")}
                      </span>
                    </div>
                  )}

                  <div style={previewActionRowStyle}>
                    <span style={previewGenreBadgeStyle}>
                      {generoFinal ? traduzirGeneroPublicar(idioma, generoFinal) : t("genero")}
                    </span>

                    <span style={previewActionBadgeStyle}>
                      {t("previa")}
                    </span>
                  </div>
                </div>
              </article>
            ) : (
              <div
                style={isDesktop ? desktopEmptyPreviewBoxStyle : emptyPreviewBoxStyle}
              >
                <div style={emptyPreviewCoverStyle}>
                  <span style={emptyPreviewIconStyle}>+</span>
                </div>

                <div style={emptyPreviewContentStyle}>
                  <strong style={emptyPreviewTitleStyle}>
                    {t("previaAqui")}
                  </strong>

                  <span style={emptyPreviewTextStyle}>
                    {t("dicaPrevia")}
                  </span>
                </div>
              </div>
            )}
          </aside>
        </section>
      </section>
    </main>
  );
}

const publicarPageCss = `
  html {
    --historietas-publicar-bg-page: #070212;
    --historietas-publicar-bg-deep: #04000A;
    --historietas-publicar-surface: #08030F;
    --historietas-publicar-bg-end: #020006;
    --historietas-publicar-accent: #F97316;
    --historietas-publicar-secondary: #7C3AED;
    --historietas-publicar-accent-soft: #FDBA74;
    --historietas-publicar-purple-text: #DDD6FE;
    --historietas-publicar-purple-soft: #A78BFA;
    --historietas-publicar-author-text: #D8C8FF;
    --historietas-publicar-danger: #EF4444;
    --historietas-publicar-danger-text: #FCA5A5;
    --historietas-publicar-heart: #E11D48;
    --historietas-publicar-success: #86EFAC;
    --historietas-publicar-purple-border: rgba(59, 7, 100, 0.58);
    --historietas-publicar-danger-bg: rgba(239,68,68,0.075);
    --historietas-publicar-danger-border: rgba(239,68,68,0.18);
    --historietas-publicar-success-bg: rgba(34, 197, 94, 0.12);
    --historietas-publicar-success-border: rgba(34, 197, 94, 0.22);
  }

  html[data-historietas-tema-visual="foco"] {
    --historietas-publicar-bg-page: #000000;
    --historietas-publicar-bg-deep: #000000;
    --historietas-publicar-surface: #050505;
    --historietas-publicar-bg-end: #000000;
    --historietas-publicar-accent: #FFFFFF;
    --historietas-publicar-secondary: #A1A1AA;
    --historietas-publicar-accent-soft: #FFFFFF;
    --historietas-publicar-purple-text: #FFFFFF;
    --historietas-publicar-purple-soft: #D4D4D8;
    --historietas-publicar-author-text: #D4D4D8;
    --historietas-publicar-danger: #FFFFFF;
    --historietas-publicar-danger-text: #FFFFFF;
    --historietas-publicar-heart: #FFFFFF;
    --historietas-publicar-success: #FFFFFF;
    --historietas-publicar-purple-border: rgba(255,255,255,0.18);
    --historietas-publicar-danger-bg: rgba(255,255,255,0.06);
    --historietas-publicar-danger-border: rgba(255,255,255,0.18);
    --historietas-publicar-success-bg: rgba(255,255,255,0.06);
    --historietas-publicar-success-border: rgba(255,255,255,0.18);
  }

  html[data-historietas-tema-visual="original"] body,
  html[data-historietas-tema-visual="original"] main {
    background: #070212 !important;
  }

  html[data-historietas-tema-visual="foco"] body,
  html[data-historietas-tema-visual="foco"] main {
    background: #000000 !important;
    color: #FFFFFF !important;
  }

  html[data-historietas-tema-visual] main > div[aria-hidden="true"] {
    background: transparent !important;
    opacity: 0 !important;
  }

  html[data-historietas-tema-visual] nav,
  html[data-historietas-tema-visual] [data-bottom-nav],
  html[data-historietas-tema-visual] [data-mobile-nav] {
    background: var(--historietas-bottom-nav-bg, #04000A) !important;
  }

  html[data-historietas-tema-visual] nav a[href="/publicar"],
  html[data-historietas-tema-visual] [data-bottom-nav] a[href="/publicar"],
  html[data-historietas-tema-visual] [data-mobile-nav] a[href="/publicar"] {
    background: var(
      --historietas-bottom-nav-active-bg,
      rgba(59, 7, 100, 0.54)
    ) !important;
    border-color: var(
      --historietas-bottom-nav-active-border,
      rgba(109, 40, 217, 0.48)
    ) !important;
    color: #FFFFFF !important;
    box-shadow: none !important;
  }

  html[data-historietas-tema-visual] nav a[href="/publicar"] .historietas-bottom-nav-icon,
  html[data-historietas-tema-visual] [data-bottom-nav] a[href="/publicar"] .historietas-bottom-nav-icon,
  html[data-historietas-tema-visual] [data-mobile-nav] a[href="/publicar"] .historietas-bottom-nav-icon {
    color: #FFFFFF !important;
    background: var(
      --historietas-bottom-nav-active-icon-bg,
      #3B0764
    ) !important;
    border-color: var(
      --historietas-bottom-nav-active-icon-border,
      rgba(167, 139, 250, 0.46)
    ) !important;
  }

  html[data-historietas-tema-visual="foco"] nav a[href="/publicar"],
  html[data-historietas-tema-visual="foco"] [data-bottom-nav] a[href="/publicar"],
  html[data-historietas-tema-visual="foco"] [data-mobile-nav] a[href="/publicar"] {
    background: #050505 !important;
    border-color: #FFFFFF !important;
    color: #FFFFFF !important;
    box-shadow: none !important;
  }

  html[data-historietas-tema-visual="foco"] nav a[href="/publicar"] .historietas-bottom-nav-icon,
  html[data-historietas-tema-visual="foco"] [data-bottom-nav] a[href="/publicar"] .historietas-bottom-nav-icon,
  html[data-historietas-tema-visual="foco"] [data-mobile-nav] a[href="/publicar"] .historietas-bottom-nav-icon {
    background: #000000 !important;
    border-color: rgba(255,255,255,0.24) !important;
    color: #FFFFFF !important;
  }

  html[data-historietas-tema-visual] input::placeholder,
  html[data-historietas-tema-visual] textarea::placeholder {
    color: rgba(212,212,216,0.68) !important;
  }

  html[data-historietas-tema-visual] input,
  html[data-historietas-tema-visual] textarea,
  html[data-historietas-tema-visual] select {
    color: #FFFFFF !important;
  }

  html[data-historietas-tema-visual="foco"] option {
    background: #000000;
    color: #FFFFFF;
  }
`;

const safeTextStyle: CSSProperties = {
  overflowWrap: "anywhere",
  wordBreak: "break-word",
};

const pageDecorationLayerStyle: CSSProperties = {
  display: "none",
};

const mobileTopWaterFadeStyle: CSSProperties = {
  position: "absolute",
  top: 0,
  left: 0,
  right: 0,
  height: "min(340px, 48vh)",
  pointerEvents: "none",
  zIndex: 0,
  background: "transparent",
  WebkitMaskImage: "none",
  maskImage: "none",
  opacity: 0,
};

const desktopTopWaterFadeStyle: CSSProperties = {
  position: "absolute",
  top: 0,
  left: 0,
  right: 0,
  height: "min(620px, 68vh)",
  pointerEvents: "none",
  zIndex: 0,
  background: "transparent",
  WebkitMaskImage: "none",
  maskImage: "none",
  opacity: 0,
};

const heroDecorationLayerStyle: CSSProperties = {
  display: "none",
};

const heroPremiumShineStyle: CSSProperties = {
  display: "none",
};

const pageStyle: CSSProperties = {
  position: "relative",
  minHeight: "100vh",
  width: "100%",
  maxWidth: "100%",
  overflowX: "hidden",
  background: "var(--historietas-publicar-bg-page, #070212)",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontFamily: "Inter, Poppins, Manrope, Arial, Helvetica, sans-serif",
};

const containerStyle: CSSProperties = {
  position: "relative",
  zIndex: 1,
  width: "min(900px, calc(100% - 24px))",
  maxWidth: "100%",
  margin: "0 auto",
  padding: "14px 0 18px",
  boxSizing: "border-box",
  minWidth: 0,
};

const topStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  gap: "12px",
  marginBottom: "14px",
  minWidth: 0,
};

const logoStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  textDecoration: "none",
  fontSize: "25px",
  fontWeight: 950,
  letterSpacing: "-0.06em",
  display: "flex",
  alignItems: "center",
  gap: "4px",
  minWidth: 0,
  maxWidth: "100%",
  overflow: "visible",
  ...safeTextStyle,
};

const logoMarkStyle: CSSProperties = {
  width: "34px",
  height: "34px",
  borderRadius: "12px",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  background: "var(--historietas-publicar-bg-deep, #04000A)",
  color: "#FFFFFF",
  fontSize: "19px",
  fontWeight: 950,
  letterSpacing: 0,
  flex: "0 0 auto",
  border: "1px solid var(--historietas-publicar-purple-border, rgba(59, 7, 100, 0.58))",
  boxShadow: "none",
};

const logoTextStyle: CSSProperties = {
  marginLeft: "-1px",
  background:
    "linear-gradient(135deg, #FFFFFF 0%, var(--historietas-publicar-purple-text, #DDD6FE) 44%, var(--historietas-publicar-purple-soft, #A78BFA) 100%)",
  WebkitBackgroundClip: "text",
  backgroundClip: "text",
  color: "transparent",
  textShadow: "none",
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
};

const titleHeaderStyle: CSSProperties = {
  ...topStyle,
  justifyContent: "center",
  flexWrap: "nowrap",
  marginTop: 0,
  marginBottom: "14px",
  textAlign: "center",
};

const desktopTitleHeaderStyle: CSSProperties = {
  ...titleHeaderStyle,
  position: "relative",
  justifyContent: "center",
  minHeight: "48px",
  marginBottom: "24px",
  paddingRight: 0,
  textAlign: "center",
};

const headerTitleLinkStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  textDecoration: "none",
  fontSize: "25px",
  fontWeight: 950,
  letterSpacing: 0,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  gap: "4px",
  minWidth: 0,
  maxWidth: "100%",
  overflow: "visible",
  flex: "0 1 auto",
  ...safeTextStyle,
};

const desktopHeaderTitleLinkStyle: CSSProperties = {
  ...headerTitleLinkStyle,
  width: "100%",
  justifyContent: "center",
  textAlign: "center",
  fontSize: "29px",
};

const headerTitleMarkStyle: CSSProperties = {
  display: "none",
};

const desktopHeaderTitleMarkStyle: CSSProperties = {
  ...headerTitleMarkStyle,
};

const headerTitleTextStyle: CSSProperties = {
  display: "inline-block",
  marginLeft: "-1px",
  paddingRight: "0.2em",
  paddingBottom: "0.04em",
  whiteSpace: "nowrap",
  overflow: "visible",
  fontSize: "25px",
  lineHeight: 1.08,
  fontWeight: 950,
  letterSpacing: 0,
  wordSpacing: "normal",
  background: "none",
  color: "#FFFFFF",
  WebkitTextFillColor: "#FFFFFF",
  textShadow: "none",
};

const desktopHeaderTitleTextStyle: CSSProperties = {
  ...headerTitleTextStyle,
  fontSize: "29px",
  letterSpacing: "-0.035em",
};


const heroBoxStyle: CSSProperties = {
  position: "relative",
  display: "grid",
  justifyItems: "center",
  textAlign: "center",
  gap: "10px",
  padding: "24px 16px",
  borderRadius: "30px",
  border: "1px solid rgba(255,255,255,0.06)",
  background: "linear-gradient(135deg, var(--historietas-publicar-bg-page, #070212) 0%, var(--historietas-publicar-bg-deep, #04000A) 58%, var(--historietas-publicar-bg-end, #020006) 100%)",
  boxShadow: "none",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  overflow: "hidden",
};


const titleStyle: CSSProperties = {
  position: "relative",
  zIndex: 1,
  margin: 0,
  color: "var(--historietas-accent, var(--historietas-publicar-accent, #F97316))",
  WebkitTextFillColor: "var(--historietas-accent, var(--historietas-publicar-accent, #F97316))",
  fontSize: "clamp(30px, 8vw, 46px)",
  lineHeight: 1.12,
  fontWeight: 950,
  letterSpacing: "-0.052em",
  maxWidth: "100%",
  textAlign: "center",
  textShadow: "none",
  overflow: "visible",
  wordBreak: "normal",
  overflowWrap: "normal",
};

const descriptionStyle: CSSProperties = {
  position: "relative",
  zIndex: 1,
  margin: 0,
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "13px",
  lineHeight: 1.55,
  fontWeight: 720,
  maxWidth: "720px",
  textAlign: "center",
  ...safeTextStyle,
};

const progressBoxStyle: CSSProperties = {
  position: "relative",
  zIndex: 1,
  display: "grid",
  gap: "8px",
  padding: 0,
  borderRadius: 0,
  background: "transparent",
  border: "0",
  minWidth: 0,
  width: "min(450px, 100%)",
  maxWidth: "100%",
  boxSizing: "border-box",
  overflow: "hidden",
  boxShadow: "none",
};

const progressTopStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  gap: "10px",
  flexWrap: "wrap",
  minWidth: 0,
};

const progressLabelStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "11px",
  fontWeight: 900,
  ...safeTextStyle,
};

const progressNumberStyle: CSSProperties = {
  color: "#FFFFFF",
  fontSize: "13px",
  fontWeight: 950,
  ...safeTextStyle,
};

const progressTrackStyle: CSSProperties = {
  height: "7px",
  overflow: "hidden",
  borderRadius: "999px",
  background: "rgba(255,255,255,0.06)",
  border: "1px solid rgba(255,255,255,0.08)",
  maxWidth: "100%",
};

const progressFillStyle: CSSProperties = {
  height: "100%",
  borderRadius: "999px",
  background:
    "linear-gradient(90deg, var(--historietas-accent, var(--historietas-publicar-accent, #F97316)) 0%, var(--historietas-secondary, var(--historietas-publicar-secondary, #7C3AED)) 100%)",
  transition: "width 0.2s ease",
};

const previewProgressBoxStyle: CSSProperties = {
  display: "grid",
  gap: "6px",
  padding: "8px",
  borderRadius: "16px",
  background: "rgba(4, 0, 10, 0.72)",
  border: "1px solid rgba(255,255,255,0.06)",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  boxShadow: "none",
};

const desktopPreviewProgressBoxStyle: CSSProperties = {
  ...previewProgressBoxStyle,
  padding: "9px 12px",
  borderRadius: "17px",
};

const mainGridStyle: CSSProperties = {
  display: "grid",
  gap: "14px",
  minWidth: 0,
  maxWidth: "100%",
};

const formPanelStyle: CSSProperties = {
  display: "grid",
  gap: "14px",
  background: "transparent",
  border: "0",
  borderRadius: 0,
  padding: 0,
  boxShadow: "none",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  overflow: "visible",
};

const errorBoxStyle: CSSProperties = {
  display: "grid",
  gap: "5px",
  padding: "11px",
  borderRadius: "16px",
  background: "var(--historietas-publicar-danger-bg, rgba(239,68,68,0.075))",
  border: "1px solid var(--historietas-publicar-danger-border, rgba(239,68,68,0.18))",
  color: "var(--historietas-publicar-danger-text, #FCA5A5)",
  fontSize: "12px",
  fontWeight: 850,
  minWidth: 0,
  ...safeTextStyle,
};

const formSectionHeaderStyle: CSSProperties = {
  display: "grid",
  justifyItems: "center",
  gap: "4px",
  padding: "4px 0 2px",
  textAlign: "center",
  minWidth: 0,
};


const formSectionTitleStyle: CSSProperties = {
  color: "var(--historietas-accent, var(--historietas-publicar-accent, #F97316))",
  fontSize: "18px",
  lineHeight: 1.05,
  fontWeight: 950,
  letterSpacing: "-0.045em",
  textAlign: "center",
  ...safeTextStyle,
};

const formSectionTitleStandaloneStyle: CSSProperties = {
  ...formSectionTitleStyle,
  display: "block",
  width: "100%",
  padding: 0,
  background: "transparent",
  border: "0",
  borderRadius: 0,
  boxShadow: "none",
};

const desktopFormSectionTitleStandaloneStyle: CSSProperties = {
  ...formSectionTitleStandaloneStyle,
  gridColumn: "1 / -1",
};

const formSectionTextStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "11px",
  lineHeight: 1.45,
  fontWeight: 700,
  textAlign: "center",
  maxWidth: "520px",
  ...safeTextStyle,
};


const fieldGroupStyle: CSSProperties = {
  display: "grid",
  gap: "7px",
  minWidth: 0,
  maxWidth: "100%",
};

const doubleFieldStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "1fr",
  gap: "12px",
  minWidth: 0,
  maxWidth: "100%",
};

const labelRowStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  gap: "8px",
  flexWrap: "wrap",
};

const fileUploadLabelRowStyle: CSSProperties = {
  ...labelRowStyle,
  alignItems: "center",
};

const fileOptionalBadgeStyle: CSSProperties = {
  width: "fit-content",
  maxWidth: "100%",
  padding: 0,
  borderRadius: 0,
  background: "transparent",
  border: "0",
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "10px",
  fontWeight: 950,
  letterSpacing: "0.04em",
  textTransform: "uppercase",
  ...safeTextStyle,
};

const labelStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "12px",
  fontWeight: 950,
  letterSpacing: "-0.01em",
  ...safeTextStyle,
};

const hiddenInputStyle: CSSProperties = {
  display: "none",
};

const coverUploadBoxStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "minmax(86px, 96px) minmax(0, 1fr)",
  gap: "12px",
  alignItems: "stretch",
  padding: "10px",
  borderRadius: "21px",
  background: "rgba(255,255,255,0.04)",
  border: "1px solid rgba(255,255,255,0.06)",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  overflow: "hidden",
  boxShadow: "none",
};

const coverUploadPreviewStyle: CSSProperties = {
  minWidth: 0,
  maxWidth: "100%",
};

const coverPlaceholderStyle: CSSProperties = {
  minHeight: "138px",
  borderRadius: "18px",
  background: "var(--historietas-publicar-bg-deep, #04000A)",
  backgroundImage: "linear-gradient(135deg, var(--historietas-publicar-surface, #08030F) 0%, var(--historietas-publicar-bg-deep, #04000A) 100%)",
  border: "1px solid rgba(255,255,255,0.08)",
  display: "grid",
  alignContent: "center",
  justifyItems: "center",
  gap: "6px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  overflow: "hidden",
  boxShadow: "none",
};

const coverPlaceholderIconStyle: CSSProperties = {
  width: "32px",
  height: "32px",
  borderRadius: "999px",
  background: "var(--historietas-accent, var(--historietas-publicar-accent, #F97316))",
  color: "#FFFFFF",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: "22px",
  fontWeight: 950,
};

const coverPlaceholderTextStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "10px",
  fontWeight: 900,
  textAlign: "center",
  ...safeTextStyle,
};

const coverUploadContentStyle: CSSProperties = {
  display: "grid",
  alignContent: "center",
  gap: "7px",
  minWidth: 0,
  maxWidth: "100%",
};

const coverUploadTitleStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "17px",
  fontWeight: 950,
  letterSpacing: "-0.045em",
  ...safeTextStyle,
};

const fileNameStyle: CSSProperties = {
  color: "var(--historietas-accent, var(--historietas-publicar-accent-soft, #FDBA74))",
  fontSize: "11px",
  fontWeight: 850,
  ...safeTextStyle,
};

const coverErrorStyle: CSSProperties = {
  color: "var(--historietas-publicar-danger-text, #FCA5A5)",
  fontSize: "11px",
  fontWeight: 850,
  ...safeTextStyle,
};

const coverButtonsStyle: CSSProperties = {
  display: "flex",
  flexWrap: "wrap",
  alignItems: "stretch",
  gap: "7px",
  minWidth: 0,
  maxWidth: "100%",
};

const coverButtonStyle: CSSProperties = {
  flex: "1 1 94px",
  minHeight: "36px",
  maxWidth: "100%",
  padding: "0 12px",
  borderRadius: "999px",
  border: "1px solid rgba(255,255,255,0.10)",
  background: "var(--historietas-publicar-surface, #08030F)",
  color: "#FFFFFF",
  fontSize: "11px",
  fontWeight: 950,
  cursor: "pointer",
  fontFamily: "inherit",
  textAlign: "center",
  boxSizing: "border-box",
  whiteSpace: "normal",
  boxShadow: "none",
  ...safeTextStyle,
};

const removeCoverButtonStyle: CSSProperties = {
  flex: "1 1 94px",
  minHeight: "34px",
  maxWidth: "100%",
  padding: "0 11px",
  borderRadius: "999px",
  border: "1px solid rgba(255,255,255,0.08)",
  background: "rgba(255,255,255,0.06)",
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "11px",
  fontWeight: 950,
  cursor: "pointer",
  fontFamily: "inherit",
  textAlign: "center",
  boxSizing: "border-box",
  whiteSpace: "normal",
  boxShadow: "none",
  ...safeTextStyle,
};

const inputStyle: CSSProperties = {
  width: "100%",
  minHeight: "46px",
  borderRadius: "999px",
  border: "1px solid rgba(255,255,255,0.08)",
  background: "var(--historietas-publicar-bg-deep, #04000A)",
  color: "#FFFFFF",
  padding: "0 14px",
  outline: "none",
  fontSize: "13px",
  fontWeight: 700,
  fontFamily: "inherit",
  boxSizing: "border-box",
  minWidth: 0,
  maxWidth: "100%",
  boxShadow: "none",
};

const textareaStyle: CSSProperties = {
  width: "100%",
  minHeight: "90px",
  borderRadius: "20px",
  border: "1px solid rgba(255,255,255,0.08)",
  background: "var(--historietas-publicar-bg-deep, #04000A)",
  color: "#FFFFFF",
  padding: "14px",
  outline: "none",
  fontSize: "13px",
  fontWeight: 700,
  lineHeight: 1.58,
  resize: "vertical",
  fontFamily: "inherit",
  boxSizing: "border-box",
  minWidth: 0,
  maxWidth: "100%",
  boxShadow: "none",
  ...safeTextStyle,
};

const hintStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "11px",
  lineHeight: 1.45,
  fontWeight: 650,
  ...safeTextStyle,
};


const buttonAreaStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(138px, 1fr))",
  gap: "9px",
  marginTop: "2px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const primaryButtonStyle: CSSProperties = {
  minHeight: "50px",
  borderRadius: "999px",
  border: "1px solid rgba(255,255,255,0.10)",
  background: "var(--historietas-publicar-surface, #08030F)",
  color: "#FFFFFF",
  fontSize: "14px",
  fontWeight: 950,
  cursor: "pointer",
  boxShadow: "none",
  fontFamily: "inherit",
  textAlign: "center",
  padding: "0 14px",
  lineHeight: 1.15,
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  whiteSpace: "normal",
  ...safeTextStyle,
};

const disabledButtonStyle: CSSProperties = {
  ...primaryButtonStyle,
  background: "var(--historietas-secondary-surface, rgba(255,255,255,0.08))",
  color: "var(--historietas-text-secondary, #A1A1AA)",
  boxShadow: "none",
  cursor: "not-allowed",
};

const secondaryButtonStyle: CSSProperties = {
  ...primaryButtonStyle,
  textDecoration: "none",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
};

const chapterImportBoxStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "minmax(56px, 64px) minmax(0, 1fr)",
  gap: "12px",
  alignItems: "stretch",
  padding: 0,
  borderRadius: 0,
  background: "transparent",
  border: "0",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  overflow: "visible",
  boxShadow: "none",
};

const chapterImportIconBoxStyle: CSSProperties = {
  minHeight: "82px",
  borderRadius: "18px",
  background: "var(--historietas-publicar-bg-deep, #04000A)",
  border: "1px solid rgba(255,255,255,0.08)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  boxShadow: "none",
};

const chapterImportIconStyle: CSSProperties = {
  color: "#FFFFFF",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: "22px",
  fontWeight: 950,
  lineHeight: 1,
  background: "transparent",
  boxShadow: "none",
};

const chapterImportContentStyle: CSSProperties = {
  display: "grid",
  alignContent: "center",
  gap: "7px",
  minWidth: 0,
  maxWidth: "100%",
};

const chapterImportTitleStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "16px",
  fontWeight: 950,
  letterSpacing: "-0.04em",
  ...safeTextStyle,
};

const chapterImportStatsStyle: CSSProperties = {
  display: "flex",
  flexWrap: "wrap",
  gap: "6px",
  minWidth: 0,
  maxWidth: "100%",
};

const inlineStatStyle: CSSProperties = {
  width: "fit-content",
  maxWidth: "100%",
  padding: "6px 8px",
  borderRadius: "999px",
  background: "rgba(255,255,255,0.06)",
  border: "1px solid rgba(255,255,255,0.08)",
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "10px",
  fontWeight: 900,
  ...safeTextStyle,
};

const previewPanelStyle: CSSProperties = {
  display: "grid",
  gap: "12px",
  padding: 0,
  background: "transparent",
  border: "none",
  borderRadius: 0,
  boxShadow: "none",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const previewHeaderStyle: CSSProperties = {
  display: "grid",
  gap: "4px",
  justifyItems: "center",
  textAlign: "center",
  minWidth: 0,
};

const previewMiniTitleStyle: CSSProperties = {
  color: "#FFFFFF",
  WebkitTextFillColor: "#FFFFFF",
  fontSize: "19px",
  lineHeight: 1.05,
  fontWeight: 950,
  letterSpacing: "-0.035em",
  textAlign: "center",
  textTransform: "uppercase",
  ...safeTextStyle,
};


const previewCardStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "minmax(88px, 98px) minmax(0, 1fr)",
  alignItems: "stretch",
  gap: "14px",
  padding: "11px",
  borderRadius: "22px",
  background: "rgba(4, 0, 10, 0.72)",
  border: "1px solid rgba(255,255,255,0.06)",
  color: "var(--historietas-text-primary, #FFFFFF)",
  boxShadow: "none",
  minWidth: 0,
  maxWidth: "100%",
  overflow: "hidden",
  boxSizing: "border-box",
};

const emptyPreviewBoxStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "80px minmax(0, 1fr)",
  gap: "13px",
  alignItems: "center",
  padding: "13px",
  borderRadius: "21px",
  background: "rgba(4, 0, 10, 0.72)",
  border: "1px solid rgba(255,255,255,0.06)",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  overflow: "hidden",
  boxShadow: "none",
};

const emptyPreviewCoverStyle: CSSProperties = {
  minHeight: "104px",
  borderRadius: "18px",
  background: "var(--historietas-publicar-bg-deep, #04000A)",
  backgroundImage: "linear-gradient(135deg, var(--historietas-publicar-surface, #08030F) 0%, var(--historietas-publicar-bg-deep, #04000A) 100%)",
  border: "1px solid rgba(255,255,255,0.08)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  boxShadow: "none",
};

const emptyPreviewIconStyle: CSSProperties = {
  color: "#FFFFFF",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: "24px",
  fontWeight: 950,
  lineHeight: 1,
  background: "transparent",
};

const emptyPreviewContentStyle: CSSProperties = {
  display: "grid",
  gap: "6px",
  minWidth: 0,
};

const emptyPreviewTitleStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "16px",
  fontWeight: 950,
  letterSpacing: "-0.04em",
  ...safeTextStyle,
};

const emptyPreviewTextStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "12px",
  lineHeight: 1.45,
  fontWeight: 700,
  ...safeTextStyle,
};

const previewCoverStyle: CSSProperties = {
  width: "100%",
  minHeight: "116px",
  height: "100%",
  maxHeight: "none",
  maxWidth: "100%",
  alignSelf: "stretch",
  borderRadius: "16px",
  position: "relative",
  overflow: "hidden",
  background: "var(--historietas-publicar-bg-deep, #04000A)",
  backgroundImage: "linear-gradient(135deg, var(--historietas-publicar-surface, #08030F) 0%, var(--historietas-publicar-bg-deep, #04000A) 100%)",
  backgroundSize: "cover",
  backgroundPosition: "center",
  border: "1px solid rgba(255,255,255,0.08)",
  minWidth: 0,
  boxSizing: "border-box",
  flex: "0 0 auto",
  boxShadow: "none",
};

const previewCoverGlowStyle: CSSProperties = {
  display: "none",
};


const previewCoverBottomStyle: CSSProperties = {
  position: "absolute",
  left: "9px",
  right: "9px",
  bottom: "9px",
  display: "grid",
  gridTemplateColumns: "auto minmax(0, 1fr)",
  alignItems: "end",
  gap: "5px",
  minWidth: 0,
  maxWidth: "100%",
};

const previewCoverNumberStyle: CSSProperties = {
  color: "#FFFFFF",
  fontSize: "30px",
  lineHeight: 0.88,
  fontWeight: 950,
  letterSpacing: "-0.07em",
  textShadow: "0 1px 10px rgba(0,0,0,0.34)",
  ...safeTextStyle,
};

const previewCoverTextStyle: CSSProperties = {
  color: "#FFFFFF",
  fontSize: "8.5px",
  lineHeight: 1,
  fontWeight: 950,
  letterSpacing: "0.055em",
  textAlign: "left",
  textTransform: "uppercase",
  textShadow: "0 1px 10px rgba(0,0,0,0.34)",
  ...safeTextStyle,
};

const previewContentStyle: CSSProperties = {
  display: "grid",
  alignContent: "center",
  gap: "7px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const previewBadgesStyle: CSSProperties = {
  display: "flex",
  flexWrap: "wrap",
  gap: "6px",
  rowGap: "5px",
  minWidth: 0,
  maxWidth: "100%",
};

const previewBadgeStyle: CSSProperties = {
  width: "fit-content",
  maxWidth: "100%",
  padding: "5px 8px",
  borderRadius: "999px",
  background: "rgba(255,255,255,0.06)",
  border: "1px solid rgba(255,255,255,0.08)",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "10px",
  fontWeight: 900,
  whiteSpace: "normal",
  ...safeTextStyle,
};

const previewRatingBadgeStyle: CSSProperties = {
  ...previewBadgeStyle,
  color: "#FFFFFF",
};


const previewImportedBadgeStyle: CSSProperties = {
  ...previewBadgeStyle,
  background: "var(--historietas-publicar-success-bg, rgba(34, 197, 94, 0.12))",
  border: "1px solid var(--historietas-publicar-success-border, rgba(34, 197, 94, 0.22))",
  color: "var(--historietas-publicar-success, #86EFAC)",
};

const previewObraTitleStyle: CSSProperties = {
  margin: 0,
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "20px",
  lineHeight: 1.05,
  fontFamily:
    'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  fontWeight: 500,
  letterSpacing: "-0.01em",
  maxWidth: "100%",
  display: "-webkit-box",
  WebkitLineClamp: 2,
  WebkitBoxOrient: "vertical",
  overflow: "hidden",
  textDecoration: "none",
  borderBottom: "none",
  ...safeTextStyle,
};

const previewAuthorStyle: CSSProperties = {
  width: "fit-content",
  maxWidth: "100%",
  margin: 0,
  color: "var(--historietas-text-secondary, var(--historietas-publicar-author-text, #D8C8FF))",
  fontSize: "12px",
  fontFamily:
    'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  fontWeight: 450,
  lineHeight: 1.25,
  textDecoration: "none",
  borderBottom: "none",
  ...safeTextStyle,
};

const previewSinopseStyle: CSSProperties = {
  margin: 0,
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "11px",
  lineHeight: 1.32,
  fontWeight: 700,
  whiteSpace: "pre-wrap",
  maxWidth: "100%",
  display: "-webkit-box",
  WebkitLineClamp: 2,
  WebkitBoxOrient: "vertical",
  overflow: "hidden",
  overflowWrap: "break-word",
  wordBreak: "break-word",
  ...safeTextStyle,
};

const previewImportedChapterStyle: CSSProperties = {
  display: "grid",
  gap: "3px",
  padding: "7px",
  borderRadius: "13px",
  background: "rgba(255,255,255,0.04)",
  border: "1px solid rgba(255,255,255,0.06)",
  minWidth: 0,
  maxWidth: "100%",
  overflow: "hidden",
  boxShadow: "none",
};

const previewImportedMiniStyle: CSSProperties = {
  color: "var(--historietas-publicar-success, #86EFAC)",
  fontSize: "8px",
  fontWeight: 950,
  letterSpacing: "0.055em",
  textTransform: "uppercase",
  ...safeTextStyle,
};

const previewImportedTitleStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "14px",
  lineHeight: 1.2,
  fontWeight: 950,
  ...safeTextStyle,
};

const previewImportedTextStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "11px",
  lineHeight: 1.35,
  fontWeight: 750,
  ...safeTextStyle,
};

const previewTopRowStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "1fr",
  gap: "8px",
  minWidth: 0,
  maxWidth: "100%",
};

const previewStatsStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: "8px",
  flexWrap: "wrap",
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "11px",
  fontFamily:
    'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  fontWeight: 850,
  maxWidth: "100%",
  minWidth: 0,
};

const previewStatItemStyle: CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  gap: "4px",
  minWidth: 0,
  whiteSpace: "nowrap",
  lineHeight: 1,
};

const previewStatIconStyle: CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  lineHeight: 1,
  flex: "0 0 auto",
};

const previewStatHeartIconStyle: CSSProperties = {
  ...previewStatIconStyle,
  color: "var(--historietas-publicar-heart, #E11D48)",
};

const previewStatValueStyle: CSSProperties = {
  display: "inline-block",
  lineHeight: 1,
  whiteSpace: "nowrap",
};

const previewProgressCompactStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "minmax(0, 1fr) auto",
  alignItems: "center",
  gap: "8px",
  maxWidth: "100%",
  boxSizing: "border-box",
  minWidth: 0,
};

const previewProgressTrackStyle: CSSProperties = {
  width: "100%",
  height: "7px",
  borderRadius: "999px",
  background: "rgba(255,255,255,0.06)",
  border: "1px solid rgba(255,255,255,0.08)",
  overflow: "hidden",
  boxSizing: "border-box",
};

const previewProgressFillStyle: CSSProperties = {
  height: "100%",
  borderRadius: "999px",
  background:
    "linear-gradient(90deg, var(--historietas-accent, var(--historietas-publicar-accent, #F97316)) 0%, var(--historietas-secondary, var(--historietas-publicar-secondary, #7C3AED)) 100%)",
};

const previewProgressTextStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "11px",
  fontWeight: 850,
  lineHeight: 1.2,
  whiteSpace: "nowrap",
};

const previewActionRowStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: "8px",
  marginTop: "2px",
  maxWidth: "100%",
  minWidth: 0,
  overflow: "hidden",
  boxSizing: "border-box",
};

const previewGenreBadgeStyle: CSSProperties = {
  flex: "0 1 42%",
  maxWidth: "42%",
  minHeight: "34px",
  padding: "0 10px",
  borderRadius: "999px",
  background: "rgba(255,255,255,0.06)",
  border: "1px solid rgba(255,255,255,0.08)",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "11px",
  fontWeight: 900,
  lineHeight: 1.12,
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  whiteSpace: "nowrap",
  overflow: "hidden",
  textOverflow: "ellipsis",
  boxSizing: "border-box",
  ...safeTextStyle,
};

const previewActionBadgeStyle: CSSProperties = {
  flex: "1 1 auto",
  minWidth: 0,
  maxWidth: "100%",
  minHeight: "34px",
  padding: "0 12px",
  borderRadius: "999px",
  background: "var(--historietas-publicar-surface, #08030F)",
  border: "1px solid rgba(255,255,255,0.10)",
  color: "#FFFFFF",
  fontSize: "13px",
  fontWeight: 950,
  lineHeight: 1.15,
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  boxSizing: "border-box",
  textAlign: "center",
  ...safeTextStyle,
};


const tagPreviewListStyle: CSSProperties = {
  display: "flex",
  flexWrap: "wrap",
  gap: "6px",
  minWidth: 0,
};

const previewTagStyle: CSSProperties = {
  width: "fit-content",
  maxWidth: "100%",
  padding: "4px 6px",
  borderRadius: "999px",
  background: "rgba(255,255,255,0.06)",
  border: "1px solid rgba(255,255,255,0.08)",
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "9px",
  fontWeight: 950,
  ...safeTextStyle,
};

const miniCounterOkStyle: CSSProperties = {
  width: "fit-content",
  padding: 0,
  borderRadius: 0,
  background: "transparent",
  border: "0",
  color: "#FFFFFF",
  fontSize: "10px",
  fontWeight: 900,
  ...safeTextStyle,
};

const miniCounterWarningStyle: CSSProperties = {
  ...miniCounterOkStyle,
  color: "#FFFFFF",
};

const desktopContainerStyle: CSSProperties = {
  ...containerStyle,
  width: "min(1180px, calc(100% - 64px))",
  maxWidth: "100%",
  padding: "30px 0 72px",
};

const desktopTopStyle: CSSProperties = {
  ...topStyle,
  marginBottom: "14px",
};

const desktopHeroBoxStyle: CSSProperties = {
  ...heroBoxStyle,
  padding: "30px 24px",
  borderRadius: "30px",
};


const desktopTitleStyle: CSSProperties = {
  ...titleStyle,
  fontSize: "clamp(38px, 4.4vw, 58px)",
  maxWidth: "760px",
  margin: "0 auto",
  textAlign: "center",
};


const desktopDescriptionStyle: CSSProperties = {
  ...descriptionStyle,
  margin: "10px auto 0",
  maxWidth: "620px",
  textAlign: "center",
  fontSize: "14px",
};


const desktopProgressBoxStyle: CSSProperties = {
  ...progressBoxStyle,
  gridColumn: "1 / -1",
  width: "100%",
  padding: 0,
};


const desktopMainGridSingleStyle: CSSProperties = {
  ...mainGridStyle,
  gridTemplateColumns: "minmax(0, 760px)",
  justifyContent: "center",
  alignItems: "start",
  gap: "28px",
  width: "100%",
};


const desktopFormPanelStyle: CSSProperties = {
  ...formPanelStyle,
  gridTemplateColumns: "minmax(0, 1fr)",
  alignItems: "start",
  width: "100%",
  maxWidth: "760px",
  padding: 0,
  borderRadius: 0,
  gap: "16px",
  background: "transparent",
  border: "0",
  boxShadow: "none",
  overflow: "visible",
};

const desktopHalfFieldStyle: CSSProperties = {
  ...fieldGroupStyle,
  gridColumn: "auto",
  minWidth: 0,
};

const desktopFullWidthFieldStyle: CSSProperties = {
  ...fieldGroupStyle,
  gridColumn: "1 / -1",
  minWidth: 0,
};

const desktopFullWidthErrorBoxStyle: CSSProperties = {
  ...errorBoxStyle,
  gridColumn: "1 / -1",
};

const desktopFormSectionHeaderStyle: CSSProperties = {
  ...formSectionHeaderStyle,
  gridColumn: "1 / -1",
  padding: "8px 0 4px",
};


const desktopDoubleFieldStyle: CSSProperties = {
  ...doubleFieldStyle,
  gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
  gap: "16px",
};

const desktopFullWidthDoubleFieldStyle: CSSProperties = {
  ...desktopDoubleFieldStyle,
  gridColumn: "1 / -1",
};


const desktopCoverUploadBoxStyle: CSSProperties = {
  ...coverUploadBoxStyle,
  gridTemplateColumns: "116px minmax(0, 1fr)",
  gap: "16px",
  padding: "12px",
  borderRadius: "22px",
};


const desktopCoverUploadContentStyle: CSSProperties = {
  ...coverUploadContentStyle,
  alignContent: "center",
  gap: "8px",
};

const desktopCoverButtonsStyle: CSSProperties = {
  ...coverButtonsStyle,
  justifyContent: "flex-start",
  gap: "9px",
};

const desktopCoverButtonStyle: CSSProperties = {
  ...coverButtonStyle,
  flex: "0 1 auto",
  width: "auto",
  minWidth: "138px",
  maxWidth: "220px",
  padding: "0 17px",
  whiteSpace: "normal",
};

const desktopRemoveCoverButtonStyle: CSSProperties = {
  ...removeCoverButtonStyle,
  flex: "0 1 auto",
  width: "auto",
  minWidth: "112px",
  maxWidth: "180px",
  padding: "0 16px",
  whiteSpace: "normal",
};

const desktopChapterImportBoxStyle: CSSProperties = {
  ...chapterImportBoxStyle,
  gridTemplateColumns: "108px minmax(0, 1fr)",
  gap: "16px",
  alignItems: "center",
  padding: 0,
  borderRadius: 0,
  background: "transparent",
  border: "0",
  boxShadow: "none",
  overflow: "visible",
};

const desktopCoverUploadIconBoxStyle: CSSProperties = {
  width: "108px",
  minWidth: "108px",
  minHeight: "144px",
  height: "144px",
  alignSelf: "center",
  borderRadius: "18px",
};

const desktopFileUploadIconBoxStyle: CSSProperties = {
  width: "88px",
  minWidth: "88px",
  minHeight: "96px",
  height: "96px",
  alignSelf: "center",
  borderRadius: "18px",
};

const desktopFullWidthArquivoObraBoxStyle: CSSProperties = {
  ...chapterImportBoxStyle,
  gridTemplateColumns: "88px minmax(0, 1fr)",
  gap: "16px",
  alignItems: "center",
  padding: 0,
  borderRadius: 0,
  background: "transparent",
  border: "0",
  boxShadow: "none",
  overflow: "visible",
};

const desktopChapterImportContentStyle: CSSProperties = {
  ...chapterImportContentStyle,
  alignContent: "center",
  gap: "9px",
};

const desktopFullWidthArquivoObraContentStyle: CSSProperties = {
  ...chapterImportContentStyle,
  alignContent: "center",
  gap: "9px",
  gridTemplateColumns: "minmax(0, 1fr)",
  maxWidth: "100%",
};

const desktopButtonAreaStyle: CSSProperties = {
  ...buttonAreaStyle,
  gridColumn: "1 / -1",
  gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
  justifyContent: "stretch",
  gap: "10px",
  marginTop: "4px",
};

const desktopPreviewPanelStyle: CSSProperties = {
  ...previewPanelStyle,
  position: "static",
  top: "auto",
  alignSelf: "stretch",
  width: "100%",
  maxWidth: "760px",
  margin: "0 auto",
};


const desktopPreviewCardStyle: CSSProperties = {
  ...previewCardStyle,
  gridTemplateColumns: "132px minmax(0, 1fr)",
  gap: "18px",
  padding: "14px",
  borderRadius: "22px",
  width: "100%",
};

const desktopEmptyPreviewBoxStyle: CSSProperties = {
  ...emptyPreviewBoxStyle,
  gridTemplateColumns: "118px minmax(0, 1fr)",
  gap: "18px",
  padding: "14px",
  borderRadius: "22px",
  width: "100%",
};