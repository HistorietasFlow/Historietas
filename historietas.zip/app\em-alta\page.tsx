"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";
import type { CSSProperties } from "react";
import { supabase } from "../../lib/supabase/client";
import {
  historietasThemeCss,
  useHistorietasTheme,
} from "../../lib/historietasTheme";
import { useHistorietasLanguage } from "../../components/HistorietasLanguageProvider";
import type { HistorietasLanguage } from "../../lib/i18n";
import {
  criarSlugBase,
  idObraSupabaseValido,
  normalizarTexto,
} from "../../lib/utils";

type CapituloLocal = {
  id: string;
  titulo: string;
  texto: string;
  curtiu: boolean;
  salvo: boolean;
  comentario: string;
  criadoEm: string;
  lido: boolean;
  lidoEm: string;
};

type ArquivoObraLocal = {
  nome: string;
  tipo: "imagem" | "documento" | "texto" | "outro";
  tamanho: number;
  conteudo: string;
  enviadoEm: string;
};

type ObraLocal = {
  id: string;
  titulo: string;
  autor: string;
  autorId?: string;
  autorAvatarRanking?: string;
  genero: string;
  formato: string;
  classificacaoIndicativa: string;
  sinopse: string;
  tags: string[];
  capa: string;
  capaNome: string;
  publicado: boolean;
  capitulos: CapituloLocal[];
  criadaEm: string;
  ultimoCapituloLidoId: string;
  ultimaLeituraEm: string;
  progressoLeitura: number;
  slug: string;
  link: string;
  arquivoObra: ArquivoObraLocal | null;
  totalCurtidasRanking?: number;
  totalComentariosRanking?: number;
  totalSalvosRanking?: number;
  totalViewsRanking?: number;
  totalSeguidoresRanking?: number;
  totalSeguidoresAutorRanking?: number;
  totalAvaliacoesRanking?: number;
  mediaAvaliacoesRanking?: number;
};

type SupabaseObraRow = {
  id: string;
  user_id: string | null;
  titulo: string | null;
  autor: string | null;
  genero: string | null;
  formato: string | null;
  classificacao_indicativa: string | null;
  sinopse: string | null;
  tags: string[] | null;
  capa_url: string | null;
  capa_nome: string | null;
  arquivo_url: string | null;
  arquivo_nome: string | null;
  arquivo_tipo: string | null;
  arquivo_tamanho: number | null;
  arquivo_categoria: string | null;
  visualizacoes: number | null;
  publicado: boolean | null;
  slug: string | null;
  link: string | null;
  criada_em: string | null;
  atualizado_em: string | null;
};

type SupabaseCapituloRow = {
  id: string;
  obra_id: string;
  user_id: string | null;
  titulo: string | null;
  texto: string | null;
  ordem: number | null;
  publicado: boolean | null;
  criado_em: string | null;
  atualizado_em: string | null;
};

type SupabaseInteracaoObraRow = {
  obra_id: string | null;
  user_id: string | null;
};

type SupabaseProgressoLeituraEmAltaRow = {
  obra_id: string | null;
  capitulo_id: string | null;
  lido: boolean | null;
  atualizado_em: string | null;
};

type SupabaseAvaliacaoObraRow = {
  obra_id: string | null;
  user_id: string | null;
  nota: number | null;
};

type UsuariosPorObraRanking = Record<string, string[]>;

type ResultadoInteracoesObrasRanking = {
  porObra: Record<string, number>;
  usuariosPorObra: UsuariosPorObraRanking;
};

type SupabaseProfileAutorRankingRow = {
  id: string | null;
  user_id: string | null;
  nome: string | null;
  avatar_url?: string | null;
  avatar?: string | null;
  foto_url?: string | null;
  imagem_url?: string | null;
  photo_url?: string | null;
} & Record<string, unknown>;

type AvaliacaoRankingObra = {
  total: number;
  media: number;
};

type ObraRanking = {
  id: string;
  storageId: string;
  tipo: "local";
  titulo: string;
  autor: string;
  autorId?: string;
  autorAvatar: string;
  seguidoresAutor: number;
  genero: string;
  formato: string;
  classificacaoIndicativa: string;
  status: string;
  href: string;
  disponivel: boolean;
  capa: string;
  capaNome: string;
  capitulos: number;
  capitulosLidos: number;
  progressoLeitura: number;
  ultimoCapituloLidoTitulo: string;
  ultimoCapituloLidoHref: string;
  ultimaLeituraEm: string;
  curtidas: number;
  comentarios: number;
  salvos: number;
  views: number;
  avaliacoes: number;
  mediaAvaliacao: number;
  pontuacao: number;
  criadaEmTimestamp: number;
};

type AutorRanking = {
  id: string;
  nome: string;
  autorId: string;
  avatar: string;
  href: string;
  obras: number;
  capitulos: number;
  seguidores: number;
  seguidoresObras: number;
  views: number;
  curtidas: number;
  comentarios: number;
  avaliacoes: number;
  mediaAvaliacao: number;
  pontuacao: number;
};

type TipoRanking =
  | "geral"
  | "lidas"
  | "curtidas"
  | "comentadas"
  | "salvas"
  | "recentes"
  | "capitulos";


type TraducaoEmAlta = {
  en: string;
  es: string;
};

const EM_ALTA_UI_TRANSLATIONS: Record<string, TraducaoEmAlta> = {
  "Carregando": { en: "Loading", es: "Cargando" },
  "Carregando Em Alta": { en: "Loading Trending", es: "Cargando Tendencias" },
  "Voltar para a Home": { en: "Back to Home", es: "Volver al inicio" },
  "Notificações": { en: "Notifications", es: "Notificaciones" },
  "ISTORIETAS": { en: "ISTORIETAS", es: "ISTORIETAS" },
  "ISTORIETAS POPULARES": { en: "ISTORIETAS — POPULAR", es: "ISTORIETAS POPULARES" },
  "ISTORIETAS PUBLICADAS": { en: "ISTORIETAS — PUBLISHED", es: "ISTORIETAS PUBLICADAS" },
  "Ranking Mestre": { en: "Master Ranking", es: "Ranking Maestro" },
  "Alcance Dominante": { en: "Dominant Reach", es: "Alcance Dominante" },
  "Preferidas do Público": { en: "Readers' Favorites", es: "Favoritas del Público" },
  "Mais Comentadas": { en: "Most Commented", es: "Más Comentadas" },
  "Mais Seguidas": { en: "Most Followed", es: "Más Seguidas" },
  "Novas Promessas": { en: "Rising Stars", es: "Nuevas Promesas" },
  "Grandes Jornadas": { en: "Epic Journeys", es: "Grandes Aventuras" },
  "Autores em Alta": { en: "Trending Authors", es: "Autores en Tendencia" },
  "Catálogo em formação": { en: "Catalog in progress", es: "Catálogo en formación" },
  "Obras publicadas": { en: "Published works", es: "Obras publicadas" },
  "Ainda não há obras publicadas": { en: "There are no published works yet", es: "Todavía no hay obras publicadas" },
  "Nada para mostrar neste ranking": { en: "Nothing to show in this ranking", es: "Nada que mostrar en este ranking" },
  "As histórias que mais chamaram atenção dos leitores.": { en: "The stories that attracted the most reader attention.", es: "Las historias que más llamaron la atención de los lectores." },
  "As obras que mais receberam curtidas e reações positivas.": { en: "The works with the most likes and positive reactions.", es: "Las obras que más recibieron Me gusta y reacciones positivas." },
  "As histórias que mais puxaram conversa entre os leitores.": { en: "The stories that sparked the most reader discussion.", es: "Las historias que más conversación generaron entre los lectores." },
  "Obras que mais leitores decidiram acompanhar.": { en: "Works that the most readers chose to follow.", es: "Obras que más lectores decidieron seguir." },
  "Publicações recentes começando a aparecer no radar.": { en: "Recent publications starting to gain attention.", es: "Publicaciones recientes que empiezan a destacar." },
  "Histórias com mais capítulos e conteúdo publicado.": { en: "Stories with the most chapters and published content.", es: "Historias con más capítulos y contenido publicado." },
  "Catálogo inicial com obras publicadas no HISTORIETAS.": { en: "Initial catalog of works published on HISTORIETAS.", es: "Catálogo inicial de obras publicadas en HISTORIETAS." },
  "Obra Publicada": { en: "Published Work", es: "Obra Publicada" },
  "Obras Publicadas": { en: "Published Works", es: "Obras Publicadas" },
  "Por": { en: "By", es: "Por" },
  "História": { en: "Story", es: "Historia" },
  "Publicado": { en: "Published", es: "Publicado" },
  "Sem data": { en: "No date", es: "Sin fecha" },
  "Não informado": { en: "Not provided", es: "No informado" },
  "Não informada": { en: "Not provided", es: "No informada" },
  "Obra sem título": { en: "Untitled work", es: "Obra sin título" },
  "Autor não informado": { en: "Author not provided", es: "Autor no informado" },
  "Arquivo da obra": { en: "Work file", es: "Archivo de la obra" },
  "Capítulo": { en: "Chapter", es: "Capítulo" },
  "Capítulos": { en: "Chapters", es: "Capítulos" },
  "Alcance": { en: "Reach", es: "Alcance" },
  "Reação": { en: "Reaction", es: "Reacción" },
  "Discussão": { en: "Discussion", es: "Discusión" },
  "Seguidores": { en: "Followers", es: "Seguidores" },
  "Novidade": { en: "New", es: "Novedad" },
  "Conteúdo": { en: "Content", es: "Contenido" },
  "Diamante": { en: "Diamond", es: "Diamante" },
  "Rubi": { en: "Ruby", es: "Rubí" },
  "Ouro": { en: "Gold", es: "Oro" },
  "Prata": { en: "Silver", es: "Plata" },
  "Bronze": { en: "Bronze", es: "Bronce" },
  "Fantasia": { en: "Fantasy", es: "Fantasía" },
  "Terror": { en: "Horror", es: "Terror" },
  "Ficção": { en: "Fiction", es: "Ficción" },
  "Romance": { en: "Romance", es: "Romance" },
  "Drama": { en: "Drama", es: "Drama" },
  "Ação": { en: "Action", es: "Acción" },
  "Mistério": { en: "Mystery", es: "Misterio" },
  "Suspense": { en: "Thriller", es: "Suspenso" },
  "Aventura": { en: "Adventure", es: "Aventura" },
  "Comédia": { en: "Comedy", es: "Comedia" },
  "Conto": { en: "Short story", es: "Cuento" },
  "Poesia": { en: "Poetry", es: "Poesía" },
  "Mangá": { en: "Manga", es: "Manga" },
  "HQ": { en: "Comics", es: "Cómic" },
  "Livre": { en: "All ages", es: "Todo público" },
};

function traduzirDataEmAlta(texto: string, idioma: HistorietasLanguage) {
  const correspondencia = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(texto);

  if (!correspondencia || idioma !== "en") {
    return "";
  }

  return `${correspondencia[2]}/${correspondencia[1]}/${correspondencia[3]}`;
}

function traduzirTextoEmAlta(
  texto: string,
  idioma: HistorietasLanguage
): string {
  if (idioma === "pt-BR" || !texto) {
    return texto;
  }

  const partes = /^(\s*)([\s\S]*?)(\s*)$/.exec(texto);

  if (!partes) {
    return texto;
  }

  const inicio = partes[1];
  const conteudo = partes[2];
  const fim = partes[3];
  const traducaoExata = EM_ALTA_UI_TRANSLATIONS[conteudo];

  if (traducaoExata) {
    return `${inicio}${traducaoExata[idioma]}${fim}`;
  }

  const dataTraduzida = traduzirDataEmAlta(conteudo, idioma);

  if (dataTraduzida) {
    return `${inicio}${dataTraduzida}${fim}`;
  }

  let correspondencia = /^Notificações:\s*(\d+)\s*não lidas$/i.exec(conteudo);

  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Notifications: ${correspondencia[1]} unread${fim}`
      : `${inicio}Notificaciones: ${correspondencia[1]} sin leer${fim}`;
  }

  correspondencia = /^Abrir perfil de (.+)$/i.exec(conteudo);

  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Open ${correspondencia[1]}'s profile${fim}`
      : `${inicio}Abrir el perfil de ${correspondencia[1]}${fim}`;
  }

  correspondencia = /^Abrir página da obra (.+)$/i.exec(conteudo);

  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Open the page for ${correspondencia[1]}${fim}`
      : `${inicio}Abrir la página de ${correspondencia[1]}${fim}`;
  }

  correspondencia = /^(Voltar|Avançar) carrossel (.+)$/i.exec(conteudo);

  if (correspondencia) {
    const titulo = traduzirTextoEmAlta(correspondencia[2], idioma).trim();

    if (idioma === "en") {
      return `${inicio}${correspondencia[1].toLowerCase() === "voltar" ? "Previous" : "Next"} ${titulo} carousel${fim}`;
    }

    return `${inicio}${correspondencia[1].toLowerCase() === "voltar" ? "Retroceder" : "Avanzar"} carrusel de ${titulo}${fim}`;
  }

  correspondencia = /^(.+) em carrossel$/i.exec(conteudo);

  if (correspondencia) {
    const titulo = traduzirTextoEmAlta(correspondencia[1], idioma).trim();

    return idioma === "en"
      ? `${inicio}${titulo} carousel${fim}`
      : `${inicio}Carrusel de ${titulo}${fim}`;
  }

  correspondencia = /^Posição\s+(\d+)º\s+—\s+(.+)$/i.exec(conteudo);

  if (correspondencia) {
    const nivel = traduzirTextoEmAlta(correspondencia[2], idioma).trim();

    return idioma === "en"
      ? `${inicio}Position ${correspondencia[1]} — ${nivel}${fim}`
      : `${inicio}Posición ${correspondencia[1]} — ${nivel}${fim}`;
  }

  correspondencia = /^([\d.,]+)\s+(Obra Publicada|Obras Publicadas)$/i.exec(conteudo);

  if (correspondencia) {
    const quantidade = correspondencia[1];
    const singular = correspondencia[2].toLowerCase() === "obra publicada";

    return idioma === "en"
      ? `${inicio}${quantidade} ${singular ? "Published Work" : "Published Works"}${fim}`
      : `${inicio}${quantidade} ${singular ? "Obra Publicada" : "Obras Publicadas"}${fim}`;
  }

  correspondencia = /^([\d.,]+)\s+(visualização|visualizações|curtida|curtidas|comentário|comentários|seguidor|seguidores|capítulo|capítulos)$/i.exec(conteudo);

  if (correspondencia) {
    const quantidade = correspondencia[1];
    const unidade = correspondencia[2].toLowerCase();
    const singular = !unidade.endsWith("s") && unidade !== "visualizações";

    if (idioma === "en") {
      const traducao = unidade.startsWith("visualiza")
        ? singular ? "view" : "views"
        : unidade.startsWith("curtida")
          ? singular ? "like" : "likes"
          : unidade.startsWith("coment")
            ? singular ? "comment" : "comments"
            : unidade.startsWith("seguidor")
              ? singular ? "follower" : "followers"
              : singular ? "chapter" : "chapters";

      return `${inicio}${quantidade} ${traducao}${fim}`;
    }

    const traducao = unidade.startsWith("visualiza")
      ? singular ? "visualización" : "visualizaciones"
      : unidade.startsWith("curtida")
        ? singular ? "Me gusta" : "Me gusta"
        : unidade.startsWith("coment")
          ? singular ? "comentario" : "comentarios"
          : unidade.startsWith("seguidor")
            ? singular ? "seguidor" : "seguidores"
            : singular ? "capítulo" : "capítulos";

    return `${inicio}${quantidade} ${traducao}${fim}`;
  }

  return texto;
}

function EmAltaLanguageBridge() {
  const { language } = useHistorietasLanguage();

  useEffect(() => {
    if (typeof document === "undefined") {
      return;
    }

    const seletorRaiz = "[data-historietas-em-alta-root='true']";

    type EstadoTraducaoEmAlta = {
      original: string;
      traduzido: string;
    };

    const estadosTexto: WeakMap<Text, EstadoTraducaoEmAlta> = new WeakMap();
    const estadosAtributos: WeakMap<
      Element,
      Map<string, EstadoTraducaoEmAlta>
    > = new WeakMap();
    const textosAlterados = new Set<Text>();
    const atributosAlterados: Array<{ elemento: Element; atributo: string }> = [];
    const atributosTraduziveis = ["aria-label", "title", "placeholder", "alt"];
    let aplicando = false;

    function elementoEstaNaPagina(elemento: Element | null) {
      return Boolean(
        elemento?.matches(seletorRaiz) || elemento?.closest(seletorRaiz)
      );
    }

    function deveIgnorarElemento(elemento: Element | null) {
      if (!elemento || !elementoEstaNaPagina(elemento)) {
        return true;
      }

      if (elemento.closest("[data-historietas-i18n-ignore='true']")) {
        return true;
      }

      const tag = elemento.tagName.toLowerCase();

      return tag === "script" || tag === "style";
    }

    function aplicarTexto(no: Text) {
      const elementoPai = no.parentElement;

      if (
        deveIgnorarElemento(elementoPai) ||
        elementoPai?.tagName.toLowerCase() === "textarea"
      ) {
        return;
      }

      const atual = no.data;
      let estado = estadosTexto.get(no);

      if (!estado) {
        estado = { original: atual, traduzido: atual };
        estadosTexto.set(no, estado);
        textosAlterados.add(no);
      } else if (atual !== estado.traduzido && atual !== estado.original) {
        estado.original = atual;
      }

      const proximo = traduzirTextoEmAlta(estado.original, language);
      estado.traduzido = proximo;

      if (no.data !== proximo) {
        no.data = proximo;
      }
    }

    function aplicarAtributos(elemento: Element) {
      if (deveIgnorarElemento(elemento)) {
        return;
      }

      let estadosElemento = estadosAtributos.get(elemento);

      if (!estadosElemento) {
        estadosElemento = new Map();
        estadosAtributos.set(elemento, estadosElemento);
      }

      atributosTraduziveis.forEach((atributo) => {
        const atual = elemento.getAttribute(atributo);

        if (atual === null) {
          return;
        }

        let estado = estadosElemento?.get(atributo);

        if (!estado) {
          estado = { original: atual, traduzido: atual };
          estadosElemento?.set(atributo, estado);
          atributosAlterados.push({ elemento, atributo });
        } else if (atual !== estado.traduzido && atual !== estado.original) {
          estado.original = atual;
        }

        const proximo = traduzirTextoEmAlta(estado.original, language);
        estado.traduzido = proximo;

        if (atual !== proximo) {
          elemento.setAttribute(atributo, proximo);
        }
      });
    }

    function aplicarNo(no: Node) {
      if (no.nodeType === Node.TEXT_NODE) {
        aplicarTexto(no as Text);
        return;
      }

      if (no.nodeType !== Node.ELEMENT_NODE) {
        return;
      }

      const elemento = no as Element;

      if (deveIgnorarElemento(elemento)) {
        return;
      }

      aplicarAtributos(elemento);

      elemento.querySelectorAll("*").forEach((filho) => {
        if (!deveIgnorarElemento(filho)) {
          aplicarAtributos(filho);
        }
      });

      const percorrer = document.createTreeWalker(
        elemento,
        NodeFilter.SHOW_TEXT
      );
      let textoAtual = percorrer.nextNode();

      while (textoAtual) {
        aplicarTexto(textoAtual as Text);
        textoAtual = percorrer.nextNode();
      }
    }

    function aplicarPagina() {
      if (aplicando) {
        return;
      }

      aplicando = true;

      try {
        document.querySelectorAll(seletorRaiz).forEach(aplicarNo);
      } finally {
        aplicando = false;
      }
    }

    aplicarPagina();

    const observador = new MutationObserver((mutacoes) => {
      if (aplicando) {
        return;
      }

      aplicando = true;

      try {
        mutacoes.forEach((mutacao) => {
          if (mutacao.type === "characterData") {
            aplicarTexto(mutacao.target as Text);
            return;
          }

          if (mutacao.type === "attributes") {
            aplicarAtributos(mutacao.target as Element);
            return;
          }

          mutacao.addedNodes.forEach(aplicarNo);
        });
      } finally {
        aplicando = false;
      }
    });

    observador.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: atributosTraduziveis,
    });

    return () => {
      observador.disconnect();

      textosAlterados.forEach((no) => {
        const estado = estadosTexto.get(no);

        if (estado && no.isConnected && no.data === estado.traduzido) {
          no.data = estado.original;
        }
      });

      atributosAlterados.forEach(({ elemento, atributo }) => {
        const estado = estadosAtributos.get(elemento)?.get(atributo);

        if (
          estado &&
          elemento.isConnected &&
          elemento.getAttribute(atributo) === estado.traduzido
        ) {
          elemento.setAttribute(atributo, estado.original);
        }
      });
    };
  }, [language]);

  return null;
}

const FAVORITES_STORAGE_KEY = "historietas-obras-favoritas";
const COMPLETED_STORAGE_KEY = "historietas-obras-concluidas";
const VIEWED_WORKS_STORAGE_KEY = "historietas-obras-visualizacoes";
const RATED_WORKS_STORAGE_KEY = "historietas-obras-avaliacoes";
const AUTHOR_PROFILE_STORAGE_KEY = "historietas-perfis-autores";

function normalizarListaIdsEmAlta(valor: unknown) {
  return Array.isArray(valor)
    ? Array.from(
        new Set(
          valor
            .filter((id): id is string => typeof id === "string")
            .map((id) => id.trim())
            .filter(Boolean),
        ),
      )
    : [];
}

function criarStorageKeyUsuarioEmAlta(chave: string, userId: string) {
  const userIdLimpo = userId.trim();

  return userIdLimpo ? `${chave}:${userIdLimpo}` : "";
}

function normalizarChaveAutorEmAlta(valor: string) {
  return valor.trim().replace(/\s+/g, " ").toLowerCase();
}

function adicionarAvatarAutorLocalEmAlta(
  avataresPorAutor: Map<string, string>,
  chave: string,
  avatar: unknown,
) {
  const chaveLimpa = normalizarChaveAutorEmAlta(chave);
  const avatarLimpo = typeof avatar === "string" ? avatar.trim() : "";

  if (!chaveLimpa || !avatarLimpo) {
    return;
  }

  avataresPorAutor.set(chaveLimpa, avatarLimpo);
}

function carregarAvataresAutoresLocaisEmAlta(userIds: string[]) {
  const avataresPorAutor = new Map<string, string>();

  if (typeof window === "undefined") {
    return avataresPorAutor;
  }

  const chavesParaLer = Array.from(
    new Set(
      userIds
        .map((userId) => userId.trim())
        .filter(Boolean)
        .map((userId) =>
          criarStorageKeyUsuarioEmAlta(AUTHOR_PROFILE_STORAGE_KEY, userId),
        ),
    ),
  );

  chavesParaLer.forEach((chaveStorage) => {
    if (!chaveStorage) {
      return;
    }

    try {
      const texto = localStorage.getItem(chaveStorage);
      const perfis = texto ? JSON.parse(texto) : null;

      if (!perfis || typeof perfis !== "object" || Array.isArray(perfis)) {
        return;
      }

      Object.entries(perfis as Record<string, unknown>).forEach(
        ([chaveAutor, perfil]) => {
          if (!perfil || typeof perfil !== "object" || Array.isArray(perfil)) {
            return;
          }

          const registro = perfil as Record<string, unknown>;

          adicionarAvatarAutorLocalEmAlta(
            avataresPorAutor,
            chaveAutor,
            registro.avatar ??
              registro.avatar_url ??
              registro.foto_url ??
              registro.imagem_url ??
              registro.photo_url,
          );

          adicionarAvatarAutorLocalEmAlta(
            avataresPorAutor,
            typeof registro.nome === "string" ? registro.nome : "",
            registro.avatar ??
              registro.avatar_url ??
              registro.foto_url ??
              registro.imagem_url ??
              registro.photo_url,
          );
        },
      );
    } catch {
      // Avatar local é só fallback para os cards de autores.
    }
  });

  return avataresPorAutor;
}

function obterAvatarAutorLocalEmAlta(
  avataresPorAutor: Map<string, string>,
  nomeAutor: string,
  autorId: string,
) {
  const chaves = [autorId, nomeAutor, normalizarTexto(nomeAutor)]
    .map((chave) => normalizarChaveAutorEmAlta(chave))
    .filter(Boolean);

  for (const chave of chaves) {
    const avatar = avataresPorAutor.get(chave);

    if (avatar) {
      return avatar;
    }
  }

  return "";
}

function carregarListaIdsLocalEmAlta(chave: string, userId: string) {
  const userIdLimpo = userId.trim();

  if (typeof window === "undefined" || !userIdLimpo) {
    return [];
  }

  try {
    const chaveStorage = criarStorageKeyUsuarioEmAlta(chave, userIdLimpo);

    if (!chaveStorage) {
      return [];
    }

    const textoLista = localStorage.getItem(chaveStorage);
    const jsonLista: unknown = textoLista ? JSON.parse(textoLista) : [];

    return normalizarListaIdsEmAlta(jsonLista);
  } catch {
    return [];
  }
}

function salvarListaIdsLocalEmAlta(
  chave: string,
  userId: string,
  lista: string[],
) {
  const userIdLimpo = userId.trim();

  if (typeof window === "undefined" || !userIdLimpo) {
    return;
  }

  try {
    const chaveStorage = criarStorageKeyUsuarioEmAlta(chave, userIdLimpo);

    if (!chaveStorage) {
      return;
    }

    const listaNormalizada = normalizarListaIdsEmAlta(lista);

    localStorage.setItem(chaveStorage, JSON.stringify(listaNormalizada));
  } catch {
    // localStorage é fallback; o ranking continua com estado em memória.
  }
}

async function carregarIdsColecaoUsuarioSupabaseEmAlta(
  tabela: "favoritos" | "concluidas",
  userId: string,
) {
  const userIdLimpo = userId.trim();

  if (!userIdLimpo) {
    return [] as string[];
  }

  try {
    const { data, error } = await supabase
      .from(tabela)
      .select("obra_id")
      .eq("user_id", userIdLimpo)
      .limit(1000);

    if (error || !Array.isArray(data)) {
      if (error) {
        console.warn(
          `Não consegui carregar ${tabela} no Em Alta:`,
          error.message,
        );
      }

      return [] as string[];
    }

    return normalizarListaIdsEmAlta(
      data.map((registro) => {
        if (
          !registro ||
          typeof registro !== "object" ||
          Array.isArray(registro)
        ) {
          return "";
        }

        const obraId = (registro as Record<string, unknown>).obra_id;

        return typeof obraId === "string" ? obraId : "";
      }),
    );
  } catch (error) {
    console.warn(`Não consegui acessar ${tabela} no Em Alta:`, error);
    return [] as string[];
  }
}

function obterIdentificadoresObraLocalEmAlta(
  obra: Pick<ObraLocal, "id" | "slug" | "titulo">,
) {
  return Array.from(
    new Set(
      [
        obra.id,
        obra.slug,
        criarSlugBase(obra.titulo),
        normalizarTexto(obra.titulo),
      ]
        .map((id) => id.trim())
        .filter(Boolean),
    ),
  );
}

function obterIdentificadoresRankingObra(
  obra: Pick<ObraRanking, "storageId" | "titulo" | "href">,
) {
  const hrefSlug = obra.href.startsWith("/obra/")
    ? decodeURIComponent(obra.href.replace("/obra/", "").split(/[?#]/)[0] || "")
    : "";

  return Array.from(
    new Set(
      [
        obra.storageId,
        hrefSlug,
        criarSlugBase(obra.titulo),
        normalizarTexto(obra.titulo),
      ]
        .map((id) => id.trim())
        .filter(Boolean),
    ),
  );
}

function listaTemRankingObra(
  obra: Pick<ObraRanking, "storageId" | "titulo" | "href">,
  lista: string[],
) {
  const listaNormalizada = new Set(
    lista.map((id) => id.trim()).filter(Boolean),
  );

  return obterIdentificadoresRankingObra(obra).some((id) =>
    listaNormalizada.has(id),
  );
}

function removerRankingObraDaLista(
  obra: Pick<ObraRanking, "storageId" | "titulo" | "href">,
  lista: string[],
) {
  const idsObra = new Set(obterIdentificadoresRankingObra(obra));

  return normalizarListaIdsEmAlta(lista).filter((id) => !idsObra.has(id));
}

function adicionarRankingObraNaLista(
  obra: Pick<ObraRanking, "storageId" | "titulo" | "href">,
  lista: string[],
) {
  return normalizarListaIdsEmAlta([
    ...removerRankingObraDaLista(obra, lista),
    obra.storageId,
  ]);
}

async function sincronizarColecaoRankingSupabase(
  tabela: "favoritos" | "concluidas",
  obra: Pick<ObraRanking, "storageId" | "titulo"> | null,
  ativo: boolean,
) {
  try {
    const { data } = await supabase.auth.getUser();
    const userId = data.user?.id || "";
    const obraId = obra?.storageId?.trim() || "";

    if (!userId || !obraId || !idObraSupabaseValido(obraId)) {
      return;
    }

    await supabase
      .from(tabela)
      .delete()
      .eq("user_id", userId)
      .eq("obra_id", obraId);

    if (!ativo) {
      return;
    }

    const payloadBase = {
      user_id: userId,
      obra_id: obraId,
    };

    const { error } = await supabase.from(tabela).insert({
      ...payloadBase,
      visibilidade: "parcial",
    });

    if (error) {
      await supabase.from(tabela).insert(payloadBase);
    }
  } catch (error) {
    console.warn(`Não consegui sincronizar ${tabela} pelo Em Alta:`, error);
  }
}

async function registrarColecaoRankingNoDiario(
  tipo: "favoritou_obra" | "concluiu_obra",
  obra: Pick<ObraRanking, "storageId" | "titulo"> | null,
) {
  try {
    const { data } = await supabase.auth.getUser();
    const userId = data.user?.id || "";
    const obraId = obra?.storageId?.trim() || "";

    if (!userId || !obraId || !idObraSupabaseValido(obraId)) {
      return;
    }

    const payload = {
      user_id: userId,
      obra_id: obraId,
      tipo,
      texto:
        tipo === "favoritou_obra"
          ? `adicionou ${obra?.titulo || "uma obra"} à lista`
          : `concluiu ${obra?.titulo || "uma obra"}`,
      visibilidade: "parcial",
      metadata: {
        obra_titulo: obra?.titulo || "",
        origem: "em-alta",
      },
    };

    const { error } = await supabase.from("diario_atividades").insert(payload);

    if (error) {
      await supabase.from("diario_atividades").insert({
        user_id: payload.user_id,
        obra_id: payload.obra_id,
        tipo: payload.tipo,
        texto: payload.texto,
        metadata: payload.metadata,
      });
    }
  } catch {
    // O ranking não deve falhar por causa do Diário.
  }
}

function criarLoginHrefEmAlta() {
  const redirectTo =
    typeof window !== "undefined"
      ? `${window.location.pathname}${window.location.search}`
      : "/em-alta";
  const destinoSeguro =
    redirectTo && redirectTo.startsWith("/") && !redirectTo.startsWith("//")
      ? redirectTo
      : "/em-alta";
  const params = new URLSearchParams({
    redirectTo: destinoSeguro,
  });

  return `/login?${params.toString()}`;
}

function criarHrefLeituraCapitulo(
  obra: Pick<ObraLocal, "id" | "slug" | "titulo" | "publicado">,
  capitulo: CapituloLocal,
  numeroCapitulo: number,
) {
  const slugSeguro = obra.slug?.trim() || criarSlugBase(obra.titulo);

  if (
    obra.publicado &&
    idObraSupabaseValido(obra.id) &&
    slugSeguro &&
    Number.isInteger(numeroCapitulo) &&
    numeroCapitulo > 0
  ) {
    return `/obra/${encodeURIComponent(slugSeguro)}/capitulo/${numeroCapitulo}`;
  }

  return `/ler-capitulo?obraId=${encodeURIComponent(
    obra.id,
  )}&capituloId=${encodeURIComponent(capitulo.id)}`;
}

function criarLinkPerfilAutorRanking(nomeAutor: string, autorId?: string) {
  const params = new URLSearchParams();
  const nomeAutorLimpo = nomeAutor.trim();

  if (nomeAutorLimpo) {
    params.set("autor", nomeAutorLimpo);
  }

  const autorIdLimpo = autorId?.trim();

  if (autorIdLimpo) {
    params.set("autorId", autorIdLimpo);
    params.set("userId", autorIdLimpo);
  }

  const query = params.toString();

  return query ? `/perfil-autor?${query}` : "/perfil-autor";
}

function obterNomeProfileAutorRanking(
  profile?: SupabaseProfileAutorRankingRow | null,
) {
  return typeof profile?.nome === "string" && profile.nome.trim()
    ? profile.nome.trim()
    : "";
}

function obterAvatarProfileAutorRanking(
  profile?: SupabaseProfileAutorRankingRow | null,
) {
  const candidatos = [
    profile?.avatar_url,
    profile?.avatar,
    profile?.foto_url,
    profile?.imagem_url,
    profile?.photo_url,
  ];

  const avatar = candidatos.find(
    (valor): valor is string =>
      typeof valor === "string" && Boolean(valor.trim()),
  );

  return avatar?.trim() || "";
}

function adicionarProfileAutorRankingNoMapa(
  mapa: Map<string, SupabaseProfileAutorRankingRow>,
  profile: SupabaseProfileAutorRankingRow,
) {
  const userId =
    typeof profile.user_id === "string" ? profile.user_id.trim() : "";
  const id = typeof profile.id === "string" ? profile.id.trim() : "";

  if (userId) {
    mapa.set(userId, profile);
  }

  if (id) {
    mapa.set(id, profile);
  }
}

async function carregarProfilesAutoresRanking(userIds: string[]) {
  const idsUnicos = Array.from(
    new Set(userIds.map((userId) => userId.trim()).filter(Boolean)),
  );
  const profilesPorUsuario = new Map<string, SupabaseProfileAutorRankingRow>();

  if (idsUnicos.length === 0) {
    return profilesPorUsuario;
  }

  try {
    const { data, error } = await supabase
      .from("profiles")
      .select("id,user_id,nome,avatar_url")
      .in("user_id", idsUnicos)
      .limit(1000);

    if (error) {
      console.warn(
        "Não consegui carregar profiles por user_id no ranking:",
        error.message,
      );
    } else {
      ((data || []) as unknown as SupabaseProfileAutorRankingRow[]).forEach(
        (profile) => {
          adicionarProfileAutorRankingNoMapa(profilesPorUsuario, profile);
        },
      );
    }
  } catch (error) {
    console.warn(
      "Não consegui acessar profiles por user_id no ranking:",
      error,
    );
  }

  try {
    const { data, error } = await supabase
      .from("profiles")
      .select("id,user_id,nome,avatar_url")
      .in("id", idsUnicos)
      .limit(1000);

    if (error) {
      console.warn(
        "Não consegui carregar profiles por id no ranking:",
        error.message,
      );
    } else {
      ((data || []) as unknown as SupabaseProfileAutorRankingRow[]).forEach(
        (profile) => {
          adicionarProfileAutorRankingNoMapa(profilesPorUsuario, profile);
        },
      );
    }
  } catch (error) {
    console.warn("Não consegui acessar profiles por id no ranking:", error);
  }

  return profilesPorUsuario;
}

async function buscarSeguidoresAutoresRanking(autorIds: string[]) {
  const idsUnicos = Array.from(
    new Set(autorIds.map((autorId) => autorId.trim()).filter(Boolean)),
  );

  if (idsUnicos.length === 0) {
    return {} as Record<string, number>;
  }

  try {
    const { data, error } = await supabase
      .from("seguindo_usuarios")
      .select("seguido_id,seguidor_id")
      .in("seguido_id", idsUnicos)
      .limit(3000);

    if (error || !Array.isArray(data)) {
      if (error) {
        console.warn(
          "Não consegui carregar seguidores dos autores no ranking:",
          error.message,
        );
      }

      return {} as Record<string, number>;
    }

    const usuariosPorAutor = new Map<string, Set<string>>();

    data.forEach((registro) => {
      if (
        !registro ||
        typeof registro !== "object" ||
        Array.isArray(registro)
      ) {
        return;
      }

      const linha = registro as Record<string, unknown>;
      const autorId =
        typeof linha.seguido_id === "string" ? linha.seguido_id.trim() : "";
      const seguidorId =
        typeof linha.seguidor_id === "string"
          ? linha.seguidor_id.trim()
          : "";

      if (!autorId || !seguidorId) {
        return;
      }

      const usuarios = usuariosPorAutor.get(autorId) || new Set<string>();
      usuarios.add(seguidorId);
      usuariosPorAutor.set(autorId, usuarios);
    });

    return Array.from(usuariosPorAutor.entries()).reduce<Record<string, number>>(
      (contagem, [autorId, usuarios]) => {
        contagem[autorId] = usuarios.size;
        return contagem;
      },
      {},
    );
  } catch (error) {
    console.warn("Não consegui acessar seguindo_usuarios no ranking:", error);
    return {} as Record<string, number>;
  }
}

function formatarNumero(numero: number) {
  if (!Number.isFinite(numero)) {
    return "0";
  }

  return numero.toLocaleString("pt-BR");
}

function formatarMediaRanking(media: number) {
  if (!Number.isFinite(media) || media <= 0) {
    return "0";
  }

  const mediaArredondada = Math.round(media * 10) / 10;

  return Number.isInteger(mediaArredondada)
    ? String(mediaArredondada)
    : mediaArredondada.toFixed(1);
}

function normalizarVisualizacoesRanking(valor: unknown) {
  if (!valor || typeof valor !== "object" || Array.isArray(valor)) {
    return {};
  }

  return Object.entries(valor as Record<string, unknown>).reduce<
    Record<string, number>
  >((visualizacoesNormalizadas, [chave, total]) => {
    const chaveLimpa = chave.trim();
    const totalNumerico =
      typeof total === "number" && Number.isFinite(total) ? total : 0;

    if (chaveLimpa && totalNumerico > 0) {
      visualizacoesNormalizadas[chaveLimpa] = Math.round(totalNumerico);
    }

    return visualizacoesNormalizadas;
  }, {});
}

function obterVisualizacoesRegistradasObra(
  obra: ObraLocal,
  visualizacoesRegistradas: Record<string, number>,
) {
  const chavesObra = [
    obra.id,
    obra.slug,
    criarSlugBase(obra.titulo),
    normalizarTexto(obra.titulo),
  ];

  return chavesObra.reduce((maiorTotal, chave) => {
    const total = visualizacoesRegistradas[chave] || 0;

    return Math.max(maiorTotal, total);
  }, 0);
}

function normalizarAvaliacoesLocaisRanking(valor: unknown) {
  if (!valor || typeof valor !== "object" || Array.isArray(valor)) {
    return {};
  }

  return Object.entries(valor as Record<string, unknown>).reduce<
    Record<string, number>
  >((avaliacoesNormalizadas, [chave, nota]) => {
    const chaveLimpa = chave.trim();
    const notaNumerica =
      typeof nota === "number" && Number.isFinite(nota)
        ? Math.round(nota * 2) / 2
        : 0;

    if (chaveLimpa && notaNumerica >= 0.5 && notaNumerica <= 5) {
      avaliacoesNormalizadas[chaveLimpa] = notaNumerica;
    }

    return avaliacoesNormalizadas;
  }, {});
}

function obterAvaliacaoLocalRanking(
  obra: ObraLocal,
  avaliacoesLocais: Record<string, number>,
) {
  const chavesObra = [
    obra.id,
    obra.slug,
    criarSlugBase(obra.titulo),
    normalizarTexto(obra.titulo),
  ];

  return chavesObra.reduce((maiorNota, chave) => {
    const nota = avaliacoesLocais[chave] || 0;

    return Math.max(maiorNota, nota);
  }, 0);
}

function formatarDataRanking(timestamp: number) {
  if (!timestamp) {
    return "Sem data";
  }

  const data = new Date(timestamp);

  if (Number.isNaN(data.getTime())) {
    return "Sem data";
  }

  return data.toLocaleDateString("pt-BR");
}

function formatarGeneroCard(genero: string) {
  const generoLimpo = genero.trim();

  if (normalizarTexto(generoLimpo) === "fantasia sombria") {
    return "Fantasia";
  }

  return generoLimpo || "Não informado";
}

function calcularCapitulosLidos(capitulos: CapituloLocal[]) {
  return capitulos.filter((capitulo) => capitulo.lido).length;
}

function calcularProgressoLeitura(capitulos: CapituloLocal[]) {
  if (capitulos.length === 0) {
    return 0;
  }

  return Math.round(
    (calcularCapitulosLidos(capitulos) / capitulos.length) * 100,
  );
}

function normalizarTipoArquivoSupabase(
  tipo: string | null,
): ArquivoObraLocal["tipo"] {
  if (
    tipo === "imagem" ||
    tipo === "documento" ||
    tipo === "texto" ||
    tipo === "outro"
  ) {
    return tipo;
  }

  return "outro";
}

function adicionarUsuarioRanking(
  usuariosPorChave: Map<string, Set<string>>,
  chave: string,
  userId: string,
) {
  const chaveLimpa = chave.trim();
  const userIdLimpo = userId.trim();

  if (!chaveLimpa || !userIdLimpo) {
    return;
  }

  const usuarios = usuariosPorChave.get(chaveLimpa) || new Set<string>();
  usuarios.add(userIdLimpo);
  usuariosPorChave.set(chaveLimpa, usuarios);
}

function converterMapaUsuariosRanking(
  usuariosPorChave: Map<string, Set<string>>,
) {
  return Array.from(usuariosPorChave.entries()).reduce<UsuariosPorObraRanking>(
    (resultado, [chave, usuarios]) => {
      resultado[chave] = Array.from(usuarios);
      return resultado;
    },
    {},
  );
}

function contarUsuariosRanking(usuariosPorObra: UsuariosPorObraRanking) {
  return Object.entries(usuariosPorObra).reduce<Record<string, number>>(
    (contagem, [obraId, usuarios]) => {
      contagem[obraId] = new Set(
        usuarios.map((userId) => userId.trim()).filter(Boolean),
      ).size;

      return contagem;
    },
    {},
  );
}

function combinarUsuariosRanking(
  ...fontes: UsuariosPorObraRanking[]
): UsuariosPorObraRanking {
  const usuariosCombinados = new Map<string, Set<string>>();

  fontes.forEach((fonte) => {
    Object.entries(fonte).forEach(([obraId, usuarios]) => {
      usuarios.forEach((userId) => {
        adicionarUsuarioRanking(usuariosCombinados, obraId, userId);
      });
    });
  });

  return converterMapaUsuariosRanking(usuariosCombinados);
}

function contarPorObra(
  linhas: SupabaseInteracaoObraRow[],
  contarCadaRegistro = false,
): ResultadoInteracoesObrasRanking {
  const usuariosPorObra = new Map<string, Set<string>>();
  const registrosPorObra: Record<string, number> = {};

  linhas.forEach((linha) => {
    const obraId = linha.obra_id?.trim() || "";
    const userId = linha.user_id?.trim() || "";

    if (!obraId) {
      return;
    }

    if (contarCadaRegistro) {
      registrosPorObra[obraId] = (registrosPorObra[obraId] || 0) + 1;
    }

    adicionarUsuarioRanking(usuariosPorObra, obraId, userId);
  });

  const usuariosNormalizados = converterMapaUsuariosRanking(usuariosPorObra);

  return {
    porObra: contarCadaRegistro
      ? registrosPorObra
      : contarUsuariosRanking(usuariosNormalizados),
    usuariosPorObra: usuariosNormalizados,
  };
}

function calcularAvaliacoesPorObra(linhas: SupabaseAvaliacaoObraRow[]) {
  const notasPorUsuarioObra = new Map<string, number>();
  const obraPorChave = new Map<string, string>();

  linhas.forEach((linha) => {
    const obraId = linha.obra_id?.trim() || "";
    const userId = linha.user_id?.trim() || "";
    const nota =
      typeof linha.nota === "number" && Number.isFinite(linha.nota)
        ? linha.nota
        : 0;

    if (!obraId || !userId || nota <= 0) {
      return;
    }

    const chave = `${obraId}::${userId}`;
    notasPorUsuarioObra.set(chave, nota);
    obraPorChave.set(chave, obraId);
  });

  const somaPorObra: Record<string, number> = {};
  const totalPorObra: Record<string, number> = {};

  notasPorUsuarioObra.forEach((nota, chave) => {
    const obraId = obraPorChave.get(chave) || "";

    if (!obraId) {
      return;
    }

    somaPorObra[obraId] = (somaPorObra[obraId] || 0) + nota;
    totalPorObra[obraId] = (totalPorObra[obraId] || 0) + 1;
  });

  return Object.entries(totalPorObra).reduce<
    Record<string, AvaliacaoRankingObra>
  >((avaliacoes, [obraId, total]) => {
    const soma = somaPorObra[obraId] || 0;

    avaliacoes[obraId] = {
      total,
      media: total > 0 ? soma / total : 0,
    };

    return avaliacoes;
  }, {});
}

async function buscarContagemInteracoesObras(
  tabela:
    | "obra_curtidas"
    | "seguindo_obras"
    | "favoritos"
    | "comentarios_obras",
  obraIds: string[],
  contarCadaRegistro = false,
): Promise<ResultadoInteracoesObrasRanking> {
  const idsUnicos = Array.from(
    new Set(obraIds.map((obraId) => obraId.trim()).filter(Boolean)),
  );

  if (idsUnicos.length === 0) {
    return {
      porObra: {},
      usuariosPorObra: {},
    };
  }

  try {
    const linhas: SupabaseInteracaoObraRow[] = [];
    const tamanhoPagina = 1000;

    for (let inicioIds = 0; inicioIds < idsUnicos.length; inicioIds += 80) {
      const loteIds = idsUnicos.slice(inicioIds, inicioIds + 80);
      let inicio = 0;

      while (true) {
        const { data, error } = await supabase
          .from(tabela)
          .select("obra_id,user_id")
          .in("obra_id", loteIds)
          .range(inicio, inicio + tamanhoPagina - 1);

        if (error) {
          console.warn(`Não consegui carregar ${tabela}:`, error.message);
          return {
            porObra: {},
            usuariosPorObra: {},
          };
        }

        const pagina = (data || []) as unknown as SupabaseInteracaoObraRow[];
        linhas.push(...pagina);

        if (pagina.length < tamanhoPagina) {
          break;
        }

        inicio += tamanhoPagina;
      }
    }

    return contarPorObra(linhas, contarCadaRegistro);
  } catch (error) {
    console.warn(`Não consegui acessar ${tabela} agora:`, error);
    return {
      porObra: {},
      usuariosPorObra: {},
    };
  }
}

async function buscarAvaliacoesObras(obraIds: string[]) {
  if (obraIds.length === 0) {
    return {};
  }

  try {
    const { data, error } = await supabase
      .from("obra_avaliacoes")
      .select("obra_id,user_id,nota")
      .in("obra_id", obraIds)
      .limit(3000);

    if (error) {
      console.warn("Não consegui carregar obra_avaliacoes:", error.message);
      return {};
    }

    return calcularAvaliacoesPorObra(
      (data || []) as unknown as SupabaseAvaliacaoObraRow[],
    );
  } catch (error) {
    console.warn("Não consegui acessar obra_avaliacoes agora:", error);
    return {};
  }
}

async function carregarProgressoUsuarioEmAlta(
  userId: string,
  obraIds: string[],
  capituloIds: string[],
) {
  const userIdLimpo = userId.trim();

  if (
    !userIdLimpo ||
    obraIds.length === 0 ||
    capituloIds.length === 0
  ) {
    return {
      progressoPorCapitulo:
        new Map<string, SupabaseProgressoLeituraEmAltaRow>(),
      carregado: Boolean(userIdLimpo),
    };
  }

  try {
    const { data, error } = await supabase
      .from("progresso_leitura")
      .select("obra_id,capitulo_id,lido,atualizado_em")
      .eq("user_id", userIdLimpo)
      .in("obra_id", obraIds)
      .in("capitulo_id", capituloIds)
      .order("atualizado_em", { ascending: false })
      .limit(5000);

    if (error || !Array.isArray(data)) {
      if (error) {
        console.warn(
          "Não consegui carregar o progresso pessoal no Em Alta:",
          error.message,
        );
      }

      return {
        progressoPorCapitulo:
          new Map<string, SupabaseProgressoLeituraEmAltaRow>(),
        carregado: false,
      };
    }

    const progressoPorCapitulo =
      new Map<string, SupabaseProgressoLeituraEmAltaRow>();

    (data as unknown as SupabaseProgressoLeituraEmAltaRow[]).forEach(
      (registro) => {
        const obraId = registro.obra_id?.trim() || "";
        const capituloId = registro.capitulo_id?.trim() || "";
        const chave = obraId && capituloId
          ? `${obraId}::${capituloId}`
          : "";

        if (chave && !progressoPorCapitulo.has(chave)) {
          progressoPorCapitulo.set(chave, registro);
        }
      },
    );

    return {
      progressoPorCapitulo,
      carregado: true,
    };
  } catch (error) {
    console.warn(
      "Não consegui acessar o progresso pessoal no Em Alta:",
      error,
    );

    return {
      progressoPorCapitulo:
        new Map<string, SupabaseProgressoLeituraEmAltaRow>(),
      carregado: false,
    };
  }
}

function converterObraSupabaseParaLocal(
  obra: SupabaseObraRow,
  capitulos: SupabaseCapituloRow[],
  obraLocal: ObraLocal | undefined,
  index: number,
  curtidasUnicasPorObra: Record<string, number>,
  comentariosTotaisPorObra: Record<string, number>,
  salvosUnicosPorObra: Record<string, number>,
  seguidoresPorObra: Record<string, number>,
  avaliacoesPorObra: Record<string, AvaliacaoRankingObra>,
  profilesAutores: Map<string, SupabaseProfileAutorRankingRow>,
  seguidoresAutores: Record<string, number>,
  avataresLocaisAutores: Map<string, string>,
  progressoPorCapitulo:
    Map<string, SupabaseProgressoLeituraEmAltaRow>,
  progressoCarregado: boolean,
): ObraLocal {
  const capitulosLocaisPorId = new Map(
    (obraLocal?.capitulos || []).map((capitulo) => [capitulo.id, capitulo]),
  );

  let ultimoCapituloLidoId = progressoCarregado
    ? ""
    : obraLocal?.ultimoCapituloLidoId || "";
  let ultimaLeituraEm = progressoCarregado
    ? ""
    : obraLocal?.ultimaLeituraEm || "";

  const capitulosNormalizados = capitulos.map((capitulo, capituloIndex) => {
    const capituloLocal = capitulosLocaisPorId.get(capitulo.id);
    const chaveProgresso = `${obra.id}::${capitulo.id}`;
    const registroProgresso = progressoPorCapitulo.get(chaveProgresso);
    const lido = progressoCarregado
      ? registroProgresso?.lido === true
      : Boolean(capituloLocal?.lido);
    const lidoEm =
      lido && typeof registroProgresso?.atualizado_em === "string"
        ? registroProgresso.atualizado_em
        : lido
          ? capituloLocal?.lidoEm || ""
          : "";

    if (lido) {
      const tempoAtual = new Date(lidoEm).getTime();
      const tempoUltimo = new Date(ultimaLeituraEm).getTime();
      const tempoAtualSeguro = Number.isNaN(tempoAtual) ? 0 : tempoAtual;
      const tempoUltimoSeguro = Number.isNaN(tempoUltimo) ? 0 : tempoUltimo;

      if (!ultimoCapituloLidoId || tempoAtualSeguro >= tempoUltimoSeguro) {
        ultimoCapituloLidoId = capitulo.id;
        ultimaLeituraEm = lidoEm;
      }
    }

    return {
      id: capitulo.id,
      titulo:
        capitulo.titulo?.trim() ||
        `Capítulo ${capituloIndex + 1}`,
      texto: "",
      curtiu: Boolean(capituloLocal?.curtiu),
      salvo: Boolean(capituloLocal?.salvo),
      comentario: capituloLocal?.comentario || "",
      criadoEm: capitulo.criado_em || "",
      lido,
      lidoEm,
    } satisfies CapituloLocal;
  });

  const capitulosMesclados = capitulosNormalizados;
  const titulo = obra.titulo?.trim() || "Obra sem título";
  const slug =
    obra.slug?.trim() ||
    criarSlugBase(titulo || `obra-${index + 1}`);
  const arquivoUrl = obra.arquivo_url?.trim() || "";
  const arquivoTipo = normalizarTipoArquivoSupabase(obra.arquivo_categoria);
  const totalSeguidoresObra = seguidoresPorObra[obra.id] || 0;
  const avaliacaoObra = avaliacoesPorObra[obra.id] || { total: 0, media: 0 };
  const autorId = obra.user_id?.trim() || "";
  const profileAutor = autorId ? profilesAutores.get(autorId) || null : null;
  const nomeAutorProfile = obterNomeProfileAutorRanking(profileAutor);
  const nomeAutorObra = obra.autor?.trim() || "";
  const nomeAutor = nomeAutorProfile || nomeAutorObra || "Autor não informado";
  const avatarAutor =
    obterAvatarProfileAutorRanking(profileAutor) ||
    obterAvatarAutorLocalEmAlta(avataresLocaisAutores, nomeAutor, autorId) ||
    obterAvatarAutorLocalEmAlta(
      avataresLocaisAutores,
      nomeAutorObra,
      autorId,
    ) ||
    "";
  const totalSeguidoresAutor = autorId ? seguidoresAutores[autorId] || 0 : 0;

  return {
    id: obra.id || `obra-${index + 1}`,
    titulo,
    autor: nomeAutor,
    autorId,
    autorAvatarRanking: avatarAutor,
    genero: obra.genero?.trim() || "Não informado",
    formato: obra.formato?.trim() || "Não informado",
    classificacaoIndicativa:
      obra.classificacao_indicativa?.trim() ||
      "Não informada",
    sinopse:
      obra.sinopse?.trim() ||
      "Nenhuma sinopse informada.",
    tags:
      Array.isArray(obra.tags) && obra.tags.length > 0
        ? obra.tags.filter(
            (tag) => typeof tag === "string" && Boolean(tag.trim()),
          )
        : ["sem tags"],
    capa: obra.capa_url?.trim() || "",
    capaNome: obra.capa_nome?.trim() || "",
    publicado: Boolean(obra.publicado),
    capitulos: capitulosMesclados,
    criadaEm: obra.criada_em || "",
    ultimoCapituloLidoId,
    ultimaLeituraEm,
    progressoLeitura: calcularProgressoLeitura(capitulosMesclados),
    slug,
    link: obra.link?.trim() || `/obra/${slug}`,
    arquivoObra: arquivoUrl
      ? {
          nome:
            obra.arquivo_nome?.trim() ||
            "Arquivo da obra",
          tipo: arquivoTipo,
          tamanho:
            typeof obra.arquivo_tamanho === "number" &&
            Number.isFinite(obra.arquivo_tamanho)
              ? obra.arquivo_tamanho
              : 0,
          conteudo: arquivoUrl,
          enviadoEm: obra.criada_em || "",
        }
      : null,
    totalCurtidasRanking: curtidasUnicasPorObra[obra.id] || 0,
    totalComentariosRanking: comentariosTotaisPorObra[obra.id] || 0,
    totalSalvosRanking: salvosUnicosPorObra[obra.id] || 0,
    totalViewsRanking:
      typeof obra.visualizacoes === "number" &&
      Number.isFinite(obra.visualizacoes)
        ? obra.visualizacoes
        : 0,
    totalSeguidoresRanking: totalSeguidoresObra,
    totalSeguidoresAutorRanking: totalSeguidoresAutor,
    totalAvaliacoesRanking: avaliacaoObra.total,
    mediaAvaliacoesRanking: avaliacaoObra.media,
  };
}

async function carregarObrasSupabasePublicadas(
  obrasLocais: ObraLocal[],
  userId = "",
) {
  try {
    const { data: obrasBanco, error: erroObras } = await supabase
      .from("obras")
      .select(
        "id,user_id,titulo,autor,genero,formato,classificacao_indicativa,sinopse,tags,capa_url,capa_nome,arquivo_url,arquivo_nome,arquivo_tipo,arquivo_tamanho,arquivo_categoria,visualizacoes,publicado,slug,link,criada_em,atualizado_em",
      )
      .eq("publicado", true)
      .order("criada_em", { ascending: false })
      .limit(80);

    if (erroObras) {
      console.warn(
        "Não consegui carregar obras publicadas do Supabase:",
        erroObras.message,
      );
      return [] as ObraLocal[];
    }

    const obrasSupabase = (obrasBanco || []) as unknown as SupabaseObraRow[];

    if (obrasSupabase.length === 0) {
      return [] as ObraLocal[];
    }

    const obraIds = obrasSupabase.map((obra) => obra.id).filter(Boolean);
    const autorIds = obrasSupabase
      .map((obra) => obra.user_id?.trim() || "")
      .filter(Boolean);
    const avataresLocaisAutores = carregarAvataresAutoresLocaisEmAlta(autorIds);

    const { data: capitulosBanco, error: erroCapitulos } = await supabase
      .from("capitulos")
      .select(
        "id,obra_id,user_id,titulo,ordem,publicado,criado_em,atualizado_em",
      )
      .in("obra_id", obraIds)
      .eq("publicado", true)
      .order("ordem", { ascending: true })
      .limit(600);

    if (erroCapitulos) {
      console.warn(
        "Não consegui carregar capítulos publicados do ranking:",
        erroCapitulos.message,
      );
    }

    const capitulosSupabase = erroCapitulos
      ? []
      : ((capitulosBanco || []) as unknown as SupabaseCapituloRow[]);
    const capituloIds = capitulosSupabase
      .map((capitulo) => capitulo.id)
      .filter(Boolean);
    const [
      curtidasObraResultado,
      seguidoresObraResultado,
      favoritosObraResultado,
      comentariosObraResultado,
      avaliacoesPorObra,
      profilesAutores,
      seguidoresAutores,
      progressoUsuario,
    ] = await Promise.all([
      buscarContagemInteracoesObras("obra_curtidas", obraIds),
      buscarContagemInteracoesObras("seguindo_obras", obraIds),
      buscarContagemInteracoesObras("favoritos", obraIds),
      buscarContagemInteracoesObras("comentarios_obras", obraIds, true),
      buscarAvaliacoesObras(obraIds),
      carregarProfilesAutoresRanking(autorIds),
      buscarSeguidoresAutoresRanking(autorIds),
      carregarProgressoUsuarioEmAlta(userId, obraIds, capituloIds),
    ]);

    const curtidasUnicasPorObra = curtidasObraResultado.porObra;
    const comentariosTotaisPorObra = comentariosObraResultado.porObra;
    const usuariosSalvosPorObra = combinarUsuariosRanking(
      seguidoresObraResultado.usuariosPorObra,
      favoritosObraResultado.usuariosPorObra,
    );
    const salvosUnicosPorObra = contarUsuariosRanking(usuariosSalvosPorObra);

    const capitulosPorObra = capitulosSupabase.reduce<
      Record<string, SupabaseCapituloRow[]>
    >((grupos, capitulo) => {
      if (!grupos[capitulo.obra_id]) {
        grupos[capitulo.obra_id] = [];
      }

      grupos[capitulo.obra_id].push(capitulo);

      return grupos;
    }, {});

    const obrasLocaisPorId = new Map(
      obrasLocais.map((obra) => [obra.id, obra]),
    );
    const obrasLocaisPorSlug = new Map(
      obrasLocais.map((obra) => [obra.slug, obra]),
    );

    return obrasSupabase
      .map((obra, index) => {
        const slug =
          obra.slug?.trim() || criarSlugBase(obra.titulo || `obra-${index + 1}`);
        const obraLocal =
          obrasLocaisPorId.get(obra.id) || obrasLocaisPorSlug.get(slug);

        return converterObraSupabaseParaLocal(
          obra,
          capitulosPorObra[obra.id] || [],
          obraLocal,
          index,
          curtidasUnicasPorObra,
          comentariosTotaisPorObra,
          salvosUnicosPorObra,
          seguidoresObraResultado.porObra,
          avaliacoesPorObra,
          profilesAutores,
          seguidoresAutores,
          avataresLocaisAutores,
          progressoUsuario.progressoPorCapitulo,
          progressoUsuario.carregado,
        );
      })
      .filter((obra) => obra.capitulos.length > 0 || Boolean(obra.arquivoObra));
  } catch (error) {
    console.warn("Não consegui acessar o Supabase no Em Alta agora:", error);
    return [] as ObraLocal[];
  }
}

function encontrarCapituloParaContinuar(obra: ObraLocal) {
  const temCapituloLido = obra.capitulos.some((capitulo) => capitulo.lido);

  if (!temCapituloLido) {
    return null;
  }

  const indiceUltimoCapituloLido = obra.ultimoCapituloLidoId
    ? obra.capitulos.findIndex(
        (capitulo) => capitulo.id === obra.ultimoCapituloLidoId,
      )
    : -1;

  if (indiceUltimoCapituloLido >= 0) {
    const proximoCapituloNaoLido = obra.capitulos
      .slice(indiceUltimoCapituloLido + 1)
      .find((capitulo) => !capitulo.lido);

    if (proximoCapituloNaoLido) {
      return proximoCapituloNaoLido;
    }
  }

  return obra.capitulos.find((capitulo) => !capitulo.lido) || null;
}

function criarRankingCoverStyle(
  capa: string,
  isDesktop = false,
  _posicao = 5,
): CSSProperties {
  const baseStyle = isDesktop ? desktopCoverStyle : coverStyle;

  if (!capa) {
    return {
      ...baseStyle,
      backgroundColor: "var(--historietas-em-alta-hex-04000a, #04000A)",
      backgroundImage: "linear-gradient(135deg, var(--historietas-em-alta-hex-08030f, #08030F) 0%, var(--historietas-em-alta-hex-04000a, #04000A) 100%)",
      border: "none",
    };
  }

  return {
    ...baseStyle,
    backgroundColor: "var(--historietas-em-alta-hex-04000a, #04000A)",
    backgroundImage: `url(${capa})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    border: "none",
  };
}

function ordenarRanking(lista: ObraRanking[], tipo: TipoRanking) {
  const novaLista = [...lista];

  if (tipo === "geral") {
    return novaLista.sort((obraA, obraB) => obraB.pontuacao - obraA.pontuacao);
  }

  if (tipo === "lidas") {
    return novaLista.sort((obraA, obraB) => obraB.views - obraA.views);
  }

  if (tipo === "curtidas") {
    return novaLista.sort((obraA, obraB) => obraB.curtidas - obraA.curtidas);
  }

  if (tipo === "comentadas") {
    return novaLista.sort(
      (obraA, obraB) => obraB.comentarios - obraA.comentarios,
    );
  }

  if (tipo === "salvas") {
    return novaLista.sort((obraA, obraB) => obraB.salvos - obraA.salvos);
  }

  if (tipo === "recentes") {
    return novaLista.sort(
      (obraA, obraB) => obraB.criadaEmTimestamp - obraA.criadaEmTimestamp,
    );
  }

  if (tipo === "capitulos") {
    return novaLista.sort((obraA, obraB) => obraB.capitulos - obraA.capitulos);
  }

  return novaLista;
}

function pegarTopRanking(lista: ObraRanking[], tipo: TipoRanking) {
  return ordenarRanking(lista, tipo).slice(0, 5);
}

function rankingTemInteracaoReal(obra: ObraRanking) {
  return (
    obra.views > 0 ||
    obra.curtidas > 0 ||
    obra.comentarios > 0 ||
    obra.salvos > 0 ||
    obra.avaliacoes > 0 ||
    obra.mediaAvaliacao > 0
  );
}

function criarDecoracaoPaginaStyle(index: number): CSSProperties {
  const posicoes: CSSProperties[] = [
    {
      top: "32%",
      right: "-18px",
      fontSize: "72px",
      transform: "rotate(-14deg)",
    },
    { top: "64%", left: "-16px", fontSize: "58px", transform: "rotate(12deg)" },
  ];

  return {
    position: "absolute",
    color: "var(--historietas-em-alta-rgba-139-92-246-0-18, rgba(139, 92, 246, 0.18))",
    opacity: 0.035,
    lineHeight: 1,
    fontWeight: 950,
    filter: "none",
    userSelect: "none",
    ...posicoes[index % posicoes.length],
  };
}

function LoadingSpinner({ label = "Carregando" }: { label?: string }) {
  return (
    <div
      role="status"
      aria-live="polite"
      aria-label={label}
      style={loadingPageStyle}
    >
      <span
        className="historietas-loading-spinner"
        style={loadingSpinnerStyle}
        aria-hidden="true"
      />
    </div>
  );
}

export default function EmAltaPage() {
  const router = useRouter();
  const [obrasLocais, setObrasLocais] = useState<ObraLocal[]>([]);
  const [obrasFavoritas, setObrasFavoritas] = useState<string[]>([]);
  const [obrasConcluidas, setObrasConcluidas] = useState<string[]>([]);
  const [visualizacoesRegistradas, setVisualizacoesRegistradas] = useState<
    Record<string, number>
  >({});
  const [avaliacoesLocaisRegistradas, setAvaliacoesLocaisRegistradas] =
    useState<Record<string, number>>({});
  const [isDesktop, setIsDesktop] = useState(false);
  const [carregandoRanking, setCarregandoRanking] = useState(true);
  const [usuarioLogado, setUsuarioLogado] = useState(false);
  const [usuarioLogadoId, setUsuarioLogadoId] = useState("");
  const { pageThemeStyle } = useHistorietasTheme(pageStyle);

  useEffect(() => {
    const mediaQuery = window.matchMedia("(min-width: 1024px)");

    const atualizarModoDesktop = () => {
      setIsDesktop(mediaQuery.matches);
    };

    const atualizarModoDesktopTimer = window.setTimeout(
      atualizarModoDesktop,
      0,
    );

    if (typeof mediaQuery.addEventListener === "function") {
      mediaQuery.addEventListener("change", atualizarModoDesktop);

      return () => {
        window.clearTimeout(atualizarModoDesktopTimer);
        mediaQuery.removeEventListener("change", atualizarModoDesktop);
      };
    }

    mediaQuery.addListener(atualizarModoDesktop);

    return () => {
      window.clearTimeout(atualizarModoDesktopTimer);
      mediaQuery.removeListener(atualizarModoDesktop);
    };
  }, [usuarioLogadoId]);

  useEffect(() => {
    let ativo = true;

    async function verificarUsuarioLogado() {
      try {
        const { data } = await supabase.auth.getUser();

        window.setTimeout(() => {
          if (ativo) {
            setUsuarioLogado(Boolean(data.user));
            setUsuarioLogadoId(data.user?.id || "");
          }
        }, 0);
      } catch {
        window.setTimeout(() => {
          if (ativo) {
            setUsuarioLogado(false);
            setUsuarioLogadoId("");
          }
        }, 0);
      }
    }

    void verificarUsuarioLogado();

    return () => {
      ativo = false;
    };
  }, []);

  useEffect(() => {
    let cancelado = false;

    async function carregarRanking() {
      window.setTimeout(() => {
        if (!cancelado) {
          setCarregandoRanking(true);
        }
      }, 0);

      try {
        const obrasNormalizadas: ObraLocal[] = [];
        let userIdAtual = usuarioLogadoId;

        if (!userIdAtual) {
          try {
            const { data } = await supabase.auth.getUser();
            userIdAtual = data.user?.id || "";
          } catch {
            userIdAtual = "";
          }
        }

        const [favoritosSupabase, concluidasSupabase] = await Promise.all([
          carregarIdsColecaoUsuarioSupabaseEmAlta("favoritos", userIdAtual),
          carregarIdsColecaoUsuarioSupabaseEmAlta("concluidas", userIdAtual),
        ]);

        const obrasFavoritasNormalizadas = normalizarListaIdsEmAlta([
          ...carregarListaIdsLocalEmAlta(FAVORITES_STORAGE_KEY, userIdAtual),
          ...favoritosSupabase,
        ]);

        const obrasConcluidasNormalizadas = normalizarListaIdsEmAlta([
          ...carregarListaIdsLocalEmAlta(COMPLETED_STORAGE_KEY, userIdAtual),
          ...concluidasSupabase,
        ]);

        salvarListaIdsLocalEmAlta(
          FAVORITES_STORAGE_KEY,
          userIdAtual,
          obrasFavoritasNormalizadas,
        );
        salvarListaIdsLocalEmAlta(
          COMPLETED_STORAGE_KEY,
          userIdAtual,
          obrasConcluidasNormalizadas,
        );

        const chaveVisualizacoesUsuario = userIdAtual
          ? criarStorageKeyUsuarioEmAlta(VIEWED_WORKS_STORAGE_KEY, userIdAtual)
          : "";
        const visualizacoesTexto = chaveVisualizacoesUsuario
          ? localStorage.getItem(chaveVisualizacoesUsuario)
          : null;
        const visualizacoesJson = visualizacoesTexto
          ? JSON.parse(visualizacoesTexto)
          : {};
        const visualizacoesNormalizadas =
          normalizarVisualizacoesRanking(visualizacoesJson);

        const chaveAvaliacoesUsuario = userIdAtual
          ? criarStorageKeyUsuarioEmAlta(RATED_WORKS_STORAGE_KEY, userIdAtual)
          : "";
        const avaliacoesLocaisTexto = chaveAvaliacoesUsuario
          ? localStorage.getItem(chaveAvaliacoesUsuario)
          : null;
        const avaliacoesLocaisJson = avaliacoesLocaisTexto
          ? JSON.parse(avaliacoesLocaisTexto)
          : {};
        const avaliacoesLocaisNormalizadas =
          normalizarAvaliacoesLocaisRanking(avaliacoesLocaisJson);

        window.setTimeout(() => {
          if (!cancelado) {
            setUsuarioLogado(Boolean(userIdAtual));
            setUsuarioLogadoId(userIdAtual);
            setObrasLocais(obrasNormalizadas);
            setObrasFavoritas(obrasFavoritasNormalizadas);
            setObrasConcluidas(obrasConcluidasNormalizadas);
            setVisualizacoesRegistradas(visualizacoesNormalizadas);
            setAvaliacoesLocaisRegistradas(avaliacoesLocaisNormalizadas);
          }
        }, 0);

        const obrasComSupabase =
          await carregarObrasSupabasePublicadas(
            obrasNormalizadas,
            userIdAtual,
          );

        window.setTimeout(() => {
          if (!cancelado) {
            setObrasLocais(obrasComSupabase);
          }
        }, 0);
      } catch {
        window.setTimeout(() => {
          if (!cancelado) {
            setObrasLocais([]);
            setObrasFavoritas([]);
            setObrasConcluidas([]);
            setVisualizacoesRegistradas({});
            setAvaliacoesLocaisRegistradas({});
          }
        }, 0);
      } finally {
        window.setTimeout(() => {
          if (!cancelado) {
            setCarregandoRanking(false);
          }
        }, 0);
      }
    }

    void carregarRanking();

    return () => {
      cancelado = true;
    };
  }, []);

  const ranking = useMemo<ObraRanking[]>(() => {
    return obrasLocais
      .filter((obra) => obra.publicado)
      .map((obra) => {
        const totalCurtidas = Math.max(0, obra.totalCurtidasRanking || 0);
        const totalComentarios = Math.max(0, obra.totalComentariosRanking || 0);
        const totalSalvos = Math.max(0, obra.totalSalvosRanking || 0);
        const avaliacaoLocalObra = obterAvaliacaoLocalRanking(
          obra,
          avaliacoesLocaisRegistradas,
        );
        const totalAvaliacoes = Math.max(
          0,
          obra.totalAvaliacoesRanking || 0,
          avaliacaoLocalObra > 0 ? 1 : 0,
        );
        const mediaAvaliacoes = Math.max(
          0,
          Math.min(
            5,
            Math.max(obra.mediaAvaliacoesRanking || 0, avaliacaoLocalObra),
          ),
        );

        const visualizacoesRegistradasObra = obterVisualizacoesRegistradasObra(
          obra,
          visualizacoesRegistradas,
        );
        const capitulosLidos = calcularCapitulosLidos(obra.capitulos);
        const visualizacoes = Math.max(
          obra.totalViewsRanking || 0,
          visualizacoesRegistradasObra,
        );
        const progressoLeitura = calcularProgressoLeitura(obra.capitulos);
        const capituloParaContinuar = encontrarCapituloParaContinuar(obra);
        const ultimoCapituloLidoTitulo = capituloParaContinuar
          ? capituloParaContinuar.titulo
          : "";
        const indiceCapituloParaContinuar = capituloParaContinuar
          ? obra.capitulos.findIndex(
              (capitulo) => capitulo.id === capituloParaContinuar.id,
            )
          : -1;
        const numeroCapituloParaContinuar =
          indiceCapituloParaContinuar >= 0
            ? indiceCapituloParaContinuar + 1
            : 1;
        const ultimoCapituloLidoHref = capituloParaContinuar
          ? criarHrefLeituraCapitulo(
              obra,
              capituloParaContinuar,
              numeroCapituloParaContinuar,
            )
          : "";
        const ultimaLeituraEm =
          obra.ultimaLeituraEm || capituloParaContinuar?.lidoEm || "";

        const criadaEmTimestamp = new Date(obra.criadaEm).getTime();
        const dataValida = Number.isNaN(criadaEmTimestamp)
          ? 0
          : criadaEmTimestamp;

        const pontuacao =
          totalCurtidas * 2 +
          totalComentarios * 3 +
          totalSalvos * 4 +
          visualizacoes * 1 +
          totalAvaliacoes * 4 +
          Math.round(mediaAvaliacoes * 4);

        return {
          id: `local-${obra.id}`,
          storageId: obra.id,
          tipo: "local",
          titulo: obra.titulo,
          autor: obra.autor,
          autorId: obra.autorId || "",
          autorAvatar: obra.autorAvatarRanking || "",
          seguidoresAutor: obra.totalSeguidoresAutorRanking || 0,
          genero: obra.genero,
          formato: obra.formato,
          classificacaoIndicativa: obra.classificacaoIndicativa,
          status: "Publicado",
          href: obra.link || `/obra/${obra.slug}`,
          disponivel: true,
          capa: obra.capa,
          capaNome: obra.capaNome,
          capitulos: obra.capitulos.length,
          capitulosLidos,
          progressoLeitura,
          ultimoCapituloLidoTitulo,
          ultimoCapituloLidoHref,
          ultimaLeituraEm,
          curtidas: totalCurtidas,
          comentarios: totalComentarios,
          salvos: totalSalvos,
          views: visualizacoes,
          avaliacoes: totalAvaliacoes,
          mediaAvaliacao: mediaAvaliacoes,
          pontuacao,
          criadaEmTimestamp: dataValida,
        } satisfies ObraRanking;
      });
  }, [avaliacoesLocaisRegistradas, obrasLocais, visualizacoesRegistradas]);

  const rankingAutores = useMemo<AutorRanking[]>(() => {
    type AutorRankingAcumulado = AutorRanking & {
      somaNotas: number;
      pesoNotas: number;
    };

    const autoresPorChave = new Map<string, AutorRankingAcumulado>();

    ranking.forEach((obra) => {
      const nome = obra.autor.trim();
      const nomeNormalizado = normalizarTexto(nome);

      if (!nome || nomeNormalizado === "autor nao informado") {
        return;
      }

      const autorId = obra.autorId?.trim() || "";
      const chave = autorId || `nome:${nomeNormalizado}`;
      const pesoNota =
        obra.avaliacoes > 0 ? obra.avaliacoes : obra.mediaAvaliacao > 0 ? 1 : 0;
      const existente = autoresPorChave.get(chave);

      if (!existente) {
        autoresPorChave.set(chave, {
          id: chave,
          nome,
          autorId,
          avatar: obra.autorAvatar,
          href: criarLinkPerfilAutorRanking(nome, autorId),
          obras: 1,
          capitulos: obra.capitulos,
          seguidores: obra.seguidoresAutor,
          seguidoresObras: obra.salvos,
          views: obra.views,
          curtidas: obra.curtidas,
          comentarios: obra.comentarios,
          avaliacoes: obra.avaliacoes,
          mediaAvaliacao: 0,
          pontuacao: 0,
          somaNotas: obra.mediaAvaliacao * pesoNota,
          pesoNotas: pesoNota,
        });

        return;
      }

      existente.obras += 1;
      existente.capitulos += obra.capitulos;
      existente.seguidores = Math.max(
        existente.seguidores,
        obra.seguidoresAutor,
      );
      existente.seguidoresObras += obra.salvos;
      existente.views += obra.views;
      existente.curtidas += obra.curtidas;
      existente.comentarios += obra.comentarios;
      existente.avaliacoes += obra.avaliacoes;
      existente.somaNotas += obra.mediaAvaliacao * pesoNota;
      existente.pesoNotas += pesoNota;

      if (!existente.avatar && obra.autorAvatar) {
        existente.avatar = obra.autorAvatar;
      }

      if (!existente.autorId && autorId) {
        existente.autorId = autorId;
        existente.href = criarLinkPerfilAutorRanking(existente.nome, autorId);
      }
    });

    return Array.from(autoresPorChave.values())
      .map((autor) => {
        const mediaAvaliacao =
          autor.pesoNotas > 0 ? autor.somaNotas / autor.pesoNotas : 0;
        const pontuacao =
          autor.obras * 1 +
          autor.seguidores * 4 +
          autor.seguidoresObras * 4 +
          autor.views * 1 +
          autor.curtidas * 2 +
          autor.comentarios * 3 +
          autor.avaliacoes * 4 +
          Math.round(mediaAvaliacao * 4);

        const {
          somaNotas: _somaNotas,
          pesoNotas: _pesoNotas,
          ...autorFinal
        } = autor;
        void _somaNotas;
        void _pesoNotas;

        return {
          ...autorFinal,
          mediaAvaliacao,
          pontuacao,
        };
      })
      .sort((autorA, autorB) => {
        if (autorB.pontuacao !== autorA.pontuacao) {
          return autorB.pontuacao - autorA.pontuacao;
        }

        if (autorB.views !== autorA.views) {
          return autorB.views - autorA.views;
        }

        return autorA.nome.localeCompare(autorB.nome, "pt-BR");
      })
      .slice(0, 5);
  }, [ranking]);

  const obrasFavoritasProtegidas = usuarioLogado ? obrasFavoritas : [];
  const obrasConcluidasProtegidas = usuarioLogado ? obrasConcluidas : [];

  const rankingGeral = useMemo(
    () => pegarTopRanking(ranking, "geral"),
    [ranking],
  );

  const rankingMaisLidas = useMemo(
    () => pegarTopRanking(ranking, "lidas"),
    [ranking],
  );

  const rankingMaisCurtidas = useMemo(
    () => pegarTopRanking(ranking, "curtidas"),
    [ranking],
  );

  const rankingMaisComentadas = useMemo(
    () => pegarTopRanking(ranking, "comentadas"),
    [ranking],
  );

  const rankingMaisSalvas = useMemo(
    () => pegarTopRanking(ranking, "salvas"),
    [ranking],
  );

  const rankingMaisRecentes = useMemo(
    () => pegarTopRanking(ranking, "recentes"),
    [ranking],
  );

  const rankingMaisCapitulos = useMemo(
    () => pegarTopRanking(ranking, "capitulos"),
    [ranking],
  );

  const rankingTemAtividadeReal = useMemo(() => {
    return ranking.some((obra) => rankingTemInteracaoReal(obra));
  }, [ranking]);

  const rankingParaCatalogoInicial = useMemo(() => {
    return rankingMaisRecentes.length > 0 ? rankingMaisRecentes : rankingGeral;
  }, [rankingGeral, rankingMaisRecentes]);

  const tituloCabecalho = carregandoRanking
    ? "ISTORIETAS"
    : rankingTemAtividadeReal
      ? "ISTORIETAS POPULARES"
      : "ISTORIETAS PUBLICADAS";

  function avisarLoginRanking() {
    router.push(criarLoginHrefEmAlta());
  }

  async function usuarioTemSessaoAtiva() {
    try {
      const { data } = await supabase.auth.getUser();
      const userId = data.user?.id || "";
      const logado = Boolean(userId);

      setUsuarioLogado(logado);
      setUsuarioLogadoId(userId);

      return logado;
    } catch {
      setUsuarioLogado(false);
      setUsuarioLogadoId("");

      return false;
    }
  }

  async function alternarFavorito(obraId: string) {
    const logado = await usuarioTemSessaoAtiva();

    if (!logado) {
      avisarLoginRanking();
      return;
    }

    const obraRanking =
      ranking.find((obra) => {
        return obra.storageId === obraId || obra.id === obraId;
      }) || null;

    const obraVaiFicarFavorita = obraRanking
      ? !listaTemRankingObra(obraRanking, obrasFavoritas)
      : !obrasFavoritas.includes(obraId);

    const novasObrasFavoritas = obraRanking
      ? obraVaiFicarFavorita
        ? adicionarRankingObraNaLista(obraRanking, obrasFavoritas)
        : removerRankingObraDaLista(obraRanking, obrasFavoritas)
      : obraVaiFicarFavorita
        ? normalizarListaIdsEmAlta([...obrasFavoritas, obraId])
        : obrasFavoritas.filter((id) => id !== obraId);

    salvarListaIdsLocalEmAlta(
      FAVORITES_STORAGE_KEY,
      usuarioLogadoId,
      novasObrasFavoritas,
    );

    setObrasFavoritas(novasObrasFavoritas);

    void sincronizarColecaoRankingSupabase(
      "favoritos",
      obraRanking,
      obraVaiFicarFavorita,
    );

    if (obraVaiFicarFavorita) {
      void registrarColecaoRankingNoDiario("favoritou_obra", obraRanking);
    }
  }

  async function alternarConcluido(obraId: string) {
    const logado = await usuarioTemSessaoAtiva();

    if (!logado) {
      avisarLoginRanking();
      return;
    }

    const obraRanking =
      ranking.find((obra) => {
        return obra.storageId === obraId || obra.id === obraId;
      }) || null;

    const obraVaiFicarConcluida = obraRanking
      ? !listaTemRankingObra(obraRanking, obrasConcluidas)
      : !obrasConcluidas.includes(obraId);

    const novasObrasConcluidas = obraRanking
      ? obraVaiFicarConcluida
        ? adicionarRankingObraNaLista(obraRanking, obrasConcluidas)
        : removerRankingObraDaLista(obraRanking, obrasConcluidas)
      : obraVaiFicarConcluida
        ? normalizarListaIdsEmAlta([...obrasConcluidas, obraId])
        : obrasConcluidas.filter((id) => id !== obraId);

    salvarListaIdsLocalEmAlta(
      COMPLETED_STORAGE_KEY,
      usuarioLogadoId,
      novasObrasConcluidas,
    );

    setObrasConcluidas(novasObrasConcluidas);

    void sincronizarColecaoRankingSupabase(
      "concluidas",
      obraRanking,
      obraVaiFicarConcluida,
    );

    if (obraVaiFicarConcluida) {
      void registrarColecaoRankingNoDiario("concluiu_obra", obraRanking);
    }
  }

  if (carregandoRanking) {
    return (
      <main
        className="historietas-em-alta-page"
        data-historietas-em-alta-root="true"
        style={pageThemeStyle}
        aria-busy="true"
      >
        <style>{`${historietasThemeCss}${emAltaPageCss}`}</style>
        <EmAltaLanguageBridge />
        <LoadingSpinner label="Carregando Em Alta" />
      </main>
    );
  }

  return (
    <main
      className="historietas-em-alta-page"
      data-historietas-em-alta-root="true"
      style={pageThemeStyle}
    >
      <style>{`${historietasThemeCss}${emAltaPageCss}`}</style>
      <EmAltaLanguageBridge />

      <div style={pageDecorationLayerStyle} aria-hidden="true">
        {["#", "★"].map((decoracao, index) => (
          <span
            key={`${decoracao}-${index}`}
            style={criarDecoracaoPaginaStyle(index)}
          >
            {decoracao}
          </span>
        ))}
      </div>

      {isDesktop && <div style={desktopTopWaterFadeStyle} aria-hidden="true" />}

      {!isDesktop && <div style={mobileTopWaterFadeStyle} aria-hidden="true" />}

      <section style={isDesktop ? desktopContainerStyle : containerStyle}>
        <header style={isDesktop ? desktopTitleHeaderStyle : titleHeaderStyle}>
          <Link
            href="/"
            style={
              isDesktop ? desktopHeaderTitleLinkStyle : headerTitleLinkStyle
            }
            aria-label="Voltar para a Home"
          >
            <span
              className="historietas-em-alta-logo-mark"
              style={
                isDesktop ? desktopHeaderTitleMarkStyle : headerTitleMarkStyle
              }
            >
              H
            </span>
            <span
              className="historietas-em-alta-hero-title"
              style={
                isDesktop ? desktopHeaderTitleTextStyle : headerTitleTextStyle
              }
            >
              {tituloCabecalho}
            </span>
          </Link>

        </header>

        {!carregandoRanking && ranking.length > 0 && rankingTemAtividadeReal && (
          <>
            <AutoresEmAltaSection
              autores={rankingAutores}
              isDesktop={isDesktop}
            />

            <RankingSection
              titulo="Ranking Mestre"
              descricao=""
              obras={rankingGeral}
              tipo="geral"
              obrasFavoritas={obrasFavoritasProtegidas}
              obrasConcluidas={obrasConcluidasProtegidas}
              onAlternarFavorito={alternarFavorito}
              onAlternarConcluido={alternarConcluido}
              isDesktop={isDesktop}
            />

            <RankingSection
              titulo="Alcance Dominante"
              descricao="As histórias que mais chamaram atenção dos leitores."
              obras={rankingMaisLidas}
              tipo="lidas"
              obrasFavoritas={obrasFavoritasProtegidas}
              obrasConcluidas={obrasConcluidasProtegidas}
              onAlternarFavorito={alternarFavorito}
              onAlternarConcluido={alternarConcluido}
              isDesktop={isDesktop}
            />

            <RankingSection
              titulo="Preferidas do Público"
              descricao="As obras que mais receberam curtidas e reações positivas."
              obras={rankingMaisCurtidas}
              tipo="curtidas"
              obrasFavoritas={obrasFavoritasProtegidas}
              obrasConcluidas={obrasConcluidasProtegidas}
              onAlternarFavorito={alternarFavorito}
              onAlternarConcluido={alternarConcluido}
              isDesktop={isDesktop}
            />

            <RankingSection
              titulo="Mais Comentadas"
              descricao="As histórias que mais puxaram conversa entre os leitores."
              obras={rankingMaisComentadas}
              tipo="comentadas"
              obrasFavoritas={obrasFavoritasProtegidas}
              obrasConcluidas={obrasConcluidasProtegidas}
              onAlternarFavorito={alternarFavorito}
              onAlternarConcluido={alternarConcluido}
              isDesktop={isDesktop}
            />

            <RankingSection
              titulo="Mais Seguidas"
              descricao="Obras que mais leitores decidiram acompanhar."
              obras={rankingMaisSalvas}
              tipo="salvas"
              obrasFavoritas={obrasFavoritasProtegidas}
              obrasConcluidas={obrasConcluidasProtegidas}
              onAlternarFavorito={alternarFavorito}
              onAlternarConcluido={alternarConcluido}
              isDesktop={isDesktop}
            />

            <RankingSection
              titulo="Novas Promessas"
              descricao="Publicações recentes começando a aparecer no radar."
              obras={rankingMaisRecentes}
              tipo="recentes"
              obrasFavoritas={obrasFavoritasProtegidas}
              obrasConcluidas={obrasConcluidasProtegidas}
              onAlternarFavorito={alternarFavorito}
              onAlternarConcluido={alternarConcluido}
              isDesktop={isDesktop}
            />

            <RankingSection
              titulo="Grandes Jornadas"
              descricao="Histórias com mais capítulos e conteúdo publicado."
              obras={rankingMaisCapitulos}
              tipo="capitulos"
              obrasFavoritas={obrasFavoritasProtegidas}
              obrasConcluidas={obrasConcluidasProtegidas}
              onAlternarFavorito={alternarFavorito}
              onAlternarConcluido={alternarConcluido}
              isDesktop={isDesktop}
            />
          </>
        )}

        {!carregandoRanking && ranking.length > 0 && !rankingTemAtividadeReal && (
          <>
            <p
              style={{
                margin: "10px 0 18px",
                color: "#FFFFFF",
                fontSize: "12px",
                fontWeight: 800,
                textAlign: "center",
              }}
            >
              Catálogo em formação
            </p>

            <RankingSection
              titulo="Obras publicadas"
              descricao="Catálogo inicial com obras publicadas no HISTORIETAS."
              obras={rankingParaCatalogoInicial}
              tipo="recentes"
              obrasFavoritas={obrasFavoritasProtegidas}
              obrasConcluidas={obrasConcluidasProtegidas}
              onAlternarFavorito={alternarFavorito}
              onAlternarConcluido={alternarConcluido}
              isDesktop={isDesktop}
            />
          </>
        )}

        {!carregandoRanking && ranking.length === 0 && (
          <p
            style={{
              margin: "10px 0 0",
              color: "#FFFFFF",
              fontSize: "12px",
              fontWeight: 800,
              textAlign: "center",
            }}
          >
            Ainda não há obras publicadas
          </p>
        )}
      </section>
    </main>
  );
}

function obterTemaRanking(tipo: TipoRanking) {
  if (tipo === "geral") {
    return {
      icone: "👑",
      label: "Ranking Mestre",
      titleColor: "var(--historietas-accent, var(--historietas-em-alta-hex-fdba74, #FDBA74))",
      accent: "var(--historietas-accent, var(--historietas-em-alta-hex-fdba74, #FDBA74))",
      border:
        "color-mix(in srgb, var(--historietas-accent, var(--historietas-em-alta-hex-f97316, #F97316)) 42%, transparent)",
      borderStrong:
        "color-mix(in srgb, var(--historietas-accent, var(--historietas-em-alta-hex-f97316, #F97316)) 58%, transparent)",
      glow: "color-mix(in srgb, var(--historietas-accent, var(--historietas-em-alta-hex-f97316, #F97316)) 12%, transparent)",
      background:
        "linear-gradient(135deg, var(--historietas-em-alta-rgba-41-27-53-0-82, rgba(41,27,53,0.82)) 0%, var(--historietas-em-alta-rgba-18-12-30-0-92, rgba(18,12,30,0.92)) 100%)",
    };
  }

  if (tipo === "lidas") {
    return {
      icone: "👁",
      label: "Alcance",
      titleColor: "#FFFFFF",
      accent: "var(--historietas-em-alta-hex-38bdf8, #38BDF8)",
      border: "var(--historietas-em-alta-rgba-56-189-248-0-42, rgba(56,189,248,0.42))",
      borderStrong: "var(--historietas-em-alta-rgba-56-189-248-0-58, rgba(56,189,248,0.58))",
      glow: "var(--historietas-em-alta-rgba-56-189-248-0-12, rgba(56,189,248,0.12))",
      background:
        "linear-gradient(135deg, var(--historietas-em-alta-rgba-18-36-54-0-82, rgba(18,36,54,0.82)) 0%, var(--historietas-em-alta-rgba-11-17-32-0-92, rgba(11,17,32,0.92)) 100%)",
    };
  }

  if (tipo === "curtidas") {
    return {
      icone: "❤",
      label: "Reação",
      titleColor: "#FFFFFF",
      accent: "var(--historietas-em-alta-hex-fb7185, #FB7185)",
      border: "var(--historietas-em-alta-rgba-251-113-133-0-42, rgba(251,113,133,0.42))",
      borderStrong: "var(--historietas-em-alta-rgba-251-113-133-0-58, rgba(251,113,133,0.58))",
      glow: "var(--historietas-em-alta-rgba-251-113-133-0-12, rgba(251,113,133,0.12))",
      background:
        "linear-gradient(135deg, var(--historietas-em-alta-rgba-54-20-38-0-82, rgba(54,20,38,0.82)) 0%, var(--historietas-em-alta-rgba-29-13-27-0-92, rgba(29,13,27,0.92)) 100%)",
    };
  }

  if (tipo === "comentadas") {
    return {
      icone: "💬",
      label: "Discussão",
      titleColor: "#FFFFFF",
      accent: "var(--historietas-em-alta-hex-c084fc, #C084FC)",
      border: "var(--historietas-em-alta-rgba-192-132-252-0-42, rgba(192,132,252,0.42))",
      borderStrong: "var(--historietas-em-alta-rgba-192-132-252-0-58, rgba(192,132,252,0.58))",
      glow: "var(--historietas-em-alta-rgba-192-132-252-0-12, rgba(192,132,252,0.12))",
      background:
        "linear-gradient(135deg, var(--historietas-em-alta-rgba-40-25-62-0-82, rgba(40,25,62,0.82)) 0%, var(--historietas-em-alta-rgba-20-12-34-0-92, rgba(20,12,34,0.92)) 100%)",
    };
  }

  if (tipo === "salvas") {
    return {
      icone: "👥",
      label: "Seguidores",
      titleColor: "#FFFFFF",
      accent: "var(--historietas-em-alta-hex-34d399, #34D399)",
      border: "var(--historietas-em-alta-rgba-52-211-153-0-42, rgba(52,211,153,0.42))",
      borderStrong: "var(--historietas-em-alta-rgba-52-211-153-0-58, rgba(52,211,153,0.58))",
      glow: "var(--historietas-em-alta-rgba-52-211-153-0-11, rgba(52,211,153,0.11))",
      background:
        "linear-gradient(135deg, var(--historietas-em-alta-rgba-17-48-39-0-82, rgba(17,48,39,0.82)) 0%, var(--historietas-em-alta-rgba-10-29-25-0-92, rgba(10,29,25,0.92)) 100%)",
    };
  }

  if (tipo === "recentes") {
    return {
      icone: "✨",
      label: "Novidade",
      titleColor: "#FFFFFF",
      accent: "var(--historietas-em-alta-hex-f472b6, #F472B6)",
      border: "var(--historietas-em-alta-rgba-244-114-182-0-42, rgba(244,114,182,0.42))",
      borderStrong: "var(--historietas-em-alta-rgba-244-114-182-0-58, rgba(244,114,182,0.58))",
      glow: "var(--historietas-em-alta-rgba-244-114-182-0-11, rgba(244,114,182,0.11))",
      background:
        "linear-gradient(135deg, var(--historietas-em-alta-rgba-54-22-45-0-82, rgba(54,22,45,0.82)) 0%, var(--historietas-em-alta-rgba-30-13-31-0-92, rgba(30,13,31,0.92)) 100%)",
    };
  }

  return {
    icone: "📚",
    label: "Conteúdo",
    titleColor: "#FFFFFF",
    accent: "var(--historietas-em-alta-hex-a78bfa, #A78BFA)",
    border: "var(--historietas-em-alta-rgba-167-139-250-0-42, rgba(167,139,250,0.42))",
    borderStrong: "var(--historietas-em-alta-rgba-167-139-250-0-58, rgba(167,139,250,0.58))",
    glow: "var(--historietas-em-alta-rgba-167-139-250-0-12, rgba(167,139,250,0.12))",
    background:
      "linear-gradient(135deg, var(--historietas-em-alta-rgba-37-27-60-0-82, rgba(37,27,60,0.82)) 0%, var(--historietas-em-alta-rgba-18-12-34-0-92, rgba(18,12,34,0.92)) 100%)",
  };
}
function criarSectionHeaderTemaStyle(
  _tema: ReturnType<typeof obterTemaRanking>,
): CSSProperties {
  void _tema;

  return {
    ...sectionHeaderStyle,
    background: "transparent",
    border: "none",
    boxShadow: "none",
  };
}

function criarDesktopSectionHeaderTemaStyle(
  _tema: ReturnType<typeof obterTemaRanking>,
): CSSProperties {
  void _tema;

  return {
    ...desktopSectionHeaderStyle,
    background: "transparent",
    border: "none",
    boxShadow: "none",
  };
}

function criarSectionIconStyle(
  tema: ReturnType<typeof obterTemaRanking>,
): CSSProperties {
  return {
    width: "auto",
    height: "auto",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    background: "transparent",
    border: "none",
    color: tema.accent,
    fontSize: "28px",
    lineHeight: 1,
    flex: "0 0 auto",
    boxShadow: "none",
  };
}

function RankingSection({
  titulo,
  obras,
  tipo,
  obrasFavoritas,
  obrasConcluidas,
  onAlternarFavorito: _onAlternarFavorito,
  onAlternarConcluido: _onAlternarConcluido,
  isDesktop,
}: {
  titulo: string;
  descricao: string;
  obras: ObraRanking[];
  tipo: TipoRanking;
  obrasFavoritas: string[];
  obrasConcluidas: string[];
  onAlternarFavorito: (obraId: string) => void;
  onAlternarConcluido: (obraId: string) => void;
  isDesktop: boolean;
}) {
  void _onAlternarFavorito;
  void _onAlternarConcluido;

  const tema = obterTemaRanking(tipo);
  const carrosselRef = useRef<HTMLDivElement | null>(null);
  const obrasComPosicao = obras.map((obra, index) => ({
    obra,
    posicao: index + 1,
  }));
  const obrasEmOrdem = [...obrasComPosicao].reverse();

  function rolarCarrossel(direcao: "esquerda" | "direita") {
    const carrossel = carrosselRef.current;

    if (!carrossel) {
      return;
    }

    const distancia = Math.max(320, Math.floor(carrossel.clientWidth * 0.82));

    carrossel.scrollBy({
      left: direcao === "direita" ? distancia : -distancia,
      behavior: "smooth",
    });
  }

  return (
    <section style={isDesktop ? desktopSectionStyle : sectionStyle}>
      <div
        style={
          isDesktop
            ? criarDesktopSectionHeaderTemaStyle(tema)
            : criarSectionHeaderTemaStyle(tema)
        }
      >
        <div
          style={
            isDesktop
              ? desktopSectionHeaderContentStyle
              : sectionHeaderContentStyle
          }
        >
          <span
            className={`historietas-em-alta-emoji-icon${
              tipo === "curtidas" ? " historietas-em-alta-heart-icon" : ""
            }`}
            style={{
              ...criarSectionIconStyle(tema),
              ...(tipo === "curtidas"
                ? {
                    color:
                      "#EF4444",
                    fontFamily: "Arial, Helvetica, sans-serif",
                  }
                : {}),
            }}
          >
            {tema.icone}
          </span>

          <div
            style={
              isDesktop ? desktopSectionTextBlockStyle : sectionTextBlockStyle
            }
          >
            <h2
              style={
                isDesktop
                  ? {
                      ...sectionTitleStyle,
                      color: "#FFFFFF",
                      textAlign: "center",
                    }
                  : { ...sectionTitleStyle, color: "#FFFFFF" }
              }
            >
              {titulo}
            </h2>
          </div>
        </div>
      </div>

      {obras.length > 0 ? (
        <div style={isDesktop ? desktopCarouselShellStyle : carouselShellStyle}>
          {isDesktop && obras.length > 3 && (
            <button
              type="button"
              aria-label={`Voltar carrossel ${titulo}`}
              onClick={(event) => {
                event.stopPropagation();
                rolarCarrossel("esquerda");
              }}
              style={carouselArrowLeftStyle}
            >
              <span aria-hidden="true" style={carouselArrowLeftIconStyle} />
            </button>
          )}

          <div
            ref={carrosselRef}
            style={isDesktop ? desktopCarouselStyle : carouselStyle}
            aria-label={`${titulo} em carrossel`}
          >
            {obrasEmOrdem.map(({ obra, posicao }) => (
              <RankingCard
                key={`${tipo}-${obra.id}`}
                obra={obra}
                posicao={posicao}
                tipo={tipo}
                favorita={listaTemRankingObra(obra, obrasFavoritas)}
                concluida={listaTemRankingObra(obra, obrasConcluidas)}
                isDesktop={isDesktop}
              />
            ))}
          </div>

          {isDesktop && obras.length > 3 && (
            <button
              type="button"
              aria-label={`Avançar carrossel ${titulo}`}
              onClick={(event) => {
                event.stopPropagation();
                rolarCarrossel("direita");
              }}
              style={carouselArrowRightStyle}
            >
              <span aria-hidden="true" style={carouselArrowRightIconStyle} />
            </button>
          )}
        </div>
      ) : (
        <p
          style={{
            margin: "10px 0 0",
            color: "#FFFFFF",
            fontSize: "12px",
            fontWeight: 800,
            textAlign: "center",
          }}
        >
          Nada para mostrar neste ranking
        </p>
      )}
    </section>
  );
}
function AutoresEmAltaSection({
  autores,
  isDesktop,
}: {
  autores: AutorRanking[];
  isDesktop: boolean;
}) {
  const tema = obterTemaRanking("geral");
  const carrosselRef = useRef<HTMLDivElement | null>(null);
  const autoresComPosicao = autores.map((autor, index) => ({
    autor,
    posicao: index + 1,
  }));
  const autoresEmOrdem = [...autoresComPosicao].reverse();

  function rolarCarrossel(direcao: "esquerda" | "direita") {
    const carrossel = carrosselRef.current;

    if (!carrossel) {
      return;
    }

    const distancia = Math.max(320, Math.floor(carrossel.clientWidth * 0.82));

    carrossel.scrollBy({
      left: direcao === "direita" ? distancia : -distancia,
      behavior: "smooth",
    });
  }

  if (autores.length === 0) {
    return null;
  }

  return (
    <section style={isDesktop ? desktopSectionStyle : sectionStyle}>
      <div
        style={
          isDesktop
            ? criarDesktopSectionHeaderTemaStyle(tema)
            : criarSectionHeaderTemaStyle(tema)
        }
      >
        <div
          style={
            isDesktop
              ? desktopSectionHeaderContentStyle
              : sectionHeaderContentStyle
          }
        >
          <span className="historietas-em-alta-emoji-icon" style={criarSectionIconStyle(tema)}>👤</span>

          <div
            style={
              isDesktop ? desktopSectionTextBlockStyle : sectionTextBlockStyle
            }
          >
            <h2
              style={
                isDesktop
                  ? {
                      ...sectionTitleStyle,
                      color: "#FFFFFF",
                      textAlign: "center",
                    }
                  : { ...sectionTitleStyle, color: "#FFFFFF" }
              }
            >
              Autores em Alta
            </h2>
          </div>
        </div>
      </div>

      <div style={isDesktop ? desktopCarouselShellStyle : carouselShellStyle}>
        {isDesktop && autores.length > 3 && (
          <button
            type="button"
            aria-label="Voltar carrossel Autores em Alta"
            onClick={(event) => {
              event.stopPropagation();
              rolarCarrossel("esquerda");
            }}
            style={carouselArrowLeftStyle}
          >
            <span aria-hidden="true" style={carouselArrowLeftIconStyle} />
          </button>
        )}

        <div
          ref={carrosselRef}
          style={isDesktop ? desktopCarouselStyle : carouselStyle}
          aria-label="Autores em Alta em carrossel"
        >
          {autoresEmOrdem.map(({ autor, posicao }) => (
            <AutorRankingCard
              key={`autor-ranking-${autor.id}`}
              autor={autor}
              posicao={posicao}
              isDesktop={isDesktop}
            />
          ))}
        </div>

        {isDesktop && autores.length > 3 && (
          <button
            type="button"
            aria-label="Avançar carrossel Autores em Alta"
            onClick={(event) => {
              event.stopPropagation();
              rolarCarrossel("direita");
            }}
            style={carouselArrowRightStyle}
          >
            <span aria-hidden="true" style={carouselArrowRightIconStyle} />
          </button>
        )}
      </div>
    </section>
  );
}

function AutorRankingCard({
  autor,
  posicao,
  isDesktop,
}: {
  autor: AutorRanking;
  posicao: number;
  isDesktop: boolean;
}) {
  const router = useRouter();
  const inicialAutor = autor.nome.trim().charAt(0).toUpperCase() || "A";
  const temaPosicao = obterTemaPosicao(posicao);
  const avatarAutor = autor.avatar.trim();

  function abrirPerfil() {
    router.push(autor.href);
  }

  return (
    <article
      className="historietas-ranking-card historietas-ranking-author-card"
      data-ranking-level={temaPosicao.nome.toLowerCase()}
      style={criarCardRankingStyle(posicao, true, "geral", isDesktop)}
      role="link"
      tabIndex={0}
      aria-label={`Abrir perfil de ${autor.nome}`}
      onClick={abrirPerfil}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          abrirPerfil();
        }
      }}
    >
      <div
        style={criarAutorAvatarRankingStyle(avatarAutor, posicao, isDesktop)}
      >
        {!avatarAutor && (
          <span style={authorRankingAvatarInitialStyle}>{inicialAutor}</span>
        )}
      </div>

      <div style={isDesktop ? desktopCardContentStyle : cardContentStyle}>
        <div style={authorRankingTitleAreaStyle}>
          <h3 data-historietas-i18n-ignore="true" style={criarAutorCardTitleRankingStyle(posicao)}>{autor.nome}</h3>
        </div>

        <div style={authorRankingMetaStackStyle}>
          <span style={authorRankingWorksBadgeStyle}>
            {formatarNumero(autor.obras)}{" "}
            {autor.obras === 1 ? "Obra Publicada" : "Obras Publicadas"}
          </span>
        </div>

        <div style={statsStyle}>
          <span style={statsItemStyle}>
            <span className="historietas-em-alta-emoji-icon" style={metricIconStyle} aria-hidden="true">
              💬
            </span>
            <span style={metricValueStyle}>
              {formatarNumero(autor.comentarios)}
            </span>
          </span>

          <span style={statsItemStyle}>
            <span className="historietas-em-alta-emoji-icon" style={metricIconStyle} aria-hidden="true">
              👥
            </span>
            <span style={metricValueStyle}>
              {formatarNumero(autor.seguidores)}
            </span>
          </span>

          <span style={statsItemStyle}>
            <span className="historietas-em-alta-emoji-icon" style={metricIconStyle} aria-hidden="true">
              📚
            </span>
            <span style={metricValueStyle}>
              {formatarNumero(autor.capitulos)}
            </span>
          </span>
        </div>

        <div style={ratingStatsStyle}>
          <span style={statsItemStyle}>
            <span className="historietas-em-alta-emoji-icon" style={metricIconStyle} aria-hidden="true">
              👁
            </span>
            <span style={metricValueStyle}>{formatarNumero(autor.views)}</span>
          </span>

          <span style={statsItemStyle}>
            <span className="historietas-em-alta-emoji-icon" style={heartMetricIconStyle} aria-hidden="true">
              ❤️
            </span>
            <span style={metricValueStyle}>
              {formatarNumero(autor.curtidas)}
            </span>
          </span>

          <span style={statsItemStyle}>
            <span className="historietas-em-alta-emoji-icon" style={starMetricIconStyle} aria-hidden="true">
              ★
            </span>
            <span style={metricValueStyle}>
              {formatarMediaRanking(autor.mediaAvaliacao)}
            </span>
          </span>
        </div>

        <div style={authorRankingScoreRowStyle}>
          <span className="historietas-ranking-level-line" style={criarAutorPointsBadgeStyle(posicao)}>
            {formatarNumero(autor.pontuacao)} pts
          </span>

          <span
            className="historietas-ranking-level-line historietas-ranking-tier-badge"
            style={criarAutorTierInlineBadgeStyle(posicao)}
            aria-label={`Posição ${posicao}º — ${temaPosicao.nome}`}
          >
            <span style={coroaNumberStyle}>{posicao}º</span>
            <span style={coroaNumberStyle}>{temaPosicao.nome}</span>
          </span>
        </div>
      </div>
    </article>
  );
}

function RankingCard({
  obra,
  posicao,
  tipo,
  favorita,
  concluida,
  isDesktop,
}: {
  obra: ObraRanking;
  posicao: number;
  tipo: TipoRanking;
  favorita: boolean;
  concluida: boolean;
  isDesktop: boolean;
}) {
  void favorita;
  void concluida;

  const router = useRouter();
  const mostrarClassificacao =
    obra.classificacaoIndicativa &&
    obra.classificacaoIndicativa !== "Não informada";
  const temaPosicao = obterTemaPosicao(posicao);
  const generoCard = formatarGeneroCard(obra.genero);
  const formatoCard = obra.formato.trim() || "História";
  const mostrarGeneroRanking = Boolean(
    generoCard && normalizarTexto(generoCard) !== "nao informado",
  );
  const mostrarFormatoRanking = Boolean(
    formatoCard && normalizarTexto(formatoCard) !== "nao informado",
  );
  const mostrarStatusRanking = normalizarTexto(obra.status) !== "publicado";
  const mostrarFormatoNoTopoRankingMestre =
    tipo === "geral" && mostrarFormatoRanking;
  const destaque =
    tipo === "geral"
      ? `${formatarNumero(obra.pontuacao)} pts`
      : tipo === "lidas"
        ? `${formatarNumero(obra.views)} visualizações`
        : tipo === "curtidas"
          ? `${formatarNumero(obra.curtidas)} curtidas`
          : tipo === "comentadas"
            ? `${formatarNumero(obra.comentarios)} comentários`
            : tipo === "salvas"
              ? `${formatarNumero(obra.salvos)} seguidores`
              : tipo === "recentes"
                ? formatarDataRanking(obra.criadaEmTimestamp)
                : `${formatarNumero(obra.capitulos)} capítulos`;

  function abrirObra() {
    router.push(obra.href);
  }

  return (
    <article
      className="historietas-ranking-card historietas-ranking-work-card"
      data-ranking-level={temaPosicao.nome.toLowerCase()}
      style={criarCardRankingStyle(posicao, obra.disponivel, tipo, isDesktop)}
      role="link"
      tabIndex={0}
      aria-label={`Abrir página da obra ${obra.titulo}`}
      onClick={abrirObra}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          abrirObra();
        }
      }}
    >
      <div style={criarRankingCoverStyle(obra.capa, isDesktop, posicao)}>
        {null}
      </div>

      <div style={isDesktop ? desktopCardContentStyle : cardContentStyle}>
        <div style={cardTopStyle}>
          <h3 data-historietas-i18n-ignore="true" style={criarObraCardTitleRankingStyle(posicao)}>{obra.titulo}</h3>
        </div>

        <Link
          href={criarLinkPerfilAutorRanking(obra.autor, obra.autorId)}
          style={authorLinkStyle}
          aria-label={`Abrir perfil de ${obra.autor}`}
          onClick={(event) => {
            event.stopPropagation();
          }}
          onKeyDown={(event) => {
            event.stopPropagation();
          }}
        >
          Por{" "}
          <span data-historietas-i18n-ignore="true">{obra.autor}</span>
        </Link>

        {(mostrarFormatoNoTopoRankingMestre ||
          mostrarGeneroRanking ||
          mostrarClassificacao) && (
          <div style={cardMetaRowStyle}>
            {mostrarFormatoNoTopoRankingMestre && (
              <span className="historietas-ranking-level-line" style={formatBadgeStyle}>{formatoCard}</span>
            )}

            {mostrarGeneroRanking && (
              <span className="historietas-ranking-level-line" style={formatBadgeStyle}>{generoCard}</span>
            )}

            {mostrarClassificacao && (
              <span
                className="historietas-ranking-level-line"
                style={classificationBadgeStyle}
              >
                {obra.classificacaoIndicativa}
              </span>
            )}
          </div>
        )}

        {mostrarStatusRanking && (
          <div style={statusRowStyle}>
            <span
              style={obra.tipo === "local" ? publishedStatusStyle : statusStyle}
            >
              {obra.status}
            </span>
          </div>
        )}

        <div style={statsStyle}>
          <span style={statsItemStyle}>
            <span className="historietas-em-alta-emoji-icon" style={metricIconStyle} aria-hidden="true">
              💬
            </span>
            <span style={metricValueStyle}>
              {formatarNumero(obra.comentarios)}
            </span>
          </span>

          <span style={statsItemStyle}>
            <span className="historietas-em-alta-emoji-icon" style={metricIconStyle} aria-hidden="true">
              👥
            </span>
            <span style={metricValueStyle}>{formatarNumero(obra.salvos)}</span>
          </span>

          <span style={statsItemStyle}>
            <span className="historietas-em-alta-emoji-icon" style={metricIconStyle} aria-hidden="true">
              📚
            </span>
            <span style={metricValueStyle}>
              {formatarNumero(obra.capitulos)}
            </span>
          </span>
        </div>

        <div style={ratingStatsStyle}>
          <span style={statsItemStyle}>
            <span className="historietas-em-alta-emoji-icon" style={metricIconStyle} aria-hidden="true">
              👁
            </span>
            <span style={metricValueStyle}>{formatarNumero(obra.views)}</span>
          </span>

          <span style={statsItemStyle}>
            <span className="historietas-em-alta-emoji-icon" style={heartMetricIconStyle} aria-hidden="true">
              ❤️
            </span>
            <span style={metricValueStyle}>
              {formatarNumero(obra.curtidas)}
            </span>
          </span>

          <span style={statsItemStyle}>
            <span className="historietas-em-alta-emoji-icon" style={starMetricIconStyle} aria-hidden="true">
              ★
            </span>
            <span style={metricValueStyle}>
              {formatarMediaRanking(obra.mediaAvaliacao)}
            </span>
          </span>
        </div>

        <div
          style={
            isDesktop
              ? desktopRankingCardActionRowStyle
              : rankingCardActionRowStyle
          }
        >
          <span
            className="historietas-ranking-level-line"
            style={
              isDesktop ? desktopRankingThemeBadgeStyle : rankingThemeBadgeStyle
            }
          >
            {tipo === "geral"
              ? destaque
              : mostrarFormatoRanking
                ? formatoCard
                : "História"}
          </span>

          <span
            className="historietas-ranking-level-line historietas-ranking-tier-badge"
            style={criarRankingTierInlineBadgeStyle(posicao)}
            aria-label={`Posição ${posicao}º — ${temaPosicao.nome}`}
          >
            <span style={coroaNumberStyle}>{posicao}º</span>
            <span style={coroaNumberStyle}>{temaPosicao.nome}</span>
          </span>
        </div>
      </div>
    </article>
  );
}

function obterTemaPosicao(posicao: number) {
  if (posicao === 1) {
    return {
      nome: "Diamante",
      simbolo: "◆",
      accent: "var(--historietas-em-alta-hex-7dd3fc, #7DD3FC)",
      accentSoft: "var(--historietas-em-alta-hex-e0f2fe, #E0F2FE)",
      deep: "var(--historietas-em-alta-hex-061523, #061523)",
      border: "var(--historietas-em-alta-rgba-125-211-252-0-78, rgba(125,211,252,0.78))",
      cardBackground: "var(--historietas-em-alta-hex-2486c2, #2486C2)",
      coverBackground:
        "radial-gradient(circle at 28% 18%, var(--historietas-em-alta-rgba-224-242-254-0-22, rgba(224,242,254,0.22)), transparent 26%), radial-gradient(circle at 80% 92%, var(--historietas-em-alta-rgba-56-189-248-0-22, rgba(56,189,248,0.22)), transparent 32%), linear-gradient(145deg, var(--historietas-em-alta-hex-0b2235, #0B2235) 0%, var(--historietas-em-alta-hex-111c33, #111C33) 52%, var(--historietas-em-alta-hex-090a18, #090A18) 100%)",
      coverOverlay:
        "linear-gradient(180deg, var(--historietas-em-alta-rgba-224-242-254-0-06, rgba(224,242,254,0.06)) 0%, var(--historietas-em-alta-rgba-6-21-35-0-76, rgba(6,21,35,0.76)) 100%), radial-gradient(circle at 18% 12%, var(--historietas-em-alta-rgba-125-211-252-0-22, rgba(125,211,252,0.22)), transparent 34%)",
      rankBackground:
        "linear-gradient(135deg, var(--historietas-em-alta-hex-ecfeff, #ECFEFF) 0%, var(--historietas-em-alta-hex-7dd3fc, #7DD3FC) 46%, var(--historietas-em-alta-hex-a78bfa, #A78BFA) 100%)",
      rankText: "var(--historietas-em-alta-hex-061523, #061523)",
      tierBackground:
        "linear-gradient(135deg, var(--historietas-em-alta-rgba-236-254-255-0-96, rgba(236,254,255,0.96)) 0%, var(--historietas-em-alta-rgba-125-211-252-0-96, rgba(125,211,252,0.96)) 52%, var(--historietas-em-alta-rgba-167-139-250-0-96, rgba(167,139,250,0.96)) 100%)",
      tierText: "#FFFFFF",
      badgeBackground: "var(--historietas-em-alta-rgba-125-211-252-0-16, rgba(125,211,252,0.16))",
      badgeBorder: "var(--historietas-em-alta-rgba-125-211-252-0-42, rgba(125,211,252,0.42))",
      badgeText: "var(--historietas-em-alta-hex-bae6fd, #BAE6FD)",
      readColor: "var(--historietas-em-alta-hex-7dd3fc, #7DD3FC)",
      shadow:
        "0 18px 38px rgba(0,0,0,0.34), inset 0 1px 0 rgba(255,255,255,0.08)",
    };
  }

  if (posicao === 2) {
    return {
      nome: "Rubi",
      simbolo: "◆",
      accent: "var(--historietas-em-alta-hex-fb7185, #FB7185)",
      accentSoft: "var(--historietas-em-alta-hex-ffe4e6, #FFE4E6)",
      deep: "var(--historietas-em-alta-hex-2a0716, #2A0716)",
      border: "var(--historietas-em-alta-rgba-251-113-133-0-74, rgba(251,113,133,0.74))",
      cardBackground: "var(--historietas-em-alta-hex-a32a4b, #A32A4B)",
      coverBackground:
        "radial-gradient(circle at 28% 18%, var(--historietas-em-alta-rgba-255-228-230-0-16, rgba(255,228,230,0.16)), transparent 28%), radial-gradient(circle at 80% 92%, var(--historietas-em-alta-rgba-251-113-133-0-24, rgba(251,113,133,0.24)), transparent 34%), linear-gradient(145deg, var(--historietas-em-alta-hex-3a1020, #3A1020) 0%, var(--historietas-em-alta-hex-28101f, #28101F) 52%, var(--historietas-em-alta-hex-0d0917, #0D0917) 100%)",
      coverOverlay:
        "linear-gradient(180deg, var(--historietas-em-alta-rgba-255-228-230-0-05, rgba(255,228,230,0.05)) 0%, var(--historietas-em-alta-rgba-42-7-22-0-78, rgba(42,7,22,0.78)) 100%), radial-gradient(circle at 18% 12%, var(--historietas-em-alta-rgba-251-113-133-0-24, rgba(251,113,133,0.24)), transparent 34%)",
      rankBackground:
        "linear-gradient(135deg, var(--historietas-em-alta-hex-ffe4e6, #FFE4E6) 0%, var(--historietas-em-alta-hex-fb7185, #FB7185) 48%, var(--historietas-em-alta-hex-be123c, #BE123C) 100%)",
      rankText: "#FFFFFF",
      tierBackground:
        "linear-gradient(135deg, var(--historietas-em-alta-hex-ffe4e6, #FFE4E6) 0%, var(--historietas-em-alta-hex-fb7185, #FB7185) 50%, var(--historietas-em-alta-hex-be123c, #BE123C) 100%)",
      tierText: "#FFFFFF",
      badgeBackground: "var(--historietas-em-alta-rgba-251-113-133-0-16, rgba(251,113,133,0.16))",
      badgeBorder: "var(--historietas-em-alta-rgba-251-113-133-0-44, rgba(251,113,133,0.44))",
      badgeText: "var(--historietas-em-alta-hex-fda4af, #FDA4AF)",
      readColor: "var(--historietas-em-alta-hex-fb7185, #FB7185)",
      shadow:
        "0 18px 38px rgba(0,0,0,0.34), inset 0 1px 0 rgba(255,255,255,0.075)",
    };
  }

  if (posicao === 3) {
    return {
      nome: "Ouro",
      simbolo: "◆",
      accent: "var(--historietas-em-alta-hex-fbbf24, #FBBF24)",
      accentSoft: "var(--historietas-em-alta-hex-fef3c7, #FEF3C7)",
      deep: "var(--historietas-em-alta-hex-271504, #271504)",
      border: "var(--historietas-em-alta-rgba-251-191-36-0-72, rgba(251,191,36,0.72))",
      cardBackground: "var(--historietas-em-alta-hex-b57d22, #B57D22)",
      coverBackground:
        "radial-gradient(circle at 28% 18%, var(--historietas-em-alta-rgba-254-243-199-0-18, rgba(254,243,199,0.18)), transparent 28%), radial-gradient(circle at 80% 92%, var(--historietas-em-alta-rgba-251-191-36-0-24, rgba(251,191,36,0.24)), transparent 34%), linear-gradient(145deg, var(--historietas-em-alta-hex-3a2508, #3A2508) 0%, var(--historietas-em-alta-hex-271808, #271808) 52%, var(--historietas-em-alta-hex-100a14, #100A14) 100%)",
      coverOverlay:
        "linear-gradient(180deg, var(--historietas-em-alta-rgba-254-243-199-0-05, rgba(254,243,199,0.05)) 0%, var(--historietas-em-alta-rgba-39-21-4-0-78, rgba(39,21,4,0.78)) 100%), radial-gradient(circle at 18% 12%, var(--historietas-em-alta-rgba-251-191-36-0-24, rgba(251,191,36,0.24)), transparent 34%)",
      rankBackground:
        "linear-gradient(135deg, var(--historietas-em-alta-hex-fef3c7, #FEF3C7) 0%, var(--historietas-em-alta-hex-fbbf24, #FBBF24) 48%, var(--historietas-em-alta-hex-d97706, #D97706) 100%)",
      rankText: "var(--historietas-em-alta-hex-2b1407, #2B1407)",
      tierBackground:
        "linear-gradient(135deg, var(--historietas-em-alta-hex-fef3c7, #FEF3C7) 0%, var(--historietas-em-alta-hex-fbbf24, #FBBF24) 52%, var(--historietas-em-alta-hex-d97706, #D97706) 100%)",
      tierText: "#FFFFFF",
      badgeBackground: "var(--historietas-em-alta-rgba-251-191-36-0-16, rgba(251,191,36,0.16))",
      badgeBorder: "var(--historietas-em-alta-rgba-251-191-36-0-44, rgba(251,191,36,0.44))",
      badgeText: "var(--historietas-em-alta-hex-fcd34d, #FCD34D)",
      readColor: "var(--historietas-em-alta-hex-fbbf24, #FBBF24)",
      shadow:
        "0 18px 38px rgba(0,0,0,0.34), inset 0 1px 0 rgba(255,255,255,0.075)",
    };
  }

  if (posicao === 4) {
    return {
      nome: "Prata",
      simbolo: "◆",
      accent: "var(--historietas-em-alta-hex-cbd5e1, #CBD5E1)",
      accentSoft: "var(--historietas-em-alta-hex-f8fafc, #F8FAFC)",
      deep: "var(--historietas-em-alta-hex-101722, #101722)",
      border: "var(--historietas-em-alta-rgba-203-213-225-0-68, rgba(203,213,225,0.68))",
      cardBackground: "var(--historietas-em-alta-hex-7b8aa3, #7B8AA3)",
      coverBackground:
        "radial-gradient(circle at 28% 18%, var(--historietas-em-alta-rgba-248-250-252-0-14, rgba(248,250,252,0.14)), transparent 28%), radial-gradient(circle at 80% 92%, var(--historietas-em-alta-rgba-148-163-184-0-18, rgba(148,163,184,0.18)), transparent 34%), linear-gradient(145deg, var(--historietas-em-alta-hex-26303d, #26303D) 0%, var(--historietas-em-alta-hex-1a202b, #1A202B) 52%, var(--historietas-em-alta-hex-0d0b16, #0D0B16) 100%)",
      coverOverlay:
        "linear-gradient(180deg, var(--historietas-em-alta-rgba-248-250-252-0-04, rgba(248,250,252,0.04)) 0%, var(--historietas-em-alta-rgba-16-23-34-0-78, rgba(16,23,34,0.78)) 100%), radial-gradient(circle at 18% 12%, var(--historietas-em-alta-rgba-203-213-225-0-18, rgba(203,213,225,0.18)), transparent 34%)",
      rankBackground:
        "linear-gradient(135deg, var(--historietas-em-alta-hex-f8fafc, #F8FAFC) 0%, var(--historietas-em-alta-hex-cbd5e1, #CBD5E1) 52%, var(--historietas-em-alta-hex-64748b, #64748B) 100%)",
      rankText: "var(--historietas-em-alta-hex-111827, #111827)",
      tierBackground:
        "linear-gradient(135deg, var(--historietas-em-alta-hex-f8fafc, #F8FAFC) 0%, var(--historietas-em-alta-hex-cbd5e1, #CBD5E1) 52%, var(--historietas-em-alta-hex-64748b, #64748B) 100%)",
      tierText: "#FFFFFF",
      badgeBackground: "var(--historietas-em-alta-rgba-203-213-225-0-13, rgba(203,213,225,0.13))",
      badgeBorder: "var(--historietas-em-alta-rgba-203-213-225-0-38, rgba(203,213,225,0.38))",
      badgeText: "var(--historietas-em-alta-hex-e2e8f0, #E2E8F0)",
      readColor: "var(--historietas-em-alta-hex-cbd5e1, #CBD5E1)",
      shadow:
        "0 18px 38px rgba(0,0,0,0.32), inset 0 1px 0 rgba(255,255,255,0.07)",
    };
  }

  return {
    nome: "Bronze",
    simbolo: "◆",
    accent: "var(--historietas-em-alta-hex-fb923c, #FB923C)",
    accentSoft: "var(--historietas-em-alta-hex-fed7aa, #FED7AA)",
    deep: "var(--historietas-em-alta-hex-241006, #241006)",
    border: "var(--historietas-em-alta-rgba-251-146-60-0-70, rgba(251,146,60,0.70))",
    cardBackground: "var(--historietas-em-alta-hex-9a6535, #9A6535)",
    coverBackground:
      "radial-gradient(circle at 28% 18%, var(--historietas-em-alta-rgba-254-215-170-0-14, rgba(254,215,170,0.14)), transparent 28%), radial-gradient(circle at 80% 92%, var(--historietas-em-alta-rgba-251-146-60-0-22, rgba(251,146,60,0.22)), transparent 34%), linear-gradient(145deg, var(--historietas-em-alta-hex-351d0e, #351D0E) 0%, var(--historietas-em-alta-hex-24140b, #24140B) 52%, var(--historietas-em-alta-hex-100a14, #100A14) 100%)",
    coverOverlay:
      "linear-gradient(180deg, var(--historietas-em-alta-rgba-254-215-170-0-04, rgba(254,215,170,0.04)) 0%, var(--historietas-em-alta-rgba-36-16-6-0-78, rgba(36,16,6,0.78)) 100%), radial-gradient(circle at 18% 12%, var(--historietas-em-alta-rgba-251-146-60-0-20, rgba(251,146,60,0.20)), transparent 34%)",
    rankBackground:
      "linear-gradient(135deg, var(--historietas-em-alta-hex-fed7aa, #FED7AA) 0%, var(--historietas-em-alta-hex-fb923c, #FB923C) 48%, var(--historietas-em-alta-hex-9a3412, #9A3412) 100%)",
    rankText: "#FFFFFF",
    tierBackground:
      "linear-gradient(135deg, var(--historietas-em-alta-hex-fed7aa, #FED7AA) 0%, var(--historietas-em-alta-hex-fb923c, #FB923C) 50%, var(--historietas-em-alta-hex-9a3412, #9A3412) 100%)",
    tierText: "#FFFFFF",
    badgeBackground: "var(--historietas-em-alta-rgba-251-146-60-0-15, rgba(251,146,60,0.15))",
    badgeBorder: "var(--historietas-em-alta-rgba-251-146-60-0-40, rgba(251,146,60,0.40))",
    badgeText: "var(--historietas-em-alta-hex-fdba74, #FDBA74)",
    readColor: "var(--historietas-em-alta-hex-fb923c, #FB923C)",
    shadow:
      "0 18px 38px rgba(0,0,0,0.33), inset 0 1px 0 rgba(255,255,255,0.07)",
  };
}
function criarCardRankingStyle(
  posicao: number,
  disponivel: boolean,
  _tipo: TipoRanking,
  isDesktop = false,
): CSSProperties {
  const temaPosicao = obterTemaPosicao(posicao);

  return {
    ...(disponivel
      ? isDesktop
        ? desktopCardStyle
        : cardStyle
      : isDesktop
        ? desktopCardSoonStyle
        : cardSoonStyle),
    background: temaPosicao.cardBackground,
    backgroundColor: temaPosicao.cardBackground,
    border: `1px solid ${temaPosicao.border}`,
    outline: "none",
    boxShadow: temaPosicao.shadow,
  };
}
function criarTierBadgeStyle(posicao: number): CSSProperties {
  const temaPosicao = obterTemaPosicao(posicao);

  return {
    position: "absolute",
    left: "8px",
    right: "8px",
    bottom: "8px",
    zIndex: 5,
    minHeight: "30px",
    maxWidth: "calc(100% - 16px)",
    padding: "0 8px",
    borderRadius: "999px",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexWrap: "nowrap",
    gap: "5px",
    background: temaPosicao.badgeBackground,
    border: `1px solid ${temaPosicao.badgeBorder}`,
    color: "#FFFFFF",
    fontSize: "10px",
    lineHeight: 1,
    fontWeight: 950,
    letterSpacing: "0.055em",
    textTransform: "uppercase",
    whiteSpace: "nowrap",
    overflowWrap: "normal",
    wordBreak: "normal",
    overflow: "hidden",
    boxShadow:
      "0 8px 16px rgba(0,0,0,0.24), inset 0 1px 0 rgba(255,255,255,0.22)",
    pointerEvents: "none",
  };
}

function criarRankingTierInlineBadgeStyle(posicao: number): CSSProperties {
  const temaPosicao = obterTemaPosicao(posicao);

  return {
    ...highlightBadgeStyle,
    ...rankingHighlightBadgeInlineStyle,
    position: "static",
    minHeight: "34px",
    marginTop: 0,
    padding: "0 12px",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "5px",
    background: temaPosicao.badgeBackground,
    border: `1px solid ${temaPosicao.badgeBorder}`,
    color: "#FFFFFF",
    fontSize: "10px",
    fontWeight: 950,
    letterSpacing: "0.055em",
    lineHeight: 1,
    textTransform: "uppercase",
    whiteSpace: "nowrap",
    boxShadow: "none",
  };
}

function criarCardTitleRankingStyle(_posicao: number): CSSProperties {
  return {
    ...cardTitleStyle,
    color: "#FFFFFF",
  };
}
function criarObraCardTitleRankingStyle(_posicao: number): CSSProperties {
  return {
    ...cardTitleStyle,
    color: "#FFFFFF",
  };
}
function criarReadRankingStyle(
  posicao: number,
  disponivel: boolean,
): CSSProperties {
  const temaPosicao = obterTemaPosicao(posicao);

  return {
    ...(disponivel ? readStyle : soonReadStyle),
    color: temaPosicao.readColor,
  };
}

function criarAutorCardRankingStyle(
  posicao: number,
  isDesktop: boolean,
): CSSProperties {
  const temaPosicao = obterTemaPosicao(posicao);

  return {
    ...(isDesktop ? desktopAuthorRankingCardStyle : authorRankingCardStyle),
    background: temaPosicao.cardBackground,
    backgroundColor: temaPosicao.cardBackground,
    border: `1px solid ${temaPosicao.border}`,
    outline: "none",
    boxShadow: temaPosicao.shadow,
  };
}
function criarAutorAvatarRankingStyle(
  avatar: string,
  posicao: number,
  isDesktop: boolean,
): CSSProperties {
  const temaPosicao = obterTemaPosicao(posicao);
  const baseStyle = isDesktop ? desktopCoverStyle : coverStyle;

  return {
    ...baseStyle,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: temaPosicao.deep,
    backgroundImage: avatar
      ? `linear-gradient(180deg, rgba(0,0,0,0.02), rgba(0,0,0,0.24)), url(${avatar})`
      : temaPosicao.coverBackground,
    backgroundSize: "cover",
    backgroundPosition: "center",
    border: "none",
    outline: "none",
    boxShadow: "none",
  };
}

function criarAutorTierInlineBadgeStyle(posicao: number): CSSProperties {
  const temaPosicao = obterTemaPosicao(posicao);

  return {
    ...authorRankingTierBadgeStyle,
    position: "static",
    left: "auto",
    right: "auto",
    bottom: "auto",
    minHeight: "34px",
    padding: "0 16px",
    width: "fit-content",
    maxWidth: "100%",
    flex: "0 0 auto",
    background: temaPosicao.badgeBackground,
    border: `1px solid ${temaPosicao.badgeBorder}`,
    color: "#FFFFFF",
    boxSizing: "border-box",
  };
}

function criarAutorPointsBadgeStyle(_posicao: number): CSSProperties {
  return {
    ...highlightBadgeStyle,
    marginTop: 0,
    minHeight: "34px",
    padding: "0 16px",
    color: "#FFFFFF",
    flex: "0 0 auto",
  };
}

function criarAutorCardTitleRankingStyle(_posicao: number): CSSProperties {
  return {
    ...authorRankingCardTitleStyle,
    color: "#FFFFFF",
  };
}

const emAltaPageCss = `
  @keyframes historietas-loading-spin {
    to {
      transform: rotate(360deg);
    }
  }

  @media (prefers-reduced-motion: reduce) {
    .historietas-loading-spinner {
      animation-duration: 1.4s !important;
    }
  }

  html {
    --historietas-em-alta-hex-04000a: #04000A;
    --historietas-em-alta-hex-061523: #061523;
    --historietas-em-alta-hex-070212: #070212;
    --historietas-em-alta-hex-08030f: #08030F;
    --historietas-em-alta-hex-090a18: #090A18;
    --historietas-em-alta-hex-0b2235: #0B2235;
    --historietas-em-alta-hex-0d0917: #0D0917;
    --historietas-em-alta-hex-0d0b16: #0D0B16;
    --historietas-em-alta-hex-100a14: #100A14;
    --historietas-em-alta-hex-101722: #101722;
    --historietas-em-alta-hex-111827: #111827;
    --historietas-em-alta-hex-111c33: #111C33;
    --historietas-em-alta-hex-1a202b: #1A202B;
    --historietas-em-alta-hex-241006: #241006;
    --historietas-em-alta-hex-24140b: #24140B;
    --historietas-em-alta-hex-2486c2: #2486C2;
    --historietas-em-alta-hex-26303d: #26303D;
    --historietas-em-alta-hex-271504: #271504;
    --historietas-em-alta-hex-271808: #271808;
    --historietas-em-alta-hex-28101f: #28101F;
    --historietas-em-alta-hex-2a0716: #2A0716;
    --historietas-em-alta-hex-2b1407: #2B1407;
    --historietas-em-alta-hex-34d399: #34D399;
    --historietas-em-alta-hex-351d0e: #351D0E;
    --historietas-em-alta-hex-38bdf8: #38BDF8;
    --historietas-em-alta-hex-3a1020: #3A1020;
    --historietas-em-alta-hex-3a2508: #3A2508;
    --historietas-em-alta-hex-64748b: #64748B;
    --historietas-em-alta-hex-7b8aa3: #7B8AA3;
    --historietas-em-alta-hex-7c3aed: #7C3AED;
    --historietas-em-alta-hex-7dd3fc: #7DD3FC;
    --historietas-em-alta-hex-86efac: #86EFAC;
    --historietas-em-alta-hex-9a3412: #9A3412;
    --historietas-em-alta-hex-9a6535: #9A6535;
    --historietas-em-alta-hex-a32a4b: #A32A4B;
    --historietas-em-alta-hex-a78bfa: #A78BFA;
    --historietas-em-alta-hex-b57d22: #B57D22;
    --historietas-em-alta-hex-bae6fd: #BAE6FD;
    --historietas-em-alta-hex-be123c: #BE123C;
    --historietas-em-alta-hex-c084fc: #C084FC;
    --historietas-em-alta-hex-c4b5fd: #C4B5FD;
    --historietas-em-alta-hex-cbd5e1: #CBD5E1;
    --historietas-em-alta-hex-d8c8ff: #D8C8FF;
    --historietas-em-alta-hex-d97706: #D97706;
    --historietas-em-alta-hex-ddd6fe: #DDD6FE;
    --historietas-em-alta-hex-e0f2fe: #E0F2FE;
    --historietas-em-alta-hex-e2e8f0: #E2E8F0;
    --historietas-em-alta-hex-ecfeff: #ECFEFF;
    --historietas-em-alta-hex-ef4444: #EF4444;
    --historietas-em-alta-hex-f472b6: #F472B6;
    --historietas-em-alta-hex-f5f3ff: #F5F3FF;
    --historietas-em-alta-hex-f8fafc: #F8FAFC;
    --historietas-em-alta-hex-f97316: #F97316;
    --historietas-em-alta-hex-fb7185: #FB7185;
    --historietas-em-alta-hex-fb923c: #FB923C;
    --historietas-em-alta-hex-fbbf24: #FBBF24;
    --historietas-em-alta-hex-fcd34d: #FCD34D;
    --historietas-em-alta-hex-fda4af: #FDA4AF;
    --historietas-em-alta-hex-fdba74: #FDBA74;
    --historietas-em-alta-hex-fed7aa: #FED7AA;
    --historietas-em-alta-hex-fef3c7: #FEF3C7;
    --historietas-em-alta-hex-ffe4e6: #FFE4E6;
    --historietas-em-alta-rgba-10-29-25-0-92: rgba(10,29,25,0.92);
    --historietas-em-alta-rgba-11-17-32-0-92: rgba(11,17,32,0.92);
    --historietas-em-alta-rgba-125-211-252-0-16: rgba(125,211,252,0.16);
    --historietas-em-alta-rgba-125-211-252-0-22: rgba(125,211,252,0.22);
    --historietas-em-alta-rgba-125-211-252-0-42: rgba(125,211,252,0.42);
    --historietas-em-alta-rgba-125-211-252-0-78: rgba(125,211,252,0.78);
    --historietas-em-alta-rgba-125-211-252-0-96: rgba(125,211,252,0.96);
    --historietas-em-alta-rgba-139-92-246-0-18: rgba(139, 92, 246, 0.18);
    --historietas-em-alta-rgba-148-163-184-0-18: rgba(148,163,184,0.18);
    --historietas-em-alta-rgba-16-23-34-0-78: rgba(16,23,34,0.78);
    --historietas-em-alta-rgba-167-139-250-0-12: rgba(167,139,250,0.12);
    --historietas-em-alta-rgba-167-139-250-0-42: rgba(167,139,250,0.42);
    --historietas-em-alta-rgba-167-139-250-0-58: rgba(167,139,250,0.58);
    --historietas-em-alta-rgba-167-139-250-0-96: rgba(167,139,250,0.96);
    --historietas-em-alta-rgba-17-48-39-0-82: rgba(17,48,39,0.82);
    --historietas-em-alta-rgba-18-12-30-0-92: rgba(18,12,30,0.92);
    --historietas-em-alta-rgba-18-12-34-0-92: rgba(18,12,34,0.92);
    --historietas-em-alta-rgba-18-36-54-0-82: rgba(18,36,54,0.82);
    --historietas-em-alta-rgba-192-132-252-0-12: rgba(192,132,252,0.12);
    --historietas-em-alta-rgba-192-132-252-0-42: rgba(192,132,252,0.42);
    --historietas-em-alta-rgba-192-132-252-0-58: rgba(192,132,252,0.58);
    --historietas-em-alta-rgba-20-12-34-0-92: rgba(20,12,34,0.92);
    --historietas-em-alta-rgba-203-213-225-0-13: rgba(203,213,225,0.13);
    --historietas-em-alta-rgba-203-213-225-0-18: rgba(203,213,225,0.18);
    --historietas-em-alta-rgba-203-213-225-0-38: rgba(203,213,225,0.38);
    --historietas-em-alta-rgba-203-213-225-0-68: rgba(203,213,225,0.68);
    --historietas-em-alta-rgba-224-242-254-0-06: rgba(224,242,254,0.06);
    --historietas-em-alta-rgba-224-242-254-0-22: rgba(224,242,254,0.22);
    --historietas-em-alta-rgba-236-254-255-0-96: rgba(236,254,255,0.96);
    --historietas-em-alta-rgba-244-114-182-0-11: rgba(244,114,182,0.11);
    --historietas-em-alta-rgba-244-114-182-0-42: rgba(244,114,182,0.42);
    --historietas-em-alta-rgba-244-114-182-0-58: rgba(244,114,182,0.58);
    --historietas-em-alta-rgba-248-250-252-0-04: rgba(248,250,252,0.04);
    --historietas-em-alta-rgba-248-250-252-0-14: rgba(248,250,252,0.14);
    --historietas-em-alta-rgba-251-113-133-0-12: rgba(251,113,133,0.12);
    --historietas-em-alta-rgba-251-113-133-0-16: rgba(251,113,133,0.16);
    --historietas-em-alta-rgba-251-113-133-0-24: rgba(251,113,133,0.24);
    --historietas-em-alta-rgba-251-113-133-0-42: rgba(251,113,133,0.42);
    --historietas-em-alta-rgba-251-113-133-0-44: rgba(251,113,133,0.44);
    --historietas-em-alta-rgba-251-113-133-0-58: rgba(251,113,133,0.58);
    --historietas-em-alta-rgba-251-113-133-0-74: rgba(251,113,133,0.74);
    --historietas-em-alta-rgba-251-146-60-0-15: rgba(251,146,60,0.15);
    --historietas-em-alta-rgba-251-146-60-0-20: rgba(251,146,60,0.20);
    --historietas-em-alta-rgba-251-146-60-0-22: rgba(251,146,60,0.22);
    --historietas-em-alta-rgba-251-146-60-0-40: rgba(251,146,60,0.40);
    --historietas-em-alta-rgba-251-146-60-0-70: rgba(251,146,60,0.70);
    --historietas-em-alta-rgba-251-191-36-0-16: rgba(251,191,36,0.16);
    --historietas-em-alta-rgba-251-191-36-0-24: rgba(251,191,36,0.24);
    --historietas-em-alta-rgba-251-191-36-0-44: rgba(251,191,36,0.44);
    --historietas-em-alta-rgba-251-191-36-0-72: rgba(251,191,36,0.72);
    --historietas-em-alta-rgba-254-215-170-0-04: rgba(254,215,170,0.04);
    --historietas-em-alta-rgba-254-215-170-0-14: rgba(254,215,170,0.14);
    --historietas-em-alta-rgba-254-243-199-0-05: rgba(254,243,199,0.05);
    --historietas-em-alta-rgba-254-243-199-0-18: rgba(254,243,199,0.18);
    --historietas-em-alta-rgba-255-228-230-0-05: rgba(255,228,230,0.05);
    --historietas-em-alta-rgba-255-228-230-0-16: rgba(255,228,230,0.16);
    --historietas-em-alta-rgba-29-13-27-0-92: rgba(29,13,27,0.92);
    --historietas-em-alta-rgba-30-13-31-0-92: rgba(30,13,31,0.92);
    --historietas-em-alta-rgba-34-197-94-0-14: rgba(34, 197, 94, 0.14);
    --historietas-em-alta-rgba-34-197-94-0-3: rgba(34, 197, 94, 0.3);
    --historietas-em-alta-rgba-36-16-6-0-78: rgba(36,16,6,0.78);
    --historietas-em-alta-rgba-37-27-60-0-82: rgba(37,27,60,0.82);
    --historietas-em-alta-rgba-39-21-4-0-78: rgba(39,21,4,0.78);
    --historietas-em-alta-rgba-4-0-10-0-72: rgba(4, 0, 10, 0.72);
    --historietas-em-alta-rgba-40-25-62-0-82: rgba(40,25,62,0.82);
    --historietas-em-alta-rgba-41-27-53-0-82: rgba(41,27,53,0.82);
    --historietas-em-alta-rgba-42-7-22-0-78: rgba(42,7,22,0.78);
    --historietas-em-alta-rgba-52-211-153-0-11: rgba(52,211,153,0.11);
    --historietas-em-alta-rgba-52-211-153-0-42: rgba(52,211,153,0.42);
    --historietas-em-alta-rgba-52-211-153-0-58: rgba(52,211,153,0.58);
    --historietas-em-alta-rgba-54-20-38-0-82: rgba(54,20,38,0.82);
    --historietas-em-alta-rgba-54-22-45-0-82: rgba(54,22,45,0.82);
    --historietas-em-alta-rgba-56-189-248-0-12: rgba(56,189,248,0.12);
    --historietas-em-alta-rgba-56-189-248-0-22: rgba(56,189,248,0.22);
    --historietas-em-alta-rgba-56-189-248-0-42: rgba(56,189,248,0.42);
    --historietas-em-alta-rgba-56-189-248-0-58: rgba(56,189,248,0.58);
    --historietas-em-alta-rgba-59-7-100-0-58: rgba(59, 7, 100, 0.58);
    --historietas-em-alta-rgba-6-21-35-0-76: rgba(6,21,35,0.76);
  }

  html[data-historietas-tema-visual="foco"] {
    --historietas-em-alta-hex-04000a: #000000;
    --historietas-em-alta-hex-061523: #000000;
    --historietas-em-alta-hex-070212: #000000;
    --historietas-em-alta-hex-08030f: #000000;
    --historietas-em-alta-hex-090a18: #000000;
    --historietas-em-alta-hex-0b2235: #000000;
    --historietas-em-alta-hex-0d0917: #000000;
    --historietas-em-alta-hex-0d0b16: #000000;
    --historietas-em-alta-hex-100a14: #000000;
    --historietas-em-alta-hex-101722: #000000;
    --historietas-em-alta-hex-111827: #000000;
    --historietas-em-alta-hex-111c33: #000000;
    --historietas-em-alta-hex-1a202b: #000000;
    --historietas-em-alta-hex-241006: #000000;
    --historietas-em-alta-hex-24140b: #000000;
    --historietas-em-alta-hex-2486c2: #050505;
    --historietas-em-alta-hex-26303d: #000000;
    --historietas-em-alta-hex-271504: #000000;
    --historietas-em-alta-hex-271808: #000000;
    --historietas-em-alta-hex-28101f: #000000;
    --historietas-em-alta-hex-2a0716: #000000;
    --historietas-em-alta-hex-2b1407: #000000;
    --historietas-em-alta-hex-34d399: #FFFFFF;
    --historietas-em-alta-hex-351d0e: #000000;
    --historietas-em-alta-hex-38bdf8: #FFFFFF;
    --historietas-em-alta-hex-3a1020: #000000;
    --historietas-em-alta-hex-3a2508: #000000;
    --historietas-em-alta-hex-64748b: #A1A1AA;
    --historietas-em-alta-hex-7b8aa3: #050505;
    --historietas-em-alta-hex-7c3aed: #FFFFFF;
    --historietas-em-alta-hex-7dd3fc: #FFFFFF;
    --historietas-em-alta-hex-86efac: #D4D4D8;
    --historietas-em-alta-hex-9a3412: #A1A1AA;
    --historietas-em-alta-hex-9a6535: #050505;
    --historietas-em-alta-hex-a32a4b: #050505;
    --historietas-em-alta-hex-a78bfa: #FFFFFF;
    --historietas-em-alta-hex-b57d22: #050505;
    --historietas-em-alta-hex-bae6fd: #D4D4D8;
    --historietas-em-alta-hex-be123c: #A1A1AA;
    --historietas-em-alta-hex-c084fc: #FFFFFF;
    --historietas-em-alta-hex-c4b5fd: #D4D4D8;
    --historietas-em-alta-hex-cbd5e1: #D4D4D8;
    --historietas-em-alta-hex-d8c8ff: #D4D4D8;
    --historietas-em-alta-hex-d97706: #A1A1AA;
    --historietas-em-alta-hex-ddd6fe: #D4D4D8;
    --historietas-em-alta-hex-e0f2fe: #D4D4D8;
    --historietas-em-alta-hex-e2e8f0: #D4D4D8;
    --historietas-em-alta-hex-ecfeff: #FFFFFF;
    --historietas-em-alta-hex-ef4444: #FFFFFF;
    --historietas-em-alta-hex-f472b6: #FFFFFF;
    --historietas-em-alta-hex-f5f3ff: #FFFFFF;
    --historietas-em-alta-hex-f8fafc: #FFFFFF;
    --historietas-em-alta-hex-f97316: #FFFFFF;
    --historietas-em-alta-hex-fb7185: #FFFFFF;
    --historietas-em-alta-hex-fb923c: #FFFFFF;
    --historietas-em-alta-hex-fbbf24: #FFFFFF;
    --historietas-em-alta-hex-fcd34d: #D4D4D8;
    --historietas-em-alta-hex-fda4af: #D4D4D8;
    --historietas-em-alta-hex-fdba74: #D4D4D8;
    --historietas-em-alta-hex-fed7aa: #FFFFFF;
    --historietas-em-alta-hex-fef3c7: #FFFFFF;
    --historietas-em-alta-hex-ffe4e6: #FFFFFF;
    --historietas-em-alta-rgba-10-29-25-0-92: rgba(0,0,0,0.92);
    --historietas-em-alta-rgba-11-17-32-0-92: rgba(0,0,0,0.92);
    --historietas-em-alta-rgba-125-211-252-0-16: rgba(212,212,216,0.16);
    --historietas-em-alta-rgba-125-211-252-0-22: rgba(212,212,216,0.22);
    --historietas-em-alta-rgba-125-211-252-0-42: rgba(212,212,216,0.42);
    --historietas-em-alta-rgba-125-211-252-0-78: rgba(212,212,216,0.78);
    --historietas-em-alta-rgba-125-211-252-0-96: rgba(212,212,216,0.96);
    --historietas-em-alta-rgba-139-92-246-0-18: rgba(212,212,216,0.18);
    --historietas-em-alta-rgba-148-163-184-0-18: rgba(212,212,216,0.18);
    --historietas-em-alta-rgba-16-23-34-0-78: rgba(0,0,0,0.78);
    --historietas-em-alta-rgba-167-139-250-0-12: rgba(212,212,216,0.12);
    --historietas-em-alta-rgba-167-139-250-0-42: rgba(212,212,216,0.42);
    --historietas-em-alta-rgba-167-139-250-0-58: rgba(212,212,216,0.58);
    --historietas-em-alta-rgba-167-139-250-0-96: rgba(212,212,216,0.96);
    --historietas-em-alta-rgba-17-48-39-0-82: rgba(0,0,0,0.82);
    --historietas-em-alta-rgba-18-12-30-0-92: rgba(0,0,0,0.92);
    --historietas-em-alta-rgba-18-12-34-0-92: rgba(0,0,0,0.92);
    --historietas-em-alta-rgba-18-36-54-0-82: rgba(0,0,0,0.82);
    --historietas-em-alta-rgba-192-132-252-0-12: rgba(212,212,216,0.12);
    --historietas-em-alta-rgba-192-132-252-0-42: rgba(212,212,216,0.42);
    --historietas-em-alta-rgba-192-132-252-0-58: rgba(212,212,216,0.58);
    --historietas-em-alta-rgba-20-12-34-0-92: rgba(0,0,0,0.92);
    --historietas-em-alta-rgba-203-213-225-0-13: rgba(212,212,216,0.13);
    --historietas-em-alta-rgba-203-213-225-0-18: rgba(212,212,216,0.18);
    --historietas-em-alta-rgba-203-213-225-0-38: rgba(212,212,216,0.38);
    --historietas-em-alta-rgba-203-213-225-0-68: rgba(212,212,216,0.68);
    --historietas-em-alta-rgba-224-242-254-0-06: rgba(212,212,216,0.06);
    --historietas-em-alta-rgba-224-242-254-0-22: rgba(212,212,216,0.22);
    --historietas-em-alta-rgba-236-254-255-0-96: rgba(212,212,216,0.96);
    --historietas-em-alta-rgba-244-114-182-0-11: rgba(212,212,216,0.11);
    --historietas-em-alta-rgba-244-114-182-0-42: rgba(212,212,216,0.42);
    --historietas-em-alta-rgba-244-114-182-0-58: rgba(212,212,216,0.58);
    --historietas-em-alta-rgba-248-250-252-0-04: rgba(212,212,216,0.04);
    --historietas-em-alta-rgba-248-250-252-0-14: rgba(212,212,216,0.14);
    --historietas-em-alta-rgba-251-113-133-0-12: rgba(212,212,216,0.12);
    --historietas-em-alta-rgba-251-113-133-0-16: rgba(212,212,216,0.16);
    --historietas-em-alta-rgba-251-113-133-0-24: rgba(212,212,216,0.24);
    --historietas-em-alta-rgba-251-113-133-0-42: rgba(212,212,216,0.42);
    --historietas-em-alta-rgba-251-113-133-0-44: rgba(212,212,216,0.44);
    --historietas-em-alta-rgba-251-113-133-0-58: rgba(212,212,216,0.58);
    --historietas-em-alta-rgba-251-113-133-0-74: rgba(212,212,216,0.74);
    --historietas-em-alta-rgba-251-146-60-0-15: rgba(212,212,216,0.15);
    --historietas-em-alta-rgba-251-146-60-0-20: rgba(212,212,216,0.2);
    --historietas-em-alta-rgba-251-146-60-0-22: rgba(212,212,216,0.22);
    --historietas-em-alta-rgba-251-146-60-0-40: rgba(212,212,216,0.4);
    --historietas-em-alta-rgba-251-146-60-0-70: rgba(212,212,216,0.7);
    --historietas-em-alta-rgba-251-191-36-0-16: rgba(212,212,216,0.16);
    --historietas-em-alta-rgba-251-191-36-0-24: rgba(212,212,216,0.24);
    --historietas-em-alta-rgba-251-191-36-0-44: rgba(212,212,216,0.44);
    --historietas-em-alta-rgba-251-191-36-0-72: rgba(212,212,216,0.72);
    --historietas-em-alta-rgba-254-215-170-0-04: rgba(212,212,216,0.04);
    --historietas-em-alta-rgba-254-215-170-0-14: rgba(212,212,216,0.14);
    --historietas-em-alta-rgba-254-243-199-0-05: rgba(212,212,216,0.05);
    --historietas-em-alta-rgba-254-243-199-0-18: rgba(212,212,216,0.18);
    --historietas-em-alta-rgba-255-228-230-0-05: rgba(212,212,216,0.05);
    --historietas-em-alta-rgba-255-228-230-0-16: rgba(212,212,216,0.16);
    --historietas-em-alta-rgba-29-13-27-0-92: rgba(0,0,0,0.92);
    --historietas-em-alta-rgba-30-13-31-0-92: rgba(0,0,0,0.92);
    --historietas-em-alta-rgba-34-197-94-0-14: rgba(161,161,170,0.14);
    --historietas-em-alta-rgba-34-197-94-0-3: rgba(161,161,170,0.3);
    --historietas-em-alta-rgba-36-16-6-0-78: rgba(0,0,0,0.78);
    --historietas-em-alta-rgba-37-27-60-0-82: rgba(0,0,0,0.82);
    --historietas-em-alta-rgba-39-21-4-0-78: rgba(0,0,0,0.78);
    --historietas-em-alta-rgba-4-0-10-0-72: rgba(0,0,0,0.72);
    --historietas-em-alta-rgba-40-25-62-0-82: rgba(0,0,0,0.82);
    --historietas-em-alta-rgba-41-27-53-0-82: rgba(0,0,0,0.82);
    --historietas-em-alta-rgba-42-7-22-0-78: rgba(0,0,0,0.78);
    --historietas-em-alta-rgba-52-211-153-0-11: rgba(161,161,170,0.11);
    --historietas-em-alta-rgba-52-211-153-0-42: rgba(161,161,170,0.42);
    --historietas-em-alta-rgba-52-211-153-0-58: rgba(161,161,170,0.58);
    --historietas-em-alta-rgba-54-20-38-0-82: rgba(0,0,0,0.82);
    --historietas-em-alta-rgba-54-22-45-0-82: rgba(0,0,0,0.82);
    --historietas-em-alta-rgba-56-189-248-0-12: rgba(212,212,216,0.12);
    --historietas-em-alta-rgba-56-189-248-0-22: rgba(212,212,216,0.22);
    --historietas-em-alta-rgba-56-189-248-0-42: rgba(212,212,216,0.42);
    --historietas-em-alta-rgba-56-189-248-0-58: rgba(212,212,216,0.58);
    --historietas-em-alta-rgba-59-7-100-0-58: rgba(0,0,0,0.58);
    --historietas-em-alta-rgba-6-21-35-0-76: rgba(0,0,0,0.76);
    --historietas-page-background: #000000;
    --historietas-bg-start: #000000;
    --historietas-bg-mid: #000000;
    --historietas-bg-end: #000000;
    --historietas-surface: #050505;
    --historietas-surface-strong: #000000;
    --historietas-text-primary: #FFFFFF;
    --historietas-text-secondary: #A1A1AA;
    --historietas-accent: #FFFFFF;
    --historietas-secondary: #A1A1AA;
    --historietas-border-soft: rgba(255,255,255,0.18);
    --historietas-active-surface: rgba(255,255,255,0.10);
    --historietas-secondary-surface: rgba(255,255,255,0.06);
    --historietas-title-from: #FFFFFF;
    --historietas-title-mid: #FFFFFF;
    --historietas-title-to: #FFFFFF;
  }

  html[data-historietas-tema-visual="original"] body,
  html[data-historietas-tema-visual="original"] main.historietas-em-alta-page {
    background: #070212 !important;
  }

  html[data-historietas-tema-visual="foco"] body,
  html[data-historietas-tema-visual="foco"] main.historietas-em-alta-page {
    background: #000000 !important;
    color: #FFFFFF !important;
    color-scheme: dark;
  }

  .historietas-em-alta-page,
  .historietas-em-alta-page *,
  .historietas-em-alta-page *::before,
  .historietas-em-alta-page *::after {
    -webkit-tap-highlight-color: transparent !important;
  }

  .historietas-em-alta-page a,
  .historietas-em-alta-page button,
  .historietas-em-alta-page [role="link"],
  .historietas-em-alta-page [role="button"] {
    -webkit-tap-highlight-color: transparent !important;
    -webkit-touch-callout: none;
    touch-action: manipulation;
  }

  .historietas-em-alta-page a:active,
  .historietas-em-alta-page button:active,
  .historietas-em-alta-page [role="link"]:active,
  .historietas-em-alta-page [role="button"]:active,
  .historietas-em-alta-page a:focus,
  .historietas-em-alta-page button:focus,
  .historietas-em-alta-page [role="link"]:focus,
  .historietas-em-alta-page [role="button"]:focus,
  .historietas-em-alta-page a:focus-visible,
  .historietas-em-alta-page button:focus-visible,
  .historietas-em-alta-page [role="link"]:focus-visible,
  .historietas-em-alta-page [role="button"]:focus-visible {
    outline: none !important;
  }

  html[data-historietas-tema-visual="foco"] .historietas-ranking-card[data-ranking-level="diamante"] {
    --historietas-ranking-line-color: #7DD3FC;
  }

  html[data-historietas-tema-visual="foco"] .historietas-ranking-card[data-ranking-level="rubi"] {
    --historietas-ranking-line-color: #FB7185;
  }

  html[data-historietas-tema-visual="foco"] .historietas-ranking-card[data-ranking-level="ouro"] {
    --historietas-ranking-line-color: #FBBF24;
  }

  html[data-historietas-tema-visual="foco"] .historietas-ranking-card[data-ranking-level="prata"] {
    --historietas-ranking-line-color: #CBD5E1;
  }

  html[data-historietas-tema-visual="foco"] .historietas-ranking-card[data-ranking-level="bronze"] {
    --historietas-ranking-line-color: #FB923C;
  }

  html[data-historietas-tema-visual="foco"] .historietas-em-alta-page article {
    background: #050505 !important;
    background-color: #050505 !important;
    background-image: none !important;
    border: 1px solid rgba(255,255,255,0.18) !important;
    box-shadow: none !important;
  }

  html[data-historietas-tema-visual="foco"] .historietas-em-alta-page article.historietas-ranking-card {
    border-color: var(--historietas-ranking-line-color, rgba(255,255,255,0.18)) !important;
  }

  html[data-historietas-tema-visual="foco"] .historietas-ranking-card .historietas-ranking-level-line {
    border: 1px solid var(--historietas-ranking-line-color, rgba(255,255,255,0.18)) !important;
    background: transparent !important;
    background-color: transparent !important;
    background-image: none !important;
    backdrop-filter: none !important;
    -webkit-backdrop-filter: none !important;
  }

  html[data-historietas-tema-visual="foco"] .historietas-em-alta-page *,
  html[data-historietas-tema-visual="foco"] .historietas-em-alta-page *::before,
  html[data-historietas-tema-visual="foco"] .historietas-em-alta-page *::after {
    box-shadow: none !important;
    text-shadow: none !important;
  }

  html[data-historietas-tema-visual="foco"] .historietas-em-alta-hero-title {
    background: none !important;
    color: #FFFFFF !important;
    -webkit-text-fill-color: #FFFFFF !important;
    text-shadow: none !important;
  }

  html[data-historietas-tema-visual="foco"] .historietas-em-alta-emoji-icon {
    filter: none !important;
  }

  html[data-historietas-tema-visual="foco"] .historietas-em-alta-heart-icon {
    color: #EF4444 !important;
    -webkit-text-fill-color: #EF4444 !important;
  }

  html[data-historietas-tema-visual="foco"] .historietas-em-alta-logo-mark {
    background: #04000A !important;
    color: #FFFFFF !important;
    border-color: rgba(59, 7, 100, 0.58) !important;
    box-shadow: none !important;
  }

  html[data-historietas-tema-visual="foco"] .historietas-em-alta-page > div[aria-hidden="true"] {
    opacity: 0 !important;
  }

  html[data-historietas-tema-visual="foco"] input::placeholder,
  html[data-historietas-tema-visual="foco"] textarea::placeholder {
    color: #A1A1AA !important;
    opacity: 1 !important;
  }

  html[data-historietas-tema-visual="foco"] input,
  html[data-historietas-tema-visual="foco"] textarea,
  html[data-historietas-tema-visual="foco"] select {
    background: #000000 !important;
    color: #FFFFFF !important;
    border-color: rgba(255,255,255,0.18) !important;
  }

  html[data-historietas-tema-visual] nav a[href="/em-alta"],
  html[data-historietas-tema-visual] [data-bottom-nav] a[href="/em-alta"],
  html[data-historietas-tema-visual] [data-mobile-nav] a[href="/em-alta"] {
    background: transparent !important;
    background-image: none !important;
    border: 0 !important;
    box-shadow: none !important;
    outline: none !important;
  }

  html[data-historietas-tema-visual] nav a[href="/em-alta"]:not([aria-current="page"]):not(.historietas-bottom-nav-item-active),
  html[data-historietas-tema-visual] [data-bottom-nav] a[href="/em-alta"]:not([aria-current="page"]):not(.historietas-bottom-nav-item-active),
  html[data-historietas-tema-visual] [data-mobile-nav] a[href="/em-alta"]:not([aria-current="page"]):not(.historietas-bottom-nav-item-active) {
    color: var(--historietas-bottom-nav-text, #A1A1AA) !important;
    -webkit-text-fill-color: var(--historietas-bottom-nav-text, #A1A1AA) !important;
  }

  html[data-historietas-tema-visual] nav a[href="/em-alta"][aria-current="page"],
  html[data-historietas-tema-visual] nav a[href="/em-alta"].historietas-bottom-nav-item-active,
  html[data-historietas-tema-visual] [data-bottom-nav] a[href="/em-alta"][aria-current="page"],
  html[data-historietas-tema-visual] [data-bottom-nav] a[href="/em-alta"].historietas-bottom-nav-item-active,
  html[data-historietas-tema-visual] [data-mobile-nav] a[href="/em-alta"][aria-current="page"],
  html[data-historietas-tema-visual] [data-mobile-nav] a[href="/em-alta"].historietas-bottom-nav-item-active {
    color: #FFFFFF !important;
    -webkit-text-fill-color: #FFFFFF !important;
  }

  html[data-historietas-tema-visual] nav a[href="/em-alta"] .historietas-bottom-nav-icon,
  html[data-historietas-tema-visual] [data-bottom-nav] a[href="/em-alta"] .historietas-bottom-nav-icon,
  html[data-historietas-tema-visual] [data-mobile-nav] a[href="/em-alta"] .historietas-bottom-nav-icon {
    color: currentColor !important;
    background: transparent !important;
    background-image: none !important;
    border: 0 !important;
    border-radius: 0 !important;
    box-shadow: none !important;
    filter: none !important;
  }

  html[data-historietas-tema-visual] nav a[href="/em-alta"] .historietas-bottom-nav-svg,
  html[data-historietas-tema-visual] nav a[href="/em-alta"] .historietas-bottom-nav-svg *,
  html[data-historietas-tema-visual] [data-bottom-nav] a[href="/em-alta"] .historietas-bottom-nav-svg,
  html[data-historietas-tema-visual] [data-bottom-nav] a[href="/em-alta"] .historietas-bottom-nav-svg *,
  html[data-historietas-tema-visual] [data-mobile-nav] a[href="/em-alta"] .historietas-bottom-nav-svg,
  html[data-historietas-tema-visual] [data-mobile-nav] a[href="/em-alta"] .historietas-bottom-nav-svg * {
    color: currentColor !important;
    stroke: currentColor !important;
  }
`;


const safeTextStyle: CSSProperties = {
  overflowWrap: "anywhere",
  wordBreak: "break-word",
};

const pageDecorationLayerStyle: CSSProperties = {
  position: "absolute",
  inset: 0,
  overflow: "hidden",
  pointerEvents: "none",
  zIndex: 0,
};

const mobileTopWaterFadeStyle: CSSProperties = {
  position: "absolute",
  top: 0,
  left: 0,
  right: 0,
  height: "min(340px, 48vh)",
  pointerEvents: "none",
  zIndex: 0,
  background: "transparent",
  WebkitMaskImage: "none",
  maskImage: "none",
};

const desktopTopWaterFadeStyle: CSSProperties = {
  position: "absolute",
  top: 0,
  left: 0,
  right: 0,
  height: "min(620px, 68vh)",
  pointerEvents: "none",
  zIndex: 0,
  background: "transparent",
  WebkitMaskImage: "none",
  maskImage: "none",
};

const loadingPageStyle: CSSProperties = {
  position: "relative",
  zIndex: 2,
  width: "100%",
  minHeight: "100dvh",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  boxSizing: "border-box",
};

const loadingSpinnerStyle: CSSProperties = {
  width: "30px",
  height: "30px",
  borderRadius: "999px",
  border: "3px solid rgba(255,255,255,0.20)",
  borderTopColor: "#FFFFFF",
  boxSizing: "border-box",
  animation: "historietas-loading-spin 0.78s linear infinite",
  flex: "0 0 auto",
};

const pageStyle: CSSProperties = {
  position: "relative",
  minHeight: "100vh",
  width: "100%",
  maxWidth: "100vw",
  overflowX: "hidden",
  backgroundColor: "var(--historietas-em-alta-hex-070212, #070212)",
  background: "var(--historietas-em-alta-hex-070212, #070212)",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontFamily: "Inter, Poppins, Manrope, Arial, Helvetica, sans-serif",
};

const containerStyle: CSSProperties = {
  position: "relative",
  zIndex: 1,
  width: "min(820px, calc(100% - 28px))",
  maxWidth: "100%",
  margin: "0 auto",
  padding: "14px 0 116px",
  boxSizing: "border-box",
  minWidth: 0,
};

const desktopContainerStyle: CSSProperties = {
  ...containerStyle,
  width: "min(1180px, calc(100% - 64px))",
  padding: "18px 0 84px",
};

const topStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  gap: "12px",
  marginBottom: "14px",
  minWidth: 0,
};

const titleStyle: CSSProperties = {
  position: "relative",
  zIndex: 1,
  margin: 0,
  fontSize: "clamp(30px, 8vw, 46px)",
  lineHeight: 1.04,
  fontWeight: 950,
  letterSpacing: "-0.074em",
  maxWidth: "100%",
  textAlign: "center",
  background:
    "linear-gradient(135deg, var(--historietas-title-from, #FFFFFF) 0%, var(--historietas-title-mid, var(--historietas-em-alta-hex-f5f3ff, #F5F3FF)) 42%, var(--historietas-title-to, var(--historietas-em-alta-hex-fdba74, #FDBA74)) 100%)",
  WebkitBackgroundClip: "text",
  backgroundClip: "text",
  color: "transparent",
  textShadow: "none",
  ...safeTextStyle,
};

const desktopTitleStyle: CSSProperties = {
  ...titleStyle,
  fontSize: "clamp(38px, 4.4vw, 58px)",
  maxWidth: "760px",
  margin: "0 auto",
  textAlign: "center",
};

const titleHeaderStyle: CSSProperties = {
  ...topStyle,
  justifyContent: "center",
  marginTop: "4px",
  marginBottom: "18px",
  textAlign: "center",
};

const desktopTitleHeaderStyle: CSSProperties = {
  ...titleHeaderStyle,
  position: "relative",
  marginTop: "6px",
  marginBottom: "22px",
};



const headerTitleLinkStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  textDecoration: "none",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  gap: "3px",
  width: "100%",
  maxWidth: "100%",
  margin: "0 auto",
  minWidth: 0,
  textAlign: "center",
};

const desktopHeaderTitleLinkStyle: CSSProperties = {
  ...headerTitleLinkStyle,
  gap: "4px",
};

const headerTitleMarkStyle: CSSProperties = {
  width: "clamp(36px, 8vw, 48px)",
  height: "clamp(36px, 8vw, 48px)",
  borderRadius: "clamp(12px, 2.6vw, 16px)",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  background: "var(--historietas-em-alta-hex-04000a, #04000A)",
  color: "#FFFFFF",
  fontSize: "clamp(18px, 4.3vw, 24px)",
  lineHeight: 1,
  fontWeight: 950,
  letterSpacing: "-0.04em",
  flex: "0 0 auto",
  border: "1px solid var(--historietas-em-alta-rgba-59-7-100-0-58, rgba(59, 7, 100, 0.58))",
  boxShadow: "none",
};

const desktopHeaderTitleMarkStyle: CSSProperties = {
  ...headerTitleMarkStyle,
  width: "50px",
  height: "50px",
  borderRadius: "17px",
  fontSize: "25px",
};

const headerTitleTextStyle: CSSProperties = {
  ...titleStyle,
  margin: 0,
  fontSize: "clamp(26px, 6.8vw, 40px)",
  maxWidth: "calc(100vw - 86px)",
  textAlign: "center",
  background: "none",
  WebkitBackgroundClip: "initial",
  backgroundClip: "initial",
  color: "#FFFFFF",
  textShadow: "none",
  textTransform: "uppercase",
  wordSpacing: "0.1em",
  whiteSpace: "nowrap",
};

const desktopHeaderTitleTextStyle: CSSProperties = {
  ...headerTitleTextStyle,
  fontSize: "clamp(34px, 3.6vw, 44px)",
  maxWidth: "760px",
};

const sectionStyle: CSSProperties = {
  marginTop: "32px",
  paddingBottom: "14px",
  maxWidth: "100%",
  boxSizing: "border-box",
  minWidth: 0,
};

const desktopSectionStyle: CSSProperties = {
  ...sectionStyle,
  marginTop: "40px",
  paddingBottom: "18px",
};

const sectionHeaderStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "minmax(0, 1fr)",
  justifyItems: "center",
  gap: "6px",
  marginBottom: "14px",
  maxWidth: "100%",
  minWidth: 0,
  textAlign: "center",
};

const desktopSectionHeaderStyle: CSSProperties = {
  ...sectionHeaderStyle,
  padding: "8px 0 12px",
  borderRadius: 0,
};

const sectionTitleStyle: CSSProperties = {
  margin: 0,
  color: "#FFFFFF",
  fontSize: "clamp(24px, 4vw, 30px)",
  lineHeight: 1.05,
  fontWeight: 950,
  letterSpacing: "-0.03em",
  maxWidth: "100%",
  textAlign: "center",
  textShadow: "none",
  ...safeTextStyle,
};

const carouselShellStyle: CSSProperties = {
  position: "relative",
  minWidth: 0,
  width: "100%",
  maxWidth: "100%",
  boxSizing: "border-box",
  overflow: "visible",
};

const desktopCarouselShellStyle: CSSProperties = {
  ...carouselShellStyle,
  width: "100%",
  maxWidth: "100%",
  marginLeft: 0,
  marginRight: 0,
  overflow: "visible",
  marginTop: "0",
};

const carouselArrowButtonStyle: CSSProperties = {
  position: "absolute",
  top: "50%",
  transform: "translateY(-50%)",
  zIndex: 8,
  width: "52px",
  height: "96px",
  padding: 0,
  borderRadius: 0,
  border: "none",
  background: "transparent",
  color: "#FFFFFF",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  cursor: "pointer",
  boxShadow: "none",
  outline: "none",
  WebkitTapHighlightColor: "transparent",
  touchAction: "manipulation",
};

const carouselArrowIconStyle: CSSProperties = {
  display: "block",
  width: "18px",
  height: "18px",
  borderTop: "4px solid #FFFFFF",
  borderRight: "4px solid #FFFFFF",
  filter: "drop-shadow(0 2px 5px rgba(0,0,0,0.92))",
  pointerEvents: "none",
  boxSizing: "border-box",
};

const carouselArrowLeftIconStyle: CSSProperties = {
  ...carouselArrowIconStyle,
  transform: "rotate(-135deg)",
};

const carouselArrowRightIconStyle: CSSProperties = {
  ...carouselArrowIconStyle,
  transform: "rotate(45deg)",
};

const carouselArrowLeftStyle: CSSProperties = {
  ...carouselArrowButtonStyle,
  left: "-10px",
};

const carouselArrowRightStyle: CSSProperties = {
  ...carouselArrowButtonStyle,
  right: "-10px",
};

const carouselStyle: CSSProperties = {
  display: "flex",
  alignItems: "stretch",
  gap: "16px",
  width: "calc(100% + 24px)",
  maxWidth: "calc(100% + 24px)",
  minWidth: 0,
  boxSizing: "border-box",
  overflowX: "auto",
  overflowY: "hidden",
  padding: "4px 12px 22px",
  margin: "0 -12px",
  scrollSnapType: "x mandatory",
  scrollPaddingLeft: "12px",
  scrollPaddingRight: "12px",
  scrollbarWidth: "none",
  overscrollBehaviorX: "contain",
};

const desktopCarouselStyle: CSSProperties = {
  ...carouselStyle,
  gap: "22px",
  width: "calc(100% + 24px)",
  maxWidth: "calc(100% + 24px)",
  padding: "8px 12px 30px",
  margin: "0 -12px",
  scrollPaddingLeft: "12px",
  scrollPaddingRight: "12px",
};

const sectionHeaderContentStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  gap: "10px",
  minWidth: 0,
  textAlign: "center",
};

const desktopSectionHeaderContentStyle: CSSProperties = {
  ...sectionHeaderContentStyle,
  justifyContent: "center",
  textAlign: "center",
};

const sectionTextBlockStyle: CSSProperties = {
  minWidth: 0,
  display: "grid",
  justifyItems: "center",
  textAlign: "center",
};

const desktopSectionTextBlockStyle: CSSProperties = {
  ...sectionTextBlockStyle,
  maxWidth: "760px",
  textAlign: "center",
};

const cardStyle: CSSProperties = {
  position: "relative",
  flex: "0 0 min(360px, 88vw)",
  width: "min(360px, 88vw)",
  scrollSnapAlign: "start",
  scrollSnapStop: "always",
  display: "grid",
  gridTemplateColumns: "minmax(88px, 98px) minmax(0, 1fr)",
  gap: "14px",
  alignItems: "stretch",
  padding: "11px",
  borderRadius: "22px",
  background: "var(--historietas-em-alta-rgba-4-0-10-0-72, rgba(4, 0, 10, 0.72))",
  border: "1px solid rgba(255,255,255,0.06)",
  color: "var(--historietas-text-primary, #FFFFFF)",
  textDecoration: "none",
  minWidth: 0,
  maxWidth: "88vw",
  overflow: "hidden",
  boxShadow: "none",
  boxSizing: "border-box",
  cursor: "pointer",
  WebkitTapHighlightColor: "transparent",
  touchAction: "manipulation",
  userSelect: "none",
};

const desktopCardStyle: CSSProperties = {
  ...cardStyle,
  flex: "0 0 calc((100% - 44px) / 3)",
  width: "calc((100% - 44px) / 3)",
  maxWidth: "none",
  minWidth: 0,
  gridTemplateColumns: "112px minmax(0, 1fr)",
  gap: "15px",
  padding: "13px",
  borderRadius: "24px",
  boxShadow: "none",
};

const cardSoonStyle: CSSProperties = {
  ...cardStyle,
  opacity: 0.9,
};

const desktopCardSoonStyle: CSSProperties = {
  ...desktopCardStyle,
  opacity: 0.9,
};

const coroaNumberStyle: CSSProperties = {
  fontSize: "11px",
  fontWeight: 950,
  lineHeight: 1,
  color: "#FFFFFF",
  textShadow: "0 1px 4px rgba(0,0,0,0.28)",
};

const coverStyle: CSSProperties = {
  minHeight: "122px",
  borderRadius: "16px",
  position: "relative",
  overflow: "hidden",
  backgroundImage: "linear-gradient(135deg, var(--historietas-em-alta-hex-08030f, #08030F) 0%, var(--historietas-em-alta-hex-04000a, #04000A) 100%)",
  backgroundSize: "cover",
  backgroundPosition: "center",
  maxWidth: "100%",
  boxSizing: "border-box",
  minWidth: 0,
  border: "none",
  outline: "none",
  boxShadow: "none",
  transform: "scaleX(1.125) scaleY(1.095)",
  transformOrigin: "center",
};

const desktopCoverStyle: CSSProperties = {
  ...coverStyle,
  minHeight: "142px",
  borderRadius: "18px",
};

const cardContentStyle: CSSProperties = {
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  display: "grid",
  alignContent: "center",
  gap: "7px",
};

const desktopCardContentStyle: CSSProperties = {
  ...cardContentStyle,
  gap: "7px",
  alignContent: "center",
};

const cardTopStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "1fr",
  gap: "8px",
  minWidth: 0,
};

const cardTitleStyle: CSSProperties = {
  margin: 0,
  color: "#FFFFFF",
  fontSize: "20px",
  lineHeight: 1.05,
  fontFamily:
    'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  fontWeight: 500,
  letterSpacing: "-0.01em",
  maxWidth: "100%",
  display: "-webkit-box",
  WebkitLineClamp: 2,
  WebkitBoxOrient: "vertical",
  overflow: "hidden",
  ...safeTextStyle,
};

const statusRowStyle: CSSProperties = {
  display: "flex",
  flexWrap: "wrap",
  gap: "6px",
  minWidth: 0,
};

const cardMetaRowStyle: CSSProperties = {
  display: "flex",
  flexWrap: "wrap",
  gap: "6px",
  maxWidth: "100%",
  minWidth: 0,
};

const rankingCardActionRowStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: "8px",
  marginTop: "2px",
  maxWidth: "100%",
  minWidth: 0,
  overflow: "hidden",
  boxSizing: "border-box",
};

const desktopRankingCardActionRowStyle: CSSProperties = {
  ...rankingCardActionRowStyle,
  overflow: "visible",
};

const rankingThemeBadgeStyle: CSSProperties = {
  flex: "0 1 42%",
  maxWidth: "42%",
  minHeight: "34px",
  padding: "0 10px",
  borderRadius: "999px",
  background: "rgba(255,255,255,0.06)",
  border: "1px solid rgba(255,255,255,0.08)",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "11px",
  fontWeight: 900,
  lineHeight: 1.12,
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  whiteSpace: "nowrap",
  overflow: "hidden",
  textOverflow: "ellipsis",
  boxSizing: "border-box",
  ...safeTextStyle,
};

const desktopRankingThemeBadgeStyle: CSSProperties = {
  ...rankingThemeBadgeStyle,
  flex: "0 1 46%",
  maxWidth: "46%",
  padding: "0 8px",
  textAlign: "center",
  whiteSpace: "normal",
  overflow: "visible",
  textOverflow: "clip",
};

const rankingHighlightBadgeInlineStyle: CSSProperties = {
  flex: "1 1 auto",
  minWidth: 0,
  marginTop: 0,
  padding: "0 12px",
  textAlign: "center",
};

const statusStyle: CSSProperties = {
  width: "fit-content",
  maxWidth: "100%",
  padding: "6px 9px",
  borderRadius: "999px",
  background:
    "color-mix(in srgb, var(--historietas-accent, var(--historietas-em-alta-hex-f97316, #F97316)) 14%, transparent)",
  border:
    "1px solid color-mix(in srgb, var(--historietas-accent, var(--historietas-em-alta-hex-f97316, #F97316)) 28%, transparent)",
  color: "var(--historietas-accent, var(--historietas-em-alta-hex-fdba74, #FDBA74))",
  fontSize: "11px",
  fontWeight: 850,
  whiteSpace: "normal",
  ...safeTextStyle,
};

const publishedStatusStyle: CSSProperties = {
  width: "fit-content",
  maxWidth: "100%",
  padding: "6px 9px",
  borderRadius: "999px",
  background: "var(--historietas-em-alta-rgba-34-197-94-0-14, rgba(34, 197, 94, 0.14))",
  border: "1px solid var(--historietas-em-alta-rgba-34-197-94-0-3, rgba(34, 197, 94, 0.3))",
  color: "var(--historietas-em-alta-hex-86efac, #86EFAC)",
  fontSize: "11px",
  fontWeight: 900,
  whiteSpace: "normal",
  ...safeTextStyle,
};

const formatBadgeStyle: CSSProperties = {
  width: "fit-content",
  maxWidth: "100%",
  padding: "5px 8px",
  borderRadius: "999px",
  background: "rgba(255,255,255,0.06)",
  border: "none",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "10px",
  fontWeight: 900,
  whiteSpace: "normal",
  ...safeTextStyle,
};

const classificationBadgeStyle: CSSProperties = {
  width: "fit-content",
  maxWidth: "100%",
  padding: "5px 8px",
  borderRadius: "999px",
  background: "rgba(255,255,255,0.06)",
  border: "none",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "10px",
  fontWeight: 950,
  whiteSpace: "normal",
  ...safeTextStyle,
};

const highlightBadgeStyle: CSSProperties = {
  width: "fit-content",
  maxWidth: "100%",
  minHeight: "34px",
  padding: "0 10px",
  marginTop: "4px",
  borderRadius: "999px",
  background: "rgba(255,255,255,0.06)",
  border: "1px solid rgba(255,255,255,0.08)",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "11px",
  fontWeight: 900,
  lineHeight: 1.12,
  textDecoration: "none",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  gap: "5px",
  boxSizing: "border-box",
  whiteSpace: "normal",
  overflow: "hidden",
  textOverflow: "ellipsis",
  ...safeTextStyle,
};

const authorStyle: CSSProperties = {
  margin: 0,
  color: "var(--historietas-text-secondary, var(--historietas-em-alta-hex-d8c8ff, #D8C8FF))",
  fontSize: "12px",
  fontFamily:
    'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  fontWeight: 450,
  lineHeight: 1.25,
  maxWidth: "100%",
  display: "-webkit-box",
  WebkitLineClamp: 1,
  WebkitBoxOrient: "vertical",
  overflow: "hidden",
  ...safeTextStyle,
};

const authorLinkStyle: CSSProperties = {
  ...authorStyle,
  textDecoration: "none",
  cursor: "pointer",
  WebkitTapHighlightColor: "transparent",
  touchAction: "manipulation",
};

const statsStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: "8px",
  flexWrap: "wrap",
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "11px",
  fontFamily:
    'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  fontWeight: 850,
  maxWidth: "100%",
  minWidth: 0,
};

const ratingStatsStyle: CSSProperties = {
  ...statsStyle,
  flexWrap: "nowrap",
};

const statsItemStyle: CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  gap: "4px",
  minWidth: 0,
  whiteSpace: "nowrap",
  lineHeight: 1,
};

const metricIconStyle: CSSProperties = {
  width: "14px",
  minWidth: "14px",
  height: "17px",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  lineHeight: 1,
  fontSize: "13px",
};

const metricValueStyle: CSSProperties = {
  display: "inline-block",
  lineHeight: 1,
  whiteSpace: "nowrap",
  color: "#FFFFFF",
};

const heartMetricIconStyle: CSSProperties = {
  ...metricIconStyle,
  width: "16px",
  minWidth: "16px",
  fontSize: "13px",
  color: "var(--historietas-em-alta-hex-ef4444, #EF4444)",
};

const starMetricIconStyle: CSSProperties = {
  ...metricIconStyle,
  color: "var(--historietas-em-alta-hex-fbbf24, #FBBF24)",
  transform: "translateY(-1px)",
};

const progressCompactStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "1fr auto",
  alignItems: "center",
  gap: "8px",
  minWidth: 0,
};

const progressTrackStyle: CSSProperties = {
  width: "100%",
  height: "7px",
  borderRadius: "999px",
  background: "var(--historietas-secondary-surface, rgba(255,255,255,0.08))",
  border: "1px solid var(--historietas-border-soft, rgba(255,255,255,0.1))",
  overflow: "hidden",
};

const progressBarStyle: CSSProperties = {
  height: "100%",
  borderRadius: "999px",
  background:
    "linear-gradient(135deg, var(--historietas-accent, var(--historietas-em-alta-hex-f97316, #F97316)) 0%, var(--historietas-secondary, var(--historietas-em-alta-hex-7c3aed, #7C3AED)) 100%)",
};

const progressTextStyle: CSSProperties = {
  margin: 0,
  color: "#D4D4D8",
  fontSize: "11px",
  fontWeight: 850,
  lineHeight: 1.2,
  whiteSpace: "nowrap",
};

const readStyle: CSSProperties = {
  width: "fit-content",
  maxWidth: "100%",
  marginTop: "2px",
  color: "var(--historietas-accent, var(--historietas-em-alta-hex-f97316, #F97316))",
  fontSize: "14px",
  fontWeight: 950,
  ...safeTextStyle,
};

const soonReadStyle: CSSProperties = {
  width: "fit-content",
  maxWidth: "100%",
  marginTop: "4px",
  color: "#A1A1AA",
  fontSize: "14px",
  fontWeight: 950,
  ...safeTextStyle,
};

const authorRankingSectionStyle: CSSProperties = {
  ...sectionStyle,
  marginTop: "38px",
};

const desktopAuthorRankingSectionStyle: CSSProperties = {
  ...desktopSectionStyle,
  marginTop: "44px",
};

const authorRankingSectionIconStyle: CSSProperties = {
  width: "auto",
  height: "auto",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  color: "var(--historietas-em-alta-hex-fbbf24, #FBBF24)",
  fontSize: "28px",
  lineHeight: 1,
  fontWeight: 950,
};

const authorRankingSectionTitleStyle: CSSProperties = {
  ...sectionTitleStyle,
  color: "var(--historietas-em-alta-hex-fbbf24, #FBBF24)",
  textAlign: "center",
};

const authorRankingDescriptionStyle: CSSProperties = {
  margin: "4px 0 0",
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "12px",
  lineHeight: 1.35,
  fontWeight: 750,
  textAlign: "center",
  maxWidth: "560px",
  ...safeTextStyle,
};

const authorRankingCarouselStyle: CSSProperties = {
  ...carouselStyle,
  gridAutoColumns: "minmax(278px, calc(100vw - 52px))",
};

const desktopAuthorRankingCarouselStyle: CSSProperties = {
  ...desktopCarouselStyle,
  gridAutoColumns: "minmax(340px, 370px)",
};

const authorRankingCardStyle: CSSProperties = {
  position: "relative",
  display: "grid",
  gridTemplateColumns: "88px minmax(0, 1fr)",
  alignItems: "center",
  gap: "12px",
  minHeight: "154px",
  padding: "12px",
  paddingRight: "50px",
  borderRadius: "24px",
  color: "var(--historietas-text-primary, #FFFFFF)",
  cursor: "pointer",
  scrollSnapAlign: "start",
  minWidth: 0,
  overflow: "hidden",
  boxSizing: "border-box",
  boxShadow: "none",
};

const desktopAuthorRankingCardStyle: CSSProperties = {
  ...authorRankingCardStyle,
  gridTemplateColumns: "96px minmax(0, 1fr)",
  minHeight: "164px",
  padding: "14px",
  paddingRight: "54px",
  borderRadius: "26px",
};

const authorRankingAvatarStyle: CSSProperties = {
  position: "relative",
  width: "88px",
  height: "112px",
  borderRadius: "22px",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  overflow: "hidden",
  flex: "0 0 auto",
};

const desktopAuthorRankingAvatarStyle: CSSProperties = {
  ...authorRankingAvatarStyle,
  width: "96px",
  height: "124px",
  borderRadius: "24px",
};

const authorRankingAvatarInitialStyle: CSSProperties = {
  color: "#FFFFFF",
  fontSize: "34px",
  lineHeight: 1,
  fontWeight: 950,
  textShadow: "0 4px 12px rgba(0,0,0,0.42)",
};

const authorRankingTierBadgeStyle: CSSProperties = {
  position: "absolute",
  left: "6px",
  right: "6px",
  bottom: "6px",
  zIndex: 3,
  minHeight: "24px",
  padding: "0 7px",
  borderRadius: "999px",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  gap: "4px",
  fontSize: "8px",
  lineHeight: 1,
  fontWeight: 950,
  letterSpacing: "0.055em",
  textTransform: "uppercase",
  whiteSpace: "nowrap",
  boxShadow: "0 6px 12px rgba(0,0,0,0.22)",
  ...safeTextStyle,
};

const authorRankingContentStyle: CSSProperties = {
  display: "grid",
  alignContent: "center",
  gap: "7px",
  minWidth: 0,
};

const authorRankingCardTitleStyle: CSSProperties = {
  margin: 0,
  fontSize: "19px",
  lineHeight: 1.05,
  fontFamily:
    'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  fontWeight: 500,
  letterSpacing: "-0.01em",
  maxWidth: "100%",
  display: "-webkit-box",
  WebkitLineClamp: 2,
  WebkitBoxOrient: "vertical",
  overflow: "hidden",
  ...safeTextStyle,
};

const authorRankingWorksStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, var(--historietas-em-alta-hex-c4b5fd, #C4B5FD))",
  fontSize: "11px",
  lineHeight: 1.15,
  fontWeight: 850,
  ...safeTextStyle,
};

const authorRankingStatsStyle: CSSProperties = {
  ...statsStyle,
  columnGap: "7px",
  fontSize: "11px",
};

const authorRankingTitleAreaStyle: CSSProperties = {
  ...cardTopStyle,
  minHeight: "21px",
  paddingRight: "2px",
};

const authorRankingMetaStackStyle: CSSProperties = {
  display: "grid",
  justifyItems: "start",
  alignItems: "start",
  gap: "5px",
  width: "100%",
  minWidth: 0,
};

const authorRankingWorksBadgeStyle: CSSProperties = {
  margin: 0,
  color: "var(--historietas-text-secondary, var(--historietas-em-alta-hex-d8c8ff, #D8C8FF))",
  fontSize: "12px",
  fontFamily:
    'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  fontWeight: 450,
  lineHeight: 1.25,
  width: "fit-content",
  maxWidth: "100%",
  background: "transparent",
  border: "none",
  padding: 0,
  borderRadius: 0,
  whiteSpace: "normal",
  ...safeTextStyle,
};

const authorRankingScoreRowStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: "8px",
  flexWrap: "wrap",
  marginTop: "4px",
  maxWidth: "100%",
  minWidth: 0,
};

const emptyButtonStyle: CSSProperties = {
  width: "fit-content",
  minHeight: "40px",
  margin: "0 auto",
  padding: "0 15px",
  borderRadius: "999px",
  background: "var(--historietas-em-alta-hex-08030f, #08030F)",
  color: "#FFFFFF",
  textDecoration: "none",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: "13px",
  fontWeight: 950,
  border: "1px solid rgba(255,255,255,0.10)",
  boxShadow: "none",
};