"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import type { CSSProperties } from "react";
import { supabase } from "../../../lib/supabase/client";
import { formatarData, normalizarTexto } from "../../../lib/utils";
import {
  historietasThemeCss,
  useHistorietasTheme,
} from "../../../lib/historietasTheme";
import { useNotificacoes } from "../../../components/NotificacoesProvider";
import { useHistorietasLanguage } from "../../../components/HistorietasLanguageProvider";
import type { HistorietasLanguage } from "../../../lib/i18n";

type TipoAlvoDenuncia =
  | "post"
  | "comentario"
  | "comentario_capitulo"
  | "obra"
  | "capitulo"
  | "comentario_obra"
  | "diario_anotacao"
  | "comentario_diario";

type StatusDenuncia =
  | "pendente"
  | "em_analise"
  | "resolvida"
  | "rejeitada";

type StatusFiltroDenuncia = StatusDenuncia | "todas" | "arquivadas";

type DenunciaComunidade = {
  id: string;
  alvoTipo: TipoAlvoDenuncia;
  alvoId: string;
  denuncianteId: string;
  motivo: string;
  detalhe: string;
  status: StatusDenuncia;
  arquivada: boolean;
  observacaoAdmin: string;
  analisadoPor: string | null;
  analisadoEm: string | null;
  criadoEm: string;
};

type PostDenunciado = {
  id: string;
  autor_nome: string;
  categoria: string;
  tipo_publicacao: string | null;
  tem_spoiler: boolean | null;
  texto: string;
  obra_relacionada: string | null;
  criado_em: string;
};

type ComentarioDenunciado = {
  id: string;
  post_id: string;
  autor_nome: string;
  texto: string;
  criado_em: string;
};

type ComentarioCapituloDenunciado = {
  id: string;
  capitulo_id: string;
  user_id: string;
  comentario: string;
  criado_em: string;
};

type CapituloContextoDenuncia = {
  id: string;
  obra_id: string;
  titulo: string | null;
};

type CapituloDenunciado = {
  id: string;
  obra_id: string;
  user_id: string;
  titulo: string | null;
  texto: string | null;
  ordem: number | null;
  publicado: boolean | null;
  criado_em: string;
};

type ObraDenunciada = {
  id: string;
  user_id: string;
  titulo: string | null;
  autor: string | null;
  slug: string | null;
  link: string | null;
  publicado: boolean | null;
  criada_em: string;
};

type ComentarioObraDenunciado = {
  id: string;
  obra_id: string;
  user_id: string;
  comentario: string;
  criado_em: string;
};

type DiarioAnotacaoDenunciada = {
  id: string;
  obra_id: string;
  user_id: string;
  tipo: string | null;
  texto: string;
  visibilidade: string | null;
  contem_spoiler: boolean | null;
  criado_em: string;
  atualizado_em: string | null;
};

type ComentarioDiarioDenunciado = {
  id: string;
  anotacao_id: string;
  user_id: string;
  texto: string;
  criado_em: string;
  atualizado_em: string | null;
};


type PerfilModeracao = {
  id?: string | null;
  user_id?: string | null;
  nome: string | null;
};

type DenunciaComContexto = DenunciaComunidade & {
  denuncianteNome: string;
  alvoResumo: string;
  alvoAutor: string;
  alvoData: string;
  alvoPostId: string;
  alvoCategoria?: string;
  alvoTipoPublicacao?: string;
  alvoTemSpoiler?: boolean;
  alvoObra?: string;
  alvoCapituloId?: string;
  alvoObraId?: string;
  alvoObraSlug?: string;
  alvoCapituloTitulo?: string;
  alvoPerfilUserId?: string;
  alvoAnotacaoId?: string;
};

type StatusDenunciaPerfil = "pendente" | "analisada" | "ignorada" | "resolvida";

type DenunciaPerfil = {
  id: string;
  denuncianteId: string;
  denunciadoId: string;
  perfilNome: string;
  perfilUrl: string;
  motivo: string;
  descricao: string;
  status: StatusDenunciaPerfil;
  criadoEm: string;
  atualizadoEm: string;
};

type DenunciaPerfilComContexto = DenunciaPerfil & {
  denuncianteNome: string;
  denunciadoNome: string;
  perfilHref: string;
};


type TraducaoAdminComunidade = {
  en: string;
  es: string;
};

const ADMIN_COMUNIDADE_UI_TRANSLATIONS: Record<
  string,
  TraducaoAdminComunidade
> = {
  "Pendente": { en: "Pending", es: "Pendiente" },
  "Em análise": { en: "Under review", es: "En revisión" },
  "Resolvida": { en: "Resolved", es: "Resuelta" },
  "Rejeitada": { en: "Rejected", es: "Rechazada" },
  "Analisada": { en: "Reviewed", es: "Revisada" },
  "Ignorada": { en: "Ignored", es: "Ignorada" },
  "Spam": { en: "Spam", es: "Spam" },
  "Conteúdo ofensivo": { en: "Offensive content", es: "Contenido ofensivo" },
  "Perfil falso": { en: "Fake profile", es: "Perfil falso" },
  "Assédio": { en: "Harassment", es: "Acoso" },
  "Conteúdo impróprio": { en: "Inappropriate content", es: "Contenido inapropiado" },
  "Outro": { en: "Other", es: "Otro" },
  "Denúncia de perfil": { en: "Profile report", es: "Denuncia de perfil" },
  "Usuário sem nome": { en: "Unnamed user", es: "Usuario sin nombre" },
  "Usuário": { en: "User", es: "Usuario" },
  "Usuário denunciado": { en: "Reported user", es: "Usuario denunciado" },
  "Conteúdo inadequado": { en: "Inappropriate content", es: "Contenido inapropiado" },
  "Ódio ou discriminação": { en: "Hate or discrimination", es: "Odio o discriminación" },
  "Ameaça ou violência": { en: "Threats or violence", es: "Amenazas o violencia" },
  "Conteúdo sexual impróprio": { en: "Improper sexual content", es: "Contenido sexual inapropiado" },
  "Risco envolvendo menor": { en: "Risk involving a minor", es: "Riesgo relacionado con un menor" },
  "Plágio ou direitos autorais": { en: "Plagiarism or copyright", es: "Plagio o derechos de autor" },
  "Informações pessoais expostas": { en: "Exposed personal information", es: "Información personal expuesta" },
  "Fraude ou golpe": { en: "Fraud or scam", es: "Fraude o estafa" },
  "Publicação não encontrada ou removida.": {
    en: "Post not found or removed.",
    es: "Publicación no encontrada o eliminada.",
  },
  "Comentário não encontrado ou removido.": {
    en: "Comment not found or removed.",
    es: "Comentario no encontrado o eliminado.",
  },
  "Comentário de capítulo não encontrado ou removido.": {
    en: "Chapter comment not found or removed.",
    es: "Comentario del capítulo no encontrado o eliminado.",
  },
  "Obra não encontrada ou removida.": {
    en: "Work not found or removed.",
    es: "Obra no encontrada o eliminada.",
  },
  "Capítulo não encontrado ou removido.": {
    en: "Chapter not found or removed.",
    es: "Capítulo no encontrado o eliminado.",
  },
  "Comentário da obra não encontrado ou removido.": {
    en: "Work comment not found or removed.",
    es: "Comentario de la obra no encontrado o eliminado.",
  },
  "Anotação do Diário não encontrada ou removida.": {
    en: "Journal entry not found or removed.",
    es: "Anotación del Diario no encontrada o eliminada.",
  },
  "Comentário do Diário não encontrado ou removido.": {
    en: "Journal comment not found or removed.",
    es: "Comentario del Diario no encontrado o eliminado.",
  },
  "Autor não encontrado": { en: "Author not found", es: "Autor no encontrado" },
  "Discussão": { en: "Discussion", es: "Discusión" },
  "Área restrita": { en: "Restricted area", es: "Área restringida" },
  "Acesso negado": { en: "Access denied", es: "Acceso denegado" },
  "Moderação": { en: "Moderation", es: "Moderación" },
  "Fechar busca": { en: "Close search", es: "Cerrar búsqueda" },
  "Abrir busca": { en: "Open search", es: "Abrir búsqueda" },
  "Notificações": { en: "Notifications", es: "Notificaciones" },
  "Problemas técnicos": {
    en: "Technical issues",
    es: "Problemas técnicos",
  },
  "Abrir problemas técnicos": {
    en: "Open technical issues",
    es: "Abrir problemas técnicos",
  },
  "Buscar denúncias...": { en: "Search reports...", es: "Buscar denuncias..." },
  "total": { en: "total", es: "total" },
  "pendentes": { en: "pending", es: "pendientes" },
  "em análise": { en: "under review", es: "en revisión" },
  "resolvidas": { en: "resolved", es: "resueltas" },
  "rejeitadas": { en: "rejected", es: "rechazadas" },
  "perfis": { en: "profiles", es: "perfiles" },
  "perfis pend.": { en: "pending profiles", es: "perfiles pend." },
  "Todas": { en: "All", es: "Todas" },
  "Arquivadas": { en: "Archived", es: "Archivadas" },
  "Limpar filtros": { en: "Clear filters", es: "Limpiar filtros" },
  "Filtrar denúncias": { en: "Filter reports", es: "Filtrar denuncias" },
  "Fechar filtros": { en: "Close filters", es: "Cerrar filtros" },
  "Status": { en: "Status", es: "Estado" },
  "Perfil": { en: "Profile", es: "Perfil" },
  "Ações da denúncia": { en: "Report actions", es: "Acciones de la denuncia" },
  "Abrir perfil denunciado": {
    en: "Open reported profile",
    es: "Abrir perfil denunciado",
  },
  "Removendo...": { en: "Removing...", es: "Eliminando..." },
  "Remover do painel": { en: "Remove from dashboard", es: "Eliminar del panel" },
  "Assumindo...": { en: "Starting review...", es: "Asumiendo revisión..." },
  "Assumir análise": { en: "Start review", es: "Asumir revisión" },
  "Salvando...": { en: "Saving...", es: "Guardando..." },
  "Perfil denunciado": { en: "Reported profile", es: "Perfil denunciado" },
  "Denunciante:": { en: "Reporter:", es: "Denunciante:" },
  "Denúncia": { en: "Report", es: "Denuncia" },
  "Registro interno": { en: "Internal record", es: "Registro interno" },
  "Sem descrição adicional.": {
    en: "No additional description.",
    es: "Sin descripción adicional.",
  },
  "Publicação": { en: "Post", es: "Publicación" },
  "Comentário": { en: "Comment", es: "Comentario" },
  "Comentário de capítulo": {
    en: "Chapter comment",
    es: "Comentario del capítulo",
  },
  "Obra": { en: "Work", es: "Obra" },
  "Capítulo": { en: "Chapter", es: "Capítulo" },
  "Comentário da obra": {
    en: "Work comment",
    es: "Comentario de la obra",
  },
  "Anotação do Diário": {
    en: "Journal entry",
    es: "Anotación del Diario",
  },
  "Comentário do Diário": {
    en: "Journal comment",
    es: "Comentario del Diario",
  },
  "Diário": { en: "Journal", es: "Diario" },
  "Arquivada": { en: "Archived", es: "Archivada" },
  "Abrir publicação na Comunidade": {
    en: "Open post in Community",
    es: "Abrir publicación en la Comunidad",
  },
  "Abrir capítulo denunciado": {
    en: "Open reported chapter",
    es: "Abrir capítulo denunciado",
  },
  "Abrir obra denunciada": {
    en: "Open reported work",
    es: "Abrir obra denunciada",
  },
  "Abrir conteúdo no Diário": {
    en: "Open content in Journal",
    es: "Abrir contenido en el Diario",
  },
  "Restaurar para o painel": {
    en: "Restore to dashboard",
    es: "Restaurar al panel",
  },
  "Arquivar denúncia": { en: "Archive report", es: "Archivar denuncia" },
  "Remover publicação": { en: "Remove post", es: "Eliminar publicación" },
  "Remover comentário": { en: "Remove comment", es: "Eliminar comentario" },
  "Remover comentário do capítulo": {
    en: "Remove chapter comment",
    es: "Eliminar comentario del capítulo",
  },
  "Remover obra": { en: "Remove work", es: "Eliminar obra" },
  "Remover capítulo": { en: "Remove chapter", es: "Eliminar capítulo" },
  "Remover comentário da obra": {
    en: "Remove work comment",
    es: "Eliminar comentario de la obra",
  },
  "Remover anotação do Diário": {
    en: "Remove Journal entry",
    es: "Eliminar anotación del Diario",
  },
  "Remover comentário do Diário": {
    en: "Remove Journal comment",
    es: "Eliminar comentario del Diario",
  },
  "Conteúdo denunciado": { en: "Reported content", es: "Contenido denunciado" },
  "Indisponível": { en: "Unavailable", es: "No disponible" },
  "Conteúdo removido ou indisponível.": {
    en: "Content removed or unavailable.",
    es: "Contenido eliminado o no disponible.",
  },
  "Autor:": { en: "Author:", es: "Autor:" },
  "Data:": { en: "Date:", es: "Fecha:" },
  "Categoria:": { en: "Category:", es: "Categoría:" },
  "Tipo:": { en: "Type:", es: "Tipo:" },
  "Spoiler:": { en: "Spoiler:", es: "Spoiler:" },
  "Sim": { en: "Yes", es: "Sí" },
  "Não": { en: "No", es: "No" },
  "Obra:": { en: "Work:", es: "Obra:" },
  "Capítulo:": { en: "Chapter:", es: "Capítulo:" },
  "Sem detalhe adicional.": {
    en: "No additional details.",
    es: "Sin detalles adicionales.",
  },
  "Observação interna": { en: "Internal note", es: "Observación interna" },
  "Até 800 caracteres": { en: "Up to 800 characters", es: "Hasta 800 caracteres" },
  "Ex.: conteúdo analisado, ação tomada, manter observação interna...": {
    en: "E.g.: content reviewed, action taken, keep an internal note...",
    es: "Ej.: contenido revisado, acción tomada, mantener una observación interna...",
  },
  "Nenhuma denúncia encontrada": { en: "No reports found", es: "No se encontraron denuncias" },
  "Fechar ações da denúncia de perfil": {
    en: "Close profile report actions",
    es: "Cerrar acciones de la denuncia de perfil",
  },
  "Abrir ações da denúncia de perfil": {
    en: "Open profile report actions",
    es: "Abrir acciones de la denuncia de perfil",
  },
  "Ações da denúncia de perfil": {
    en: "Profile report actions",
    es: "Acciones de la denuncia de perfil",
  },
  "Fechar ações da denúncia": {
    en: "Close report actions",
    es: "Cerrar acciones de la denuncia",
  },
  "Abrir ações da denúncia": {
    en: "Open report actions",
    es: "Abrir acciones de la denuncia",
  },
  "O conteúdo denunciado não possui um identificador válido.": {
    en: "The reported content does not have a valid identifier.",
    es: "El contenido denunciado no tiene un identificador válido.",
  },
  "O conteúdo não foi encontrado ou o banco recusou a remoção.": {
    en: "The content was not found or the database rejected the removal.",
    es: "El contenido no fue encontrado o la base de datos rechazó la eliminación.",
  },
  "Apenas moderadores podem atualizar denúncias de perfis.": {
    en: "Only moderators can update profile reports.",
    es: "Solo los moderadores pueden actualizar denuncias de perfiles.",
  },
  "A denúncia de perfil não foi encontrada ou não pôde ser atualizada.": {
    en: "The profile report was not found or could not be updated.",
    es: "La denuncia de perfil no fue encontrada o no pudo actualizarse.",
  },
  "Apenas moderadores podem atualizar denúncias.": {
    en: "Only moderators can update reports.",
    es: "Solo los moderadores pueden actualizar denuncias.",
  },
  "A denúncia não foi encontrada ou não pôde ser atualizada.": {
    en: "The report was not found or could not be updated.",
    es: "La denuncia no fue encontrada o no pudo actualizarse.",
  },
  "Apenas moderadores podem remover conteúdo denunciado.": {
    en: "Only moderators can remove reported content.",
    es: "Solo los moderadores pueden eliminar contenido denunciado.",
  },
  "O conteúdo foi removido, mas nenhuma denúncia correspondente pôde ser atualizada.": {
    en: "The content was removed, but no matching report could be updated.",
    es: "El contenido fue eliminado, pero no se pudo actualizar ninguna denuncia correspondiente.",
  },
  "Apenas moderadores podem arquivar denúncias.": {
    en: "Only moderators can archive reports.",
    es: "Solo los moderadores pueden archivar denuncias.",
  },
  "A denúncia não foi encontrada ou não pôde ser arquivada.": {
    en: "The report was not found or could not be archived.",
    es: "La denuncia no fue encontrada o no pudo archivarse.",
  },
  "Denúncia arquivada e ocultada do painel principal.": {
    en: "Report archived and hidden from the main dashboard.",
    es: "Denuncia archivada y ocultada del panel principal.",
  },
  "Apenas moderadores podem restaurar denúncias.": {
    en: "Only moderators can restore reports.",
    es: "Solo los moderadores pueden restaurar denuncias.",
  },
  "A denúncia não foi encontrada ou não pôde ser restaurada.": {
    en: "The report was not found or could not be restored.",
    es: "La denuncia no fue encontrada o no pudo restaurarse.",
  },
  "Denúncia restaurada para o painel principal.": {
    en: "Report restored to the main dashboard.",
    es: "Denuncia restaurada al panel principal.",
  },
  "Apenas moderadores podem remover denúncias resolvidas.": {
    en: "Only moderators can remove resolved reports.",
    es: "Solo los moderadores pueden eliminar denuncias resueltas.",
  },
  "Somente denúncias resolvidas podem ser removidas do painel.": {
    en: "Only resolved reports can be removed from the dashboard.",
    es: "Solo las denuncias resueltas pueden eliminarse del panel.",
  },
  "A denúncia resolvida não foi encontrada ou não pôde ser removida.": {
    en: "The resolved report was not found or could not be removed.",
    es: "La denuncia resuelta no fue encontrada o no pudo eliminarse.",
  },
  "Denúncia resolvida removida do painel.": {
    en: "Resolved report removed from the dashboard.",
    es: "Denuncia resuelta eliminada del panel.",
  },
  "Apenas moderadores podem remover denúncias de perfis resolvidas.": {
    en: "Only moderators can remove resolved profile reports.",
    es: "Solo los moderadores pueden eliminar denuncias de perfiles resueltas.",
  },
  "Somente denúncias de perfis resolvidas podem ser removidas do painel.": {
    en: "Only resolved profile reports can be removed from the dashboard.",
    es: "Solo las denuncias de perfiles resueltas pueden eliminarse del panel.",
  },
  "A denúncia de perfil resolvida não foi encontrada ou não pôde ser removida.": {
    en: "The resolved profile report was not found or could not be removed.",
    es: "La denuncia de perfil resuelta no fue encontrada o no pudo eliminarse.",
  },
  "Denúncia de perfil resolvida removida do painel.": {
    en: "Resolved profile report removed from the dashboard.",
    es: "Denuncia de perfil resuelta eliminada del panel.",
  },
  "Erro ao carregar moderação": {
    en: "Error loading moderation",
    es: "Error al cargar la moderación",
  },
  "Erro ao atualizar denúncia de perfil": {
    en: "Error updating profile report",
    es: "Error al actualizar la denuncia de perfil",
  },
  "Erro ao atualizar denúncia": {
    en: "Error updating report",
    es: "Error al actualizar la denuncia",
  },
  "Erro ao remover conteúdo denunciado": {
    en: "Error removing reported content",
    es: "Error al eliminar el contenido denunciado",
  },
  "Erro ao arquivar denúncia": {
    en: "Error archiving report",
    es: "Error al archivar la denuncia",
  },
  "Erro ao restaurar denúncia": {
    en: "Error restoring report",
    es: "Error al restaurar la denuncia",
  },
  "Erro ao remover denúncia resolvida": {
    en: "Error removing resolved report",
    es: "Error al eliminar la denuncia resuelta",
  },
  "Erro ao remover denúncia de perfil resolvida": {
    en: "Error removing resolved profile report",
    es: "Error al eliminar la denuncia de perfil resuelta",
  },
  "erro desconhecido.": { en: "unknown error.", es: "error desconocido." },
};

function traduzirStatusAdminComunidade(
  status: string,
  language: HistorietasLanguage
) {
  const statusNormalizado = normalizarTexto(status);

  if (language === "en") {
    if (statusNormalizado === "pendente") return "pending";
    if (statusNormalizado === "em analise") return "under review";
    if (statusNormalizado === "resolvida") return "resolved";
    if (statusNormalizado === "rejeitada") return "rejected";
    if (statusNormalizado === "analisada") return "reviewed";
    if (statusNormalizado === "ignorada") return "ignored";
  }

  if (statusNormalizado === "pendente") return "pendiente";
  if (statusNormalizado === "em analise") return "en revisión";
  if (statusNormalizado === "resolvida") return "resuelta";
  if (statusNormalizado === "rejeitada") return "rechazada";
  if (statusNormalizado === "analisada") return "revisada";
  if (statusNormalizado === "ignorada") return "ignorada";

  return status;
}

function localeAdminComunidade(language: HistorietasLanguage) {
  return language === "en" ? "en-US" : language === "es" ? "es-ES" : "pt-BR";
}

function textoConfirmacaoRemocaoAdminComunidade(
  alvoTipo: TipoAlvoDenuncia,
  language: HistorietasLanguage
) {
  const textos: Record<
    TipoAlvoDenuncia,
    { "pt-BR": string; en: string; es: string }
  > = {
    post: {
      "pt-BR":
        "Remover esta publicação denunciada? Essa ação apaga a publicação da Comunidade.",
      en: "Remove this reported post? This action deletes the post from the Community.",
      es: "¿Eliminar esta publicación denunciada? Esta acción elimina la publicación de la Comunidad.",
    },
    comentario: {
      "pt-BR":
        "Remover este comentário denunciado? Essa ação apaga o comentário da Comunidade.",
      en: "Remove this reported comment? This action deletes the comment from the Community.",
      es: "¿Eliminar este comentario denunciado? Esta acción elimina el comentario de la Comunidad.",
    },
    comentario_capitulo: {
      "pt-BR":
        "Remover este comentário de capítulo denunciado? Essa ação apaga o comentário do capítulo.",
      en: "Remove this reported chapter comment? This action deletes the comment from the chapter.",
      es: "¿Eliminar este comentario del capítulo denunciado? Esta acción elimina el comentario del capítulo.",
    },
    obra: {
      "pt-BR":
        "Remover esta obra denunciada? Essa ação apaga a obra e pode apagar capítulos e interações relacionadas.",
      en: "Remove this reported work? This may also delete related chapters and interactions.",
      es: "¿Eliminar esta obra denunciada? Esto también puede eliminar capítulos e interacciones relacionadas.",
    },
    capitulo: {
      "pt-BR":
        "Remover este capítulo denunciado? Essa ação apaga o capítulo e pode apagar interações relacionadas.",
      en: "Remove this reported chapter? This may also delete related interactions.",
      es: "¿Eliminar este capítulo denunciado? Esto también puede eliminar interacciones relacionadas.",
    },
    comentario_obra: {
      "pt-BR":
        "Remover este comentário de obra denunciado? Essa ação apaga o comentário da obra.",
      en: "Remove this reported work comment? This action deletes the comment from the work.",
      es: "¿Eliminar este comentario de obra denunciado? Esta acción elimina el comentario de la obra.",
    },
    diario_anotacao: {
      "pt-BR":
        "Remover esta anotação denunciada? Essa ação apaga a anotação e as interações relacionadas no Diário.",
      en: "Remove this reported Journal entry? This action deletes the entry and its related interactions.",
      es: "¿Eliminar esta anotación denunciada? Esta acción elimina la anotación y sus interacciones relacionadas.",
    },
    comentario_diario: {
      "pt-BR":
        "Remover este comentário denunciado? Essa ação apaga o comentário do Diário.",
      en: "Remove this reported Journal comment? This action deletes the comment from the Journal.",
      es: "¿Eliminar este comentario denunciado? Esta acción elimina el comentario del Diario.",
    },
  };

  return textos[alvoTipo][language];
}

function traduzirTextoAdminComunidade(
  texto: string,
  language: HistorietasLanguage
) {
  if (language === "pt-BR" || !texto) {
    return texto;
  }

  const partes = /^(\s*)([\s\S]*?)(\s*)$/.exec(texto);
  const inicio = partes?.[1] || "";
  const conteudo = partes?.[2] || texto;
  const fim = partes?.[3] || "";
  const traducaoExata = ADMIN_COMUNIDADE_UI_TRANSLATIONS[conteudo];

  if (traducaoExata) {
    return `${inicio}${traducaoExata[language]}${fim}`;
  }

  let correspondencia = /^Notificações:\s*(\d+)\s*não lidas$/i.exec(conteudo);

  if (correspondencia) {
    return language === "en"
      ? `${inicio}Notifications: ${correspondencia[1]} unread${fim}`
      : `${inicio}Notificaciones: ${correspondencia[1]} sin leer${fim}`;
  }

  correspondencia = /^(\d+)\s+denúncia de perfil encontrada$/i.exec(conteudo);

  if (correspondencia) {
    return language === "en"
      ? `${inicio}${correspondencia[1]} profile report found${fim}`
      : `${inicio}${correspondencia[1]} denuncia de perfil encontrada${fim}`;
  }

  correspondencia = /^(\d+)\s+denúncias de perfis encontradas$/i.exec(conteudo);

  if (correspondencia) {
    return language === "en"
      ? `${inicio}${correspondencia[1]} profile reports found${fim}`
      : `${inicio}${correspondencia[1]} denuncias de perfiles encontradas${fim}`;
  }

  correspondencia = /^(\d+)\s+denúncia de conteúdo encontrada$/i.exec(conteudo);

  if (correspondencia) {
    return language === "en"
      ? `${inicio}${correspondencia[1]} content report found${fim}`
      : `${inicio}${correspondencia[1]} denuncia de contenido encontrada${fim}`;
  }

  correspondencia = /^(\d+)\s+denúncias da Comunidade encontradas$/i.exec(
    conteudo
  );

  if (correspondencia) {
    return language === "en"
      ? `${inicio}${correspondencia[1]} content reports found${fim}`
      : `${inicio}${correspondencia[1]} denuncias de contenido encontradas${fim}`;
  }

  correspondencia = /^Denunciado em\s+(.+)$/i.exec(conteudo);

  if (correspondencia) {
    return language === "en"
      ? `${inicio}Reported on ${correspondencia[1]}${fim}`
      : `${inicio}Denunciado el ${correspondencia[1]}${fim}`;
  }

  correspondencia = /^Última atualização em\s+(.+)$/i.exec(conteudo);

  if (correspondencia) {
    return language === "en"
      ? `${inicio}Last updated on ${correspondencia[1]}${fim}`
      : `${inicio}Última actualización el ${correspondencia[1]}${fim}`;
  }

  correspondencia = /^Última análise em\s+(.+)$/i.exec(conteudo);

  if (correspondencia) {
    return language === "en"
      ? `${inicio}Last reviewed on ${correspondencia[1]}${fim}`
      : `${inicio}Última revisión el ${correspondencia[1]}${fim}`;
  }

  correspondencia = /^Marcar como\s+(.+)$/i.exec(conteudo);

  if (correspondencia) {
    const status = traduzirStatusAdminComunidade(
      correspondencia[1],
      language
    );

    return language === "en"
      ? `${inicio}Mark as ${status}${fim}`
      : `${inicio}Marcar como ${status}${fim}`;
  }

  correspondencia =
    /^Denúncia de perfil marcada como\s+(.+)\.$/i.exec(conteudo);

  if (correspondencia) {
    const status = traduzirStatusAdminComunidade(
      correspondencia[1],
      language
    );

    return language === "en"
      ? `${inicio}Profile report marked as ${status}.${fim}`
      : `${inicio}Denuncia de perfil marcada como ${status}.${fim}`;
  }

  correspondencia = /^Denúncia marcada como\s+(.+)\.$/i.exec(conteudo);

  if (correspondencia) {
    const status = traduzirStatusAdminComunidade(
      correspondencia[1],
      language
    );

    return language === "en"
      ? `${inicio}Report marked as ${status}.${fim}`
      : `${inicio}Denuncia marcada como ${status}.${fim}`;
  }

  correspondencia =
    /^Conteúdo removido pela moderação em\s+(.+)\.$/i.exec(conteudo);

  if (correspondencia) {
    return language === "en"
      ? `${inicio}Content removed by moderation on ${correspondencia[1]}.${fim}`
      : `${inicio}Contenido eliminado por moderación el ${correspondencia[1]}.${fim}`;
  }

  correspondencia =
    /^Conteúdo removido pela moderação\. Registro anterior:\s*([\s\S]+)$/i.exec(
      conteudo
    );

  if (correspondencia) {
    return language === "en"
      ? `${inicio}Content removed by moderation. Previous record: ${correspondencia[1]}${fim}`
      : `${inicio}Contenido eliminado por moderación. Registro anterior: ${correspondencia[1]}${fim}`;
  }

  correspondencia =
    /^(Anotação do Diário removida|Comentário do Diário removido) e denúncia marcada como resolvida\.$/i.exec(
      conteudo
    );

  if (correspondencia) {
    const alvoNormalizado = normalizarTexto(correspondencia[1]);
    const alvo = alvoNormalizado.startsWith("anotacao")
      ? language === "en"
        ? "Journal entry"
        : "Anotación del Diario"
      : language === "en"
        ? "Journal comment"
        : "Comentario del Diario";

    return language === "en"
      ? `${inicio}${alvo} removed and report marked as resolved.${fim}`
      : `${inicio}${alvo} eliminado y denuncia marcada como resuelta.${fim}`;
  }

  correspondencia =
    /^(Publicação removida|Comentário removido|Comentário do capítulo removido|Obra removida|Capítulo removido|Comentário da obra removido) e denúncia marcada como resolvida\.$/i.exec(
      conteudo
    );

  if (correspondencia) {
    const alvoNormalizado = normalizarTexto(correspondencia[1]);
    const alvo = alvoNormalizado.startsWith("publicacao")
      ? language === "en"
        ? "Post"
        : "Publicación"
      : alvoNormalizado === "obra removida"
        ? language === "en"
          ? "Work"
          : "Obra"
        : alvoNormalizado === "capitulo removido"
          ? language === "en"
            ? "Chapter"
            : "Capítulo"
          : alvoNormalizado.includes("comentario da obra")
            ? language === "en"
              ? "Work comment"
              : "Comentario de la obra"
            : alvoNormalizado.includes("capitulo")
              ? language === "en"
                ? "Chapter comment"
                : "Comentario del capítulo"
              : language === "en"
                ? "Comment"
                : "Comentario";

    return language === "en"
      ? `${inicio}${alvo} removed and report marked as resolved.${fim}`
      : `${inicio}${alvo} eliminado y denuncia marcada como resuelta.${fim}`;
  }

  correspondencia = /^(Erro ao [^:]+):\s*([\s\S]+)$/i.exec(conteudo);

  if (correspondencia) {
    const prefixo =
      ADMIN_COMUNIDADE_UI_TRANSLATIONS[correspondencia[1]]?.[language] ||
      correspondencia[1];
    const detalhe =
      ADMIN_COMUNIDADE_UI_TRANSLATIONS[correspondencia[2]]?.[language] ||
      correspondencia[2];

    return `${inicio}${prefixo}: ${detalhe}${fim}`;
  }

  return texto;
}

function AdminComunidadeLanguageBridge() {
  const { language } = useHistorietasLanguage();

  useEffect(() => {
    if (typeof document === "undefined") {
      return;
    }

    const seletorRaiz = "[data-historietas-admin-comunidade-root='true']";

    type EstadoTraducaoAdminComunidade = {
      original: string;
      traduzido: string;
    };

    const estadosTexto: WeakMap<Text, EstadoTraducaoAdminComunidade> =
      new WeakMap();
    const estadosAtributos: WeakMap<
      Element,
      Map<string, EstadoTraducaoAdminComunidade>
    > = new WeakMap();
    const textosAlterados = new Set<Text>();
    const atributosAlterados: Array<{ elemento: Element; atributo: string }> = [];
    const atributosTraduziveis = ["aria-label", "title", "placeholder", "alt"];
    let aplicando = false;

    function elementoEstaNaPagina(elemento: Element | null) {
      return Boolean(
        elemento?.matches(seletorRaiz) || elemento?.closest(seletorRaiz)
      );
    }

    function deveIgnorarElemento(elemento: Element | null) {
      if (!elemento || !elementoEstaNaPagina(elemento)) {
        return true;
      }

      if (elemento.closest("[data-historietas-i18n-ignore='true']")) {
        return true;
      }

      const tag = elemento.tagName.toLowerCase();

      return tag === "script" || tag === "style";
    }

    function aplicarTexto(no: Text) {
      const elementoPai = no.parentElement;

      if (
        deveIgnorarElemento(elementoPai) ||
        elementoPai?.tagName.toLowerCase() === "textarea"
      ) {
        return;
      }

      const atual = no.data;
      let estado = estadosTexto.get(no);

      if (!estado) {
        estado = { original: atual, traduzido: atual };
        estadosTexto.set(no, estado);
        textosAlterados.add(no);
      } else if (atual !== estado.traduzido && atual !== estado.original) {
        estado.original = atual;
      }

      const proximo = traduzirTextoAdminComunidade(
        estado.original,
        language
      );
      estado.traduzido = proximo;

      if (no.data !== proximo) {
        no.data = proximo;
      }
    }

    function aplicarAtributo(elemento: Element, atributo: string) {
      if (deveIgnorarElemento(elemento) || !elemento.hasAttribute(atributo)) {
        return;
      }

      const atual = elemento.getAttribute(atributo) || "";
      let mapaElemento = estadosAtributos.get(elemento);

      if (!mapaElemento) {
        mapaElemento = new Map();
        estadosAtributos.set(elemento, mapaElemento);
      }

      let estado = mapaElemento.get(atributo);

      if (!estado) {
        estado = { original: atual, traduzido: atual };
        mapaElemento.set(atributo, estado);
        atributosAlterados.push({ elemento, atributo });
      } else if (atual !== estado.traduzido && atual !== estado.original) {
        estado.original = atual;
      }

      const proximo = traduzirTextoAdminComunidade(
        estado.original,
        language
      );
      estado.traduzido = proximo;

      if (atual !== proximo) {
        elemento.setAttribute(atributo, proximo);
      }
    }

    function aplicarNo(no: Node) {
      if (no.nodeType === Node.TEXT_NODE) {
        aplicarTexto(no as Text);
        return;
      }

      if (!(no instanceof Element)) {
        return;
      }

      const raizes: Element[] = [];

      if (no.matches(seletorRaiz)) {
        raizes.push(no);
      } else if (no.closest(seletorRaiz)) {
        raizes.push(no);
      } else {
        no.querySelectorAll(seletorRaiz).forEach((raiz) => raizes.push(raiz));
      }

      raizes.forEach((raiz) => {
        if (deveIgnorarElemento(raiz)) {
          return;
        }

        atributosTraduziveis.forEach((atributo) =>
          aplicarAtributo(raiz, atributo)
        );

        const walker = document.createTreeWalker(
          raiz,
          NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT
        );
        let atual: Node | null = walker.nextNode();

        while (atual) {
          if (atual.nodeType === Node.TEXT_NODE) {
            aplicarTexto(atual as Text);
          } else if (atual instanceof Element && !deveIgnorarElemento(atual)) {
            atributosTraduziveis.forEach((atributo) =>
              aplicarAtributo(atual as Element, atributo)
            );
          }

          atual = walker.nextNode();
        }
      });
    }

    function aplicarTudo() {
      if (aplicando) {
        return;
      }

      aplicando = true;

      try {
        document
          .querySelectorAll(seletorRaiz)
          .forEach((raiz) => aplicarNo(raiz));
      } finally {
        aplicando = false;
      }
    }

    aplicarTudo();

    const observador = new MutationObserver((mutacoes) => {
      if (aplicando) {
        return;
      }

      aplicando = true;

      try {
        mutacoes.forEach((mutacao) => {
          if (mutacao.type === "characterData") {
            aplicarTexto(mutacao.target as Text);
            return;
          }

          if (
            mutacao.type === "attributes" &&
            mutacao.target instanceof Element
          ) {
            if (
              mutacao.attributeName &&
              atributosTraduziveis.includes(mutacao.attributeName)
            ) {
              aplicarAtributo(mutacao.target, mutacao.attributeName);
            }

            return;
          }

          mutacao.addedNodes.forEach((no) => aplicarNo(no));
        });
      } finally {
        aplicando = false;
      }
    });

    observador.observe(document.body, {
      subtree: true,
      childList: true,
      characterData: true,
      attributes: true,
      attributeFilter: atributosTraduziveis,
    });

    return () => {
      observador.disconnect();

      textosAlterados.forEach((no) => {
        const estado = estadosTexto.get(no);

        if (estado && no.data === estado.traduzido) {
          no.data = estado.original;
        }
      });

      atributosAlterados.forEach(({ elemento, atributo }) => {
        const estado = estadosAtributos.get(elemento)?.get(atributo);

        if (estado && elemento.getAttribute(atributo) === estado.traduzido) {
          elemento.setAttribute(atributo, estado.original);
        }
      });
    };
  }, [language]);

  return null;
}

const STATUS_DENUNCIAS: StatusDenuncia[] = [
  "pendente",
  "em_analise",
  "resolvida",
  "rejeitada",
];

const STATUS_LABEL: Record<StatusDenuncia, string> = {
  pendente: "Pendente",
  em_analise: "Em análise",
  resolvida: "Resolvida",
  rejeitada: "Rejeitada",
};

const STATUS_DENUNCIAS_PERFIS: StatusDenunciaPerfil[] = [
  "pendente",
  "analisada",
  "ignorada",
  "resolvida",
];

const STATUS_PERFIL_LABEL: Record<StatusDenunciaPerfil, string> = {
  pendente: "Pendente",
  analisada: "Analisada",
  ignorada: "Ignorada",
  resolvida: "Resolvida",
};

const MOTIVOS_DENUNCIA_PERFIL_LABEL: Record<string, string> = {
  spam: "Spam",
  ofensivo: "Conteúdo ofensivo",
  perfil_falso: "Perfil falso",
  assedio: "Assédio",
  improprio: "Conteúdo impróprio",
  outro: "Outro",
};

function criarLoginHrefAdminModeracao() {
  const redirectTo =
    typeof window !== "undefined"
      ? `${window.location.pathname}${window.location.search}`
      : "/admin";
  const destinoSeguro =
    redirectTo && redirectTo.startsWith("/") && !redirectTo.startsWith("//")
      ? redirectTo
      : "/admin";
  const params = new URLSearchParams({
    redirectTo: destinoSeguro,
  });

  return `/login?${params.toString()}`;
}

function normalizarStatus(valor: unknown): StatusDenuncia {
  return STATUS_DENUNCIAS.includes(valor as StatusDenuncia)
    ? (valor as StatusDenuncia)
    : "pendente";
}

function normalizarStatusPerfil(valor: unknown): StatusDenunciaPerfil {
  return STATUS_DENUNCIAS_PERFIS.includes(valor as StatusDenunciaPerfil)
    ? (valor as StatusDenunciaPerfil)
    : "pendente";
}

function formatarMotivoDenunciaPerfil(motivo: string) {
  return MOTIVOS_DENUNCIA_PERFIL_LABEL[motivo] || motivo || "Denúncia de perfil";
}

function criarHrefPerfilDenunciado(denuncia: Pick<DenunciaPerfil, "denunciadoId" | "perfilUrl">) {
  const url = denuncia.perfilUrl.trim();

  if (url && url.startsWith("/") && !url.startsWith("//")) {
    return url;
  }

  return `/perfil-autor?userId=${encodeURIComponent(denuncia.denunciadoId)}`;
}

const MOTIVOS_DENUNCIA_CONTEUDO_LABEL: Record<string, string> = {
  conteudo_inadequado: "Conteúdo inadequado",
  spam: "Spam",
  assedio: "Assédio",
  odio_discriminacao: "Ódio ou discriminação",
  ameaca_violencia: "Ameaça ou violência",
  conteudo_sexual: "Conteúdo sexual impróprio",
  risco_menor: "Risco envolvendo menor",
  plagio_direitos_autorais: "Plágio ou direitos autorais",
  informacoes_pessoais: "Informações pessoais expostas",
  fraude: "Fraude ou golpe",
  outro: "Outro",
};

function formatarMotivoDenunciaConteudo(motivo: string) {
  const motivoLimpo = motivo.trim();

  return (
    MOTIVOS_DENUNCIA_CONTEUDO_LABEL[motivoLimpo] ||
    motivoLimpo ||
    "Conteúdo inadequado"
  );
}

function normalizarTipoAlvo(valor: unknown): TipoAlvoDenuncia {
  const tiposValidos = new Set<TipoAlvoDenuncia>([
    "post",
    "comentario",
    "comentario_capitulo",
    "obra",
    "capitulo",
    "comentario_obra",
    "diario_anotacao",
    "comentario_diario",
  ]);

  return tiposValidos.has(valor as TipoAlvoDenuncia)
    ? (valor as TipoAlvoDenuncia)
    : "post";
}

function rotuloTipoAlvoDenuncia(tipo: TipoAlvoDenuncia) {
  const rotulos: Record<TipoAlvoDenuncia, string> = {
    post: "Publicação",
    comentario: "Comentário",
    comentario_capitulo: "Comentário de capítulo",
    obra: "Obra",
    capitulo: "Capítulo",
    comentario_obra: "Comentário da obra",
    diario_anotacao: "Anotação do Diário",
    comentario_diario: "Comentário do Diário",
  };

  return rotulos[tipo];
}

function rotuloRemocaoAlvoDenuncia(tipo: TipoAlvoDenuncia) {
  const rotulos: Record<TipoAlvoDenuncia, string> = {
    post: "Remover publicação",
    comentario: "Remover comentário",
    comentario_capitulo: "Remover comentário do capítulo",
    obra: "Remover obra",
    capitulo: "Remover capítulo",
    comentario_obra: "Remover comentário da obra",
    diario_anotacao: "Remover anotação do Diário",
    comentario_diario: "Remover comentário do Diário",
  };

  return rotulos[tipo];
}

function rotuloSucessoRemocaoAlvo(tipo: TipoAlvoDenuncia) {
  const rotulos: Record<TipoAlvoDenuncia, string> = {
    post: "Publicação removida",
    comentario: "Comentário removido",
    comentario_capitulo: "Comentário do capítulo removido",
    obra: "Obra removida",
    capitulo: "Capítulo removido",
    comentario_obra: "Comentário da obra removido",
    diario_anotacao: "Anotação do Diário removida",
    comentario_diario: "Comentário do Diário removido",
  };

  return rotulos[tipo];
}


function criarHrefDiarioDenunciado(
  denuncia: Pick<
    DenunciaComContexto,
    "alvoPerfilUserId" | "alvoObraId"
  >
) {
  const params = new URLSearchParams({
    modo: "perfil",
    origem: "diario",
  });
  const perfilUserId = denuncia.alvoPerfilUserId?.trim() || "";
  const obraId = denuncia.alvoObraId?.trim() || "";

  if (perfilUserId) {
    params.set("userId", perfilUserId);
  }

  if (obraId) {
    params.set("obraId", obraId);
  }

  return `/listas?${params.toString()}`;
}


function conteudoDenunciadoIndisponivel(denuncia: DenunciaComContexto) {
  const resumo = normalizarTexto(denuncia.alvoResumo);

  return (
    resumo.includes("conteudo removido pela moderacao") ||
    resumo.includes("publicacao nao encontrada ou removida") ||
    resumo.includes("comentario nao encontrado ou removido") ||
    resumo.includes("comentario de capitulo nao encontrado ou removido") ||
    resumo.includes("obra nao encontrada ou removida") ||
    resumo.includes("capitulo nao encontrado ou removido") ||
    resumo.includes("comentario da obra nao encontrado ou removido") ||
    resumo.includes("anotacao do diario nao encontrada ou removida") ||
    resumo.includes("comentario do diario nao encontrado ou removido") ||
    resumo.includes("nao encontrada ou removida") ||
    resumo.includes("nao encontrado ou removido")
  );
}

function criarMensagemErro(acao: string, erro: unknown) {
  if (!erro || typeof erro !== "object") {
    return `${acao}: erro desconhecido.`;
  }

  const supabaseErro = erro as {
    message?: string;
    code?: string;
    details?: string;
    hint?: string;
  };

  const detalhes = [
    supabaseErro.message,
    supabaseErro.code ? `código ${supabaseErro.code}` : "",
    supabaseErro.details,
    supabaseErro.hint,
  ]
    .filter(Boolean)
    .join(" · ");

  return detalhes ? `${acao}: ${detalhes}` : `${acao}: erro desconhecido.`;
}

function obterNomePerfilModeracao(perfil: PerfilModeracao) {
  return typeof perfil.nome === "string" && perfil.nome.trim()
    ? perfil.nome.trim()
    : "Usuário sem nome";
}

function criarMapaNomesPerfisModeracao(perfis: PerfilModeracao[]) {
  const mapa = new Map<string, string>();

  perfis.forEach((perfil) => {
    const nome = obterNomePerfilModeracao(perfil);
    const userId = perfil.user_id?.trim() || "";
    const id = perfil.id?.trim() || "";

    if (userId) {
      mapa.set(userId, nome);
    }

    if (id) {
      mapa.set(id, nome);
    }
  });

  return mapa;
}

function erroOpcionalIgnoravel(erro: unknown) {
  if (!erro || typeof erro !== "object") {
    return false;
  }

  const supabaseErro = erro as { code?: string; message?: string };
  const codigo = supabaseErro.code || "";
  const mensagem = (supabaseErro.message || "").toLowerCase();

  return (
    codigo === "42P01" ||
    codigo === "42703" ||
    mensagem.includes("does not exist") ||
    mensagem.includes("schema cache") ||
    mensagem.includes("could not find")
  );
}

export default function AdminComunidadePage() {
  const { language } = useHistorietasLanguage();
  const [carregando, setCarregando] = useState(true);
  const [usuarioId, setUsuarioId] = useState("");
  const [ehAdmin, setEhAdmin] = useState(false);
  const [erro, setErro] = useState("");
  const [sucesso, setSucesso] = useState("");
  const [denuncias, setDenuncias] = useState<DenunciaComContexto[]>([]);
  const [denunciasPerfis, setDenunciasPerfis] = useState<DenunciaPerfilComContexto[]>([]);
  const [statusFiltro, setStatusFiltro] = useState<StatusFiltroDenuncia>(
    "todas"
  );
  const [busca, setBusca] = useState("");
  const [buscaModeracaoAberta, setBuscaModeracaoAberta] = useState(false);
  const [mostrarFiltrosModeracao, setMostrarFiltrosModeracao] = useState(false);
  const [acaoEmAndamento, setAcaoEmAndamento] = useState("");
  const [observacoes, setObservacoes] = useState<Record<string, string>>({});
  const [menuDenunciaAbertoId, setMenuDenunciaAbertoId] = useState("");
  const [isDesktop, setIsDesktop] = useState(false);
  const router = useRouter();
  const { pageThemeStyle } = useHistorietasTheme(pageStyle);
  const { notificacoesNaoLidas } = useNotificacoes();


  useEffect(() => {
    const mediaQuery = window.matchMedia("(min-width: 1024px)");

    const atualizarModoDesktop = () => {
      setIsDesktop(mediaQuery.matches);
    };

    atualizarModoDesktop();

    if (typeof mediaQuery.addEventListener === "function") {
      mediaQuery.addEventListener("change", atualizarModoDesktop);

      return () => {
        mediaQuery.removeEventListener("change", atualizarModoDesktop);
      };
    }

    mediaQuery.addListener(atualizarModoDesktop);

    return () => {
      mediaQuery.removeListener(atualizarModoDesktop);
    };
  }, []);


  async function carregarDenuncias() {
    setErro("");

    const { data: denunciasResposta, error: denunciasErro } = await supabase
      .from("comunidade_denuncias")
      .select(
        "id, alvo_tipo, alvo_id, denunciante_id, motivo, detalhe, status, arquivada, observacao_admin, analisado_por, analisado_em, criado_em"
      )
      .order("criado_em", { ascending: false })
      .limit(200);

    if (denunciasErro) {
      throw denunciasErro;
    }

    const denunciasMapeadas: DenunciaComunidade[] = (
      (denunciasResposta || []) as unknown as Record<string, unknown>[]
    ).map((denuncia) => ({
      id: String(denuncia.id || ""),
      alvoTipo: normalizarTipoAlvo(denuncia.alvo_tipo),
      alvoId: String(denuncia.alvo_id || ""),
      denuncianteId: String(denuncia.denunciante_id || ""),
      motivo: formatarMotivoDenunciaConteudo(
        String(denuncia.motivo || "Conteúdo inadequado")
      ),
      detalhe: String(denuncia.detalhe || ""),
      status: normalizarStatus(denuncia.status),
      arquivada: Boolean(denuncia.arquivada),
      observacaoAdmin: String(denuncia.observacao_admin || ""),
      analisadoPor: denuncia.analisado_por
        ? String(denuncia.analisado_por)
        : null,
      analisadoEm: denuncia.analisado_em
        ? String(denuncia.analisado_em)
        : null,
      criadoEm: String(denuncia.criado_em || ""),
    }));

    const idsPorTipo = <T extends TipoAlvoDenuncia>(tipo: T) =>
      Array.from(
        new Set(
          denunciasMapeadas
            .filter((denuncia) => denuncia.alvoTipo === tipo)
            .map((denuncia) => denuncia.alvoId)
            .filter(Boolean)
        )
      );

    const postIds = idsPorTipo("post");
    const comentarioIds = idsPorTipo("comentario");
    const comentarioCapituloIds = idsPorTipo("comentario_capitulo");
    const obraIdsDenunciadas = idsPorTipo("obra");
    const capituloIdsDenunciados = idsPorTipo("capitulo");
    const comentarioObraIds = idsPorTipo("comentario_obra");
    const diarioAnotacaoIds = idsPorTipo("diario_anotacao");
    const comentarioDiarioIds = idsPorTipo("comentario_diario");

    const [
      postsResposta,
      comentariosResposta,
      comentariosCapitulosResposta,
      comentariosObrasResposta,
      comentariosDiarioResposta,
    ] = await Promise.all([
      postIds.length > 0
        ? supabase
            .from("comunidade_posts")
            .select(
              "id, autor_nome, categoria, tipo_publicacao, tem_spoiler, texto, obra_relacionada, criado_em"
            )
            .in("id", postIds)
            .limit(500)
        : Promise.resolve({ data: [], error: null }),
      comentarioIds.length > 0
        ? supabase
            .from("comunidade_comentarios")
            .select("id, post_id, autor_nome, texto, criado_em")
            .in("id", comentarioIds)
            .limit(500)
        : Promise.resolve({ data: [], error: null }),
      comentarioCapituloIds.length > 0
        ? supabase
            .from("comentarios_capitulos")
            .select("id, capitulo_id, user_id, comentario, criado_em")
            .in("id", comentarioCapituloIds)
            .limit(500)
        : Promise.resolve({ data: [], error: null }),
      comentarioObraIds.length > 0
        ? supabase
            .from("comentarios_obras")
            .select("id, obra_id, user_id, comentario, criado_em")
            .in("id", comentarioObraIds)
            .limit(500)
        : Promise.resolve({ data: [], error: null }),
      comentarioDiarioIds.length > 0
        ? supabase
            .from("diario_anotacao_comentarios")
            .select(
              "id, anotacao_id, user_id, texto, criado_em, atualizado_em"
            )
            .in("id", comentarioDiarioIds)
            .limit(500)
        : Promise.resolve({ data: [], error: null }),
    ]);

    const posts = postsResposta.error
      ? []
      : ((postsResposta.data || []) as unknown as PostDenunciado[]);
    const comentarios = comentariosResposta.error
      ? []
      : ((comentariosResposta.data || []) as unknown as ComentarioDenunciado[]);
    const comentariosCapitulos = comentariosCapitulosResposta.error
      ? []
      : ((comentariosCapitulosResposta.data ||
          []) as unknown as ComentarioCapituloDenunciado[]);
    const comentariosObras = comentariosObrasResposta.error
      ? []
      : ((comentariosObrasResposta.data ||
          []) as unknown as ComentarioObraDenunciado[]);
    const comentariosDiario = comentariosDiarioResposta.error
      ? []
      : ((comentariosDiarioResposta.data ||
          []) as unknown as ComentarioDiarioDenunciado[]);

    const diarioAnotacaoIdsContexto = Array.from(
      new Set([
        ...diarioAnotacaoIds,
        ...comentariosDiario
          .map((comentario) => comentario.anotacao_id)
          .filter(Boolean),
      ])
    );

    const {
      data: diarioAnotacoesResposta,
      error: diarioAnotacoesErro,
    } =
      diarioAnotacaoIdsContexto.length > 0
        ? await supabase
            .from("diario_anotacoes")
            .select(
              "id, obra_id, user_id, tipo, texto, visibilidade, contem_spoiler, criado_em, atualizado_em"
            )
            .in("id", diarioAnotacaoIdsContexto)
            .limit(500)
        : { data: [], error: null };

    const diarioAnotacoes = diarioAnotacoesErro
      ? []
      : ((diarioAnotacoesResposta ||
          []) as unknown as DiarioAnotacaoDenunciada[]);

    const capituloIdsContexto = Array.from(
      new Set([
        ...capituloIdsDenunciados,
        ...comentariosCapitulos
          .map((comentario) => comentario.capitulo_id)
          .filter(Boolean),
      ])
    );

    const { data: capitulosResposta, error: capitulosErro } =
      capituloIdsContexto.length > 0
        ? await supabase
            .from("capitulos")
            .select(
              "id, obra_id, user_id, titulo, texto, ordem, publicado, criado_em"
            )
            .in("id", capituloIdsContexto)
            .limit(500)
        : { data: [], error: null };

    const capitulos = capitulosErro
      ? []
      : ((capitulosResposta || []) as unknown as CapituloDenunciado[]);

    const obraIdsContexto = Array.from(
      new Set([
        ...obraIdsDenunciadas,
        ...capitulos.map((capitulo) => capitulo.obra_id).filter(Boolean),
        ...comentariosObras
          .map((comentario) => comentario.obra_id)
          .filter(Boolean),
        ...diarioAnotacoes
          .map((anotacao) => anotacao.obra_id)
          .filter(Boolean),
      ])
    );

    const { data: obrasResposta, error: obrasErro } =
      obraIdsContexto.length > 0
        ? await supabase
            .from("obras")
            .select(
              "id, user_id, titulo, autor, slug, link, publicado, criada_em"
            )
            .in("id", obraIdsContexto)
            .limit(500)
        : { data: [], error: null };

    const obras = obrasErro
      ? []
      : ((obrasResposta || []) as unknown as ObraDenunciada[]);

    const perfilIds = Array.from(
      new Set(
        [
          ...denunciasMapeadas.map((denuncia) => denuncia.denuncianteId),
          ...comentariosCapitulos.map((comentario) => comentario.user_id),
          ...comentariosObras.map((comentario) => comentario.user_id),
          ...comentariosDiario.map((comentario) => comentario.user_id),
          ...diarioAnotacoes.map((anotacao) => anotacao.user_id),
          ...capitulos.map((capitulo) => capitulo.user_id),
          ...obras.map((obra) => obra.user_id),
        ].filter(Boolean)
      )
    );

    const [perfisPorUserIdResposta, perfisPorIdResposta] = await Promise.all([
      perfilIds.length > 0
        ? supabase
            .from("profiles")
            .select("id, user_id, nome")
            .in("user_id", perfilIds)
            .limit(1000)
        : Promise.resolve({ data: [], error: null }),
      perfilIds.length > 0
        ? supabase
            .from("profiles")
            .select("id, user_id, nome")
            .in("id", perfilIds)
            .limit(1000)
        : Promise.resolve({ data: [], error: null }),
    ]);

    const perfis = [
      ...(perfisPorUserIdResposta.error
        ? []
        : ((perfisPorUserIdResposta.data ||
            []) as unknown as PerfilModeracao[])),
      ...(perfisPorIdResposta.error
        ? []
        : ((perfisPorIdResposta.data ||
            []) as unknown as PerfilModeracao[])),
    ];

    const perfisPorId = criarMapaNomesPerfisModeracao(perfis);
    const postsPorId = new Map(posts.map((post) => [post.id, post]));
    const comentariosPorId = new Map(
      comentarios.map((comentario) => [comentario.id, comentario])
    );
    const comentariosCapitulosPorId = new Map(
      comentariosCapitulos.map((comentario) => [comentario.id, comentario])
    );
    const comentariosObrasPorId = new Map(
      comentariosObras.map((comentario) => [comentario.id, comentario])
    );
    const comentariosDiarioPorId = new Map(
      comentariosDiario.map((comentario) => [comentario.id, comentario])
    );
    const diarioAnotacoesPorId = new Map(
      diarioAnotacoes.map((anotacao) => [anotacao.id, anotacao])
    );
    const capitulosPorId = new Map(
      capitulos.map((capitulo) => [capitulo.id, capitulo])
    );
    const obrasPorId = new Map(obras.map((obra) => [obra.id, obra]));

    const nomeDenunciante = (denuncia: DenunciaComunidade) =>
      perfisPorId.get(denuncia.denuncianteId) || "Usuário";

    const denunciasComContexto: DenunciaComContexto[] =
      denunciasMapeadas.map((denuncia) => {
        if (denuncia.alvoTipo === "post") {
          const post = postsPorId.get(denuncia.alvoId);

          return {
            ...denuncia,
            denuncianteNome: nomeDenunciante(denuncia),
            alvoResumo:
              post?.texto || "Publicação não encontrada ou removida.",
            alvoAutor: post?.autor_nome || "Autor não encontrado",
            alvoData: post?.criado_em || "",
            alvoPostId: post?.id || denuncia.alvoId,
            alvoCategoria: post?.categoria || "",
            alvoTipoPublicacao: post?.tipo_publicacao || "Discussão",
            alvoTemSpoiler: Boolean(post?.tem_spoiler),
            alvoObra: post?.obra_relacionada || "",
          };
        }

        if (denuncia.alvoTipo === "comentario") {
          const comentario = comentariosPorId.get(denuncia.alvoId);

          return {
            ...denuncia,
            denuncianteNome: nomeDenunciante(denuncia),
            alvoResumo:
              comentario?.texto ||
              "Comentário não encontrado ou removido.",
            alvoAutor: comentario?.autor_nome || "Autor não encontrado",
            alvoData: comentario?.criado_em || "",
            alvoPostId: comentario?.post_id || "",
          };
        }

        if (denuncia.alvoTipo === "comentario_capitulo") {
          const comentario = comentariosCapitulosPorId.get(denuncia.alvoId);
          const capitulo = comentario
            ? capitulosPorId.get(comentario.capitulo_id)
            : undefined;
          const obra = capitulo
            ? obrasPorId.get(capitulo.obra_id)
            : undefined;

          return {
            ...denuncia,
            denuncianteNome: nomeDenunciante(denuncia),
            alvoResumo:
              comentario?.comentario ||
              "Comentário de capítulo não encontrado ou removido.",
            alvoAutor: comentario
              ? perfisPorId.get(comentario.user_id) ||
                "Autor não encontrado"
              : "Autor não encontrado",
            alvoData: comentario?.criado_em || "",
            alvoPostId: "",
            alvoObra: obra?.titulo?.trim() || "",
            alvoObraId: obra?.id || capitulo?.obra_id || "",
            alvoObraSlug: obra?.slug?.trim() || "",
            alvoCapituloId: comentario?.capitulo_id || "",
            alvoCapituloTitulo: capitulo?.titulo?.trim() || "",
          };
        }

        if (denuncia.alvoTipo === "obra") {
          const obra = obrasPorId.get(denuncia.alvoId);

          return {
            ...denuncia,
            denuncianteNome: nomeDenunciante(denuncia),
            alvoResumo:
              obra?.titulo?.trim() || "Obra não encontrada ou removida.",
            alvoAutor:
              obra?.autor?.trim() ||
              (obra
                ? perfisPorId.get(obra.user_id) || "Autor não encontrado"
                : "Autor não encontrado"),
            alvoData: obra?.criada_em || "",
            alvoPostId: "",
            alvoObraId: obra?.id || denuncia.alvoId,
            alvoObraSlug: obra?.slug?.trim() || "",
          };
        }

        if (denuncia.alvoTipo === "capitulo") {
          const capitulo = capitulosPorId.get(denuncia.alvoId);
          const obra = capitulo
            ? obrasPorId.get(capitulo.obra_id)
            : undefined;
          const textoCapitulo = capitulo?.texto?.trim() || "";

          return {
            ...denuncia,
            denuncianteNome: nomeDenunciante(denuncia),
            alvoResumo:
              textoCapitulo.slice(0, 5000) ||
              capitulo?.titulo?.trim() ||
              "Capítulo não encontrado ou removido.",
            alvoAutor: capitulo
              ? perfisPorId.get(capitulo.user_id) ||
                obra?.autor?.trim() ||
                "Autor não encontrado"
              : "Autor não encontrado",
            alvoData: capitulo?.criado_em || "",
            alvoPostId: "",
            alvoObra: obra?.titulo?.trim() || "",
            alvoObraId: obra?.id || capitulo?.obra_id || "",
            alvoObraSlug: obra?.slug?.trim() || "",
            alvoCapituloId: capitulo?.id || denuncia.alvoId,
            alvoCapituloTitulo: capitulo?.titulo?.trim() || "",
          };
        }

        if (denuncia.alvoTipo === "diario_anotacao") {
          const anotacao = diarioAnotacoesPorId.get(denuncia.alvoId);
          const obra = anotacao
            ? obrasPorId.get(anotacao.obra_id)
            : undefined;

          return {
            ...denuncia,
            denuncianteNome: nomeDenunciante(denuncia),
            alvoResumo:
              anotacao?.texto ||
              "Anotação do Diário não encontrada ou removida.",
            alvoAutor: anotacao
              ? perfisPorId.get(anotacao.user_id) ||
                "Autor não encontrado"
              : "Autor não encontrado",
            alvoData:
              anotacao?.atualizado_em ||
              anotacao?.criado_em ||
              "",
            alvoPostId: "",
            alvoCategoria: "Diário",
            alvoTipoPublicacao: anotacao?.tipo?.trim() || "",
            alvoTemSpoiler: Boolean(anotacao?.contem_spoiler),
            alvoObra: obra?.titulo?.trim() || "",
            alvoObraId: obra?.id || anotacao?.obra_id || "",
            alvoObraSlug: obra?.slug?.trim() || "",
            alvoPerfilUserId: anotacao?.user_id || "",
            alvoAnotacaoId: anotacao?.id || denuncia.alvoId,
          };
        }

        if (denuncia.alvoTipo === "comentario_diario") {
          const comentarioDiario = comentariosDiarioPorId.get(
            denuncia.alvoId
          );
          const anotacao = comentarioDiario
            ? diarioAnotacoesPorId.get(comentarioDiario.anotacao_id)
            : undefined;
          const obra = anotacao
            ? obrasPorId.get(anotacao.obra_id)
            : undefined;

          return {
            ...denuncia,
            denuncianteNome: nomeDenunciante(denuncia),
            alvoResumo:
              comentarioDiario?.texto ||
              "Comentário do Diário não encontrado ou removido.",
            alvoAutor: comentarioDiario
              ? perfisPorId.get(comentarioDiario.user_id) ||
                "Autor não encontrado"
              : "Autor não encontrado",
            alvoData:
              comentarioDiario?.atualizado_em ||
              comentarioDiario?.criado_em ||
              "",
            alvoPostId: "",
            alvoCategoria: "Diário",
            alvoTemSpoiler: Boolean(anotacao?.contem_spoiler),
            alvoObra: obra?.titulo?.trim() || "",
            alvoObraId: obra?.id || anotacao?.obra_id || "",
            alvoObraSlug: obra?.slug?.trim() || "",
            alvoPerfilUserId: anotacao?.user_id || "",
            alvoAnotacaoId:
              comentarioDiario?.anotacao_id ||
              anotacao?.id ||
              "",
          };
        }

        const comentarioObra = comentariosObrasPorId.get(
          denuncia.alvoId
        );
        const obra = comentarioObra
          ? obrasPorId.get(comentarioObra.obra_id)
          : undefined;

        return {
          ...denuncia,
          denuncianteNome: nomeDenunciante(denuncia),
          alvoResumo:
            comentarioObra?.comentario ||
            "Comentário da obra não encontrado ou removido.",
          alvoAutor: comentarioObra
            ? perfisPorId.get(comentarioObra.user_id) ||
              "Autor não encontrado"
            : "Autor não encontrado",
          alvoData: comentarioObra?.criado_em || "",
          alvoPostId: "",
          alvoObra: obra?.titulo?.trim() || "",
          alvoObraId: obra?.id || comentarioObra?.obra_id || "",
          alvoObraSlug: obra?.slug?.trim() || "",
        };
      });

    setDenuncias(denunciasComContexto);
    setObservacoes((observacoesAtuais) => {
      const proximasObservacoes = { ...observacoesAtuais };

      denunciasComContexto.forEach((denuncia) => {
        if (!(denuncia.id in proximasObservacoes)) {
          proximasObservacoes[denuncia.id] =
            denuncia.observacaoAdmin;
        }
      });

      return proximasObservacoes;
    });
  }

  async function carregarDenunciasPerfis() {
    const { data: denunciasResposta, error: denunciasErro } = await supabase
      .from("denuncias_perfis")
      .select(
        "id, denunciante_id, denunciado_id, perfil_nome, perfil_url, motivo, descricao, status, criado_em, atualizado_em"
      )
      .order("criado_em", { ascending: false })
      .limit(200);

    if (denunciasErro) {
      if (erroOpcionalIgnoravel(denunciasErro)) {
        setDenunciasPerfis([]);
        return;
      }

      throw denunciasErro;
    }

    const denunciasMapeadas: DenunciaPerfil[] = (
      (denunciasResposta || []) as unknown as Record<string, unknown>[]
    ).map((denuncia) => ({
      id: String(denuncia.id || ""),
      denuncianteId: String(denuncia.denunciante_id || ""),
      denunciadoId: String(denuncia.denunciado_id || ""),
      perfilNome: String(denuncia.perfil_nome || ""),
      perfilUrl: String(denuncia.perfil_url || ""),
      motivo: String(denuncia.motivo || "outro"),
      descricao: String(denuncia.descricao || ""),
      status: normalizarStatusPerfil(denuncia.status),
      criadoEm: String(denuncia.criado_em || ""),
      atualizadoEm: String(denuncia.atualizado_em || denuncia.criado_em || ""),
    }));

    const perfilIds = Array.from(
      new Set(
        denunciasMapeadas
          .flatMap((denuncia) => [denuncia.denuncianteId, denuncia.denunciadoId])
          .filter(Boolean)
      )
    );

    const [perfisPorUserIdResposta, perfisPorIdResposta] = await Promise.all([
      perfilIds.length > 0
        ? supabase
            .from("profiles")
            .select("id, user_id, nome")
            .in("user_id", perfilIds)
            .limit(1000)
        : Promise.resolve({ data: [], error: null }),
      perfilIds.length > 0
        ? supabase
            .from("profiles")
            .select("id, user_id, nome")
            .in("id", perfilIds)
            .limit(1000)
        : Promise.resolve({ data: [], error: null }),
    ]);

    const perfis = [
      ...(perfisPorUserIdResposta.error
        ? []
        : ((perfisPorUserIdResposta.data || []) as unknown as PerfilModeracao[])),
      ...(perfisPorIdResposta.error
        ? []
        : ((perfisPorIdResposta.data || []) as unknown as PerfilModeracao[])),
    ];

    const nomesPorId = criarMapaNomesPerfisModeracao(perfis);

    const denunciasComContexto = denunciasMapeadas.map((denuncia) => ({
      ...denuncia,
      denuncianteNome: nomesPorId.get(denuncia.denuncianteId) || "Usuário",
      denunciadoNome:
        denuncia.perfilNome ||
        nomesPorId.get(denuncia.denunciadoId) ||
        "Usuário denunciado",
      perfilHref: criarHrefPerfilDenunciado(denuncia),
    }));

    setDenunciasPerfis(denunciasComContexto);
  }


  useEffect(() => {
    let cancelado = false;

    async function iniciarModeracao() {
      setCarregando(true);
      setErro("");
      setSucesso("");

      try {
        const { data: usuarioResposta, error: usuarioErro } =
          await supabase.auth.getUser();

        if (usuarioErro) {
          throw usuarioErro;
        }

        const user = usuarioResposta.user || null;

        if (!user) {
          if (!cancelado) {
            setUsuarioId("");
            setEhAdmin(false);
            setDenuncias([]);
            setDenunciasPerfis([]);
            router.replace(criarLoginHrefAdminModeracao());
          }

          return;
        }

        const { data: adminResposta, error: adminErro } =
          await supabase.rpc("usuario_e_admin");

        if (adminErro) {
          throw adminErro;
        }

        const adminConfirmado = adminResposta === true;

        if (!cancelado) {
          setUsuarioId(user.id);
          setEhAdmin(adminConfirmado);
        }

        if (adminConfirmado) {
          await Promise.all([carregarDenuncias(), carregarDenunciasPerfis()]);
        }
      } catch (error) {
        if (!cancelado) {
          setErro(criarMensagemErro("Erro ao carregar moderação", error));
        }
      } finally {
        if (!cancelado) {
          setCarregando(false);
        }
      }
    }

    iniciarModeracao();

    return () => {
      cancelado = true;
    };
  }, [router]);

  const denunciasAtivas = useMemo(() => {
    return denuncias.filter((denuncia) => !denuncia.arquivada);
  }, [denuncias]);

  const denunciasFiltradas = useMemo(() => {
    const buscaNormalizada = normalizarTexto(busca);

    return denuncias.filter((denuncia) => {
      const arquivada = denuncia.arquivada;

      if (statusFiltro === "arquivadas") {
        if (!arquivada) {
          return false;
        }
      } else {
        if (arquivada) {
          return false;
        }

        const statusCombina =
          statusFiltro === "todas" || denuncia.status === statusFiltro;

        if (!statusCombina) {
          return false;
        }
      }

      if (!buscaNormalizada) {
        return true;
      }

      const conteudoBusca = normalizarTexto(
        [
          denuncia.motivo,
          denuncia.detalhe,
          denuncia.status,
          denuncia.denuncianteNome,
          denuncia.alvoTipo,
          denuncia.alvoResumo,
          denuncia.alvoAutor,
          denuncia.alvoPostId,
          denuncia.alvoCategoria || "",
          denuncia.alvoTipoPublicacao || "",
          denuncia.alvoTemSpoiler ? "spoiler contem spoiler" : "",
          denuncia.alvoObra || "",
          denuncia.alvoCapituloTitulo || "",
          denuncia.alvoCapituloId || "",
          denuncia.alvoObraId || "",
          denuncia.alvoObraSlug || "",
          denuncia.alvoPerfilUserId || "",
          denuncia.alvoAnotacaoId || "",
          arquivada ? "arquivada ocultada painel" : "",
        ].join(" ")
      );

      return conteudoBusca.includes(buscaNormalizada);
    });
  }, [busca, denuncias, statusFiltro]);


  const denunciasPerfisFiltradas = useMemo(() => {
    const buscaNormalizada = normalizarTexto(busca);
    const statusPerfilCorrespondente: StatusDenunciaPerfil | null =
      statusFiltro === "pendente"
        ? "pendente"
        : statusFiltro === "em_analise"
          ? "analisada"
          : statusFiltro === "resolvida"
            ? "resolvida"
            : statusFiltro === "rejeitada"
              ? "ignorada"
              : null;

    if (statusFiltro === "arquivadas") {
      return [];
    }

    return denunciasPerfis.filter((denuncia) => {
      if (statusPerfilCorrespondente && denuncia.status !== statusPerfilCorrespondente) {
        return false;
      }

      if (!buscaNormalizada) {
        return true;
      }

      const conteudoBusca = normalizarTexto(
        [
          "perfil usuario denuncia",
          denuncia.motivo,
          formatarMotivoDenunciaPerfil(denuncia.motivo),
          denuncia.descricao,
          denuncia.status,
          denuncia.denuncianteNome,
          denuncia.denunciadoNome,
          denuncia.denunciadoId,
          denuncia.perfilUrl,
        ].join(" ")
      );

      return conteudoBusca.includes(buscaNormalizada);
    });
  }, [busca, denunciasPerfis, statusFiltro]);

  useEffect(() => {
    const fecharMenuTimer = window.setTimeout(() => {
      setMenuDenunciaAbertoId("");
    }, 0);

    return () => {
      window.clearTimeout(fecharMenuTimer);
    };
  }, [busca, statusFiltro]);

  const totalPendentes = denunciasAtivas.filter(
    (denuncia) => denuncia.status === "pendente"
  ).length;

  const totalEmAnalise = denunciasAtivas.filter(
    (denuncia) => denuncia.status === "em_analise"
  ).length;

  const totalResolvidas = denunciasAtivas.filter(
    (denuncia) => denuncia.status === "resolvida"
  ).length;

  const totalRejeitadas = denunciasAtivas.filter(
    (denuncia) => denuncia.status === "rejeitada"
  ).length;


  const totalPerfisPendentes = denunciasPerfis.filter(
    (denuncia) => denuncia.status === "pendente"
  ).length;

  async function atualizarStatusDenunciaPerfil(
    denunciaId: string,
    novoStatus: StatusDenunciaPerfil
  ) {
    if (!usuarioId || !ehAdmin) {
      setErro("Apenas moderadores podem atualizar denúncias de perfis.");
      return;
    }

    const chaveAcao = `perfil-${denunciaId}-${novoStatus}`;

    if (acaoEmAndamento) {
      return;
    }

    setAcaoEmAndamento(chaveAcao);
    setErro("");
    setSucesso("");

    const atualizadoEm = new Date().toISOString();

    try {
      const { data, error } = await supabase
        .from("denuncias_perfis")
        .update({
          status: novoStatus,
          atualizado_em: atualizadoEm,
        })
        .eq("id", denunciaId)
        .select("id")
        .maybeSingle();

      if (error) {
        throw error;
      }

      if (!data?.id) {
        throw new Error(
          "A denúncia de perfil não foi encontrada ou não pôde ser atualizada."
        );
      }

      setDenunciasPerfis((denunciasAtuais) =>
        denunciasAtuais.map((denuncia) =>
          denuncia.id === denunciaId
            ? {
                ...denuncia,
                status: novoStatus,
                atualizadoEm,
              }
            : denuncia
        )
      );

      setSucesso(
        `Denúncia de perfil marcada como ${STATUS_PERFIL_LABEL[
          novoStatus
        ].toLowerCase()}.`
      );
    } catch (error) {
      setErro(criarMensagemErro("Erro ao atualizar denúncia de perfil", error));
    } finally {
      setAcaoEmAndamento("");
    }
  }

  async function atualizarStatusDenuncia(
    denunciaId: string,
    novoStatus: StatusDenuncia
  ) {
    if (!usuarioId || !ehAdmin) {
      setErro("Apenas moderadores podem atualizar denúncias.");
      return;
    }

    const chaveAcao = `${denunciaId}-${novoStatus}`;

    if (acaoEmAndamento) {
      return;
    }

    setAcaoEmAndamento(chaveAcao);
    setErro("");
    setSucesso("");

    const observacaoAtual = observacoes[denunciaId]?.trim() || "";
    const analisadoEm = new Date().toISOString();

    try {
      const { data, error } = await supabase
        .from("comunidade_denuncias")
        .update({
          status: novoStatus,
          observacao_admin: observacaoAtual.slice(0, 800),
          analisado_por: usuarioId,
          analisado_em: analisadoEm,
        })
        .eq("id", denunciaId)
        .select("id")
        .maybeSingle();

      if (error) {
        throw error;
      }

      if (!data?.id) {
        throw new Error(
          "A denúncia não foi encontrada ou não pôde ser atualizada."
        );
      }

      setDenuncias((denunciasAtuais) =>
        denunciasAtuais.map((denuncia) =>
          denuncia.id === denunciaId
            ? {
                ...denuncia,
                status: novoStatus,
                observacaoAdmin: observacaoAtual.slice(0, 800),
                analisadoPor: usuarioId,
                analisadoEm,
              }
            : denuncia
        )
      );

      setSucesso(`Denúncia marcada como ${STATUS_LABEL[novoStatus].toLowerCase()}.`);
    } catch (error) {
      setErro(criarMensagemErro("Erro ao atualizar denúncia", error));
    } finally {
      setAcaoEmAndamento("");
    }
  }

  async function removerConteudoDenunciado(denuncia: DenunciaComContexto) {
    if (!usuarioId || !ehAdmin) {
      setErro("Apenas moderadores podem remover conteúdo denunciado.");
      return;
    }

    if (acaoEmAndamento) {
      return;
    }

    if (
      !window.confirm(
        textoConfirmacaoRemocaoAdminComunidade(denuncia.alvoTipo, language)
      )
    ) {
      return;
    }

    const chaveAcao = `${denuncia.id}-remover-conteudo`;
    const observacaoAtual = observacoes[denuncia.id]?.trim() || "";
    const observacaoFinal =
      observacaoAtual ||
      `Conteúdo removido pela moderação em ${new Date().toLocaleDateString(
        localeAdminComunidade(language)
      )}.`;
    const analisadoEm = new Date().toISOString();

    setAcaoEmAndamento(chaveAcao);
    setErro("");
    setSucesso("");

    try {
      // A RPC executa a exclusão do conteúdo e a resolução de todas as
      // denúncias correspondentes dentro da mesma transação do PostgreSQL.
      // Se qualquer etapa falhar, nenhuma alteração é confirmada no banco.
      const { error: erroRemocaoTransacional } = await supabase.rpc(
        "remover_conteudo_denunciado_transacional",
        {
          p_alvo_tipo: denuncia.alvoTipo,
          p_alvo_id: denuncia.alvoId,
          p_observacao_admin: observacaoFinal.slice(0, 800),
        }
      );

      if (erroRemocaoTransacional) {
        throw erroRemocaoTransacional;
      }
    } catch (error) {
      setErro(criarMensagemErro("Erro ao remover conteúdo denunciado", error));
      return;
    } finally {
      setAcaoEmAndamento("");
    }

    setDenuncias((denunciasAtuais) =>
      denunciasAtuais.map((denunciaAtual) =>
        denunciaAtual.alvoTipo === denuncia.alvoTipo &&
        denunciaAtual.alvoId === denuncia.alvoId
          ? {
              ...denunciaAtual,
              status: "resolvida",
              observacaoAdmin: observacaoFinal.slice(0, 800),
              analisadoPor: usuarioId,
              analisadoEm,
              alvoResumo: `Conteúdo removido pela moderação. Registro anterior: ${denunciaAtual.alvoResumo}`,
            }
          : denunciaAtual
      )
    );

    setObservacoes((observacoesAtuais) => ({
      ...observacoesAtuais,
      [denuncia.id]: observacaoFinal.slice(0, 800),
    }));

    setSucesso(
      `${rotuloSucessoRemocaoAlvo(
        denuncia.alvoTipo
      )} e denúncia marcada como resolvida.`
    );
  }

  async function arquivarDenuncia(denunciaId: string) {
    if (!usuarioId || !ehAdmin) {
      setErro("Apenas moderadores podem arquivar denúncias.");
      return;
    }

    if (acaoEmAndamento) {
      return;
    }

    const chaveAcao = `${denunciaId}-arquivar`;

    setMenuDenunciaAbertoId("");
    setAcaoEmAndamento(chaveAcao);
    setErro("");
    setSucesso("");

    try {
      const { data, error } = await supabase
        .from("comunidade_denuncias")
        .update({ arquivada: true })
        .eq("id", denunciaId)
        .select("id")
        .maybeSingle();

      if (error) {
        throw error;
      }

      if (!data?.id) {
        throw new Error(
          "A denúncia não foi encontrada ou não pôde ser arquivada."
        );
      }

      setDenuncias((denunciasAtuais) =>
        denunciasAtuais.map((denuncia) =>
          denuncia.id === denunciaId
            ? {
                ...denuncia,
                arquivada: true,
              }
            : denuncia
        )
      );

      setSucesso("Denúncia arquivada e ocultada do painel principal.");
    } catch (error) {
      setErro(criarMensagemErro("Erro ao arquivar denúncia", error));
    } finally {
      setAcaoEmAndamento("");
    }
  }

  async function restaurarDenunciaArquivada(denunciaId: string) {
    if (!usuarioId || !ehAdmin) {
      setErro("Apenas moderadores podem restaurar denúncias.");
      return;
    }

    if (acaoEmAndamento) {
      return;
    }

    const chaveAcao = `${denunciaId}-restaurar`;

    setMenuDenunciaAbertoId("");
    setAcaoEmAndamento(chaveAcao);
    setErro("");
    setSucesso("");

    try {
      const { data, error } = await supabase
        .from("comunidade_denuncias")
        .update({ arquivada: false })
        .eq("id", denunciaId)
        .select("id")
        .maybeSingle();

      if (error) {
        throw error;
      }

      if (!data?.id) {
        throw new Error(
          "A denúncia não foi encontrada ou não pôde ser restaurada."
        );
      }

      setDenuncias((denunciasAtuais) =>
        denunciasAtuais.map((denuncia) =>
          denuncia.id === denunciaId
            ? {
                ...denuncia,
                arquivada: false,
              }
            : denuncia
        )
      );

      setSucesso("Denúncia restaurada para o painel principal.");
    } catch (error) {
      setErro(criarMensagemErro("Erro ao restaurar denúncia", error));
    } finally {
      setAcaoEmAndamento("");
    }
  }

  async function removerDenunciaResolvida(denunciaId: string) {
    if (!usuarioId || !ehAdmin) {
      setErro("Apenas moderadores podem remover denúncias resolvidas.");
      return;
    }

    if (acaoEmAndamento) {
      return;
    }

    const denuncia = denuncias.find((item) => item.id === denunciaId);

    if (!denuncia || denuncia.status !== "resolvida") {
      setErro("Somente denúncias resolvidas podem ser removidas do painel.");
      return;
    }

    const chaveAcao = `${denunciaId}-remover-denuncia`;

    setMenuDenunciaAbertoId("");
    setAcaoEmAndamento(chaveAcao);
    setErro("");
    setSucesso("");

    try {
      const { data, error } = await supabase
        .from("comunidade_denuncias")
        .delete()
        .eq("id", denunciaId)
        .eq("status", "resolvida")
        .select("id")
        .maybeSingle();

      if (error) {
        throw error;
      }

      if (!data?.id) {
        throw new Error(
          "A denúncia resolvida não foi encontrada ou não pôde ser removida."
        );
      }

      setDenuncias((denunciasAtuais) =>
        denunciasAtuais.filter((denunciaAtual) => denunciaAtual.id !== denunciaId)
      );
      setObservacoes((observacoesAtuais) => {
        const proximasObservacoes = { ...observacoesAtuais };
        delete proximasObservacoes[denunciaId];
        return proximasObservacoes;
      });
      setSucesso("Denúncia resolvida removida do painel.");
    } catch (error) {
      setErro(criarMensagemErro("Erro ao remover denúncia resolvida", error));
    } finally {
      setAcaoEmAndamento("");
    }
  }


  async function removerDenunciaPerfilResolvida(denunciaId: string) {
    if (!usuarioId || !ehAdmin) {
      setErro("Apenas moderadores podem remover denúncias de perfis resolvidas.");
      return;
    }

    if (acaoEmAndamento) {
      return;
    }

    const denuncia = denunciasPerfis.find((item) => item.id === denunciaId);

    if (!denuncia || denuncia.status !== "resolvida") {
      setErro("Somente denúncias de perfis resolvidas podem ser removidas do painel.");
      return;
    }

    const chaveAcao = `perfil-${denunciaId}-remover-denuncia`;

    setMenuDenunciaAbertoId("");
    setAcaoEmAndamento(chaveAcao);
    setErro("");
    setSucesso("");

    try {
      const { data, error } = await supabase
        .from("denuncias_perfis")
        .delete()
        .eq("id", denunciaId)
        .eq("status", "resolvida")
        .select("id")
        .maybeSingle();

      if (error) {
        throw error;
      }

      if (!data?.id) {
        throw new Error(
          "A denúncia de perfil resolvida não foi encontrada ou não pôde ser removida."
        );
      }

      setDenunciasPerfis((denunciasAtuais) =>
        denunciasAtuais.filter((denunciaAtual) => denunciaAtual.id !== denunciaId)
      );

      setSucesso("Denúncia de perfil resolvida removida do painel.");
    } catch (error) {
      setErro(criarMensagemErro("Erro ao remover denúncia de perfil resolvida", error));
    } finally {
      setAcaoEmAndamento("");
    }
  }

  function limparFiltros() {
    setStatusFiltro("todas");
    setBusca("");
    setBuscaModeracaoAberta(false);
    setMostrarFiltrosModeracao(false);
  }

  if (carregando) {
    return (
      <main data-historietas-admin-comunidade-root="true" style={pageThemeStyle}>
        <AdminComunidadeLanguageBridge />
        <style>{`${historietasThemeCss}${adminComunidadePageCss}`}</style>

        {isDesktop && <div style={desktopTopWaterFadeStyle} aria-hidden="true" />}
        {!isDesktop && <div style={mobileTopWaterFadeStyle} aria-hidden="true" />}
      </main>
    );
  }

  if (!usuarioId) {
    return (
      <main data-historietas-admin-comunidade-root="true" style={pageThemeStyle}>
        <AdminComunidadeLanguageBridge />
        <style>{`${historietasThemeCss}${adminComunidadePageCss}`}</style>

        {isDesktop && <div style={desktopTopWaterFadeStyle} aria-hidden="true" />}
        {!isDesktop && <div style={mobileTopWaterFadeStyle} aria-hidden="true" />}

        <section style={isDesktop ? desktopContainerStyle : containerStyle}>
          <p
            style={{
              margin: "10px 0 0",
              color: "#FFFFFF",
              fontSize: "12px",
              fontWeight: 800,
              textAlign: "center",
            }}
          >
            Área restrita
          </p>

          {erro && <span style={errorStyle}>{erro}</span>}
        </section>
      </main>
    );
  }

  if (!ehAdmin) {
    return (
      <main data-historietas-admin-comunidade-root="true" style={pageThemeStyle}>
        <AdminComunidadeLanguageBridge />
        <style>{`${historietasThemeCss}${adminComunidadePageCss}`}</style>

        {isDesktop && <div style={desktopTopWaterFadeStyle} aria-hidden="true" />}
        {!isDesktop && <div style={mobileTopWaterFadeStyle} aria-hidden="true" />}

        <section style={isDesktop ? desktopContainerStyle : containerStyle}>
          <p
            style={{
              margin: "10px 0 0",
              color: "#FFFFFF",
              fontSize: "12px",
              fontWeight: 800,
              textAlign: "center",
            }}
          >
            Acesso negado
          </p>

          {erro && <span style={errorStyle}>{erro}</span>}
        </section>
      </main>
    );
  }

  return (
    <main data-historietas-admin-comunidade-root="true" style={pageThemeStyle}>
        <AdminComunidadeLanguageBridge />
      <style>{`${historietasThemeCss}${adminComunidadePageCss}`}</style>

      {isDesktop && <div style={desktopTopWaterFadeStyle} aria-hidden="true" />}
      {!isDesktop && <div style={mobileTopWaterFadeStyle} aria-hidden="true" />}

      <section style={isDesktop ? desktopContainerStyle : containerStyle}>
        <header style={isDesktop ? desktopTitleHeaderStyle : titleHeaderStyle}>
          <button
            type="button"
            onClick={() => setMostrarFiltrosModeracao(true)}
            style={adminFilterLabelButtonStyle}
          >
            <span>Moderação</span>
            <span style={adminFilterActionIconStyle}>⇅</span>
          </button>

          <div style={titleHeaderActionsStyle}>
            <Link
              href="/admin/problemas-tecnicos"
              style={
                isDesktop
                  ? desktopTechnicalSupportButtonStyle
                  : mobileTechnicalSupportButtonStyle
              }
              aria-label="Abrir problemas técnicos"
              title="Problemas técnicos"
            >
              {isDesktop ? "Problemas técnicos" : "T"}
            </Link>

            <button
              type="button"
              aria-label={buscaModeracaoAberta ? "Fechar busca" : "Abrir busca"}
              aria-expanded={buscaModeracaoAberta || Boolean(busca.trim())}
              onClick={() => setBuscaModeracaoAberta((aberta) => !aberta)}
              style={titleSearchButtonStyle}
            >
              <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                aria-hidden="true"
              >
                <circle
                  cx="10.85"
                  cy="10.85"
                  r="6.65"
                  stroke="currentColor"
                  strokeWidth="2.15"
                />
                <path
                  d="M16.05 16.05L20.25 20.25"
                  stroke="currentColor"
                  strokeWidth="2.15"
                  strokeLinecap="round"
                />
              </svg>
            </button>

            {isDesktop ? (
              <Link
                href="/notificacoes"
                style={desktopNotificationButtonStyle}
                aria-label={
                  notificacoesNaoLidas > 0
                    ? `Notificações: ${notificacoesNaoLidas} não lidas`
                    : "Notificações"
                }
              >
                N

                {notificacoesNaoLidas > 0 ? (
                  <span style={desktopNotificationBadgeStyle}>
                    {notificacoesNaoLidas > 99
                      ? "99+"
                      : notificacoesNaoLidas}
                  </span>
                ) : null}
              </Link>
            ) : null}
          </div>
        </header>

        <section style={toolsStyle}>
          {(buscaModeracaoAberta || busca.trim()) && (
            <label style={adminSearchShellStyle}>
              <span style={adminSearchIconStyle}>
                <svg
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  aria-hidden="true"
                >
                  <circle
                    cx="10.85"
                    cy="10.85"
                    r="6.65"
                    stroke="currentColor"
                    strokeWidth="2.15"
                  />
                  <path
                    d="M16.05 16.05L20.25 20.25"
                    stroke="currentColor"
                    strokeWidth="2.15"
                    strokeLinecap="round"
                  />
                </svg>
              </span>

              <input
                value={busca}
                onChange={(event) => setBusca(event.target.value)}
                placeholder="Buscar denúncias..."
                autoComplete="off"
                autoCorrect="off"
                spellCheck={false}
                maxLength={100}
                style={adminSearchInputStyle}
              />
            </label>
          )}

          <section className="admin-comunidade-stats" style={statsGridStyle}>
            <div style={statCardStyle}>
              <strong style={statNumberStyle}>{denunciasAtivas.length}</strong>
              <span style={statLabelStyle}>total</span>
            </div>

            <div style={statCardStyle}>
              <strong style={statNumberStyle}>{totalPendentes}</strong>
              <span style={statLabelStyle}>pendentes</span>
            </div>

            <div style={statCardStyle}>
              <strong style={statNumberStyle}>{totalEmAnalise}</strong>
              <span style={statLabelStyle}>em análise</span>
            </div>

            <div style={statCardStyle}>
              <strong style={statNumberStyle}>{totalResolvidas}</strong>
              <span style={statLabelStyle}>resolvidas</span>
            </div>

            <div style={statCardStyle}>
              <strong style={statNumberStyle}>{totalRejeitadas}</strong>
              <span style={statLabelStyle}>rejeitadas</span>
            </div>

            <div style={statCardStyle}>
              <strong style={statNumberStyle}>{denunciasPerfis.length}</strong>
              <span style={statLabelStyle}>perfis</span>
            </div>

            <div style={statCardStyle}>
              <strong style={statNumberStyle}>{totalPerfisPendentes}</strong>
              <span style={statLabelStyle}>perfis pend.</span>
            </div>
          </section>

          <div style={statusFilterWrapStyle}>
            <div className="admin-comunidade-filter-buttons" style={filterButtonsStyle}>
              {(["todas", ...STATUS_DENUNCIAS, "arquivadas"] as const).map((status) => (
                <button
                  key={status}
                  type="button"
                  onClick={() => setStatusFiltro(status)}
                  style={
                    statusFiltro === status
                      ? activeFilterButtonStyle
                      : filterButtonStyle
                  }
                >
                  {status === "todas"
                    ? "Todas"
                    : status === "arquivadas"
                      ? "Arquivadas"
                      : STATUS_LABEL[status]}
                </button>
              ))}
            </div>

            {(busca || statusFiltro !== "todas") && (
              <button type="button" onClick={limparFiltros} style={clearButtonStyle}>
                Limpar filtros
              </button>
            )}
          </div>
        </section>

        {mostrarFiltrosModeracao && (
          <section
            style={adminFiltersSheetOverlayStyle}
            aria-label="Filtrar denúncias"
          >
            <button
              type="button"
              aria-label="Fechar filtros"
              onClick={() => setMostrarFiltrosModeracao(false)}
              style={adminFiltersSheetBackdropStyle}
            />

            <article style={adminFiltersSheetStyle}>
              <div style={adminFiltersSheetHandleStyle} />

              <strong style={adminFiltersSheetTitleStyle}>
                Moderação
              </strong>

              <span style={adminFiltersSheetSectionLabelStyle}>Status</span>

              {(["todas", ...STATUS_DENUNCIAS, "arquivadas"] as const).map(
                (status) => (
                  <button
                    key={status}
                    type="button"
                    onClick={() => {
                      setStatusFiltro(status);
                      setMostrarFiltrosModeracao(false);
                    }}
                    style={
                      statusFiltro === status
                        ? adminFiltersSheetOptionActiveStyle
                        : adminFiltersSheetOptionStyle
                    }
                  >
                    <span>
                      {status === "todas"
                        ? "Todas"
                        : status === "arquivadas"
                          ? "Arquivadas"
                          : STATUS_LABEL[status]}
                    </span>

                    <span
                      style={
                        statusFiltro === status
                          ? adminFiltersSheetRadioActiveStyle
                          : adminFiltersSheetRadioStyle
                      }
                    >
                      {statusFiltro === status ? "✓" : ""}
                    </span>
                  </button>
                )
              )}

              {(busca || statusFiltro !== "todas") && (
                <button
                  type="button"
                  onClick={limparFiltros}
                  style={adminFiltersSheetClearButtonStyle}
                >
                  Limpar filtros
                </button>
              )}
            </article>
          </section>
        )}

        {(erro || sucesso) && (
          <section style={feedbackWrapStyle}>
            {erro && <span style={errorStyle}>{erro}</span>}
            {sucesso && <span style={successStyle}>{sucesso}</span>}
          </section>
        )}

        {denunciasPerfisFiltradas.length > 0 && (
          <section style={listStyle}>
            <section style={summaryStyle}>
              <strong style={summaryTitleStyle}>
                {denunciasPerfisFiltradas.length === 1
                  ? "1 denúncia de perfil encontrada"
                  : `${denunciasPerfisFiltradas.length} denúncias de perfis encontradas`}
              </strong>
            </section>

            {denunciasPerfisFiltradas.map((denuncia) => {
              const acaoAtiva = acaoEmAndamento.startsWith(`perfil-${denuncia.id}`);
              const menuIdPerfil = `perfil-${denuncia.id}`;
              const menuAberto = menuDenunciaAbertoId === menuIdPerfil;

              return (
                <article key={denuncia.id} style={reportCardStyle}>
                  <div className="admin-comunidade-report-header" style={reportHeaderStyle}>
                    <div style={reportTitleWrapStyle}>
                      <div style={reportMetaLineStyle}>
                        <span
                          style={{
                            ...targetBadgeStyle,
                            ...commentTargetBadgeStyle,
                          }}
                        >
                          Perfil
                        </span>

                        <span style={reportDotStyle}>•</span>

                        <span style={reportDateStyle}>
                          Denunciado em {formatarData(denuncia.criadoEm)}
                        </span>

                        <span style={reportDotStyle}>•</span>

                        <span style={statusInlineStyle}>
                          {STATUS_PERFIL_LABEL[denuncia.status]}
                        </span>
                      </div>

                      <strong style={reportTitleStyle}>
                        {formatarMotivoDenunciaPerfil(denuncia.motivo)}
                      </strong>
                    </div>

                    <div style={reportHeaderRightStyle}>
                      <div style={reportMenuWrapStyle}>
                        <button
                          type="button"
                          aria-label={
                            menuAberto
                              ? "Fechar ações da denúncia de perfil"
                              : "Abrir ações da denúncia de perfil"
                          }
                          aria-expanded={menuAberto}
                          onClick={() =>
                            setMenuDenunciaAbertoId((denunciaAbertaId) =>
                              denunciaAbertaId === menuIdPerfil ? "" : menuIdPerfil
                            )
                          }
                          disabled={acaoAtiva}
                          style={{
                            ...reportMenuButtonStyle,
                            opacity: acaoAtiva ? 0.58 : 1,
                            cursor: acaoAtiva ? "not-allowed" : "pointer",
                          }}
                        >
                          ⋮
                        </button>

                        {menuAberto && (
                          <section
                            style={reportMenuOverlayStyle}
                            aria-label="Ações da denúncia de perfil"
                          >
                            <button
                              type="button"
                              aria-label="Fechar ações da denúncia de perfil"
                              onClick={() => setMenuDenunciaAbertoId("")}
                              style={reportMenuBackdropStyle}
                            />

                            <article role="menu" style={reportMenuStyle}>
                              <div style={reportMenuHandleStyle} />

                              <strong style={reportMenuTitleStyle}>
                                Ações da denúncia
                              </strong>

                              <Link
                                href={denuncia.perfilHref}
                                onClick={() => setMenuDenunciaAbertoId("")}
                                style={reportMenuItemLinkStyle}
                              >
                                Abrir perfil denunciado
                              </Link>

                              {denuncia.status === "resolvida" && (
                                <button
                                  type="button"
                                  onClick={() =>
                                    void removerDenunciaPerfilResolvida(denuncia.id)
                                  }
                                  disabled={acaoAtiva}
                                  style={reportMenuDangerItemStyle}
                                >
                                  {acaoEmAndamento ===
                                  `perfil-${denuncia.id}-remover-denuncia`
                                    ? "Removendo..."
                                    : "Remover do painel"}
                                </button>
                              )}

                              {denuncia.status === "pendente" && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setMenuDenunciaAbertoId("");
                                    void atualizarStatusDenunciaPerfil(
                                      denuncia.id,
                                      "analisada"
                                    );
                                  }}
                                  disabled={acaoAtiva}
                                  style={reportMenuItemStyle}
                                >
                                  {acaoEmAndamento ===
                                  `perfil-${denuncia.id}-analisada`
                                    ? "Assumindo..."
                                    : "Assumir análise"}
                                </button>
                              )}

                              <div style={reportMenuDividerStyle} />

                              {STATUS_DENUNCIAS_PERFIS.map((status) => (
                                <button
                                  key={status}
                                  type="button"
                                  onClick={() => {
                                    setMenuDenunciaAbertoId("");
                                    void atualizarStatusDenunciaPerfil(
                                      denuncia.id,
                                      status
                                    );
                                  }}
                                  disabled={acaoAtiva || denuncia.status === status}
                                  style={
                                    denuncia.status === status
                                      ? reportMenuItemActiveStyle
                                      : reportMenuItemStyle
                                  }
                                >
                                  {acaoEmAndamento ===
                                  `perfil-${denuncia.id}-${status}`
                                    ? "Salvando..."
                                    : `Marcar como ${STATUS_PERFIL_LABEL[
                                        status
                                      ].toLowerCase()}`}
                                </button>
                              ))}
                            </article>
                          </section>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="admin-comunidade-report-body" style={reportBodyStyle}>
                    <section style={contentBoxStyle}>
                      <div style={sectionHeaderLineStyle}>
                        <span style={boxLabelStyle}>Perfil denunciado</span>
                      </div>

                      <p style={reportedTextCompactStyle}>{denuncia.denunciadoNome}</p>

                      <div style={metaGridStyle}>
                        <span style={metaItemStyle}>
                          Denunciante: <strong>{denuncia.denuncianteNome}</strong>
                        </span>
                      </div>
                    </section>

                    <section style={contentBoxStyle}>
                      <div style={sectionHeaderLineStyle}>
                        <span style={boxLabelStyle}>Denúncia</span>
                        <span style={sectionHintStyle}>Registro interno</span>
                      </div>

                      {denuncia.descricao ? (
                        <p style={detailTextStyle}>{denuncia.descricao}</p>
                      ) : (
                        <p style={mutedTextStyle}>Sem descrição adicional.</p>
                      )}
                    </section>
                  </div>

                  {denuncia.atualizadoEm && denuncia.atualizadoEm !== denuncia.criadoEm && (
                    <span style={analysisMetaStyle}>
                      Última atualização em {formatarData(denuncia.atualizadoEm)}
                    </span>
                  )}
                </article>
              );
            })}
          </section>
        )}

        <section style={summaryStyle}>
          <strong style={summaryTitleStyle}>
            {denunciasFiltradas.length === 1
              ? "1 denúncia de conteúdo encontrada"
              : `${denunciasFiltradas.length} denúncias de conteúdo encontradas`}
          </strong>
        </section>

        <section style={listStyle}>
          {denunciasFiltradas.length > 0 ? (
            denunciasFiltradas.map((denuncia) => {
              const acaoAtiva = acaoEmAndamento.startsWith(denuncia.id);
              const observacao = observacoes[denuncia.id] || "";
              const menuAberto = menuDenunciaAbertoId === denuncia.id;
              const denunciaArquivada = denuncia.arquivada;
              const conteudoIndisponivel =
                conteudoDenunciadoIndisponivel(denuncia);
              const denunciaResolvidaComConteudoIndisponivel =
                denuncia.status === "resolvida" && conteudoIndisponivel;

              return (
                <article key={denuncia.id} style={reportCardStyle}>
                  <div className="admin-comunidade-report-header" style={reportHeaderStyle}>
                    <div style={reportTitleWrapStyle}>
                      <div style={reportMetaLineStyle}>
                        <span
                          style={{
                            ...targetBadgeStyle,
                            ...(denuncia.alvoTipo === "post"
                              ? postTargetBadgeStyle
                              : commentTargetBadgeStyle),
                          }}
                        >
                          {rotuloTipoAlvoDenuncia(denuncia.alvoTipo)}
                        </span>

                        <span style={reportDotStyle}>•</span>

                        <span style={reportDateStyle}>
                          Denunciado em {formatarData(denuncia.criadoEm)}
                        </span>

                        <span style={reportDotStyle}>•</span>

                        <span style={statusInlineStyle}>
                          {STATUS_LABEL[denuncia.status]}
                        </span>

                        {denunciaArquivada && (
                          <>
                            <span style={reportDotStyle}>•</span>
                            <span style={archivedInlineStyle}>Arquivada</span>
                          </>
                        )}
                      </div>

                      <strong style={reportTitleStyle}>{denuncia.motivo}</strong>
                    </div>

                    <div style={reportHeaderRightStyle}>
                      <div style={reportMenuWrapStyle}>
                        <button
                          type="button"
                          aria-label={
                            menuAberto
                              ? "Fechar ações da denúncia"
                              : "Abrir ações da denúncia"
                          }
                          aria-expanded={menuAberto}
                          onClick={() =>
                            setMenuDenunciaAbertoId((denunciaAbertaId) =>
                              denunciaAbertaId === denuncia.id ? "" : denuncia.id
                            )
                          }
                          disabled={acaoAtiva}
                          style={{
                            ...reportMenuButtonStyle,
                            opacity: acaoAtiva ? 0.58 : 1,
                            cursor: acaoAtiva ? "not-allowed" : "pointer",
                          }}
                        >
                          ⋮
                        </button>

                        {menuAberto && (
                          <section
                            style={reportMenuOverlayStyle}
                            aria-label="Ações da denúncia"
                          >
                            <button
                              type="button"
                              aria-label="Fechar ações da denúncia"
                              onClick={() => setMenuDenunciaAbertoId("")}
                              style={reportMenuBackdropStyle}
                            />

                            <article role="menu" style={reportMenuStyle}>
                              <div style={reportMenuHandleStyle} />

                              <strong style={reportMenuTitleStyle}>
                                Ações da denúncia
                              </strong>
                            {denuncia.alvoPostId && (
                              <Link
                                href={`/comunidade?post=${encodeURIComponent(
                                  denuncia.alvoPostId
                                )}`}
                                onClick={() => setMenuDenunciaAbertoId("")}
                                style={reportMenuItemLinkStyle}
                              >
                                Abrir publicação na Comunidade
                              </Link>
                            )}

                            {(denuncia.alvoTipo === "comentario_capitulo" ||
                              denuncia.alvoTipo === "capitulo") &&
                              denuncia.alvoObraId &&
                              denuncia.alvoCapituloId && (
                                <Link
                                  href={`/ler-capitulo?obraId=${encodeURIComponent(
                                    denuncia.alvoObraId
                                  )}&capituloId=${encodeURIComponent(
                                    denuncia.alvoCapituloId
                                  )}`}
                                  onClick={() => setMenuDenunciaAbertoId("")}
                                  style={reportMenuItemLinkStyle}
                                >
                                  Abrir capítulo denunciado
                                </Link>
                              )}

                            {(denuncia.alvoTipo === "obra" ||
                              denuncia.alvoTipo === "comentario_obra") &&
                              denuncia.alvoObraSlug && (
                                <Link
                                  href={`/obra/${encodeURIComponent(
                                    denuncia.alvoObraSlug
                                  )}`}
                                  onClick={() =>
                                    setMenuDenunciaAbertoId("")
                                  }
                                  style={reportMenuItemLinkStyle}
                                >
                                  Abrir obra denunciada
                                </Link>
                              )}

                            {(denuncia.alvoTipo === "diario_anotacao" ||
                              denuncia.alvoTipo === "comentario_diario") &&
                              denuncia.alvoPerfilUserId && (
                                <Link
                                  href={criarHrefDiarioDenunciado(denuncia)}
                                  onClick={() =>
                                    setMenuDenunciaAbertoId("")
                                  }
                                  style={reportMenuItemLinkStyle}
                                >
                                  Abrir conteúdo no Diário
                                </Link>
                              )}

                            {denunciaArquivada ? (
                              <button
                                type="button"
                                onClick={() => void restaurarDenunciaArquivada(denuncia.id)}
                                disabled={acaoAtiva}
                                style={reportMenuItemStyle}
                              >
                                Restaurar para o painel
                              </button>
                            ) : (
                              <button
                                type="button"
                                onClick={() => void arquivarDenuncia(denuncia.id)}
                                disabled={acaoAtiva}
                                style={reportMenuItemStyle}
                              >
                                Arquivar denúncia
                              </button>
                            )}

                            {denuncia.status === "resolvida" && (
                              <button
                                type="button"
                                onClick={() => void removerDenunciaResolvida(denuncia.id)}
                                disabled={acaoAtiva}
                                style={reportMenuDangerItemStyle}
                              >
                                {acaoEmAndamento === `${denuncia.id}-remover-denuncia`
                                  ? "Removendo..."
                                  : "Remover do painel"}
                              </button>
                            )}

                            {denuncia.status === "pendente" && (
                              <button
                                type="button"
                                onClick={() => {
                                  setMenuDenunciaAbertoId("");
                                  void atualizarStatusDenuncia(
                                    denuncia.id,
                                    "em_analise"
                                  );
                                }}
                                disabled={acaoAtiva}
                                style={reportMenuItemStyle}
                              >
                                {acaoEmAndamento === `${denuncia.id}-em_analise`
                                  ? "Assumindo..."
                                  : "Assumir análise"}
                              </button>
                            )}

                            <button
                              type="button"
                              onClick={() => {
                                setMenuDenunciaAbertoId("");
                                void removerConteudoDenunciado(denuncia);
                              }}
                              disabled={
                                acaoAtiva ||
                                conteudoIndisponivel
                              }
                              style={reportMenuDangerItemStyle}
                            >
                              {acaoEmAndamento ===
                              `${denuncia.id}-remover-conteudo`
                                ? "Removendo..."
                                : rotuloRemocaoAlvoDenuncia(
                                    denuncia.alvoTipo
                                  )}
                            </button>

                            <div style={reportMenuDividerStyle} />

                            {STATUS_DENUNCIAS.map((status) => (
                              <button
                                key={status}
                                type="button"
                                onClick={() => {
                                  setMenuDenunciaAbertoId("");
                                  void atualizarStatusDenuncia(
                                    denuncia.id,
                                    status
                                  );
                                }}
                                disabled={acaoAtiva || denuncia.status === status}
                                style={
                                  denuncia.status === status
                                    ? reportMenuItemActiveStyle
                                    : reportMenuItemStyle
                                }
                              >
                                {acaoEmAndamento === `${denuncia.id}-${status}`
                                  ? "Salvando..."
                                  : `Marcar como ${STATUS_LABEL[
                                      status
                                    ].toLowerCase()}`}
                              </button>
                            ))}

                            </article>
                          </section>
                        )}</div>
                    </div>
                  </div>

                  <div className="admin-comunidade-report-body" style={reportBodyStyle}>
                    <section style={contentBoxStyle}>
                      <div style={sectionHeaderLineStyle}>
                        <span style={boxLabelStyle}>Conteúdo denunciado</span>
                        <span style={sectionHintStyle}>
                          {conteudoIndisponivel
                            ? "Indisponível"
                            : rotuloTipoAlvoDenuncia(denuncia.alvoTipo)}
                        </span>
                      </div>

                      <p
                        style={
                          denunciaResolvidaComConteudoIndisponivel
                            ? reportedTextCompactStyle
                            : reportedTextStyle
                        }
                      >
                        {conteudoIndisponivel
                          ? "Conteúdo removido ou indisponível."
                          : denuncia.alvoResumo}
                      </p>

                      {!conteudoIndisponivel && (
                        <div style={metaGridStyle}>
                        <span style={metaItemStyle}>
                          Autor: <strong>{denuncia.alvoAutor}</strong>
                        </span>

                        <span style={metaItemStyle}>
                          Data: <strong>{formatarData(denuncia.alvoData)}</strong>
                        </span>

                        {denuncia.alvoCategoria && (
                          <span style={metaItemStyle}>
                            Categoria: <strong>{denuncia.alvoCategoria}</strong>
                          </span>
                        )}

                        {(denuncia.alvoTipo === "post" ||
                          denuncia.alvoTipo === "diario_anotacao") &&
                          denuncia.alvoTipoPublicacao && (
                            <span style={metaItemStyle}>
                              Tipo: <strong>{denuncia.alvoTipoPublicacao}</strong>
                            </span>
                          )}

                        {(denuncia.alvoTipo === "post" ||
                          denuncia.alvoTipo === "diario_anotacao" ||
                          denuncia.alvoTipo === "comentario_diario") && (
                          <span
                            style={
                              denuncia.alvoTemSpoiler
                                ? spoilerMetaItemStyle
                                : metaItemStyle
                            }
                          >
                            Spoiler:{" "}
                            <strong>
                              {denuncia.alvoTemSpoiler ? "Sim" : "Não"}
                            </strong>
                          </span>
                        )}

                          {denuncia.alvoObra && (
                            <span style={metaItemStyle}>
                              Obra: <strong>{denuncia.alvoObra}</strong>
                            </span>
                          )}

                          {(denuncia.alvoTipo === "comentario_capitulo" ||
                            denuncia.alvoTipo === "capitulo") &&
                            denuncia.alvoCapituloId && (
                              <span style={metaItemStyle}>
                                Capítulo:{" "}
                                <strong>
                                  {denuncia.alvoCapituloTitulo ||
                                    denuncia.alvoCapituloId}
                                </strong>
                              </span>
                            )}
                        </div>
                      )}
                    </section>

                    <section style={contentBoxStyle}>
                      <div style={sectionHeaderLineStyle}>
                        <span style={boxLabelStyle}>Denúncia</span>
                        <span style={sectionHintStyle}>Registro interno</span>
                      </div>

                      <div style={reasonGridStyle}>
                        <span style={reasonItemStyle}>
                          Denunciante: <strong>{denuncia.denuncianteNome}</strong>
                        </span>
                      </div>

                      {denuncia.detalhe ? (
                        <p style={detailTextStyle}>{denuncia.detalhe}</p>
                      ) : (
                        <p style={mutedTextStyle}>Sem detalhe adicional.</p>
                      )}
                    </section>

                    <label style={adminNoteStyle}>
                      <div style={sectionHeaderLineStyle}>
                        <span style={adminObservationLabelStyle}>
                          Observação interna
                        </span>
                        <span style={sectionHintStyle}>Até 800 caracteres</span>
                      </div>

                      <textarea
                        value={observacao}
                        onChange={(event) =>
                          setObservacoes((observacoesAtuais) => ({
                            ...observacoesAtuais,
                            [denuncia.id]: event.target.value,
                          }))
                        }
                        disabled={acaoAtiva}
                        placeholder="Ex.: conteúdo analisado, ação tomada, manter observação interna..."
                        maxLength={800}
                        rows={2}
                        style={textareaStyle}
                      />
                    </label>
                  </div>

                  {denuncia.analisadoEm && (
                    <span style={analysisMetaStyle}>
                      Última análise em {formatarData(denuncia.analisadoEm)}
                    </span>
                  )}
                </article>
              );
            })
          ) : (
            <p
              style={{
                margin: "10px 0 0",
                color: "#FFFFFF",
                fontSize: "12px",
                fontWeight: 800,
                textAlign: "center",
              }}
            >
              Nenhuma denúncia encontrada
            </p>
          )}
        </section>
      </section>
    </main>
  );
}


const adminComunidadePageCss = `
  html {
    --historietas-admin-comunidade-bg-page: #070212;
    --historietas-admin-comunidade-bg-deep: #04000A;
    --historietas-admin-comunidade-surface: #08030F;
    --historietas-admin-comunidade-accent: #F97316;
    --historietas-admin-comunidade-secondary: #7C3AED;
    --historietas-admin-comunidade-accent-soft: #FDBA74;
    --historietas-admin-comunidade-accent-pale: #FFD6A8;
    --historietas-admin-comunidade-purple-text: #DDD6FE;
    --historietas-admin-comunidade-title-mid: #F5F3FF;
    --historietas-admin-comunidade-danger-text: #FCA5A5;
    --historietas-admin-comunidade-danger-menu: #FB7185;
    --historietas-admin-comunidade-success-text: #86EFAC;
    --historietas-admin-comunidade-notification-badge-bg: #EF4444;
    --historietas-admin-comunidade-notification-badge-text: #FFFFFF;
    --historietas-admin-comunidade-accent-bg: rgba(249,115,22,0.10);
    --historietas-admin-comunidade-accent-bg-strong: rgba(249,115,22,0.16);
    --historietas-admin-comunidade-accent-border-soft: rgba(249,115,22,0.26);
    --historietas-admin-comunidade-accent-border: rgba(249,115,22,0.28);
    --historietas-admin-comunidade-secondary-bg: rgba(124,58,237,0.13);
    --historietas-admin-comunidade-surface-gradient: rgba(18,12,30,0.90);
    --historietas-admin-comunidade-surface-gradient-strong: rgba(18,12,30,0.92);
    --historietas-admin-comunidade-surface-strong: rgba(8,3,18,0.98);
    --historietas-admin-comunidade-danger-bg: rgba(248,113,113,0.12);
    --historietas-admin-comunidade-danger-border: rgba(248,113,113,0.22);
    --historietas-admin-comunidade-danger-border-strong: rgba(248,113,113,0.30);
    --historietas-admin-comunidade-success-bg: rgba(34,197,94,0.12);
    --historietas-admin-comunidade-success-border: rgba(34,197,94,0.22);
    --historietas-admin-comunidade-panel: rgba(4,0,10,0.72);
  }

  html[data-historietas-tema-visual="foco"] {
    --historietas-admin-comunidade-bg-page: #000000;
    --historietas-admin-comunidade-bg-deep: #000000;
    --historietas-admin-comunidade-surface: #050505;
    --historietas-admin-comunidade-accent: #FFFFFF;
    --historietas-admin-comunidade-secondary: #A1A1AA;
    --historietas-admin-comunidade-accent-soft: #FFFFFF;
    --historietas-admin-comunidade-accent-pale: #FFFFFF;
    --historietas-admin-comunidade-purple-text: #FFFFFF;
    --historietas-admin-comunidade-title-mid: #FFFFFF;
    --historietas-admin-comunidade-danger-text: #FFFFFF;
    --historietas-admin-comunidade-danger-menu: #FFFFFF;
    --historietas-admin-comunidade-success-text: #FFFFFF;
    --historietas-admin-comunidade-notification-badge-bg: #FFFFFF;
    --historietas-admin-comunidade-notification-badge-text: #000000;
    --historietas-admin-comunidade-accent-bg: rgba(255,255,255,0.06);
    --historietas-admin-comunidade-accent-bg-strong: rgba(255,255,255,0.08);
    --historietas-admin-comunidade-accent-border-soft: rgba(255,255,255,0.18);
    --historietas-admin-comunidade-accent-border: rgba(255,255,255,0.22);
    --historietas-admin-comunidade-secondary-bg: rgba(255,255,255,0.06);
    --historietas-admin-comunidade-surface-gradient: #050505;
    --historietas-admin-comunidade-surface-gradient-strong: #050505;
    --historietas-admin-comunidade-surface-strong: #000000;
    --historietas-admin-comunidade-danger-bg: rgba(255,255,255,0.06);
    --historietas-admin-comunidade-danger-border: rgba(255,255,255,0.18);
    --historietas-admin-comunidade-danger-border-strong: rgba(255,255,255,0.22);
    --historietas-admin-comunidade-success-bg: rgba(255,255,255,0.06);
    --historietas-admin-comunidade-success-border: rgba(255,255,255,0.18);
    --historietas-admin-comunidade-panel: rgba(5,5,5,0.92);
  }

  html[data-historietas-tema-visual="original"] body,
  html[data-historietas-tema-visual="original"] main {
    background: #070212 !important;
    color: #FFFFFF !important;
  }

  html[data-historietas-tema-visual="foco"] body,
  html[data-historietas-tema-visual="foco"] main {
    background: #000000 !important;
    color: #FFFFFF !important;
  }

  html[data-historietas-tema-visual] main > div[aria-hidden="true"] {
    background: transparent !important;
    opacity: 0 !important;
  }

  html[data-historietas-tema-visual] input::placeholder,
  html[data-historietas-tema-visual] textarea::placeholder {
    color: rgba(212,212,216,0.68) !important;
  }

  html[data-historietas-tema-visual] input,
  html[data-historietas-tema-visual] textarea,
  html[data-historietas-tema-visual] select {
    color: #FFFFFF !important;
  }

  html[data-historietas-tema-visual] nav,
  html[data-historietas-tema-visual] [data-bottom-nav],
  html[data-historietas-tema-visual] [data-mobile-nav] {
    background: var(--historietas-bottom-nav-bg, #04000A) !important;
  }

  html[data-historietas-tema-visual] nav a[href="/admin/comunidade"],
  html[data-historietas-tema-visual] [data-bottom-nav] a[href="/admin/comunidade"],
  html[data-historietas-tema-visual] [data-mobile-nav] a[href="/admin/comunidade"] {
    background: var(
      --historietas-bottom-nav-active-bg,
      rgba(59, 7, 100, 0.54)
    ) !important;
    border-color: var(
      --historietas-bottom-nav-active-border,
      rgba(109, 40, 217, 0.48)
    ) !important;
    color: #FFFFFF !important;
    box-shadow: none !important;
  }

  html[data-historietas-tema-visual] nav a[href="/admin/comunidade"] .historietas-bottom-nav-icon,
  html[data-historietas-tema-visual] [data-bottom-nav] a[href="/admin/comunidade"] .historietas-bottom-nav-icon,
  html[data-historietas-tema-visual] [data-mobile-nav] a[href="/admin/comunidade"] .historietas-bottom-nav-icon {
    color: #FFFFFF !important;
    background: var(
      --historietas-bottom-nav-active-icon-bg,
      #3B0764
    ) !important;
    border-color: var(
      --historietas-bottom-nav-active-icon-border,
      rgba(167, 139, 250, 0.46)
    ) !important;
  }

  html[data-historietas-tema-visual="foco"] nav a[href="/admin/comunidade"],
  html[data-historietas-tema-visual="foco"] [data-bottom-nav] a[href="/admin/comunidade"],
  html[data-historietas-tema-visual="foco"] [data-mobile-nav] a[href="/admin/comunidade"] {
    background: #050505 !important;
    border-color: #FFFFFF !important;
    color: #FFFFFF !important;
    box-shadow: none !important;
  }

  html[data-historietas-tema-visual="foco"] nav a[href="/admin/comunidade"] .historietas-bottom-nav-icon,
  html[data-historietas-tema-visual="foco"] [data-bottom-nav] a[href="/admin/comunidade"] .historietas-bottom-nav-icon,
  html[data-historietas-tema-visual="foco"] [data-mobile-nav] a[href="/admin/comunidade"] .historietas-bottom-nav-icon {
    background: #000000 !important;
    border-color: rgba(255,255,255,0.24) !important;
    color: #FFFFFF !important;
  }

  html[data-historietas-tema-visual="foco"] .historietas-theme-logo-text,
  html[data-historietas-tema-visual="foco"] .historietas-theme-title {
    background: none !important;
    color: #FFFFFF !important;
    -webkit-text-fill-color: #FFFFFF !important;
    text-shadow: none !important;
  }

  .admin-comunidade-stats > * {
    min-width: 0;
  }

  .admin-comunidade-stats > *:nth-child(-n + 3) {
    grid-column: span 4;
  }

  .admin-comunidade-stats > *:nth-child(n + 4) {
    grid-column: span 3;
  }

  .admin-comunidade-filter-buttons {
    scrollbar-width: none;
    -ms-overflow-style: none;
  }

  .admin-comunidade-filter-buttons::-webkit-scrollbar {
    width: 0;
    height: 0;
    display: none;
  }

  @media (max-width: 760px) {
    .admin-comunidade-header-actions {
      grid-template-columns: 1fr !important;
    }

    .admin-comunidade-report-header {
      grid-template-columns: minmax(0, 1fr) auto !important;
      align-items: start !important;
    }

    .admin-comunidade-report-body {
      grid-template-columns: minmax(0, 1fr) !important;
    }
  }
`;

const safeTextStyle: CSSProperties = {
  overflowWrap: "anywhere",
  wordBreak: "break-word",
};

const pageStyle: CSSProperties = {
  position: "relative",
  minHeight: "100vh",
  width: "100%",
  maxWidth: "100vw",
  overflowX: "hidden",
  background: "var(--historietas-admin-comunidade-bg-page, #070212)",
  color: "#FFFFFF",
  fontFamily: "Inter, Poppins, Manrope, Arial, Helvetica, sans-serif",
};

const containerStyle: CSSProperties = {
  position: "relative",
  width: "min(900px, calc(100% - 28px))",
  maxWidth: "100%",
  margin: "0 auto",
  padding: "10px 0 calc(24px + env(safe-area-inset-bottom))",
  boxSizing: "border-box",
  minWidth: 0,
};

const desktopContainerStyle: CSSProperties = {
  ...containerStyle,
  width: "min(1220px, calc(100% - 64px))",
  padding: "12px 0 42px",
};

const titleHeaderStyle: CSSProperties = {
  position: "relative",
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  gap: "12px",
  marginTop: 0,
  marginBottom: "12px",
  padding: 0,
  minWidth: 0,
  maxWidth: "100%",
  textAlign: "left",
  boxSizing: "border-box",
};

const desktopTitleHeaderStyle: CSSProperties = {
  ...titleHeaderStyle,
  marginTop: 0,
  marginBottom: "16px",
};

const titleHeaderActionsStyle: CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "flex-end",
  gap: "10px",
  flex: "0 0 auto",
};

const desktopTechnicalSupportButtonStyle: CSSProperties = {
  minHeight: "34px",
  borderRadius: "999px",
  border:
    "1px solid var(--historietas-border-soft, rgba(255,255,255,0.10))",
  padding: "7px 12px",
  background:
    "var(--historietas-surface-strong, var(--historietas-admin-comunidade-bg-deep, #04000A))",
  color: "var(--historietas-text-primary, #FFFFFF)",
  textDecoration: "none",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: "10px",
  lineHeight: 1,
  fontWeight: 900,
  whiteSpace: "nowrap",
  boxShadow: "none",
  zIndex: 2,
};

const mobileTechnicalSupportButtonStyle: CSSProperties = {
  width: "34px",
  height: "34px",
  borderRadius: "999px",
  border:
    "1px solid var(--historietas-border-soft, rgba(255,255,255,0.10))",
  background:
    "var(--historietas-surface-strong, var(--historietas-admin-comunidade-bg-deep, #04000A))",
  color: "var(--historietas-text-primary, #FFFFFF)",
  textDecoration: "none",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: "12px",
  lineHeight: 1,
  fontWeight: 950,
  boxShadow: "none",
  zIndex: 2,
};

const desktopNotificationButtonStyle: CSSProperties = {
  position: "relative",
  width: "34px",
  height: "34px",
  borderRadius: "999px",
  border:
    "1px solid var(--historietas-border-soft, rgba(255,255,255,0.08))",
  background: "var(--historietas-surface-strong, var(--historietas-admin-comunidade-bg-deep, #04000A))",
  color: "var(--historietas-text-primary, #FFFFFF)",
  textDecoration: "none",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: "14px",
  lineHeight: 1,
  fontWeight: 950,
  boxShadow: "none",
  zIndex: 2,
};

const desktopNotificationBadgeStyle: CSSProperties = {
  position: "absolute",
  top: "-7px",
  right: "-9px",
  minWidth: "18px",
  height: "18px",
  padding: "0 4px",
  borderRadius: "999px",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  border: "2px solid var(--historietas-bg-start, var(--historietas-admin-comunidade-bg-page, #070212))",
  background:
    "var(--historietas-admin-comunidade-notification-badge-bg, #EF4444)",
  color:
    "var(--historietas-admin-comunidade-notification-badge-text, #FFFFFF)",
  fontSize: "9px",
  lineHeight: 1,
  fontWeight: 950,
  letterSpacing: "-0.03em",
  boxShadow: "0 4px 12px rgba(0, 0, 0, 0.38)",
  pointerEvents: "none",
};


const titleSearchButtonStyle: CSSProperties = {
  width: "34px",
  height: "34px",
  borderRadius: 0,
  border: 0,
  background: "transparent",
  color: "#FFFFFF",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: "15px",
  lineHeight: 1,
  fontWeight: 950,
  fontFamily: "inherit",
  padding: 0,
  cursor: "pointer",
  boxShadow: "none",
  outline: "none",
  WebkitTapHighlightColor: "transparent",
  WebkitAppearance: "none",
  appearance: "none",
};



const mobileTopWaterFadeStyle: CSSProperties = {
  position: "absolute",
  top: 0,
  left: 0,
  right: 0,
  height: "min(340px, 48vh)",
  pointerEvents: "none",
  zIndex: 0,
  background: "transparent",
  opacity: 0,
};

const desktopTopWaterFadeStyle: CSSProperties = {
  position: "absolute",
  top: 0,
  left: 0,
  right: 0,
  height: "min(620px, 68vh)",
  pointerEvents: "none",
  zIndex: 0,
  background: "transparent",
  opacity: 0,
};

const statsGridStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(12, minmax(0, 1fr))",
  gap: "6px",
  margin: "2px 0 0",
  minWidth: 0,
};

const statCardStyle: CSSProperties = {
  display: "grid",
  justifyItems: "center",
  alignContent: "center",
  gap: "2px",
  minHeight: "54px",
  padding: "7px 3px",
  borderRadius: "15px",
  background: "rgba(255,255,255,0.045)",
  border: "none",
  textAlign: "center",
  minWidth: 0,
  overflow: "hidden",
  boxShadow: "none",
};

const statNumberStyle: CSSProperties = {
  color: "#FFFFFF",
  fontSize: "20px",
  lineHeight: 1,
  fontWeight: 950,
  letterSpacing: "-0.05em",
  textAlign: "center",
  ...safeTextStyle,
};

const statLabelStyle: CSSProperties = {
  color: "#D4D4D8",
  fontSize: "7.4px",
  lineHeight: 1.06,
  fontWeight: 950,
  textTransform: "uppercase",
  letterSpacing: "0.035em",
  textAlign: "center",
  ...safeTextStyle,
};

const toolsStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "minmax(0, 1fr)",
  gap: "7px",
  padding: 0,
  borderRadius: 0,
  background: "transparent",
  border: "none",
  marginBottom: "12px",
  minWidth: 0,
  boxShadow: "none",
  overflow: "visible",
  backdropFilter: "none",
  WebkitBackdropFilter: "none",
};

const adminSearchShellStyle: CSSProperties = {
  width: "100%",
  minHeight: "44px",
  borderRadius: "999px",
  border: "1px solid transparent",
  background: "var(--historietas-admin-comunidade-bg-deep, #04000A)",
  display: "flex",
  alignItems: "center",
  gap: "8px",
  padding: "0 15px",
  boxSizing: "border-box",
  boxShadow: "none",
  outline: "none",
};

const adminSearchIconStyle: CSSProperties = {
  color: "rgba(255,255,255,0.72)",
  width: "22px",
  height: "22px",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  lineHeight: 1,
  flex: "0 0 auto",
};

const adminSearchInputStyle: CSSProperties = {
  appearance: "none",
  WebkitAppearance: "none",
  width: "100%",
  minWidth: 0,
  height: "44px",
  border: "none",
  background: "transparent",
  color: "#FFFFFF",
  outline: "none",
  fontFamily: "inherit",
  fontSize: "14px",
  fontWeight: 700,
  letterSpacing: 0,
  boxSizing: "border-box",
};


const adminFilterLabelButtonStyle: CSSProperties = {
  appearance: "none",
  WebkitAppearance: "none",
  border: "none",
  background: "transparent",
  color: "#FFFFFF",
  fontFamily: "inherit",
  fontSize: "16px",
  lineHeight: 1.15,
  fontWeight: 950,
  letterSpacing: "-0.04em",
  textAlign: "left",
  padding: 0,
  cursor: "pointer",
  display: "inline-flex",
  alignItems: "center",
  gap: "8px",
  ...safeTextStyle,
};

const adminFilterActionIconStyle: CSSProperties = {
  color: "#FFFFFF",
  fontSize: "21px",
  lineHeight: 1,
  fontWeight: 700,
  flex: "0 0 auto",
};

const statusFilterWrapStyle: CSSProperties = {
  display: "grid",
  justifyItems: "stretch",
  gap: "7px",
  minWidth: 0,
};

const filterButtonsStyle: CSSProperties = {
  width: "calc(100% + 24px)",
  maxWidth: "calc(100% + 24px)",
  marginLeft: "-12px",
  marginRight: "-12px",
  display: "flex",
  flexWrap: "nowrap",
  justifyContent: "flex-start",
  gap: "7px",
  minWidth: 0,
  overflowX: "auto",
  overflowY: "hidden",
  padding: "0 12px",
  boxSizing: "border-box",
  scrollSnapType: "x proximity",
  WebkitOverflowScrolling: "touch",
};

const filterButtonStyle: CSSProperties = {
  flex: "0 0 auto",
  minHeight: "34px",
  padding: "0 13px",
  borderRadius: "999px",
  border: "1px solid rgba(255,255,255,0.06)",
  background: "rgba(255,255,255,0.06)",
  color: "#D4D4D8",
  fontSize: "10.5px",
  fontWeight: 880,
  cursor: "pointer",
  boxShadow: "none",
  scrollSnapAlign: "center",
};

const activeFilterButtonStyle: CSSProperties = {
  ...filterButtonStyle,
  background: "var(--historietas-admin-comunidade-surface, #08030F)",
  border: "1px solid rgba(255,255,255,0.10)",
  color: "#FFFFFF",
  boxShadow: "none",
};

const feedbackWrapStyle: CSSProperties = {
  display: "grid",
  gap: "8px",
  marginBottom: "12px",
};

const errorStyle: CSSProperties = {
  display: "block",
  padding: "10px 12px",
  borderRadius: "16px",
  background: "var(--historietas-admin-comunidade-danger-bg, rgba(248,113,113,0.12))",
  border: "1px solid var(--historietas-admin-comunidade-danger-border, rgba(248,113,113,0.22))",
  color: "var(--historietas-admin-comunidade-danger-text, #FCA5A5)",
  fontSize: "12px",
  fontWeight: 850,
  ...safeTextStyle,
};

const successStyle: CSSProperties = {
  display: "block",
  padding: "10px 12px",
  borderRadius: "16px",
  background: "var(--historietas-admin-comunidade-success-bg, rgba(34,197,94,0.12))",
  border: "1px solid var(--historietas-admin-comunidade-success-border, rgba(34,197,94,0.22))",
  color: "var(--historietas-admin-comunidade-success-text, #86EFAC)",
  fontSize: "12px",
  fontWeight: 850,
  ...safeTextStyle,
};

const summaryStyle: CSSProperties = {
  display: "grid",
  justifyItems: "center",
  gap: "2px",
  padding: "4px 0 6px",
  borderRadius: 0,
  background: "transparent",
  border: "none",
  color: "#D4D4D8",
  textAlign: "center",
  marginBottom: "6px",
  boxShadow: "none",
};

const summaryTitleStyle: CSSProperties = {
  color: "#FFFFFF",
  fontSize: "14px",
  fontWeight: 950,
  textAlign: "center",
  ...safeTextStyle,
};

const clearButtonStyle: CSSProperties = {
  minHeight: "34px",
  padding: "0 13px",
  borderRadius: "999px",
  border: "1px solid rgba(255,255,255,0.08)",
  background: "var(--historietas-admin-comunidade-panel, rgba(4,0,10,0.72))",
  color: "var(--historietas-admin-comunidade-purple-text, #DDD6FE)",
  fontSize: "10.5px",
  fontWeight: 900,
  cursor: "pointer",
  boxShadow: "none",
};

const listStyle: CSSProperties = {
  display: "grid",
  gap: 0,
  minWidth: 0,
};

const reportCardStyle: CSSProperties = {
  display: "grid",
  gap: "12px",
  padding: "16px 0",
  borderRadius: 0,
  background: "transparent",
  border: "none",
  borderBottom: "1px solid rgba(255,255,255,0.62)",
  boxShadow: "none",
  minWidth: 0,
  overflow: "visible",
};

const reportHeaderStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "minmax(0, 1fr) auto",
  alignItems: "start",
  gap: "10px",
  minWidth: 0,
};

const reportTitleWrapStyle: CSSProperties = {
  display: "grid",
  gap: "5px",
  alignContent: "start",
  justifyItems: "start",
  minWidth: 0,
};

const reportMetaLineStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: "6px",
  flexWrap: "wrap",
  minWidth: 0,
};

const reportDotStyle: CSSProperties = {
  color: "var(--historietas-text-muted, #A1A1AA)",
  fontSize: "10px",
  fontWeight: 950,
  lineHeight: 1,
};

const targetBadgeStyle: CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: "9px",
  fontWeight: 950,
  textTransform: "uppercase",
  letterSpacing: "0.07em",
};

const postTargetBadgeStyle: CSSProperties = {
  color: "#FFFFFF",
};

const commentTargetBadgeStyle: CSSProperties = {
  color: "#FFFFFF",
};

const reportTitleStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "15px",
  lineHeight: 1.24,
  fontWeight: 950,
  ...safeTextStyle,
};

const reportDateStyle: CSSProperties = {
  color: "var(--historietas-text-muted, #A1A1AA)",
  fontSize: "10.5px",
  lineHeight: 1.2,
  fontWeight: 800,
};

const statusInlineStyle: CSSProperties = {
  color: "var(--historietas-accent, var(--historietas-admin-comunidade-accent-soft, #FDBA74))",
  fontSize: "10.5px",
  lineHeight: 1.2,
  fontWeight: 950,
  whiteSpace: "nowrap",
};

const archivedInlineStyle: CSSProperties = {
  color: "var(--historietas-text-muted, #A1A1AA)",
  fontSize: "10.5px",
  lineHeight: 1.2,
  fontWeight: 900,
  whiteSpace: "nowrap",
};

const reportHeaderRightStyle: CSSProperties = {
  position: "relative",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "flex-end",
  gap: "6px",
  minWidth: 0,
};

const reportMenuWrapStyle: CSSProperties = {
  position: "relative",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  flex: "0 0 auto",
};

const reportMenuButtonStyle: CSSProperties = {
  width: "24px",
  height: "30px",
  borderRadius: 0,
  border: "none",
  background: "transparent",
  color: "var(--historietas-text-primary, #FFFFFF)",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: "24px",
  fontWeight: 950,
  letterSpacing: 0,
  lineHeight: 1,
  fontFamily: "inherit",
  cursor: "pointer",
  padding: 0,
  position: "relative",
  zIndex: 2,
  boxShadow: "none",
  outline: "none",
  WebkitTapHighlightColor: "transparent",
};

const adminFiltersSheetOverlayStyle: CSSProperties = {
  position: "fixed",
  left: 0,
  right: 0,
  top: 0,
  bottom: 0,
  height: "100dvh",
  zIndex: 9998,
  display: "flex",
  alignItems: "flex-end",
  justifyContent: "center",
  background: "rgba(0,0,0,0.68)",
  padding: 0,
  boxSizing: "border-box",
  overscrollBehavior: "none",
  touchAction: "none",
};

const adminFiltersSheetBackdropStyle: CSSProperties = {
  position: "absolute",
  inset: 0,
  border: "none",
  background: "transparent",
  cursor: "pointer",
  padding: 0,
};

const adminFiltersSheetStyle: CSSProperties = {
  position: "fixed",
  left: "50%",
  bottom: 0,
  transform: "translateX(-50%)",
  zIndex: 9999,
  width: "min(820px, 100%)",
  maxHeight: "calc(100dvh - 116px)",
  display: "grid",
  gap: "0",
  padding: "8px 0 calc(104px + env(safe-area-inset-bottom))",
  borderRadius: "24px 24px 0 0",
  background: "var(--historietas-admin-comunidade-bg-page, #070212)",
  border: "none",
  overflowY: "auto",
  overflowX: "hidden",
  overscrollBehavior: "none",
  boxShadow: "0 -18px 50px rgba(0,0,0,0.38)",
  boxSizing: "border-box",
  touchAction: "none",
};

const adminFiltersSheetHandleStyle: CSSProperties = {
  justifySelf: "center",
  width: "72px",
  height: "5px",
  borderRadius: "999px",
  background: "rgba(244,244,245,0.62)",
  margin: "0 auto 14px",
};

const adminFiltersSheetTitleStyle: CSSProperties = {
  display: "block",
  margin: "0 0 12px",
  padding: 0,
  color: "#FFFFFF",
  fontSize: "21px",
  lineHeight: 1.1,
  fontWeight: 950,
  textAlign: "center",
  letterSpacing: "-0.04em",
  ...safeTextStyle,
};

const adminFiltersSheetSectionLabelStyle: CSSProperties = {
  display: "block",
  padding: "11px 30px 5px",
  color: "rgba(244,244,245,0.56)",
  fontSize: "11px",
  lineHeight: 1,
  fontWeight: 950,
  textTransform: "uppercase",
  letterSpacing: "0.08em",
  ...safeTextStyle,
};

const adminFiltersSheetOptionStyle: CSSProperties = {
  appearance: "none",
  WebkitAppearance: "none",
  width: "100%",
  minHeight: "44px",
  border: "none",
  background: "transparent",
  color: "#FFFFFF",
  fontSize: "18px",
  lineHeight: 1,
  fontWeight: 650,
  letterSpacing: "-0.035em",
  cursor: "pointer",
  fontFamily: "inherit",
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  gap: "16px",
  padding: "0 30px",
  textAlign: "left",
  boxSizing: "border-box",
  boxShadow: "none",
  ...safeTextStyle,
};

const adminFiltersSheetOptionActiveStyle: CSSProperties = {
  ...adminFiltersSheetOptionStyle,
  fontWeight: 900,
  background: "transparent",
};

const adminFiltersSheetRadioStyle: CSSProperties = {
  width: "23px",
  height: "23px",
  borderRadius: "999px",
  border: "2.5px solid rgba(161,161,170,0.72)",
  background: "transparent",
  color: "transparent",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  flex: "0 0 auto",
  boxSizing: "border-box",
  fontSize: "15px",
  lineHeight: 1,
  fontWeight: 900,
};

const adminFiltersSheetRadioActiveStyle: CSSProperties = {
  ...adminFiltersSheetRadioStyle,
  border: "2px solid #FFFFFF",
  background: "#FFFFFF",
  color: "#111111",
};

const adminFiltersSheetClearButtonStyle: CSSProperties = {
  width: "calc(100% - 60px)",
  justifySelf: "center",
  minHeight: "46px",
  marginTop: "12px",
  borderRadius: "999px",
  border: "1px solid rgba(255,255,255,0.08)",
  background: "transparent",
  color: "#FFFFFF",
  fontFamily: "inherit",
  fontSize: "15px",
  fontWeight: 950,
  cursor: "pointer",
  textAlign: "center",
  ...safeTextStyle,
};

const reportMenuOverlayStyle: CSSProperties = {
  position: "fixed",
  left: 0,
  right: 0,
  top: 0,
  bottom: 0,
  height: "100dvh",
  zIndex: 9998,
  display: "flex",
  alignItems: "flex-end",
  justifyContent: "center",
  background: "rgba(0,0,0,0.68)",
  padding: 0,
  boxSizing: "border-box",
  overscrollBehavior: "none",
  touchAction: "none",
};

const reportMenuBackdropStyle: CSSProperties = {
  position: "absolute",
  inset: 0,
  border: "none",
  background: "transparent",
  cursor: "pointer",
  padding: 0,
};

const reportMenuStyle: CSSProperties = {
  position: "fixed",
  left: "50%",
  bottom: 0,
  transform: "translateX(-50%)",
  zIndex: 9999,
  width: "min(820px, 100%)",
  maxHeight: "calc(100dvh - 190px)",
  display: "grid",
  gap: "0",
  padding: "8px 0 calc(18px + env(safe-area-inset-bottom))",
  borderRadius: "24px 24px 0 0",
  background: "var(--historietas-admin-comunidade-bg-page, #070212)",
  border: "none",
  overflowY: "auto",
  overflowX: "hidden",
  overscrollBehavior: "none",
  boxShadow: "0 -18px 50px rgba(0,0,0,0.38)",
  boxSizing: "border-box",
  touchAction: "none",
};

const reportMenuHandleStyle: CSSProperties = {
  justifySelf: "center",
  width: "72px",
  height: "5px",
  borderRadius: "999px",
  background: "rgba(244,244,245,0.62)",
  margin: "0 auto 14px",
};

const reportMenuTitleStyle: CSSProperties = {
  display: "block",
  margin: "0 0 12px",
  padding: 0,
  color: "#FFFFFF",
  fontSize: "21px",
  lineHeight: 1.1,
  fontWeight: 950,
  textAlign: "center",
  letterSpacing: "-0.04em",
  ...safeTextStyle,
};

const reportMenuItemStyle: CSSProperties = {
  appearance: "none",
  WebkitAppearance: "none",
  width: "100%",
  minHeight: "44px",
  border: "none",
  background: "transparent",
  color: "#FFFFFF",
  fontSize: "18px",
  lineHeight: 1,
  fontWeight: 650,
  letterSpacing: "-0.035em",
  cursor: "pointer",
  fontFamily: "inherit",
  display: "flex",
  alignItems: "center",
  justifyContent: "flex-start",
  gap: "16px",
  padding: "0 30px",
  textAlign: "left",
  boxSizing: "border-box",
  boxShadow: "none",
  ...safeTextStyle,
};

const reportMenuItemLinkStyle: CSSProperties = {
  ...reportMenuItemStyle,
  textDecoration: "none",
};

const reportMenuItemActiveStyle: CSSProperties = {
  ...reportMenuItemStyle,
  color: "rgba(244,244,245,0.58)",
  cursor: "default",
  fontWeight: 900,
};

const reportMenuDangerItemStyle: CSSProperties = {
  ...reportMenuItemStyle,
  color: "var(--historietas-admin-comunidade-danger-menu, #FB7185)",
};

const reportMenuDividerStyle: CSSProperties = {
  display: "none",
  height: 0,
  margin: 0,
  background: "transparent",
};

const reportBodyStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "minmax(0, 1fr)",
  gap: 0,
  minWidth: 0,
  paddingTop: "8px",
  borderTop: "none",
};

const contentBoxStyle: CSSProperties = {
  display: "grid",
  gap: "9px",
  padding: "13px 0",
  borderRadius: 0,
  background: "transparent",
  border: "none",
  borderBottom: "none",
  boxShadow: "none",
  minWidth: 0,
  alignContent: "start",
};

const sectionHeaderLineStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  gap: "8px",
  flexWrap: "wrap",
  minWidth: 0,
};

const sectionHintStyle: CSSProperties = {
  color: "var(--historietas-text-muted, #A1A1AA)",
  fontSize: "9.8px",
  fontWeight: 850,
  ...safeTextStyle,
};

const boxLabelStyle: CSSProperties = {
  color: "#FFFFFF",
  fontSize: "9.8px",
  fontWeight: 950,
  letterSpacing: "0.105em",
  textTransform: "uppercase",
};

const adminObservationLabelStyle: CSSProperties = {
  ...boxLabelStyle,
  color: "var(--historietas-text-secondary, #D4D4D8)",
};

const reportedTextStyle: CSSProperties = {
  margin: 0,
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "13.2px",
  lineHeight: 1.48,
  fontWeight: 800,
  maxHeight: "118px",
  overflowY: "auto",
  paddingRight: "2px",
  ...safeTextStyle,
};

const reportedTextCompactStyle: CSSProperties = {
  ...reportedTextStyle,
  maxHeight: "none",
  overflowY: "visible",
  color: "var(--historietas-text-secondary, #D4D4D8)",
};

const metaGridStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(130px, 1fr))",
  gap: "4px 12px",
  minWidth: 0,
};

const metaItemStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "10.5px",
  lineHeight: 1.35,
  fontWeight: 750,
  ...safeTextStyle,
};

const spoilerMetaItemStyle: CSSProperties = {
  ...metaItemStyle,
  color: "var(--historietas-admin-comunidade-accent-soft, #FDBA74)",
};

const reasonGridStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))",
  gap: "4px 12px",
  minWidth: 0,
};

const reasonItemStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "10.5px",
  lineHeight: 1.35,
  fontWeight: 800,
  ...safeTextStyle,
};

const detailTextStyle: CSSProperties = {
  margin: 0,
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "12.5px",
  lineHeight: 1.45,
  fontWeight: 750,
  maxHeight: "92px",
  overflowY: "auto",
  paddingRight: "2px",
  ...safeTextStyle,
};

const mutedTextStyle: CSSProperties = {
  ...detailTextStyle,
  color: "var(--historietas-text-muted, #A1A1AA)",
};

const adminNoteStyle: CSSProperties = {
  display: "grid",
  gap: "7px",
  minWidth: 0,
  gridColumn: "1 / -1",
  padding: "13px 0 0",
  borderTop: "none",
  background: "transparent",
  boxShadow: "none",
};

const textareaStyle: CSSProperties = {
  width: "100%",
  border: "none",
  borderRadius: 0,
  outline: "none",
  background: "transparent",
  color: "var(--historietas-input-text, var(--historietas-text-primary, #FFFFFF))",
  padding: "8px 0 0",
  boxSizing: "border-box",
  fontSize: "12.5px",
  lineHeight: 1.4,
  fontWeight: 800,
  resize: "vertical",
  minHeight: "46px",
  cursor: "text",
  caretColor: "#FFFFFF",
  boxShadow: "none",
};

const analysisMetaStyle: CSSProperties = {
  color: "var(--historietas-text-muted, #A1A1AA)",
  fontSize: "10.5px",
  fontWeight: 800,
  textAlign: "right",
  ...safeTextStyle,
};