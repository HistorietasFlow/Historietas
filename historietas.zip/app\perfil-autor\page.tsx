"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { supabase } from "../../lib/supabase/client";
import { criarSlugBase, idObraSupabaseValido, normalizarTexto } from "../../lib/utils";
import {
  historietasThemeCss,
  useHistorietasTheme,
} from "../../lib/historietasTheme";
import { useNotificacoes } from "../../components/NotificacoesProvider";
import { useHistorietasLanguage } from "../../components/HistorietasLanguageProvider";
import DenunciaModal, {
  type TipoAlvoDenuncia,
} from "../../components/DenunciaModal";
import type { HistorietasLanguage } from "../../lib/i18n";
import {
  bloquearUsuario,
  cancelarSolicitacaoSeguidor,
  carregarEstadoBloqueioPerfil,
  carregarEstadoRelacionamentoPerfil,
  carregarPermissoesAbasPerfil,
  carregarPreferenciasPrivacidade,
  deixarDeSeguirUsuario,
  desbloquearUsuario,
  preferenciasPrivacidadePadrao,
  solicitarOuSeguirUsuario,
  type EstadoBloqueioPerfil,
  type EstadoRelacionamentoPerfil,
  type PermissoesAbasPerfil,
  type PreferenciasPrivacidadeHistorietas,
} from "../../lib/historietasPrivacy";
import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import type { ChangeEvent, CSSProperties } from "react";

type CapituloLocal = {
  id: string;
  titulo: string;
  texto: string;
  curtiu: boolean;
  salvo: boolean;
  comentario: string;
  criadoEm: string;
  lido: boolean;
  lidoEm: string;
};

type ArquivoObraLocal = {
  nome: string;
  tipo: string;
  tamanho: number;
  conteudo: string;
  categoria: "texto" | "documento" | "imagem" | "outro";
  criadoEm: string;
};

type ObraLocal = {
  id: string;
  titulo: string;
  autorId: string;
  autor: string;
  genero: string;
  formato: string;
  classificacaoIndicativa: string;
  sinopse: string;
  tags: string[];
  capa: string;
  capaNome: string;
  arquivoObra?: ArquivoObraLocal | null;
  publicado: boolean;
  capitulos: CapituloLocal[];
  criadaEm: string;
  ultimoCapituloLidoId: string;
  ultimaLeituraEm: string;
  progressoLeitura: number;
  visualizacoes: number;
  slug: string;
  link: string;
};

type CapituloSalvo = Partial<CapituloLocal> & Record<string, unknown>;

type ObraSalva = Partial<ObraLocal> & {
  capitulos?: CapituloSalvo[];
} & Record<string, unknown>;

type AutorPerfil = {
  autorId: string;
  nome: string;
  obras: ObraLocal[];
  totalCapitulos: number;
  totalCurtidas: number;
  totalComentarios: number;
  totalPublicadas: number;
};

type PerfilUsuarioRemoto = {
  userId: string;
  nome: string;
  username: string;
  avatar: string;
  bio: string;
  sobreBio: string;
  criadoEm: string;
};

type AbaPerfilAutor =
  | "obras"
  | "diario"
  | "comunidade"
  | "sobre"
  | "biblioteca";

const PERMISSOES_ABAS_PERFIL_PADRAO: PermissoesAbasPerfil = {
  obras: true,
  sobre: true,
  diario: true,
  comunidade: true,
  biblioteca: false,
  atividades: false,
};

const PERMISSOES_ABAS_PERFIL_PROPRIO: PermissoesAbasPerfil = {
  obras: true,
  sobre: true,
  diario: true,
  comunidade: true,
  biblioteca: true,
  atividades: true,
};

type AbaBibliotecaPerfil =
  | "tudo"
  | "quero-ler"
  | "lendo-agora"
  | "favoritas"
  | "concluidas"
  | "salvos"
  | "historico";

const STORAGE_KEY = "historietas-obras";
const AUTHOR_FOLLOW_STORAGE_KEY = "historietas-autores-seguidos";
const LIBRARY_FOLLOW_STORAGE_KEY = "historietas-obras-seguidas";
const FAVORITES_STORAGE_KEY = "historietas-obras-favoritas";
const COMPLETED_STORAGE_KEY = "historietas-obras-concluidas";
const AUTHOR_PROFILE_STORAGE_KEY = "historietas-perfis-autores";
const AUTHOR_RATINGS_STORAGE_KEY = "historietas-autores-avaliacoes";
const TOP_FIVE_STORAGE_KEY = "historietas-top-5-obras";
const TOP_FIVE_LIKES_STORAGE_KEY = "historietas-top-5-curtidas";
const TOP_FIVE_MAXIMO = 5;
const AVATAR_MAX_SIZE = 1 * 1024 * 1024;
const AVATAR_STORAGE_BUCKET = "avatars";
const BIO_MAX_LENGTH = 90;
const SOBRE_BIO_MAX_LENGTH = 600;
const NOTAS_AVALIACAO_AUTOR = [1, 2, 3, 4, 5] as const;
type PerfilAutorTranslationEntry = {
  en: string;
  es: string;
};

const PERFIL_AUTOR_UI_TRANSLATIONS: Record<
  string,
  PerfilAutorTranslationEntry
> = {
  "DESCUBRA NOVAS HISTÓRIAS": {
    "en": "DISCOVER NEW STORIES",
    "es": "DESCUBRE NUEVAS HISTORIAS"
  },
  "Catálogo em formação": {
    "en": "Catalog in progress",
    "es": "Catálogo en formación"
  },
  "Leitores": {
    "en": "Readers",
    "es": "Lectores"
  },
  "O HISTORIETAS está formando seu catálogo inicial. Explore obras publicadas, acompanhe autores e publique sua história quando quiser.": {
    "en": "HISTORIETAS is building its first catalog. Explore published works, follow authors, and publish your story whenever you are ready.",
    "es": "HISTORIETAS está formando su catálogo inicial. Explora obras publicadas, sigue a autores y publica tu historia cuando quieras."
  },
  "Catálogo aberto": {
    "en": "Open catalog",
    "es": "Catálogo abierto"
  },
  "Leitura online": {
    "en": "Online reading",
    "es": "Lectura en línea"
  },
  "histórias": {
    "en": "stories",
    "es": "historias"
  },
  "Ficção": {
    "en": "Fiction",
    "es": "Ficción"
  },
  "Não informado": {
    "en": "Not provided",
    "es": "No informado"
  },
  "Não informada": {
    "en": "Not provided",
    "es": "No informada"
  },
  "Nenhuma sinopse informada.": {
    "en": "No synopsis provided.",
    "es": "No se proporcionó una sinopsis."
  },
  "Em andamento": {
    "en": "Ongoing",
    "es": "En curso"
  },
  "Publicado": {
    "en": "Published",
    "es": "Publicado"
  },
  "História": {
    "en": "Story",
    "es": "Historia"
  },
  "Autor não informado": {
    "en": "Author not provided",
    "es": "Autor no informado"
  },
  "Capítulo sem título": {
    "en": "Untitled chapter",
    "es": "Capítulo sin título"
  },
  "Obra sem título": {
    "en": "Untitled work",
    "es": "Obra sin título"
  },
  "sem tags": {
    "en": "no tags",
    "es": "sin etiquetas"
  },
  "Arquivo da obra": {
    "en": "Work file",
    "es": "Archivo de la obra"
  },
  "Carregando": {
    "en": "Loading",
    "es": "Cargando"
  },
  "Carregando página inicial": {
    "en": "Loading home page",
    "es": "Cargando la página de inicio"
  },
  "Buscar...": {
    "en": "Search...",
    "es": "Buscar..."
  },
  "Configurações": {
    "en": "Settings",
    "es": "Configuración"
  },
  "Notificações": {
    "en": "Notifications",
    "es": "Notificaciones"
  },
  "Abrir busca": {
    "en": "Open search",
    "es": "Abrir búsqueda"
  },
  "Fechar busca": {
    "en": "Close search",
    "es": "Cerrar búsqueda"
  },
  "Navegação principal": {
    "en": "Main navigation",
    "es": "Navegación principal"
  },
  "Início": {
    "en": "Home",
    "es": "Inicio"
  },
  "Explorar": {
    "en": "Explore",
    "es": "Explorar"
  },
  "Em Alta": {
    "en": "Trending",
    "es": "Tendencias"
  },
  "Minhas Obras": {
    "en": "My Works",
    "es": "Mis obras"
  },
  "Biblioteca": {
    "en": "Library",
    "es": "Biblioteca"
  },
  "Seguindo": {
    "en": "Following",
    "es": "Siguiendo"
  },
  "Painel do Autor": {
    "en": "Author Dashboard",
    "es": "Panel del Autor"
  },
  "Buscar obras, autor, gênero...": {
    "en": "Search works, authors, genres...",
    "es": "Buscar obras, autores, géneros..."
  },
  "Publicar obra": {
    "en": "Publish work",
    "es": "Publicar obra"
  },
  "Explorar obras": {
    "en": "Explore works",
    "es": "Explorar obras"
  },
  "Ver obra": {
    "en": "View work",
    "es": "Ver obra"
  },
  "Salvar": {
    "en": "Save",
    "es": "Guardar"
  },
  "Salvo": {
    "en": "Saved",
    "es": "Guardado"
  },
  "Obras em destaque": {
    "en": "Featured works",
    "es": "Obras destacadas"
  },
  "Atalhos principais": {
    "en": "Main shortcuts",
    "es": "Accesos principales"
  },
  "Em breve": {
    "en": "Coming soon",
    "es": "Próximamente"
  },
  "Continuar lendo": {
    "en": "Continue reading",
    "es": "Continuar leyendo"
  },
  "Continue do ponto em que parou.": {
    "en": "Pick up where you left off.",
    "es": "Continúa desde donde lo dejaste."
  },
  "Minha lista": {
    "en": "My list",
    "es": "Mi lista"
  },
  "Autores para conhecer": {
    "en": "Authors to discover",
    "es": "Autores por descubrir"
  },
  "Perfis que dão vida ao catálogo.": {
    "en": "Profiles that bring the catalog to life.",
    "es": "Perfiles que dan vida al catálogo."
  },
  "Recomendações para você": {
    "en": "Recommendations for you",
    "es": "Recomendaciones para ti"
  },
  "Obras parecidas com o que você lê ou salvou.": {
    "en": "Works similar to what you read or saved.",
    "es": "Obras parecidas a las que lees o guardaste."
  },
  "Sugestões para começar sua próxima leitura.": {
    "en": "Suggestions for your next read.",
    "es": "Sugerencias para comenzar tu próxima lectura."
  },
  "Publicações recentes": {
    "en": "Recent publications",
    "es": "Publicaciones recientes"
  },
  "obra publicada": {
    "en": "published work",
    "es": "obra publicada"
  },
  "obras publicadas": {
    "en": "published works",
    "es": "obras publicadas"
  },
  "Novos capítulos": {
    "en": "New chapters",
    "es": "Nuevos capítulos"
  },
  "Capítulos novos para acompanhar sem perder o ritmo.": {
    "en": "New chapters to follow without missing a beat.",
    "es": "Nuevos capítulos para seguir sin perder el ritmo."
  },
  "Mais curtidas": {
    "en": "Most liked",
    "es": "Más gustadas"
  },
  "Na lista da comunidade nesta fase.": {
    "en": "Popular with the community right now.",
    "es": "Populares en la comunidad en este momento."
  },
  "Mais comentadas": {
    "en": "Most commented",
    "es": "Más comentadas"
  },
  "Histórias que estão puxando conversa.": {
    "en": "Stories sparking conversations.",
    "es": "Historias que están generando conversación."
  },
  "Extras e arquivos": {
    "en": "Extras and files",
    "es": "Extras y archivos"
  },
  "Histórias com material extra para abrir depois.": {
    "en": "Stories with extra material to open later.",
    "es": "Historias con material extra para abrir después."
  },
  "Para ler agora": {
    "en": "Read now",
    "es": "Para leer ahora"
  },
  "Obras curtas para entrar rápido no universo.": {
    "en": "Short works that pull you into the story quickly.",
    "es": "Obras cortas para entrar rápidamente en el universo."
  },
  "Catálogo": {
    "en": "Catalog",
    "es": "Catálogo"
  },
  "Obras reais publicadas na plataforma.": {
    "en": "Real works published on the platform.",
    "es": "Obras reales publicadas en la plataforma."
  },
  "Fantasia e poderes": {
    "en": "Fantasy and powers",
    "es": "Fantasía y poderes"
  },
  "Mundos, poderes e mistérios para explorar.": {
    "en": "Worlds, powers, and mysteries to explore.",
    "es": "Mundos, poderes y misterios por explorar."
  },
  "Terror e suspense": {
    "en": "Horror and suspense",
    "es": "Terror y suspenso"
  },
  "Atmosfera sombria, tensão e mistério.": {
    "en": "Dark atmosphere, tension, and mystery.",
    "es": "Atmósfera oscura, tensión y misterio."
  },
  "Romance e drama": {
    "en": "Romance and drama",
    "es": "Romance y drama"
  },
  "Relações intensas e escolhas difíceis.": {
    "en": "Intense relationships and difficult choices.",
    "es": "Relaciones intensas y decisiones difíciles."
  },
  "Ação e rivalidades": {
    "en": "Action and rivalries",
    "es": "Acción y rivalidades"
  },
  "Conflitos, disputas e personagens intensos.": {
    "en": "Conflicts, rivalries, and intense characters.",
    "es": "Conflictos, rivalidades y personajes intensos."
  },
  "Sci-fi e códigos": {
    "en": "Sci-fi and code",
    "es": "Ciencia ficción y código"
  },
  "Futuro, sistemas e universos alternativos.": {
    "en": "The future, systems, and alternate universes.",
    "es": "Futuro, sistemas y universos alternativos."
  },
  "Em breve na Historietas": {
    "en": "Coming soon to Historietas",
    "es": "Próximamente en Historietas"
  },
  "Obras chegando ao catálogo em breve.": {
    "en": "Works coming to the catalog soon.",
    "es": "Obras que llegarán pronto al catálogo."
  },
  "Obras reais disponíveis para leitura.": {
    "en": "Real works available to read.",
    "es": "Obras reales disponibles para leer."
  },
  "Continuar": {
    "en": "Continue",
    "es": "Continuar"
  },
  "Ler agora": {
    "en": "Read now",
    "es": "Leer ahora"
  },
  "Leitura": {
    "en": "Reading",
    "es": "Lectura"
  },
  "Por": {
    "en": "By",
    "es": "Por"
  },
  "Novo cap": {
    "en": "New ch.",
    "es": "Cap. nuevo"
  },
  "% lido": {
    "en": "% read",
    "es": "% leído"
  },
  "Ver perfil": {
    "en": "View profile",
    "es": "Ver perfil"
  },
  "Autor ainda sem avaliações": {
    "en": "Author has no ratings yet",
    "es": "El autor aún no tiene valoraciones"
  },
  "avaliação": {
    "en": "rating",
    "es": "valoración"
  },
  "avaliações": {
    "en": "ratings",
    "es": "valoraciones"
  },
  "Ver detalhes": {
    "en": "View details",
    "es": "Ver detalles"
  },
  "Nenhuma obra cadastrada": {
    "en": "No works available",
    "es": "No hay obras registradas"
  },
  "Nenhuma obra encontrada": {
    "en": "No works found",
    "es": "No se encontraron obras"
  },
  "Rolar carrossel para a esquerda": {
    "en": "Scroll carousel left",
    "es": "Desplazar el carrusel a la izquierda"
  },
  "Rolar carrossel para a direita": {
    "en": "Scroll carousel right",
    "es": "Desplazar el carrusel a la derecha"
  },
  "Entre na sua conta para salvar obras na sua lista.": {
    "en": "Sign in to save works to your list.",
    "es": "Inicia sesión para guardar obras en tu lista."
  },
  "A obra ficou salva no aparelho, mas não sincronizou agora.": {
    "en": "The work was saved on this device, but it could not sync right now.",
    "es": "La obra se guardó en este dispositivo, pero no pudo sincronizarse ahora."
  },
  "Carregando Explorar": {
    "en": "Loading Explore",
    "es": "Cargando Explorar"
  },
  "Abrir funções do Explorar": {
    "en": "Open Explore options",
    "es": "Abrir opciones de Explorar"
  },
  "Buscar autores...": {
    "en": "Search authors...",
    "es": "Buscar autores..."
  },
  "Buscar histórias...": {
    "en": "Search stories...",
    "es": "Buscar historias..."
  },
  "Categorias": {
    "en": "Categories",
    "es": "Categorías"
  },
  "Tudo": {
    "en": "All",
    "es": "Todo"
  },
  "Autores": {
    "en": "Authors",
    "es": "Autores"
  },
  "EXPLORAR": {
    "en": "EXPLORE",
    "es": "EXPLORAR"
  },
  "Mostrar": {
    "en": "Show",
    "es": "Mostrar"
  },
  "Todas": {
    "en": "All",
    "es": "Todas"
  },
  "Lendo agora": {
    "en": "Reading now",
    "es": "Leyendo ahora"
  },
  "Na lista": {
    "en": "In list",
    "es": "En la lista"
  },
  "Concluídas": {
    "en": "Completed",
    "es": "Completadas"
  },
  "Sem leitura": {
    "en": "Not started",
    "es": "Sin comenzar"
  },
  "Ordenar": {
    "en": "Sort",
    "es": "Ordenar"
  },
  "Relevância": {
    "en": "Relevance",
    "es": "Relevancia"
  },
  "Mais recentes": {
    "en": "Most recent",
    "es": "Más recientes"
  },
  "Limpar filtros": {
    "en": "Clear filters",
    "es": "Limpiar filtros"
  },
  "Entre na sua conta para usar filtros pessoais.": {
    "en": "Sign in to use personal filters.",
    "es": "Inicia sesión para usar filtros personales."
  },
  "Autores em destaque": {
    "en": "Featured authors",
    "es": "Autores destacados"
  },
  "Mais bem avaliados": {
    "en": "Top rated",
    "es": "Mejor valorados"
  },
  "Resultados da busca": {
    "en": "Search results",
    "es": "Resultados de búsqueda"
  },
  "Autores encontrados": {
    "en": "Authors found",
    "es": "Autores encontrados"
  },
  "Nenhum autor encontrado": {
    "en": "No author found",
    "es": "No se encontró ningún autor"
  },
  "PUBLIQUE SUA HISTÓRIA": {
    "en": "PUBLISH YOUR STORY",
    "es": "PUBLICA TU HISTORIA"
  },
  "Rascunho": {
    "en": "Draft",
    "es": "Borrador"
  },
  "Ação do começo ao fim": {
    "en": "Nonstop action",
    "es": "Acción de principio a fin"
  },
  "Aventuras sem limites": {
    "en": "Limitless adventures",
    "es": "Aventuras sin límites"
  },
  "Para rir agora": {
    "en": "A good laugh",
    "es": "Para reír ahora"
  },
  "Histórias que deixam marcas": {
    "en": "Stories that leave a mark",
    "es": "Historias que dejan huella"
  },
  "Mundos além da imaginação": {
    "en": "Worlds beyond imagination",
    "es": "Mundos más allá de la imaginación"
  },
  "Além do que é possível": {
    "en": "Beyond what is possible",
    "es": "Más allá de lo posible"
  },
  "Mistérios para desvendar": {
    "en": "Mysteries to uncover",
    "es": "Misterios por descubrir"
  },
  "Amores que deixam marcas": {
    "en": "Love stories that leave a mark",
    "es": "Amores que dejan huella"
  },
  "Tensão até a última página": {
    "en": "Tension to the final page",
    "es": "Tensión hasta la última página"
  },
  "Histórias para perder o sono": {
    "en": "Stories that will keep you awake",
    "es": "Historias para perder el sueño"
  },
  "Entre este mundo e o outro": {
    "en": "Between this world and the next",
    "es": "Entre este mundo y el otro"
  },
  "Viagens por outros tempos": {
    "en": "Journeys through other times",
    "es": "Viajes por otros tiempos"
  },
  "Vidas que merecem ser contadas": {
    "en": "Lives worth telling",
    "es": "Vidas que merecen ser contadas"
  },
  "Descobertas fora do comum": {
    "en": "Unusual discoveries",
    "es": "Descubrimientos fuera de lo común"
  },
  "Histórias para descobrir": {
    "en": "Stories to discover",
    "es": "Historias por descubrir"
  },
  "Autores que aceleram o coração": {
    "en": "Authors who make your heart race",
    "es": "Autores que aceleran el corazón"
  },
  "Autores de grandes jornadas": {
    "en": "Authors of great journeys",
    "es": "Autores de grandes viajes"
  },
  "Autores para arrancar risadas": {
    "en": "Authors who make you laugh",
    "es": "Autores que provocan risas"
  },
  "Autores que tocam fundo": {
    "en": "Authors who move you deeply",
    "es": "Autores que llegan al corazón"
  },
  "Criadores de mundos impossíveis": {
    "en": "Creators of impossible worlds",
    "es": "Creadores de mundos imposibles"
  },
  "Autores que enxergam além": {
    "en": "Authors who see beyond",
    "es": "Autores que ven más allá"
  },
  "Mestres dos enigmas": {
    "en": "Masters of mysteries",
    "es": "Maestros de los enigmas"
  },
  "Autores que escrevem sentimentos": {
    "en": "Authors who write emotions",
    "es": "Autores que escriben sentimientos"
  },
  "Mestres da tensão": {
    "en": "Masters of tension",
    "es": "Maestros de la tensión"
  },
  "Autores que dominam o medo": {
    "en": "Authors who master fear",
    "es": "Autores que dominan el miedo"
  },
  "Vozes do desconhecido": {
    "en": "Voices of the unknown",
    "es": "Voces de lo desconocido"
  },
  "Autores que revivem o passado": {
    "en": "Authors who bring the past to life",
    "es": "Autores que reviven el pasado"
  },
  "Autores de vidas reais": {
    "en": "Authors of real lives",
    "es": "Autores de vidas reales"
  },
  "Novas vozes para descobrir": {
    "en": "New voices to discover",
    "es": "Nuevas voces por descubrir"
  },
  "Autores para descobrir": {
    "en": "Authors to discover",
    "es": "Autores por descubrir"
  },
  "Geral": {
    "en": "General",
    "es": "General"
  },
  "Divulgação": {
    "en": "Promotion",
    "es": "Promoción"
  },
  "Recomendações": {
    "en": "Recommendations",
    "es": "Recomendaciones"
  },
  "Discussão": {
    "en": "Discussion",
    "es": "Discusión"
  },
  "Dúvidas": {
    "en": "Questions",
    "es": "Dudas"
  },
  "Teoria": {
    "en": "Theory",
    "es": "Teoría"
  },
  "Enquete": {
    "en": "Poll",
    "es": "Encuesta"
  },
  "Pedido de indicação": {
    "en": "Recommendation request",
    "es": "Solicitud de recomendación"
  },
  "Review": {
    "en": "Review",
    "es": "Reseña"
  },
  "Aviso de capítulo": {
    "en": "Chapter update",
    "es": "Aviso de capítulo"
  },
  "Dúvida": {
    "en": "Question",
    "es": "Duda"
  },
  "Recentes": {
    "en": "Recent",
    "es": "Recientes"
  },
  "Em alta": {
    "en": "Trending",
    "es": "Tendencias"
  },
  "Todos": {
    "en": "All",
    "es": "Todos"
  },
  "Primeiros leitores": {
    "en": "First readers",
    "es": "Primeros lectores"
  },
  "Que tipo de história você quer encontrar no HISTORIETAS?": {
    "en": "What kind of story do you want to find on HISTORIETAS?",
    "es": "¿Qué tipo de historia quieres encontrar en HISTORIETAS?"
  },
  "Enquete: qual opção você escolheria?\nOpção 1:\nOpção 2:": {
    "en": "Poll: which option would you choose?\nOption 1:\nOption 2:",
    "es": "Encuesta: ¿qué opción elegirías?\nOpción 1:\nOpción 2:"
  },
  "Usuário": {
    "en": "User",
    "es": "Usuario"
  },
  "Agora": {
    "en": "Now",
    "es": "Ahora"
  },
  "agora": {
    "en": "now",
    "es": "ahora"
  },
  "Enquete da comunidade": {
    "en": "Community poll",
    "es": "Encuesta de la comunidad"
  },
  "Responder": {
    "en": "Reply",
    "es": "Responder"
  },
  "Removendo...": {
    "en": "Removing...",
    "es": "Eliminando..."
  },
  "Remover": {
    "en": "Remove",
    "es": "Eliminar"
  },
  "Enviando...": {
    "en": "Sending...",
    "es": "Enviando..."
  },
  "Denunciar": {
    "en": "Report",
    "es": "Denunciar"
  },
  "Denunciar publicação": {
    "en": "Report post",
    "es": "Denunciar publicación"
  },
  "Denunciar obra": {
    "en": "Report work",
    "es": "Denunciar obra"
  },
  "Não foi possível identificar este conteúdo.": {
    "en": "This content could not be identified.",
    "es": "No se pudo identificar este contenido."
  },
  "Remover curtida do comentário": {
    "en": "Unlike comment",
    "es": "Quitar Me gusta del comentario"
  },
  "Curtir comentário": {
    "en": "Like comment",
    "es": "Me gusta en el comentario"
  },
  "Comentários": {
    "en": "Comments",
    "es": "Comentarios"
  },
  "Fechar comentários": {
    "en": "Close comments",
    "es": "Cerrar comentarios"
  },
  "Recolher comentários": {
    "en": "Collapse comments",
    "es": "Contraer comentarios"
  },
  "Expandir comentários": {
    "en": "Expand comments",
    "es": "Expandir comentarios"
  },
  "Ordenar comentários": {
    "en": "Sort comments",
    "es": "Ordenar comentarios"
  },
  "Relevantes": {
    "en": "Relevant",
    "es": "Relevantes"
  },
  "Ocultar respostas": {
    "en": "Hide replies",
    "es": "Ocultar respuestas"
  },
  "Sem comentários ainda": {
    "en": "No comments yet",
    "es": "Aún no hay comentarios"
  },
  "Adicionar comentário...": {
    "en": "Add a comment...",
    "es": "Añadir un comentario..."
  },
  "Entre para comentar.": {
    "en": "Sign in to comment.",
    "es": "Inicia sesión para comentar."
  },
  "Adicionar menção": {
    "en": "Add mention",
    "es": "Añadir mención"
  },
  "Enviar comentário": {
    "en": "Send comment",
    "es": "Enviar comentario"
  },
  "Carregando Comunidade": {
    "en": "Loading Community",
    "es": "Cargando Comunidad"
  },
  "Comunidade": {
    "en": "Community",
    "es": "Comunidad"
  },
  "Você já votou nesta enquete.": {
    "en": "You have already voted in this poll.",
    "es": "Ya votaste en esta encuesta."
  },
  "Erro ao votar na enquete": {
    "en": "Error voting in the poll",
    "es": "Error al votar en la encuesta"
  },
  "Voto registrado.": {
    "en": "Vote recorded.",
    "es": "Voto registrado."
  },
  "Publicação removida dos salvos.": {
    "en": "Post removed from saved items.",
    "es": "Publicación eliminada de guardados."
  },
  "Publicação salva.": {
    "en": "Post saved.",
    "es": "Publicación guardada."
  },
  "Publicação salva neste navegador.": {
    "en": "Post saved in this browser.",
    "es": "Publicación guardada en este navegador."
  },
  "Compartilhamento da publicação aberto.": {
    "en": "Post sharing opened.",
    "es": "Se abrió la opción para compartir la publicación."
  },
  "Link da publicação copiado.": {
    "en": "Post link copied.",
    "es": "Enlace de la publicación copiado."
  },
  "Não consegui compartilhar nem copiar o link da publicação neste navegador.": {
    "en": "I couldn't share or copy the post link in this browser.",
    "es": "No se pudo compartir ni copiar el enlace de la publicación en este navegador."
  },
  "Erro ao carregar Comunidade": {
    "en": "Error loading Community",
    "es": "Error al cargar Comunidad"
  },
  "Entre na sua conta para participar da Comunidade.": {
    "en": "Sign in to participate in the Community.",
    "es": "Inicia sesión para participar en la Comunidad."
  },
  "Não foi possível atualizar este usuário agora.": {
    "en": "This user could not be updated right now.",
    "es": "No se pudo actualizar este usuario ahora."
  },
  "Escreva uma publicação com pelo menos 8 caracteres.": {
    "en": "Write a post with at least 8 characters.",
    "es": "Escribe una publicación de al menos 8 caracteres."
  },
  "Escreva a pergunta da enquete na primeira linha.": {
    "en": "Write the poll question on the first line.",
    "es": "Escribe la pregunta de la encuesta en la primera línea."
  },
  "A enquete precisa ter pelo menos 2 opções preenchidas.": {
    "en": "The poll must have at least 2 completed options.",
    "es": "La encuesta debe tener al menos 2 opciones completas."
  },
  "A enquete pode ter no máximo 4 opções.": {
    "en": "The poll can have at most 4 options.",
    "es": "La encuesta puede tener como máximo 4 opciones."
  },
  "Erro ao publicar": {
    "en": "Error publishing",
    "es": "Error al publicar"
  },
  "Erro ao publicar: o Supabase não retornou a publicação criada.": {
    "en": "Error publishing: Supabase did not return the created post.",
    "es": "Error al publicar: Supabase no devolvió la publicación creada."
  },
  "Publicação enviada para a Comunidade.": {
    "en": "Post published in the Community.",
    "es": "Publicación enviada a la Comunidad."
  },
  "Erro ao atualizar curtida": {
    "en": "Error updating like",
    "es": "Error al actualizar Me gusta"
  },
  "Erro ao curtir": {
    "en": "Error liking the post",
    "es": "Error al marcar Me gusta"
  },
  "Nova curtida na Comunidade": {
    "en": "New like in the Community",
    "es": "Nuevo Me gusta en la Comunidad"
  },
  "Curtida removida.": {
    "en": "Like removed.",
    "es": "Me gusta eliminado."
  },
  "Publicação curtida.": {
    "en": "Post liked.",
    "es": "Publicación marcada con Me gusta."
  },
  "Escreva um comentário antes de enviar.": {
    "en": "Write a comment before sending.",
    "es": "Escribe un comentario antes de enviarlo."
  },
  "O comentário respondido não foi encontrado.": {
    "en": "The comment you replied to was not found.",
    "es": "No se encontró el comentario respondido."
  },
  "Erro ao comentar": {
    "en": "Error commenting",
    "es": "Error al comentar"
  },
  "Erro ao comentar: o Supabase não retornou o comentário criado.": {
    "en": "Error commenting: Supabase did not return the created comment.",
    "es": "Error al comentar: Supabase no devolvió el comentario creado."
  },
  "Novo comentário na Comunidade": {
    "en": "New comment in the Community",
    "es": "Nuevo comentario en la Comunidad"
  },
  "Comentário enviado.": {
    "en": "Comment sent.",
    "es": "Comentario enviado."
  },
  "Conteúdo inadequado": {
    "en": "Inappropriate content",
    "es": "Contenido inapropiado"
  },
  "Você já denunciou este conteúdo.": {
    "en": "You have already reported this content.",
    "es": "Ya denunciaste este contenido."
  },
  "Erro ao denunciar": {
    "en": "Error reporting",
    "es": "Error al denunciar"
  },
  "Denúncia enviada para análise.": {
    "en": "Report sent for review.",
    "es": "Denuncia enviada para revisión."
  },
  "Você só pode remover seus próprios comentários.": {
    "en": "You can only remove your own comments.",
    "es": "Solo puedes eliminar tus propios comentarios."
  },
  "Remover este comentário?": {
    "en": "Remove this comment?",
    "es": "¿Eliminar este comentario?"
  },
  "Erro ao remover comentário": {
    "en": "Error removing comment",
    "es": "Error al eliminar el comentario"
  },
  "Comentário removido.": {
    "en": "Comment removed.",
    "es": "Comentario eliminado."
  },
  "Erro ao atualizar curtida do comentário": {
    "en": "Error updating the comment like",
    "es": "Error al actualizar el Me gusta del comentario"
  },
  "Erro ao curtir comentário": {
    "en": "Error liking the comment",
    "es": "Error al marcar Me gusta en el comentario"
  },
  "Nova curtida no seu comentário": {
    "en": "New like on your comment",
    "es": "Nuevo Me gusta en tu comentario"
  },
  "Curtida do comentário removida.": {
    "en": "Comment like removed.",
    "es": "Me gusta del comentario eliminado."
  },
  "Comentário curtido.": {
    "en": "Comment liked.",
    "es": "Comentario marcado con Me gusta."
  },
  "Apenas administradores podem fixar publicações.": {
    "en": "Only administrators can pin posts.",
    "es": "Solo los administradores pueden fijar publicaciones."
  },
  "Erro ao atualizar fixado": {
    "en": "Error updating pinned status",
    "es": "Error al actualizar el estado fijado"
  },
  "Publicação fixada no topo.": {
    "en": "Post pinned to the top.",
    "es": "Publicación fijada arriba."
  },
  "Publicação desafixada.": {
    "en": "Post unpinned.",
    "es": "Publicación desfijada."
  },
  "Remover esta publicação?": {
    "en": "Remove this post?",
    "es": "¿Eliminar esta publicación?"
  },
  "Erro ao remover publicação": {
    "en": "Error removing post",
    "es": "Error al eliminar la publicación"
  },
  "Publicação removida.": {
    "en": "Post removed.",
    "es": "Publicación eliminada."
  },
  "Abrir filtros, ordenação e ações da comunidade": {
    "en": "Open Community filters, sorting, and actions",
    "es": "Abrir filtros, orden y acciones de la comunidad"
  },
  "Buscar publicações ou usuários": {
    "en": "Search posts or users",
    "es": "Buscar publicaciones o usuarios"
  },
  "Filtros, ordenação e ações da comunidade": {
    "en": "Community filters, sorting, and actions",
    "es": "Filtros, orden y acciones de la comunidad"
  },
  "Fechar filtros e ações da comunidade": {
    "en": "Close Community filters and actions",
    "es": "Cerrar filtros y acciones de la comunidad"
  },
  "Filtrar e ordenar": {
    "en": "Filter and sort",
    "es": "Filtrar y ordenar"
  },
  "Ações": {
    "en": "Actions",
    "es": "Acciones"
  },
  "Publicar": {
    "en": "Post",
    "es": "Publicar"
  },
  "Pedir recomendações": {
    "en": "Ask for recommendations",
    "es": "Pedir recomendaciones"
  },
  "Posts salvos": {
    "en": "Saved posts",
    "es": "Publicaciones guardadas"
  },
  "Usuários encontrados": {
    "en": "Users found",
    "es": "Usuarios encontrados"
  },
  "Usuários": {
    "en": "Users",
    "es": "Usuarios"
  },
  "Buscando...": {
    "en": "Searching...",
    "es": "Buscando..."
  },
  "Digite pelo menos 2 caracteres para encontrar usuários.": {
    "en": "Enter at least 2 characters to find users.",
    "es": "Escribe al menos 2 caracteres para encontrar usuarios."
  },
  "Buscando usuários": {
    "en": "Searching for users",
    "es": "Buscando usuarios"
  },
  "Perfil da comunidade": {
    "en": "Community profile",
    "es": "Perfil de la comunidad"
  },
  "Você": {
    "en": "You",
    "es": "Tú"
  },
  "Seguir": {
    "en": "Follow",
    "es": "Seguir"
  },
  "Solicitado": {
    "en": "Requested",
    "es": "Solicitado"
  },
  "Cancelar solicitação": {
    "en": "Cancel request",
    "es": "Cancelar solicitud"
  },
  "Perfil privado": {
    "en": "Private profile",
    "es": "Perfil privado"
  },
  "Conteúdo privado": {
    "en": "Private content",
    "es": "Contenido privado"
  },
  "Siga este perfil para ver as seções que o autor escolheu manter privadas.": {
    "en": "Follow this profile to view the sections the author chose to keep private.",
    "es": "Sigue este perfil para ver las secciones que el autor decidió mantener privadas."
  },
  "Este autor manteve todas as seções do perfil privadas.": {
    "en": "This author has kept all profile sections private.",
    "es": "Este autor mantuvo privadas todas las secciones del perfil."
  },
  "Apenas seguidores aprovados podem ver o Diário, a comunidade, a biblioteca e as atividades deste perfil.": {
    "en": "Only approved followers can view this profile's Journal, community, library and activity.",
    "es": "Solo los seguidores aprobados pueden ver el Diario, la comunidad, la biblioteca y la actividad de este perfil."
  },
  "Nenhum usuário encontrado.": {
    "en": "No users found.",
    "es": "No se encontraron usuarios."
  },
  "Publicações": {
    "en": "Posts",
    "es": "Publicaciones"
  },
  "Abrir opções da publicação": {
    "en": "Open post options",
    "es": "Abrir opciones de la publicación"
  },
  "Ações da publicação": {
    "en": "Post actions",
    "es": "Acciones de la publicación"
  },
  "Fechar ações da publicação": {
    "en": "Close post actions",
    "es": "Cerrar acciones de la publicación"
  },
  "Salvando...": {
    "en": "Saving...",
    "es": "Guardando..."
  },
  "Remover dos salvos": {
    "en": "Remove from saved",
    "es": "Eliminar de guardados"
  },
  "Salvar publicação": {
    "en": "Save post",
    "es": "Guardar publicación"
  },
  "Compartilhando...": {
    "en": "Sharing...",
    "es": "Compartiendo..."
  },
  "Compartilhar": {
    "en": "Share",
    "es": "Compartir"
  },
  "Atualizando...": {
    "en": "Updating...",
    "es": "Actualizando..."
  },
  "Desfixar publicação": {
    "en": "Unpin post",
    "es": "Desfijar publicación"
  },
  "Fixar publicação": {
    "en": "Pin post",
    "es": "Fijar publicación"
  },
  "Remover publicação": {
    "en": "Remove post",
    "es": "Eliminar publicación"
  },
  "Fixado": {
    "en": "Pinned",
    "es": "Fijado"
  },
  "Conteúdo com spoiler oculto": {
    "en": "Spoiler content hidden",
    "es": "Contenido con spoiler oculto"
  },
  "Votar": {
    "en": "Vote",
    "es": "Votar"
  },
  "Remover curtida da publicação": {
    "en": "Unlike post",
    "es": "Quitar Me gusta de la publicación"
  },
  "Curtir publicação": {
    "en": "Like post",
    "es": "Me gusta en la publicación"
  },
  "REVELAR": {
    "en": "REVEAL",
    "es": "MOSTRAR"
  },
  "OCULTAR": {
    "en": "HIDE",
    "es": "OCULTAR"
  },
  "Nenhuma publicação salva": {
    "en": "No saved posts",
    "es": "No hay publicaciones guardadas"
  },
  "Nenhuma publicação encontrada": {
    "en": "No posts found",
    "es": "No se encontraron publicaciones"
  },
  "Nenhuma publicação ainda": {
    "en": "No posts yet",
    "es": "Aún no hay publicaciones"
  },
  "Carregando mais publicações": {
    "en": "Loading more posts",
    "es": "Cargando más publicaciones"
  },
  "Carregar mais publicações": {
    "en": "Load more posts",
    "es": "Cargar más publicaciones"
  },
  "Criar publicação": {
    "en": "Create post",
    "es": "Crear publicación"
  },
  "Fechar publicação": {
    "en": "Close post",
    "es": "Cerrar publicación"
  },
  "Nova publicação": {
    "en": "New post",
    "es": "Nueva publicación"
  },
  "Categoria": {
    "en": "Category",
    "es": "Categoría"
  },
  "Tipo": {
    "en": "Type",
    "es": "Tipo"
  },
  "Obra relacionada": {
    "en": "Related work",
    "es": "Obra relacionada"
  },
  "Opcional: nome da obra": {
    "en": "Optional: work title",
    "es": "Opcional: nombre de la obra"
  },
  "OBRA": {
    "en": "WORK",
    "es": "OBRA"
  },
  "Publicação": {
    "en": "Post",
    "es": "Publicación"
  },
  "Modelo de enquete": {
    "en": "Poll template",
    "es": "Plantilla de encuesta"
  },
  "máx. 700": {
    "en": "max. 700",
    "es": "máx. 700"
  },
  "Abra uma conversa, peça indicação ou divulgue uma obra real publicada...": {
    "en": "Start a conversation, ask for recommendations, or promote a published work...",
    "es": "Inicia una conversación, pide recomendaciones o promociona una obra publicada..."
  },
  "Este post contém spoiler": {
    "en": "This post contains spoilers",
    "es": "Esta publicación contiene spoilers"
  },
  "Publicando...": {
    "en": "Publishing...",
    "es": "Publicando..."
  },
  "1 comentário": {
    "en": "1 comment",
    "es": "1 comentario"
  },
  "Sem título": {
    "en": "Untitled",
    "es": "Sin título"
  },
  "Não consegui carregar usuário da Comunidade:": {
    "en": "I couldn't load the Community user:",
    "es": "No se pudo cargar el usuario de la Comunidad:"
  },
  "Não consegui iniciar usuário da Comunidade:": {
    "en": "I couldn't initialize the Community user:",
    "es": "No se pudo iniciar el usuario de la Comunidad:"
  },
  "Não consegui remover a review do Diário:": {
    "en": "I couldn't remove the review from the Journal:",
    "es": "No se pudo eliminar la reseña del Diario:"
  },
  "Não consegui acessar o Diário para remover a review:": {
    "en": "I couldn't access the Journal to remove the review:",
    "es": "No se pudo acceder al Diario para eliminar la reseña:"
  },
  "Ação": {
    "en": "Action",
    "es": "Acción"
  },
  "Aventura": {
    "en": "Adventure",
    "es": "Aventura"
  },
  "Comédia": {
    "en": "Comedy",
    "es": "Comedia"
  },
  "Drama": {
    "en": "Drama",
    "es": "Drama"
  },
  "Fantasia": {
    "en": "Fantasy",
    "es": "Fantasía"
  },
  "Mistério": {
    "en": "Mystery",
    "es": "Misterio"
  },
  "Romance": {
    "en": "Romance",
    "es": "Romance"
  },
  "Suspense": {
    "en": "Thriller",
    "es": "Suspenso"
  },
  "Terror": {
    "en": "Horror",
    "es": "Terror"
  },
  "Sobrenatural": {
    "en": "Supernatural",
    "es": "Sobrenatural"
  },
  "Histórico": {
    "en": "History",
    "es": "Historial"
  },
  "Biografia": {
    "en": "Bio",
    "es": "Biografía"
  },
  "Livre": {
    "en": "All ages",
    "es": "Todo público"
  },
  "Webnovel": {
    "en": "Web novel",
    "es": "Novela web"
  },
  "Light novel": {
    "en": "Light novel",
    "es": "Novela ligera"
  },
  "Conto": {
    "en": "Short story",
    "es": "Cuento"
  },
  "Poesia": {
    "en": "Poetry",
    "es": "Poesía"
  },
  "HQ": {
    "en": "Comic",
    "es": "Cómic"
  },
  "Mangá": {
    "en": "Manga",
    "es": "Manga"
  },
  "Fanfic": {
    "en": "Fan fiction",
    "es": "Fanfic"
  },
  "Sombria": {
    "en": "Dark",
    "es": "Oscura"
  },
  "Psicológico": {
    "en": "Psychological",
    "es": "Psicológico"
  },
  "Espacial": {
    "en": "Space",
    "es": "Espacial"
  },
  "Distopia": {
    "en": "Dystopia",
    "es": "Distopía"
  },
  "Apocalipse": {
    "en": "Apocalypse",
    "es": "Apocalipsis"
  },
  "Escolar": {
    "en": "School",
    "es": "Escolar"
  },
  "Máfia": {
    "en": "Mafia",
    "es": "Mafia"
  },
  "Investigação": {
    "en": "Investigation",
    "es": "Investigación"
  },
  "Religioso": {
    "en": "Religious",
    "es": "Religioso"
  },
  "Mitologia": {
    "en": "Mythology",
    "es": "Mitología"
  },
  "Folclore": {
    "en": "Folklore",
    "es": "Folclore"
  },
  "Vampiro": {
    "en": "Vampire",
    "es": "Vampiro"
  },
  "Lobisomem": {
    "en": "Werewolf",
    "es": "Hombre lobo"
  },
  "Zumbi": {
    "en": "Zombie",
    "es": "Zombi"
  },
  "Super-herói": {
    "en": "Superhero",
    "es": "Superhéroe"
  },
  "Magia": {
    "en": "Magic",
    "es": "Magia"
  },
  "Guerra": {
    "en": "War",
    "es": "Guerra"
  },
  "Família": {
    "en": "Family",
    "es": "Familia"
  },
  "Amizade": {
    "en": "Friendship",
    "es": "Amistad"
  },
  "Traição": {
    "en": "Betrayal",
    "es": "Traición"
  },
  "Vingança": {
    "en": "Revenge",
    "es": "Venganza"
  },
  "Sobrevivência": {
    "en": "Survival",
    "es": "Supervivencia"
  },
  "Perfil de leitor no Historietas.": {
    "en": "Reader profile on Historietas.",
    "es": "Perfil de lector en Historietas."
  },
  "histórias variadas": {
    "en": "varied stories",
    "es": "historias variadas"
  },
  "Histórias variadas": {
    "en": "Varied stories",
    "es": "Historias variadas"
  },
  "Data não informada": {
    "en": "Date not provided",
    "es": "Fecha no informada"
  },
  "Lendo": {
    "en": "Reading",
    "es": "Leyendo"
  },
  "lendo": {
    "en": "reading",
    "es": "leyendo"
  },
  "Favorita": {
    "en": "Favorite",
    "es": "Favorita"
  },
  "Favoritas": {
    "en": "Favorites",
    "es": "Favoritas"
  },
  "favoritas": {
    "en": "favorites",
    "es": "favoritas"
  },
  "Concluída": {
    "en": "Completed",
    "es": "Completada"
  },
  "concluídas": {
    "en": "completed",
    "es": "completadas"
  },
  "Avaliação": {
    "en": "Rating",
    "es": "Valoración"
  },
  "Avaliações": {
    "en": "Ratings",
    "es": "Valoraciones"
  },
  "Avaliações recentes": {
    "en": "Recent ratings",
    "es": "Valoraciones recientes"
  },
  "Quero ler": {
    "en": "Want to read",
    "es": "Quiero leer"
  },
  "quero ler": {
    "en": "want to read",
    "es": "quiero leer"
  },
  "Atividade": {
    "en": "Activity",
    "es": "Actividad"
  },
  "Atividade recente": {
    "en": "Recent activity",
    "es": "Actividad reciente"
  },
  "Atividades": {
    "en": "Activity",
    "es": "Actividad"
  },
  "Reviews": {
    "en": "Reviews",
    "es": "Reseñas"
  },
  "Leitura em andamento": {
    "en": "Reading in progress",
    "es": "Lectura en curso"
  },
  "Capítulo salvo na Biblioteca": {
    "en": "Chapter saved to the Library",
    "es": "Capítulo guardado en la Biblioteca"
  },
  "Capítulo salvo na Biblioteca.": {
    "en": "Chapter saved to the Library.",
    "es": "Capítulo guardado en la Biblioteca."
  },
  "Capítulo removido dos salvos.": {
    "en": "Chapter removed from saved items.",
    "es": "Capítulo eliminado de guardados."
  },
  "Obra adicionada ao Quero ler.": {
    "en": "Work added to Want to read.",
    "es": "Obra añadida a Quiero leer."
  },
  "Obra removida do Quero ler.": {
    "en": "Work removed from Want to read.",
    "es": "Obra eliminada de Quiero leer."
  },
  "Histórico de leitura removido.": {
    "en": "Reading history removed.",
    "es": "Historial de lectura eliminado."
  },
  "Obra favoritada no perfil": {
    "en": "Work favorited on the profile",
    "es": "Obra añadida a favoritas en el perfil"
  },
  "Obra favoritada no Diário": {
    "en": "Work favorited in the Journal",
    "es": "Obra añadida a favoritas en el Diario"
  },
  "Obra marcada como concluída": {
    "en": "Work marked as completed",
    "es": "Obra marcada como completada"
  },
  "Adicionada para acompanhar depois": {
    "en": "Added to read later",
    "es": "Añadida para leer después"
  },
  "Leu um capítulo.": {
    "en": "Read a chapter.",
    "es": "Leyó un capítulo."
  },
  "Começou a ler esta obra.": {
    "en": "Started reading this work.",
    "es": "Empezó a leer esta obra."
  },
  "Concluiu esta obra.": {
    "en": "Completed this work.",
    "es": "Completó esta obra."
  },
  "Avaliou esta obra.": {
    "en": "Rated this work.",
    "es": "Valoró esta obra."
  },
  "Favoritou esta obra.": {
    "en": "Added this work to favorites.",
    "es": "Añadió esta obra a favoritas."
  },
  "Salvou para acompanhar depois.": {
    "en": "Saved to read later.",
    "es": "Guardó para leer después."
  },
  "Publicou uma review.": {
    "en": "Published a review.",
    "es": "Publicó una reseña."
  },
  "Criou uma lista de leitura.": {
    "en": "Created a reading list.",
    "es": "Creó una lista de lectura."
  },
  "Atualizou o Diário.": {
    "en": "Updated the Journal.",
    "es": "Actualizó el Diario."
  },
  "Atividade do Diário": {
    "en": "Journal activity",
    "es": "Actividad del Diario"
  },
  "Carregando perfil": {
    "en": "Loading profile",
    "es": "Cargando perfil"
  },
  "Perfil não encontrado": {
    "en": "Profile not found",
    "es": "Perfil no encontrado"
  },
  "Entre para acessar seu perfil": {
    "en": "Sign in to access your profile",
    "es": "Inicia sesión para acceder a tu perfil"
  },
  "Abrir menu do perfil": {
    "en": "Open profile menu",
    "es": "Abrir menú del perfil"
  },
  "Menu do perfil": {
    "en": "Profile menu",
    "es": "Menú del perfil"
  },
  "Ações do perfil": {
    "en": "Profile actions",
    "es": "Acciones del perfil"
  },
  "Fechar menu": {
    "en": "Close menu",
    "es": "Cerrar menú"
  },
  "Conta e sistema": {
    "en": "Account and system",
    "es": "Cuenta y sistema"
  },
  "Configurações e atividade": {
    "en": "Settings and activity",
    "es": "Configuración y actividad"
  },
  "Copiar link do perfil": {
    "en": "Copy profile link",
    "es": "Copiar enlace del perfil"
  },
  "Sair da conta": {
    "en": "Sign out",
    "es": "Cerrar sesión"
  },
  "Perfil": {
    "en": "Profile",
    "es": "Perfil"
  },
  "Comunidade do autor": {
    "en": "Author community",
    "es": "Comunidad del autor"
  },
  "Denunciar perfil": {
    "en": "Report profile",
    "es": "Denunciar perfil"
  },
  "Bloquear usuário": {
    "en": "Block user",
    "es": "Bloquear usuario"
  },
  "Desbloquear usuário": {
    "en": "Unblock user",
    "es": "Desbloquear usuario"
  },
  "Bloqueando...": {
    "en": "Blocking...",
    "es": "Bloqueando..."
  },
  "Desbloqueando...": {
    "en": "Unblocking...",
    "es": "Desbloqueando..."
  },
  "Perfil bloqueado": {
    "en": "Blocked profile",
    "es": "Perfil bloqueado"
  },
  "O conteúdo deste perfil está oculto porque existe um bloqueio entre vocês.": {
    "en": "This profile's content is hidden because there is a block between you.",
    "es": "El contenido de este perfil está oculto porque existe un bloqueo entre ustedes."
  },
  "Descoberta": {
    "en": "Discover",
    "es": "Descubrimiento"
  },
  "Explorar outras obras": {
    "en": "Explore other works",
    "es": "Explorar otras obras"
  },
  "Editar perfil": {
    "en": "Edit profile",
    "es": "Editar perfil"
  },
  "Atualize suas informações públicas": {
    "en": "Update your public information",
    "es": "Actualiza tu información pública"
  },
  "Fechar edição do perfil": {
    "en": "Close profile editor",
    "es": "Cerrar edición del perfil"
  },
  "Prévia da imagem do perfil": {
    "en": "Profile image preview",
    "es": "Vista previa de la imagen del perfil"
  },
  "Trocar imagem": {
    "en": "Change image",
    "es": "Cambiar imagen"
  },
  "Colocar imagem": {
    "en": "Add image",
    "es": "Añadir imagen"
  },
  "Nome de usuário": {
    "en": "Display name",
    "es": "Nombre de usuario"
  },
  "Digite seu nome": {
    "en": "Enter your name",
    "es": "Escribe tu nombre"
  },
  "@username público": {
    "en": "Public @username",
    "es": "@username público"
  },
  "Digite seu username": {
    "en": "Enter your username",
    "es": "Escribe tu username"
  },
  "caracteres": {
    "en": "characters",
    "es": "caracteres"
  },
  "Cancelar": {
    "en": "Cancel",
    "es": "Cancelar"
  },
  "Essa denúncia será enviada para análise da moderação.": {
    "en": "This report will be sent to moderation for review.",
    "es": "Esta denuncia se enviará a moderación para su revisión."
  },
  "Fechar denúncia": {
    "en": "Close report",
    "es": "Cerrar denuncia"
  },
  "Explique rapidamente o problema, se quiser.": {
    "en": "Briefly explain the problem, if you wish.",
    "es": "Explica brevemente el problema, si quieres."
  },
  "Enviar denúncia": {
    "en": "Submit report",
    "es": "Enviar denuncia"
  },
  "obras": {
    "en": "works",
    "es": "obras"
  },
  "seguidas": {
    "en": "followed",
    "es": "seguidas"
  },
  "seguidores": {
    "en": "followers",
    "es": "seguidores"
  },
  "seguindo": {
    "en": "following",
    "es": "siguiendo"
  },
  "Média": {
    "en": "Average",
    "es": "Promedio"
  },
  "+ Adicionar biografia": {
    "en": "+ Add bio",
    "es": "+ Añadir biografía"
  },
  "Ocultar destaques": {
    "en": "Hide highlights",
    "es": "Ocultar destacados"
  },
  "Mostrar destaques": {
    "en": "Show highlights",
    "es": "Mostrar destacados"
  },
  "Ocultar destaque": {
    "en": "Hide highlight",
    "es": "Ocultar destacado"
  },
  "Mostrar destaque": {
    "en": "Show highlight",
    "es": "Mostrar destacado"
  },
  "Remover curtida do TOP 5": {
    "en": "Unlike TOP 5",
    "es": "Quitar Me gusta del TOP 5"
  },
  "Curtir TOP 5": {
    "en": "Like TOP 5",
    "es": "Me gusta en TOP 5"
  },
  "Montar ou editar TOP 5": {
    "en": "Create or edit TOP 5",
    "es": "Crear o editar TOP 5"
  },
  "Monte seu TOP 5 para destacar suas obras favoritas.": {
    "en": "Build your TOP 5 to highlight your favorite works.",
    "es": "Crea tu TOP 5 para destacar tus obras favoritas."
  },
  "Avaliação do autor": {
    "en": "Author rating",
    "es": "Valoración del autor"
  },
  "AVALIE ESTE AUTOR": {
    "en": "RATE THIS AUTHOR",
    "es": "VALORA A ESTE AUTOR"
  },
  "Avaliação do Diário": {
    "en": "Journal rating",
    "es": "Valoración del Diario"
  },
  "AVALIE ESTE DIÁRIO": {
    "en": "RATE THIS JOURNAL",
    "es": "VALORA ESTE DIARIO"
  },
  "Seções do perfil": {
    "en": "Profile sections",
    "es": "Secciones del perfil"
  },
  "Obras": {
    "en": "Works",
    "es": "Obras"
  },
  "Diário": {
    "en": "Journal",
    "es": "Diario"
  },
  "Sobre": {
    "en": "About",
    "es": "Acerca de"
  },
  "Salvos": {
    "en": "Saved",
    "es": "Guardados"
  },
  "Carregando biblioteca": {
    "en": "Loading library",
    "es": "Cargando biblioteca"
  },
  "Sua Biblioteca ainda não tem itens em": {
    "en": "Your Library does not have any items in",
    "es": "Tu Biblioteca todavía no tiene elementos en"
  },
  "Meu Diário": {
    "en": "My Journal",
    "es": "Mi Diario"
  },
  "Ocultar resumo do Diário": {
    "en": "Hide Journal summary",
    "es": "Ocultar resumen del Diario"
  },
  "Mostrar resumo do Diário": {
    "en": "Show Journal summary",
    "es": "Mostrar resumen del Diario"
  },
  "Carregando diário": {
    "en": "Loading journal",
    "es": "Cargando diario"
  },
  "Suas leituras recentes aparecerão aqui.": {
    "en": "Your recent reads will appear here.",
    "es": "Tus lecturas recientes aparecerán aquí."
  },
  "Este perfil ainda não compartilhou leituras recentes.": {
    "en": "This profile has not shared any recent reads yet.",
    "es": "Este perfil aún no ha compartido lecturas recientes."
  },
  "As obras salvas para acompanhar depois aparecerão aqui.": {
    "en": "Works saved for later will appear here.",
    "es": "Las obras guardadas para después aparecerán aquí."
  },
  "Este perfil ainda não compartilhou obras para ler depois.": {
    "en": "This profile has not shared any works to read later yet.",
    "es": "Este perfil aún no ha compartido obras para leer después."
  },
  "Favorite obras para montar sua vitrine de leitura.": {
    "en": "Favorite works to build your reading showcase.",
    "es": "Añade obras a favoritas para crear tu escaparate de lectura."
  },
  "Este perfil ainda não compartilhou favoritas.": {
    "en": "This profile has not shared any favorites yet.",
    "es": "Este perfil aún no ha compartido favoritas."
  },
  "Obras concluídas aparecerão nesta área.": {
    "en": "Completed works will appear here.",
    "es": "Las obras completadas aparecerán aquí."
  },
  "Este perfil ainda não compartilhou obras concluídas.": {
    "en": "This profile has not shared any completed works yet.",
    "es": "Este perfil aún no ha compartido obras completadas."
  },
  "Suas avaliações públicas aparecerão aqui.": {
    "en": "Your public ratings will appear here.",
    "es": "Tus valoraciones públicas aparecerán aquí."
  },
  "Este perfil ainda não possui avaliações públicas.": {
    "en": "This profile does not have any public ratings yet.",
    "es": "Este perfil aún no tiene valoraciones públicas."
  },
  "Suas avaliações publicadas na Comunidade aparecerão aqui.": {
    "en": "Your reviews published in the Community will appear here.",
    "es": "Tus reseñas publicadas en la Comunidad aparecerán aquí."
  },
  "Este perfil ainda não publicou avaliações.": {
    "en": "This profile has not published any reviews yet.",
    "es": "Este perfil aún no ha publicado reseñas."
  },
  "PUBLICAÇÕES": {
    "en": "POSTS",
    "es": "PUBLICACIONES"
  },
  "posts do perfil": {
    "en": "profile posts",
    "es": "publicaciones del perfil"
  },
  "TEORIAS": {
    "en": "THEORIES",
    "es": "TEORÍAS"
  },
  "discussões": {
    "en": "discussions",
    "es": "discusiones"
  },
  "REVIEWS": {
    "en": "REVIEWS",
    "es": "RESEÑAS"
  },
  "opiniões": {
    "en": "opinions",
    "es": "opiniones"
  },
  "Sua comunidade ainda está vazia": {
    "en": "Your community is still empty",
    "es": "Tu comunidad todavía está vacía"
  },
  "Nenhuma publicação por aqui ainda": {
    "en": "No posts here yet",
    "es": "Aún no hay publicaciones aquí"
  },
  "Publique avisos, bastidores, teorias e chamadas para aproximar leitores das suas obras.": {
    "en": "Publish updates, behind-the-scenes posts, theories and invitations to bring readers closer to your works.",
    "es": "Publica avisos, contenido entre bastidores, teorías e invitaciones para acercar a los lectores a tus obras."
  },
  "Editar sinopse do Sobre": {
    "en": "Edit About description",
    "es": "Editar descripción de Acerca de"
  },
  "Especialidades": {
    "en": "Specialties",
    "es": "Especialidades"
  },
  "Números do perfil": {
    "en": "Profile numbers",
    "es": "Números del perfil"
  },
  "publicadas": {
    "en": "published",
    "es": "publicadas"
  },
  "capítulos": {
    "en": "chapters",
    "es": "capítulos"
  },
  "curtidas": {
    "en": "likes",
    "es": "Me gusta"
  },
  "visualizações": {
    "en": "views",
    "es": "visualizaciones"
  },
  "obras no perfil": {
    "en": "works on profile",
    "es": "obras en el perfil"
  },
  "rascunhos em desenvolvimento": {
    "en": "drafts in progress",
    "es": "borradores en desarrollo"
  },
  "comentários recebidos": {
    "en": "comments received",
    "es": "comentarios recibidos"
  },
  "concluídas por leitores": {
    "en": "completed by readers",
    "es": "completadas por lectores"
  },
  "sem capítulos ainda": {
    "en": "no chapters yet",
    "es": "sin capítulos todavía"
  },
  "Na Historietas desde": {
    "en": "On Historietas since",
    "es": "En Historietas desde"
  },
  "Você ainda não publicou obras. Seu perfil continua ativo como leitor, com Diário e Comunidade.": {
    "en": "You have not published any works yet. Your profile remains active as a reader, with Journal and Community.",
    "es": "Todavía no has publicado obras. Tu perfil sigue activo como lector, con Diario y Comunidad."
  },
  "Este perfil ainda não publicou obras. O Diário e a Comunidade continuam disponíveis.": {
    "en": "This profile has not published any works yet. The Journal and Community are still available.",
    "es": "Este perfil aún no ha publicado obras. El Diario y la Comunidad siguen disponibles."
  },
  "Nenhuma obra encontrada.": {
    "en": "No works found.",
    "es": "No se encontraron obras."
  },
  "Ler": {
    "en": "Read",
    "es": "Leer"
  },
  "Remover da lista": {
    "en": "Remove from list",
    "es": "Eliminar de la lista"
  },
  "Adicionar à lista": {
    "en": "Add to list",
    "es": "Añadir a la lista"
  },
  "Marcar como não concluída": {
    "en": "Mark as not completed",
    "es": "Marcar como no completada"
  },
  "Concluir": {
    "en": "Mark completed",
    "es": "Completar"
  },
  "capítulo": {
    "en": "chapter",
    "es": "capítulo"
  },
  "Obra": {
    "en": "Work",
    "es": "Obra"
  },
  "Ler capítulo": {
    "en": "Read chapter",
    "es": "Leer capítulo"
  },
  "Remover do Quero ler": {
    "en": "Remove from Want to read",
    "es": "Eliminar de Quiero leer"
  },
  "Remover favorita": {
    "en": "Remove favorite",
    "es": "Eliminar de favoritas"
  },
  "Favoritar": {
    "en": "Add to favorites",
    "es": "Añadir a favoritas"
  },
  "Parar leitura": {
    "en": "Stop reading",
    "es": "Dejar de leer"
  },
  "Limpar histórico": {
    "en": "Clear history",
    "es": "Borrar historial"
  },
  "Continuar leitura": {
    "en": "Continue reading",
    "es": "Continuar lectura"
  },
  "Editar anotação": {
    "en": "Edit note",
    "es": "Editar nota"
  },
  "Adicionar anotação": {
    "en": "Add note",
    "es": "Añadir nota"
  },
  "Escreva o que achou desta leitura...": {
    "en": "Write what you thought of this reading...",
    "es": "Escribe qué te pareció esta lectura..."
  },
  "Anotação": {
    "en": "Note",
    "es": "Nota"
  },
  "Remover curtida da anotação": {
    "en": "Unlike note",
    "es": "Quitar Me gusta de la nota"
  },
  "Curtir anotação": {
    "en": "Like note",
    "es": "Me gusta en la nota"
  },
  "Ocultar": {
    "en": "Hide",
    "es": "Ocultar"
  },
  "Abrir": {
    "en": "Open",
    "es": "Abrir"
  },
  "Nenhuma atividade recente para mostrar.": {
    "en": "No recent activity to show.",
    "es": "No hay actividad reciente para mostrar."
  },
  "Entre para curtir o TOP 5 deste perfil.": {
    "en": "Sign in to like this profile’s TOP 5.",
    "es": "Inicia sesión para indicar que te gusta el TOP 5 de este perfil."
  },
  "Não foi possível confirmar este perfil para edição.": {
    "en": "This profile could not be verified for editing.",
    "es": "No se pudo confirmar este perfil para editarlo."
  },
  "O nome do perfil precisa ter pelo menos 3 caracteres.": {
    "en": "The profile name must have at least 3 characters.",
    "es": "El nombre del perfil debe tener al menos 3 caracteres."
  },
  "O @username precisa ter pelo menos 3 caracteres.": {
    "en": "The @username must have at least 3 characters.",
    "es": "El @username debe tener al menos 3 caracteres."
  },
  "Salvando perfil...": {
    "en": "Saving profile...",
    "es": "Guardando perfil..."
  },
  "A imagem ficou salva neste aparelho, mas não foi enviada ao Storage.": {
    "en": "The image was saved on this device but was not uploaded to Storage.",
    "es": "La imagen se guardó en este dispositivo, pero no se subió al Storage."
  },
  "Esse @username já está em uso.": {
    "en": "That @username is already in use.",
    "es": "Ese @username ya está en uso."
  },
  "Não foi possível copiar o username agora.": {
    "en": "The username could not be copied right now.",
    "es": "No se pudo copiar el username ahora."
  },
  "Você não pode avaliar seu próprio perfil.": {
    "en": "You cannot rate your own profile.",
    "es": "No puedes valorar tu propio perfil."
  },
  "Entre na sua conta para avaliar este autor.": {
    "en": "Sign in to rate this author.",
    "es": "Inicia sesión para valorar a este autor."
  },
  "Você não pode avaliar seu próprio Diário.": {
    "en": "You cannot rate your own Journal.",
    "es": "No puedes valorar tu propio Diario."
  },
  "Entre na sua conta para avaliar este Diário.": {
    "en": "Sign in to rate this Journal.",
    "es": "Inicia sesión para valorar este Diario."
  },
  "Este Diário não está disponível para avaliação.": {
    "en": "This Journal is not available for rating.",
    "es": "Este Diario no está disponible para valoración."
  },
  "Escolha uma imagem válida.": {
    "en": "Choose a valid image.",
    "es": "Elige una imagen válida."
  },
  "A imagem precisa ter no máximo 1 MB.": {
    "en": "The image must be no larger than 1 MB.",
    "es": "La imagen debe tener como máximo 1 MB."
  },
  "Não consegui carregar essa imagem.": {
    "en": "I could not load this image.",
    "es": "No se pudo cargar esta imagen."
  },
  "Compartilhamento do perfil aberto.": {
    "en": "Profile sharing opened.",
    "es": "Se abrió la opción para compartir el perfil."
  },
  "Não consegui compartilhar nem copiar o link do perfil neste navegador.": {
    "en": "I could not share or copy the profile link in this browser.",
    "es": "No se pudo compartir ni copiar el enlace del perfil en este navegador."
  },
  "Não foi possível identificar este perfil.": {
    "en": "This profile could not be identified.",
    "es": "No se pudo identificar este perfil."
  },
  "Entre na sua conta para denunciar este perfil.": {
    "en": "Sign in to report this profile.",
    "es": "Inicia sesión para denunciar este perfil."
  },
  "Você não pode denunciar o próprio perfil.": {
    "en": "You cannot report your own profile.",
    "es": "No puedes denunciar tu propio perfil."
  },
  "Não consegui enviar a denúncia agora.": {
    "en": "I could not submit the report now.",
    "es": "No se pudo enviar la denuncia ahora."
  },
  "Obra na Historietas": {
    "en": "Work on Historietas",
    "es": "Obra en Historietas"
  },
  "Compartilhamento da obra aberto.": {
    "en": "Work sharing opened.",
    "es": "Se abrió la opción para compartir la obra."
  },
  "Link da obra copiado.": {
    "en": "Work link copied.",
    "es": "Enlace de la obra copiado."
  },
  "Não consegui compartilhar nem copiar o link da obra neste navegador.": {
    "en": "I could not share or copy the work link in this browser.",
    "es": "No se pudo compartir ni copiar el enlace de la obra en este navegador."
  },
  "Entre na sua conta para seguir perfis.": {
    "en": "Sign in to follow profiles.",
    "es": "Inicia sesión para seguir perfiles."
  },
  "Este é o seu perfil.": {
    "en": "This is your profile.",
    "es": "Este es tu perfil."
  },
  "Não consegui atualizar este seguimento agora.": {
    "en": "I could not update this follow right now.",
    "es": "No se pudo actualizar este seguimiento ahora."
  },
  "Perfil adicionado aos seus seguindo.": {
    "en": "Profile added to your following list.",
    "es": "Perfil añadido a tu lista de seguidos."
  },
  "Perfil removido dos seus seguindo.": {
    "en": "Profile removed from your following list.",
    "es": "Perfil eliminado de tu lista de seguidos."
  },
  "Sua solicitação foi enviada.": {
    "en": "Your follow request was sent.",
    "es": "Tu solicitud de seguimiento fue enviada."
  },
  "Solicitação cancelada.": {
    "en": "Request canceled.",
    "es": "Solicitud cancelada."
  },
  "Entre na sua conta para adicionar obras à lista.": {
    "en": "Sign in to add works to the list.",
    "es": "Inicia sesión para añadir obras a la lista."
  },
  "Entre na sua conta para concluir obras.": {
    "en": "Sign in to mark works as completed.",
    "es": "Inicia sesión para marcar obras como completadas."
  },
  "Entre na sua conta para atualizar a Biblioteca.": {
    "en": "Sign in to update the Library.",
    "es": "Inicia sesión para actualizar la Biblioteca."
  },
  "Entre na sua conta para limpar o histórico.": {
    "en": "Sign in to clear history.",
    "es": "Inicia sesión para borrar el historial."
  },
  "Esta anotação só pode ser criada em uma obra salva no Supabase.": {
    "en": "This note can only be created for a work saved in Supabase.",
    "es": "Esta nota solo puede crearse en una obra guardada en Supabase."
  },
  "Entre na sua conta para salvar a anotação.": {
    "en": "Sign in to save the note.",
    "es": "Inicia sesión para guardar la nota."
  },
  "A obra ainda não possui um ID válido no Supabase.": {
    "en": "The work does not yet have a valid Supabase ID.",
    "es": "La obra todavía no tiene un ID válido en Supabase."
  },
  "Escreva uma anotação antes de salvar.": {
    "en": "Write a note before saving.",
    "es": "Escribe una nota antes de guardar."
  },
  "Anotação salva no Diário.": {
    "en": "Note saved in the Journal.",
    "es": "Nota guardada en el Diario."
  },
  "Não foi possível salvar a anotação.": {
    "en": "The note could not be saved.",
    "es": "No se pudo guardar la nota."
  },
  "Remover esta anotação do Diário?": {
    "en": "Remove this note from the Journal?",
    "es": "¿Eliminar esta nota del Diario?"
  },
  "Anotação removida do Diário.": {
    "en": "Note removed from the Journal.",
    "es": "Nota eliminada del Diario."
  },
  "Não foi possível remover a anotação.": {
    "en": "The note could not be removed.",
    "es": "No se pudo eliminar la nota."
  },
  "Não foi possível atualizar a curtida.": {
    "en": "The like could not be updated.",
    "es": "No se pudo actualizar el Me gusta."
  },
  "Não foi possível enviar o comentário.": {
    "en": "The comment could not be sent.",
    "es": "No se pudo enviar el comentario."
  },
  "Não foi possível remover o comentário.": {
    "en": "The comment could not be removed.",
    "es": "No se pudo eliminar el comentario."
  },
  "Nova notificação": {
    "en": "New notification",
    "es": "Nueva notificación"
  },
  "Você recebeu uma nova notificação.": {
    "en": "You received a new notification.",
    "es": "Recibiste una nueva notificación."
  },
  "Conteúdo ofensivo": {
    "en": "Offensive content",
    "es": "Contenido ofensivo"
  },
  "Perfil falso": {
    "en": "Fake profile",
    "es": "Perfil falso"
  },
  "Assédio": {
    "en": "Harassment",
    "es": "Acoso"
  },
  "Conteúdo impróprio": {
    "en": "Inappropriate content",
    "es": "Contenido inapropiado"
  },
  "Outro": {
    "en": "Other",
    "es": "Otro"
  }
};

function obterLocaleDocumentoPerfilAutor() {
  if (typeof document === "undefined") {
    return "pt-BR";
  }

  const idiomaDocumento = document.documentElement.lang.toLowerCase();

  if (idiomaDocumento.startsWith("en")) {
    return "en-US";
  }

  if (idiomaDocumento.startsWith("es")) {
    return "es-ES";
  }

  return "pt-BR";
}

function traduzirTextoPerfilAutor(
  texto: string,
  idioma: HistorietasLanguage,
): string {
  if (idioma === "pt-BR" || !texto) {
    return texto;
  }

  const partes = /^(\s*)([\s\S]*?)(\s*)$/.exec(texto);

  if (!partes) {
    return texto;
  }

  const inicio = partes[1];
  const conteudo = partes[2];
  const fim = partes[3];
  const traducaoExata = PERFIL_AUTOR_UI_TRANSLATIONS[conteudo];

  if (traducaoExata) {
    return `${inicio}${traducaoExata[idioma]}${fim}`;
  }

  const separadorComposto = conteudo.includes(" • ")
    ? " • "
    : conteudo.includes(" · ")
      ? " · "
      : "";

  if (separadorComposto) {
    const partesOriginais = conteudo.split(separadorComposto);
    const partesTraduzidas: string[] = partesOriginais.map(
      (parte: string): string =>
        traduzirTextoPerfilAutor(parte.trim(), idioma),
    );

    if (
      partesTraduzidas.some(
        (parte, index) => parte !== partesOriginais[index]?.trim(),
      )
    ) {
      return `${inicio}${partesTraduzidas.join(separadorComposto)}${fim}`;
    }
  }

  let correspondencia = /^Notificações: (\d+) não lidas$/.exec(conteudo);

  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Notifications: ${correspondencia[1]} unread${fim}`
      : `${inicio}Notificaciones: ${correspondencia[1]} sin leer${fim}`;
  }

  correspondencia = /^(\d+|99\+) notificações não lidas$/.exec(conteudo);

  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}${correspondencia[1]} unread notifications${fim}`
      : `${inicio}${correspondencia[1]} notificaciones sin leer${fim}`;
  }

  correspondencia = /^(\d+) (avaliação|avaliações)$/.exec(conteudo);

  if (correspondencia) {
    const total = Number(correspondencia[1]);
    return idioma === "en"
      ? `${inicio}${total} ${total === 1 ? "rating" : "ratings"}${fim}`
      : `${inicio}${total} ${total === 1 ? "valoración" : "valoraciones"}${fim}`;
  }

  correspondencia = /^Média ([0-9.,]+) de 5$/.exec(conteudo);

  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Average ${correspondencia[1]} out of 5${fim}`
      : `${inicio}Promedio ${correspondencia[1]} de 5${fim}`;
  }

  correspondencia = /^Avaliar autor com ([0-9.,]+) (estrela|estrelas)$/.exec(conteudo);

  if (correspondencia) {
    const total = Number(correspondencia[1].replace(",", "."));
    return idioma === "en"
      ? `${inicio}Rate author with ${correspondencia[1]} ${total === 1 ? "star" : "stars"}${fim}`
      : `${inicio}Valorar al autor con ${correspondencia[1]} ${total === 1 ? "estrella" : "estrellas"}${fim}`;
  }

  correspondencia = /^Imagem de (.+)$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Image of ${correspondencia[1]}${fim}`
      : `${inicio}Imagen de ${correspondencia[1]}${fim}`;
  }

  correspondencia = /^Abrir obras seguidas por (.+)$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Open works followed by ${correspondencia[1]}${fim}`
      : `${inicio}Abrir obras seguidas por ${correspondencia[1]}${fim}`;
  }

  correspondencia = /^Abrir lista de seguidores de (.+)$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Open ${correspondencia[1]}'s followers list${fim}`
      : `${inicio}Abrir la lista de seguidores de ${correspondencia[1]}${fim}`;
  }

  correspondencia = /^Abrir lista de perfis que (.+) segue$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Open the list of profiles followed by ${correspondencia[1]}${fim}`
      : `${inicio}Abrir la lista de perfiles que sigue ${correspondencia[1]}${fim}`;
  }

  correspondencia = /^Diário de (.+)$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}${correspondencia[1]}'s Journal${fim}`
      : `${inicio}Diario de ${correspondencia[1]}${fim}`;
  }

  correspondencia = /^Comunidade de (.+)$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}${correspondencia[1]}'s Community${fim}`
      : `${inicio}Comunidad de ${correspondencia[1]}${fim}`;
  }

  correspondencia = /^Sobre (.+)$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}About ${correspondencia[1]}${fim}`
      : `${inicio}Acerca de ${correspondencia[1]}${fim}`;
  }

  correspondencia = /^Abrir publicações de (.+) na comunidade$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Open ${correspondencia[1]}'s posts in the Community${fim}`
      : `${inicio}Abrir las publicaciones de ${correspondencia[1]} en la Comunidad${fim}`;
  }

  correspondencia = /^Abrir teorias de (.+) na comunidade$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Open ${correspondencia[1]}'s theories in the Community${fim}`
      : `${inicio}Abrir las teorías de ${correspondencia[1]} en la Comunidad${fim}`;
  }

  correspondencia = /^Abrir reviews de (.+) na comunidade$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Open ${correspondencia[1]}'s reviews in the Community${fim}`
      : `${inicio}Abrir las reseñas de ${correspondencia[1]} en la Comunidad${fim}`;
  }

  correspondencia = /^Quando (.+) publicar posts, teorias ou reviews, eles aparecerão nesta área\.$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}When ${correspondencia[1]} publishes posts, theories or reviews, they will appear here.${fim}`
      : `${inicio}Cuando ${correspondencia[1]} publique posts, teorías o reseñas, aparecerán aquí.${fim}`;
  }

  correspondencia = /^(.+) nao montou top 5$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}${correspondencia[1]} has not created a TOP 5${fim}`
      : `${inicio}${correspondencia[1]} no ha creado un TOP 5${fim}`;
  }

  correspondencia = /^Ações da obra (.+)$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Actions for ${correspondencia[1]}${fim}`
      : `${inicio}Acciones de ${correspondencia[1]}${fim}`;
  }

  correspondencia = /^Ações da Biblioteca (.+)$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Library actions for ${correspondencia[1]}${fim}`
      : `${inicio}Acciones de Biblioteca para ${correspondencia[1]}${fim}`;
  }

  correspondencia = /^Ações do Diário (.+)$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Journal actions for ${correspondencia[1]}${fim}`
      : `${inicio}Acciones del Diario para ${correspondencia[1]}${fim}`;
  }

  correspondencia = /^Abrir opções de (.+)$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Open options for ${correspondencia[1]}${fim}`
      : `${inicio}Abrir opciones de ${correspondencia[1]}${fim}`;
  }

  correspondencia = /^Abrir (.+)$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Open ${correspondencia[1]}${fim}`
      : `${inicio}Abrir ${correspondencia[1]}${fim}`;
  }

  correspondencia = /^Por (.+)$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}By ${correspondencia[1]}${fim}`
      : `${inicio}Por ${correspondencia[1]}${fim}`;
  }

  correspondencia = /^(\d+) (capítulo|capítulos)$/.exec(conteudo);
  if (correspondencia) {
    const total = Number(correspondencia[1]);
    return idioma === "en"
      ? `${inicio}${total} ${total === 1 ? "chapter" : "chapters"}${fim}`
      : `${inicio}${total} ${total === 1 ? "capítulo" : "capítulos"}${fim}`;
  }

  correspondencia = /^(\d+)% concluíd[oa]$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}${correspondencia[1]}% completed${fim}`
      : `${inicio}${correspondencia[1]}% completado${fim}`;
  }

  correspondencia = /^Leitura em andamento • (\d+)% concluída$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Reading in progress • ${correspondencia[1]}% completed${fim}`
      : `${inicio}Lectura en curso • ${correspondencia[1]}% completada${fim}`;
  }

  correspondencia = /^Capítulo (\d+) de (\d+)$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Chapter ${correspondencia[1]} of ${correspondencia[2]}${fim}`
      : `${inicio}Capítulo ${correspondencia[1]} de ${correspondencia[2]}${fim}`;
  }

  correspondencia = /^Confira o perfil de (.+)$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Check out ${correspondencia[1]}'s profile${fim}`
      : `${inicio}Mira el perfil de ${correspondencia[1]}${fim}`;
  }

  correspondencia = /^(.+) começou a seguir você\.$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}${correspondencia[1]} started following you.${fim}`
      : `${inicio}${correspondencia[1]} empezó a seguirte.${fim}`;
  }

  correspondencia = /^Veja (.+) na Historietas\.$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}See ${correspondencia[1]} on Historietas.${fim}`
      : `${inicio}Mira ${correspondencia[1]} en Historietas.${fim}`;
  }

  correspondencia = /^Avaliou com ([0-9.,]+) estrelas(\.)?$/.exec(conteudo);
  if (correspondencia) {
    const nota =
      idioma === "en"
        ? correspondencia[1].replace(",", ".")
        : correspondencia[1];
    const pontoFinal = correspondencia[2] || "";

    return idioma === "en"
      ? `${inicio}Rated ${nota} stars${pontoFinal}${fim}`
      : `${inicio}Valoró con ${nota} estrellas${pontoFinal}${fim}`;
  }

  correspondencia = /^Publicou review: (.+)$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Published a review: ${correspondencia[1]}${fim}`
      : `${inicio}Publicó una reseña: ${correspondencia[1]}${fim}`;
  }

  correspondencia = /^Leitura em andamento • (.+)$/.exec(conteudo);
  if (correspondencia) {
    return idioma === "en"
      ? `${inicio}Reading in progress • ${correspondencia[1]}${fim}`
      : `${inicio}Lectura en curso • ${correspondencia[1]}${fim}`;
  }

  return texto;
}

function PerfilAutorLanguageBridge() {
  const { language } = useHistorietasLanguage();

  useEffect(() => {
    if (typeof document === "undefined" || !document.body) {
      return;
    }

    type EstadoTraducaoPerfilAutor = {
      original: string;
      traduzido: string;
    };

    const estadosTexto: WeakMap<Text, EstadoTraducaoPerfilAutor> = new WeakMap();
    const estadosAtributos: WeakMap<
      Element,
      Map<string, EstadoTraducaoPerfilAutor>
    > = new WeakMap();
    const textosAlterados = new Set<Text>();
    const atributosAlterados = new Set<{ elemento: Element; atributo: string }>();
    const atributosTraduziveis = ["aria-label", "title", "placeholder", "alt"];
    let aplicando = false;

    function pertenceAConteudoUsuario(elemento: Element | null) {
      return Boolean(
        elemento?.closest("[data-historietas-user-content='true']"),
      );
    }

    function deveIgnorarElemento(elemento: Element | null) {
      if (!elemento) {
        return true;
      }

      const tag = elemento.tagName.toLowerCase();

      return tag === "script" || tag === "style" || pertenceAConteudoUsuario(elemento);
    }

    function aplicarTexto(no: Text) {
      const elementoPai = no.parentElement;

      if (
        deveIgnorarElemento(elementoPai) ||
        elementoPai?.tagName.toLowerCase() === "textarea"
      ) {
        return;
      }

      const atual = no.data;
      let estado = estadosTexto.get(no);

      if (!estado) {
        estado = { original: atual, traduzido: atual };
        estadosTexto.set(no, estado);
        textosAlterados.add(no);
      } else if (atual !== estado.traduzido && atual !== estado.original) {
        estado.original = atual;
      }

      const proximo = traduzirTextoPerfilAutor(estado.original, language);
      estado.traduzido = proximo;

      if (no.data !== proximo) {
        no.data = proximo;
      }
    }

    function aplicarAtributo(elemento: Element, atributo: string) {
      if (deveIgnorarElemento(elemento) || !elemento.hasAttribute(atributo)) {
        return;
      }

      const atual = elemento.getAttribute(atributo) || "";
      let mapaElemento = estadosAtributos.get(elemento);

      if (!mapaElemento) {
        mapaElemento = new Map();
        estadosAtributos.set(elemento, mapaElemento);
      }

      let estado = mapaElemento.get(atributo);

      if (!estado) {
        estado = { original: atual, traduzido: atual };
        mapaElemento.set(atributo, estado);
        atributosAlterados.add({ elemento, atributo });
      } else if (atual !== estado.traduzido && atual !== estado.original) {
        estado.original = atual;
      }

      const proximo = traduzirTextoPerfilAutor(estado.original, language);
      estado.traduzido = proximo;

      if (atual !== proximo) {
        elemento.setAttribute(atributo, proximo);
      }
    }

    function aplicarNo(no: Node) {
      if (no.nodeType === Node.TEXT_NODE) {
        aplicarTexto(no as Text);
        return;
      }

      if (!(no instanceof Element) || deveIgnorarElemento(no)) {
        return;
      }

      atributosTraduziveis.forEach((atributo) => aplicarAtributo(no, atributo));

      const walker = document.createTreeWalker(
        no,
        NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT,
      );
      let atual: Node | null = walker.nextNode();

      while (atual) {
        if (atual.nodeType === Node.TEXT_NODE) {
          aplicarTexto(atual as Text);
        } else if (atual instanceof Element && !deveIgnorarElemento(atual)) {
          atributosTraduziveis.forEach((atributo) =>
            aplicarAtributo(atual as Element, atributo),
          );
        }

        atual = walker.nextNode();
      }
    }

    function aplicarTudo() {
      if (aplicando) {
        return;
      }

      aplicando = true;

      try {
        aplicarNo(document.body);
      } finally {
        aplicando = false;
      }
    }

    aplicarTudo();

    const observador = new MutationObserver((mutacoes) => {
      if (aplicando) {
        return;
      }

      aplicando = true;

      try {
        mutacoes.forEach((mutacao) => {
          if (mutacao.type === "characterData") {
            aplicarTexto(mutacao.target as Text);
            return;
          }

          if (mutacao.type === "attributes" && mutacao.target instanceof Element) {
            if (
              mutacao.attributeName &&
              atributosTraduziveis.includes(mutacao.attributeName)
            ) {
              aplicarAtributo(mutacao.target, mutacao.attributeName);
            }

            return;
          }

          mutacao.addedNodes.forEach((no) => aplicarNo(no));
        });
      } finally {
        aplicando = false;
      }
    });

    observador.observe(document.body, {
      subtree: true,
      childList: true,
      characterData: true,
      attributes: true,
      attributeFilter: atributosTraduziveis,
    });

    return () => {
      observador.disconnect();

      textosAlterados.forEach((no) => {
        const estado = estadosTexto.get(no);

        if (estado && no.isConnected && no.data === estado.traduzido) {
          no.data = estado.original;
        }
      });

      atributosAlterados.forEach((registro) => {
        const estado = estadosAtributos
          .get(registro.elemento)
          ?.get(registro.atributo);

        if (
          estado &&
          registro.elemento.isConnected &&
          registro.elemento.getAttribute(registro.atributo) === estado.traduzido
        ) {
          registro.elemento.setAttribute(registro.atributo, estado.original);
        }
      });
    };
  }, [language]);

  return null;
}

function normalizarAbaPerfilAutor(valor: string | null): AbaPerfilAutor {
  if (
    valor === "obras" ||
    valor === "diario" ||
    valor === "comunidade" ||
    valor === "sobre" ||
    valor === "biblioteca"
  ) {
    return valor;
  }

  return "obras";
}

type PerfilAutorSalvo = {
  avatar: string;
  avatarNome: string;
  bio: string;
  sobreBio: string;
  mostrarDestaques: boolean;
};

type AvaliacaoAutorPublica = {
  media: number;
  total: number;
  minhaNota: number;
  carregado: boolean;
  salvando: boolean;
};

type AvaliacaoDiarioPublica = AvaliacaoAutorPublica & {
  visivel: boolean;
  mostrar: boolean;
  podeAvaliar: boolean;
};

type DiarioPerfilItem = {
  chave: string;
  tipo:
    | "lendo"
    | "quero_ler"
    | "favorita"
    | "concluida"
    | "avaliacao"
    | "review"
    | "atividade";
  titulo: string;
  descricao: string;
  data: string;
  obra: ObraLocal | null;
  href?: string;
  nota?: number;
  progresso?: number;
  visibilidade?: VisibilidadeDiarioPerfil;
};

type DiarioPerfilEstado = {
  carregando: boolean;
  lendoAgora: DiarioPerfilItem[];
  queroLer: DiarioPerfilItem[];
  favoritas: DiarioPerfilItem[];
  concluidas: DiarioPerfilItem[];
  avaliacoes: DiarioPerfilItem[];
  reviews: DiarioPerfilItem[];
  atividades: DiarioPerfilItem[];
};

type DiarioPerfilResumoItem = DiarioPerfilItem & {
  tipos: DiarioPerfilItem["tipo"][];
};

type PublicacaoComunidadePerfil = {
  id: string;
  categoria: string;
  tipoPublicacao: string;
  temSpoiler: boolean;
  texto: string;
  obraRelacionada: string;
  criadoEm: string;
};

type ComunidadePerfilEstado = {
  carregando: boolean;
  erro: string;
  totalPublicacoes: number;
  totalTeorias: number;
  totalReviews: number;
  publicacoesRecentes: PublicacaoComunidadePerfil[];
};

type AlvoDenunciaConteudoPerfil = {
  alvoTipo: Extract<TipoAlvoDenuncia, "post" | "obra">;
  alvoId: string;
  alvoTitulo: string;
} | null;

type ItemBibliotecaPerfil = {
  chave: string;
  obra: ObraLocal;
  capitulo: CapituloLocal | null;
  numeroCapitulo: number;
  tempoAtividade: number;
  tipoDiario: DiarioPerfilItem["tipo"];
  descricao: string;
};

type VisibilidadeDiarioPerfil = "publico" | "parcial" | "privado";

const diarioPerfilVazio: DiarioPerfilEstado = {
  carregando: false,
  lendoAgora: [],
  queroLer: [],
  favoritas: [],
  concluidas: [],
  avaliacoes: [],
  reviews: [],
  atividades: [],
};

function aplicarPermissoesAbasAoDiario(
  diario: Omit<DiarioPerfilEstado, "carregando">,
  permissoes: PermissoesAbasPerfil,
): Omit<DiarioPerfilEstado, "carregando"> {
  return {
    lendoAgora: permissoes.diario ? diario.lendoAgora : [],
    queroLer: permissoes.diario ? diario.queroLer : [],
    favoritas: permissoes.diario ? diario.favoritas : [],
    concluidas: permissoes.diario ? diario.concluidas : [],
    avaliacoes: permissoes.diario ? diario.avaliacoes : [],
    reviews: permissoes.diario ? diario.reviews : [],
    atividades: permissoes.atividades ? diario.atividades : [],
  };
}


const avaliacaoAutorVazia: AvaliacaoAutorPublica = {
  media: 0,
  total: 0,
  minhaNota: 0,
  carregado: false,
  salvando: false,
};

const avaliacaoDiarioVazia: AvaliacaoDiarioPublica = {
  media: 0,
  total: 0,
  minhaNota: 0,
  carregado: false,
  salvando: false,
  visivel: false,
  mostrar: true,
  podeAvaliar: false,
};

function normalizarAvaliacaoDiarioPerfil(
  valor: unknown,
  estadoAnterior: AvaliacaoDiarioPublica = avaliacaoDiarioVazia,
): AvaliacaoDiarioPublica {
  const registro =
    valor && typeof valor === "object" && !Array.isArray(valor)
      ? (valor as Record<string, unknown>)
      : {};

  return {
    ...estadoAnterior,
    media: Math.max(0, Math.min(5, pegarNumero(registro.media, 0))),
    total: Math.max(0, Math.trunc(pegarNumero(registro.total, 0))),
    minhaNota: Math.max(
      0,
      Math.min(
        5,
        Math.round(
          pegarNumero(registro.minha_nota ?? registro.minhaNota, 0) * 2,
        ) / 2,
      ),
    ),
    carregado: true,
    salvando: false,
    visivel: pegarBooleano(registro.visivel, false),
    mostrar: pegarBooleano(
      registro.mostrar ?? registro.mostrar_avaliacao_diario,
      true,
    ),
    podeAvaliar: pegarBooleano(
      registro.pode_avaliar ?? registro.podeAvaliar,
      false,
    ),
  };
}


type TotaisInteracoesObrasPerfilAutor = {
  curtidasPorObra: Record<string, number>;
  comentariosPorObra: Record<string, number>;
  curtidasPorCapitulo: Record<string, number>;
  comentariosPorCapitulo: Record<string, number>;
  salvosPorObra: Record<string, number>;
  salvosPorCapitulo: Record<string, number>;
  concluidasPorObra: Record<string, number>;
};

const totaisInteracoesObrasPerfilVazio: TotaisInteracoesObrasPerfilAutor = {
  curtidasPorObra: {},
  comentariosPorObra: {},
  curtidasPorCapitulo: {},
  comentariosPorCapitulo: {},
  salvosPorObra: {},
  salvosPorCapitulo: {},
  concluidasPorObra: {},
};

type PerfisAutoresSalvos = Record<string, PerfilAutorSalvo>;

function normalizarNomeAutor(nome: string) {
  return nome.trim().replace(/\s+/g, " ").toLowerCase();
}

function normalizarUsernamePerfilAutor(valor: string) {
  return valor
    .trim()
    .replace(/^@+/, "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9._]+/g, ".")
    .replace(/[._]{2,}/g, ".")
    .replace(/^[._]+|[._]+$/g, "")
    .slice(0, 30);
}

function criarUsernameSugeridoPerfilAutor(nomeAutor: string, autorId: string) {
  const base = normalizarUsernamePerfilAutor(nomeAutor);
  const sufixo = autorId
    .replace(/[^a-z0-9]/gi, "")
    .slice(0, 4)
    .toLowerCase();

  if (base) {
    return base;
  }

  return sufixo ? `autor.${sufixo}` : "autor.historietas";
}

function criarChaveAutorPerfil(autorId: string, nomeAutor: string) {
  return autorId.trim().toLowerCase() || normalizarNomeAutor(nomeAutor);
}

function criarLoginHrefPerfilAutor() {
  const redirectTo =
    typeof window !== "undefined"
      ? `${window.location.pathname}${window.location.search}`
      : "/perfil-autor";
  const destinoSeguro =
    redirectTo && redirectTo.startsWith("/") && !redirectTo.startsWith("//")
      ? redirectTo
      : "/perfil-autor";
  const params = new URLSearchParams({
    redirectTo: destinoSeguro,
  });

  return `/login?${params.toString()}`;
}

function criarPerfilAutorHref(autor: string, autorId?: string) {
  const params = new URLSearchParams();
  const autorLimpo = autor.trim();
  const autorIdLimpo = autorId?.trim() || "";

  if (autorLimpo) {
    params.set("autor", autorLimpo);
  }

  if (autorIdLimpo) {
    params.set("autorId", autorIdLimpo);
    params.set("userId", autorIdLimpo);
  }

  const query = params.toString();

  return query ? `/perfil-autor?${query}` : "/perfil-autor";
}

function criarHrefListaSeguimentoPerfilAutor(
  aba: "seguidores" | "seguindo",
  perfil: Pick<AutorPerfil, "autorId" | "nome"> | null,
) {
  const params = new URLSearchParams();

  params.set("aba", aba);

  if (perfil?.autorId?.trim()) {
    params.set("userId", perfil.autorId.trim());
    params.set("autorId", perfil.autorId.trim());
  }

  if (perfil?.nome?.trim()) {
    params.set("autor", perfil.nome.trim());
  }

  return `/seguindo?${params.toString()}`;
}

function criarHandlePerfilAutor(
  nomeAutor: string,
  autorId: string,
  username = "",
) {
  const usernameLimpo = normalizarUsernamePerfilAutor(username);

  if (usernameLimpo) {
    return `@${usernameLimpo}`;
  }

  return `@${criarUsernameSugeridoPerfilAutor(nomeAutor, autorId)}`;
}

function criarHrefLeituraCapituloPerfilAutor(
  obra: Pick<ObraLocal, "id" | "slug" | "titulo" | "publicado">,
  capitulo: Pick<CapituloLocal, "id">,
  numeroCapitulo: number,
) {
  const slugSeguro = obra.slug?.trim() || criarSlugBase(obra.titulo);

  if (
    obra.publicado &&
    idObraSupabaseValido(obra.id) &&
    slugSeguro &&
    Number.isInteger(numeroCapitulo) &&
    numeroCapitulo > 0
  ) {
    return `/obra/${encodeURIComponent(slugSeguro)}/capitulo/${numeroCapitulo}`;
  }

  return `/ler-capitulo?obraId=${encodeURIComponent(
    obra.id,
  )}&capituloId=${encodeURIComponent(capitulo.id)}`;
}

function formatarGeneroPerfilAutor(genero: string) {
  const generoLimpo = genero.trim();
  const generoNormalizado = normalizarTexto(generoLimpo);

  if (generoNormalizado === "fantasia sombria") {
    return "Fantasia";
  }

  if (generoNormalizado === "sci-fi" || generoNormalizado === "sci fi") {
    return "Ficção";
  }

  return generoLimpo || "Não informado";
}

function formatarFormatoPerfilAutor(formato: string) {
  const formatoLimpo = formato.trim();

  if (
    !formatoLimpo ||
    normalizarTexto(formatoLimpo) === "nao informado" ||
    normalizarTexto(formatoLimpo) === "nao informada"
  ) {
    return "";
  }

  return formatoLimpo;
}

function obterTagPrincipalPerfilAutor(
  obra: Pick<ObraLocal, "tags" | "genero" | "formato">,
) {
  const generoNormalizado = normalizarTexto(obra.genero);
  const formatoNormalizado = normalizarTexto(obra.formato);

  return (obra.tags || [])
    .map((tag) => tag.trim())
    .find((tag) => {
      const tagNormalizada = normalizarTexto(tag);

      return (
        tag &&
        tagNormalizada !== "sem tags" &&
        tagNormalizada !== generoNormalizado &&
        tagNormalizada !== formatoNormalizado
      );
    }) || "";
}

function obterTimestampData(dataIso: string) {
  const data = new Date(dataIso).getTime();

  return Number.isNaN(data) ? 0 : data;
}

function normalizarNumeroPerfilAutor(valor: unknown, fallback = 0) {
  if (typeof valor === "number" && Number.isFinite(valor)) {
    return Math.max(0, Math.round(valor));
  }

  if (typeof valor === "string" && valor.trim()) {
    const numero = Number(valor.replace(/\./g, "").replace(",", "."));

    if (Number.isFinite(numero)) {
      return Math.max(0, Math.round(numero));
    }
  }

  return fallback;
}

function compactarNumeroPerfilAutor(valor: number) {
  const numero = Math.max(0, Math.round(valor));
  const locale = obterLocaleDocumentoPerfilAutor();
  const idiomaIngles = locale.startsWith("en");

  if (numero >= 1000000) {
    return `${(numero / 1000000).toLocaleString(locale, {
      maximumFractionDigits: 1,
    })} ${idiomaIngles ? "M" : "mi"}`;
  }

  if (numero >= 1000) {
    return `${(numero / 1000).toLocaleString(locale, {
      maximumFractionDigits: 1,
    })} ${idiomaIngles ? "K" : "mil"}`;
  }

  return String(numero);
}

function idAutorSupabaseValido(id: string) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id);
}

function formatarMediaAvaliacaoAutor(media: number) {
  if (!Number.isFinite(media) || media <= 0) {
    return "0";
  }

  const mediaArredondada = Math.round(media * 10) / 10;

  return Number.isInteger(mediaArredondada)
    ? String(mediaArredondada)
    : mediaArredondada.toFixed(1);
}

function formatarTotalAvaliacoesAutor(
  total: number,
  idioma: HistorietasLanguage,
) {
  const totalSeguro = Math.max(0, Math.trunc(total));

  if (idioma === "en") {
    return totalSeguro === 1 ? "1 rating" : `${totalSeguro || ""} ratings`.trim();
  }

  if (idioma === "es") {
    return totalSeguro === 1
      ? "1 valoración"
      : `${totalSeguro || ""} valoraciones`.trim();
  }

  if (totalSeguro <= 0) {
    return "avaliações";
  }

  return totalSeguro === 1 ? "1 avaliação" : `${totalSeguro} avaliações`;
}

function formatarTotalAvaliacoesDiario(
  total: number,
  idioma: HistorietasLanguage,
) {
  const totalSeguro = Math.max(0, Math.trunc(total));

  if (idioma === "en") {
    return totalSeguro === 1
      ? "1 Journal rating"
      : `${totalSeguro} Journal ratings`;
  }

  if (idioma === "es") {
    return `${totalSeguro} Val. Diario`;
  }

  return `${totalSeguro} Av. Diário`;
}

function formatarEntradaHistorietasPerfilAutor(criadoEm: string) {
  const criadoEmLimpo = criadoEm.trim();
  const dataCriacao = new Date(criadoEmLimpo);

  if (!criadoEmLimpo || Number.isNaN(dataCriacao.getTime())) {
    return new Intl.DateTimeFormat(obterLocaleDocumentoPerfilAutor(), {
      month: "long",
      year: "numeric",
    }).format(new Date(2026, 6, 1));
  }

  return new Intl.DateTimeFormat(obterLocaleDocumentoPerfilAutor(), {
    month: "long",
    year: "numeric",
  }).format(dataCriacao);
}

function obterProximaNotaAvaliacaoAutor(estrela: number, notaAtual: number) {
  const meiaNota = estrela - 0.5;
  const notaNormalizada = Math.round(notaAtual * 2) / 2;

  if (notaNormalizada === meiaNota) {
    return estrela;
  }

  if (notaNormalizada === estrela) {
    return 0;
  }

  return meiaNota;
}

function obterPreenchimentoEstrelaAutor(estrela: number, notaAtual: number) {
  const notaNormalizada = Math.max(0, Math.min(5, Math.round(notaAtual * 2) / 2));

  if (notaNormalizada >= estrela) {
    return "100%";
  }

  if (notaNormalizada >= estrela - 0.5) {
    return "50%";
  }

  return "0%";
}

function calcularProximaAvaliacaoAutor(
  avaliacaoAtual: AvaliacaoAutorPublica,
  novaNota: number,
): AvaliacaoAutorPublica {
  const notaAnterior = avaliacaoAtual.minhaNota;
  const totalAtual = avaliacaoAtual.total;
  const somaAtual = avaliacaoAtual.media * totalAtual;

  if (novaNota <= 0) {
    const totalNovo = notaAnterior > 0 ? Math.max(0, totalAtual - 1) : totalAtual;
    const somaNova = notaAnterior > 0 ? somaAtual - notaAnterior : somaAtual;

    return {
      ...avaliacaoAtual,
      media: totalNovo > 0 ? somaNova / totalNovo : 0,
      total: totalNovo,
      minhaNota: 0,
      carregado: true,
      salvando: false,
    };
  }

  const totalNovo = notaAnterior > 0 ? totalAtual : totalAtual + 1;
  const somaNova =
    notaAnterior > 0 ? somaAtual - notaAnterior + novaNota : somaAtual + novaNota;

  return {
    ...avaliacaoAtual,
    media: totalNovo > 0 ? somaNova / totalNovo : 0,
    total: totalNovo,
    minhaNota: novaNota,
    carregado: true,
    salvando: false,
  };
}

function obterChaveAvaliacaoAutor(perfil: Pick<AutorPerfil, "autorId" | "nome">) {
  return criarChaveAutorPerfil(perfil.autorId, perfil.nome);
}

function carregarAvaliacoesAutoresLocais(userId = "") {
  if (typeof window === "undefined") {
    return {};
  }

  try {
    const avaliacoesJson: unknown =
      carregarJsonUsuarioPerfilAutor(AUTHOR_RATINGS_STORAGE_KEY, userId) || {};

    if (
      !avaliacoesJson ||
      typeof avaliacoesJson !== "object" ||
      Array.isArray(avaliacoesJson)
    ) {
      return {};
    }

    return avaliacoesJson as Record<string, unknown>;
  } catch {
    return {};
  }
}

function obterAvaliacaoAutorLocal(
  perfil: Pick<AutorPerfil, "autorId" | "nome">,
  userId = "",
) {
  const chaveAvaliacao = obterChaveAvaliacaoAutor(perfil);
  const avaliacoesLocais = carregarAvaliacoesAutoresLocais(userId);
  const nota = Number(avaliacoesLocais[chaveAvaliacao]);

  return Number.isFinite(nota) && nota >= 0.5 && nota <= 5
    ? Math.round(nota * 2) / 2
    : 0;
}

function salvarAvaliacaoAutorLocal(
  perfil: Pick<AutorPerfil, "autorId" | "nome">,
  nota: number,
  userId = "",
) {
  if (typeof window === "undefined" || !userId.trim()) {
    return;
  }

  try {
    const chaveAvaliacao = obterChaveAvaliacaoAutor(perfil);

    if (!chaveAvaliacao) {
      return;
    }

    const avaliacoesLocais = carregarAvaliacoesAutoresLocais(userId);

    if (nota <= 0) {
      delete avaliacoesLocais[chaveAvaliacao];
    } else {
      avaliacoesLocais[chaveAvaliacao] = nota;
    }

    salvarJsonUsuarioPerfilAutor(
      AUTHOR_RATINGS_STORAGE_KEY,
      userId,
      avaliacoesLocais,
    );
  } catch {
    // Avaliação local é fallback e não deve travar o perfil.
  }
}

function calcularProgressoLeitura(capitulos: CapituloLocal[]) {
  if (capitulos.length === 0) {
    return 0;
  }

  const capitulosLidos = capitulos.filter((capitulo) => capitulo.lido).length;

  return Math.round((capitulosLidos / capitulos.length) * 100);
}

function normalizarCapitulo(
  capitulo: Partial<CapituloLocal>,
  capituloIndex: number,
  obraIndex: number,
): CapituloLocal {
  return {
    id:
      typeof capitulo.id === "string" && capitulo.id.trim()
        ? capitulo.id
        : `capitulo-${obraIndex + 1}-${capituloIndex + 1}`,
    titulo:
      typeof capitulo.titulo === "string" && capitulo.titulo.trim()
        ? capitulo.titulo
        : "Capítulo sem título",
    texto: typeof capitulo.texto === "string" ? capitulo.texto : "",
    curtiu: Boolean(capitulo.curtiu),
    salvo: Boolean(capitulo.salvo),
    comentario:
      typeof capitulo.comentario === "string" ? capitulo.comentario : "",
    criadoEm: typeof capitulo.criadoEm === "string" ? capitulo.criadoEm : "",
    lido: Boolean(capitulo.lido),
    lidoEm: typeof capitulo.lidoEm === "string" ? capitulo.lidoEm : "",
  };
}

function normalizarArquivoObra(valor: unknown): ArquivoObraLocal | null {
  if (!valor || typeof valor !== "object" || Array.isArray(valor)) {
    return null;
  }

  const arquivo = valor as Partial<ArquivoObraLocal>;

  if (
    typeof arquivo.nome !== "string" ||
    !arquivo.nome.trim() ||
    typeof arquivo.conteudo !== "string" ||
    !arquivo.conteudo.trim()
  ) {
    return null;
  }

  let categoria: ArquivoObraLocal["categoria"] = "outro";

  if (
    arquivo.categoria === "texto" ||
    arquivo.categoria === "documento" ||
    arquivo.categoria === "imagem" ||
    arquivo.categoria === "outro"
  ) {
    categoria = arquivo.categoria;
  }

  return {
    nome: arquivo.nome.trim(),
    tipo: typeof arquivo.tipo === "string" ? arquivo.tipo : "",
    tamanho:
      typeof arquivo.tamanho === "number" && Number.isFinite(arquivo.tamanho)
        ? arquivo.tamanho
        : 0,
    conteudo: arquivo.conteudo,
    categoria,
    criadoEm: typeof arquivo.criadoEm === "string" ? arquivo.criadoEm : "",
  };
}

function normalizarObra(obra: ObraSalva, obraIndex: number): ObraLocal {
  const capitulosNormalizados: CapituloLocal[] = Array.isArray(obra.capitulos)
    ? obra.capitulos.map((capitulo, capituloIndex) =>
        normalizarCapitulo(capitulo, capituloIndex, obraIndex),
      )
    : [];

  const tagsNormalizadas = Array.isArray(obra.tags)
    ? obra.tags
        .filter(
          (tag): tag is string =>
            typeof tag === "string" && Boolean(tag.trim()),
        )
        .map((tag) => tag.trim())
    : [];

  return {
    id:
      typeof obra.id === "string" && obra.id.trim()
        ? obra.id
        : `obra-${obraIndex + 1}`,
    titulo:
      typeof obra.titulo === "string" && obra.titulo.trim()
        ? obra.titulo
        : "Obra sem título",
    autorId:
      typeof obra.autorId === "string" && obra.autorId.trim()
        ? obra.autorId.trim()
        : typeof obra.user_id === "string" && obra.user_id.trim()
          ? obra.user_id.trim()
          : typeof obra.autor_id === "string" && obra.autor_id.trim()
            ? obra.autor_id.trim()
            : "",
    autor:
      typeof obra.autor === "string" && obra.autor.trim()
        ? obra.autor
        : "Autor não informado",
    genero:
      typeof obra.genero === "string" && obra.genero.trim()
        ? obra.genero
        : "Não informado",
    formato:
      typeof obra.formato === "string" && obra.formato.trim()
        ? obra.formato
        : "Não informado",
    classificacaoIndicativa:
      typeof obra.classificacaoIndicativa === "string" &&
      obra.classificacaoIndicativa.trim()
        ? obra.classificacaoIndicativa
        : "Não informada",
    sinopse:
      typeof obra.sinopse === "string" && obra.sinopse.trim()
        ? obra.sinopse
        : "Nenhuma sinopse informada.",
    tags: tagsNormalizadas.length > 0 ? tagsNormalizadas : ["sem tags"],
    capa: typeof obra.capa === "string" ? obra.capa : "",
    capaNome: typeof obra.capaNome === "string" ? obra.capaNome : "",
    arquivoObra: normalizarArquivoObra(obra.arquivoObra),
    publicado: Boolean(obra.publicado),
    capitulos: capitulosNormalizados,
    criadaEm: typeof obra.criadaEm === "string" ? obra.criadaEm : "",
    ultimoCapituloLidoId:
      typeof obra.ultimoCapituloLidoId === "string"
        ? obra.ultimoCapituloLidoId
        : "",
    ultimaLeituraEm:
      typeof obra.ultimaLeituraEm === "string" ? obra.ultimaLeituraEm : "",
    progressoLeitura: calcularProgressoLeitura(capitulosNormalizados),
    visualizacoes: normalizarNumeroPerfilAutor(
      obra.visualizacoes ??
        obra.views ??
        obra.visualizacoesTotal ??
        obra.totalVisualizacoes ??
        obra.total_visualizacoes,
    ),
    slug:
      typeof obra.slug === "string" && obra.slug.trim()
        ? obra.slug
        : criarSlugBase(
            typeof obra.titulo === "string" && obra.titulo.trim()
              ? obra.titulo
              : `obra-${obraIndex + 1}`,
          ),
    link:
      typeof obra.link === "string" && obra.link.trim()
        ? obra.link
        : `/obra/${
            typeof obra.slug === "string" && obra.slug.trim()
              ? obra.slug
              : criarSlugBase(
                  typeof obra.titulo === "string" && obra.titulo.trim()
                    ? obra.titulo
                    : `obra-${obraIndex + 1}`,
                )
          }`,
  };
}

function mostrarClassificacao(obra: ObraLocal) {
  return (
    obra.classificacaoIndicativa &&
    obra.classificacaoIndicativa !== "Não informada" &&
    obra.classificacaoIndicativa !== "Não informado"
  );
}

function normalizarUsuarioIdPerfilAutor(valor: string) {
  return valor.trim().toLowerCase();
}

function obraPertenceAoUsuarioPerfilAutor(obra: ObraLocal, userId: string) {
  const userIdNormalizado = normalizarUsuarioIdPerfilAutor(userId);
  const autorIdNormalizado = normalizarUsuarioIdPerfilAutor(obra.autorId || "");

  return Boolean(userIdNormalizado && autorIdNormalizado === userIdNormalizado);
}

function filtrarObrasLocaisDoUsuarioPerfilAutor(
  obrasLocais: ObraLocal[],
  userId: string,
) {
  const userIdNormalizado = normalizarUsuarioIdPerfilAutor(userId);

  if (!userIdNormalizado) {
    return [] as ObraLocal[];
  }

  return obrasLocais.filter((obra) =>
    obraPertenceAoUsuarioPerfilAutor(obra, userIdNormalizado),
  );
}

function mesclarObrasLocalStoragePerfilAutor(
  obrasLocaisOriginais: ObraLocal[],
  obrasAtualizadasDoUsuario: ObraLocal[],
  userId: string,
) {
  const userIdNormalizado = normalizarUsuarioIdPerfilAutor(userId);

  if (!userIdNormalizado) {
    return obrasLocaisOriginais;
  }

  const obrasDeOutrasContas = obrasLocaisOriginais.filter(
    (obra) => !obraPertenceAoUsuarioPerfilAutor(obra, userIdNormalizado),
  );

  return [...obrasAtualizadasDoUsuario, ...obrasDeOutrasContas];
}


function normalizarPerfisAutores(valor: unknown): PerfisAutoresSalvos {
  if (!valor || typeof valor !== "object" || Array.isArray(valor)) {
    return {};
  }

  const perfisValidos: PerfisAutoresSalvos = {};

  Object.entries(valor as Record<string, Partial<PerfilAutorSalvo>>).forEach(
    ([autor, perfil]) => {
      if (!autor.trim() || !perfil || typeof perfil !== "object") {
        return;
      }

      perfisValidos[normalizarNomeAutor(autor)] = {
        avatar: typeof perfil.avatar === "string" ? perfil.avatar : "",
        avatarNome:
          typeof perfil.avatarNome === "string" ? perfil.avatarNome : "",
        bio:
          typeof perfil.bio === "string"
            ? perfil.bio.slice(0, BIO_MAX_LENGTH)
            : "",
        sobreBio:
          typeof perfil.sobreBio === "string"
            ? perfil.sobreBio.slice(0, SOBRE_BIO_MAX_LENGTH)
            : "",
        mostrarDestaques: perfil.mostrarDestaques === true,
      };
    },
  );

  return perfisValidos;
}

function carregarPerfisAutores(userId = ""): PerfisAutoresSalvos {
  const userIdLimpo = userId.trim();

  if (typeof window === "undefined" || !userIdLimpo) {
    return {};
  }

  try {
    const perfis =
      carregarJsonUsuarioPerfilAutor(AUTHOR_PROFILE_STORAGE_KEY, userIdLimpo) ||
      {};
    const perfisNormalizados = normalizarPerfisAutores(perfis);

    salvarJsonUsuarioPerfilAutor(
      AUTHOR_PROFILE_STORAGE_KEY,
      userIdLimpo,
      perfisNormalizados,
    );

    return perfisNormalizados;
  } catch {
    salvarJsonUsuarioPerfilAutor(AUTHOR_PROFILE_STORAGE_KEY, userIdLimpo, {});
    return {};
  }
}

function criarBioAutor(perfil: AutorPerfil) {
  if (perfil.obras.length === 0) {
    return `${perfil.nome} participa da Historietas como leitor, com Diário, comunidade e atividades de leitura.`;
  }

  const generos = Array.from(
    new Set(
      perfil.obras
        .map((obra) => formatarGeneroPerfilAutor(obra.genero))
        .filter((genero) => genero && genero !== "Não informado"),
    ),
  );

  const generosTexto =
    generos.length > 0 ? generos.slice(0, 3).join(", ") : "histórias variadas";

  return `${perfil.nome} publica histórias na Historietas, com foco em ${generosTexto}.`;
}

function encontrarCapituloParaContinuar(obra: ObraLocal) {
  const indiceUltimoCapituloLido = obra.ultimoCapituloLidoId
    ? obra.capitulos.findIndex(
        (capitulo) => capitulo.id === obra.ultimoCapituloLidoId,
      )
    : -1;

  if (indiceUltimoCapituloLido >= 0) {
    const proximoCapituloNaoLido = obra.capitulos
      .slice(indiceUltimoCapituloLido + 1)
      .find((capitulo) => !capitulo.lido);

    if (proximoCapituloNaoLido) {
      return proximoCapituloNaoLido;
    }
  }

  return (
    obra.capitulos.find((capitulo) => !capitulo.lido) ||
    obra.capitulos[obra.capitulos.length - 1] ||
    null
  );
}


function criarStorageKeyUsuarioPerfilBiblioteca(chave: string, userId: string) {
  const userIdLimpo = userId.trim();

  return userIdLimpo ? `${chave}:${userIdLimpo}` : "";
}

function normalizarListaIdsPerfilBiblioteca(valor: unknown) {
  return Array.isArray(valor)
    ? valor.filter((id): id is string => typeof id === "string" && Boolean(id.trim()))
    : [];
}

function carregarListaIdsPerfilBiblioteca(chave: string, userId = "") {
  const userIdLimpo = userId.trim();

  if (typeof window === "undefined" || !userIdLimpo) {
    return [] as string[];
  }

  try {
    const chaveParaLer = criarStorageKeyUsuarioPerfilBiblioteca(chave, userIdLimpo);
    const listaTexto = localStorage.getItem(chaveParaLer);
    const lista = normalizarListaIdsPerfilBiblioteca(
      listaTexto ? JSON.parse(listaTexto) : [],
    );

    return Array.from(new Set(lista));
  } catch {
    return [] as string[];
  }
}

function salvarListaIdsPerfilBiblioteca(
  chave: string,
  userId: string,
  lista: string[],
) {
  const userIdLimpo = userId.trim();

  if (typeof window === "undefined" || !userIdLimpo) {
    return;
  }

  const listaNormalizada = normalizarListaIdsPerfilBiblioteca(lista);

  try {
    localStorage.setItem(
      criarStorageKeyUsuarioPerfilBiblioteca(chave, userIdLimpo),
      JSON.stringify(listaNormalizada),
    );
  } catch {
    // A Biblioteca continua funcionando em memória se o armazenamento local falhar.
  }
}

function carregarJsonUsuarioPerfilAutor(chave: string, userId = "") {
  const userIdLimpo = userId.trim();

  if (typeof window === "undefined" || !userIdLimpo) {
    return null;
  }

  try {
    const texto = localStorage.getItem(
      criarStorageKeyUsuarioPerfilBiblioteca(chave, userIdLimpo),
    );

    return texto ? JSON.parse(texto) : null;
  } catch {
    return null;
  }
}

function salvarJsonUsuarioPerfilAutor(chave: string, userId: string, valor: unknown) {
  const userIdLimpo = userId.trim();

  if (typeof window === "undefined" || !userIdLimpo) {
    return;
  }

  try {
    localStorage.setItem(
      criarStorageKeyUsuarioPerfilBiblioteca(chave, userIdLimpo),
      JSON.stringify(valor),
    );
  } catch {
    // localStorage é apoio; a tela segue com o estado em memória.
  }
}

function obterIdentificadoresObraPerfilBiblioteca(
  obra: Pick<ObraLocal, "id" | "slug" | "titulo">,
) {
  return Array.from(
    new Set(
      [
        obra.id,
        obra.slug,
        criarSlugBase(obra.titulo),
        normalizarTexto(obra.titulo),
      ].filter((valor): valor is string => typeof valor === "string" && Boolean(valor.trim())),
    ),
  );
}

function colecaoTemObraPerfilBiblioteca(
  colecao: string[],
  obra: Pick<ObraLocal, "id" | "slug" | "titulo">,
) {
  const idsColecao = new Set(colecao.filter((id) => typeof id === "string"));

  return obterIdentificadoresObraPerfilBiblioteca(obra).some((identificador) =>
    idsColecao.has(identificador),
  );
}

function removerObraDaColecaoPerfilBiblioteca(
  colecao: string[],
  obra: Pick<ObraLocal, "id" | "slug" | "titulo">,
) {
  const identificadores = new Set(obterIdentificadoresObraPerfilBiblioteca(obra));

  return colecao.filter((id) => !identificadores.has(id));
}

function carregarTopFivePerfilAutor(userId = "") {
  if (typeof window === "undefined" || !userId.trim()) {
    return [] as string[];
  }

  try {
    const topFiveSalvo = carregarJsonUsuarioPerfilAutor(
      TOP_FIVE_STORAGE_KEY,
      userId,
    );

    return Array.isArray(topFiveSalvo)
      ? Array.from(
          new Set(
            topFiveSalvo.filter(
              (id): id is string =>
                typeof id === "string" && Boolean(id.trim()),
            ),
          ),
        ).slice(0, TOP_FIVE_MAXIMO)
      : [];
  } catch {
    return [] as string[];
  }
}

function encontrarObraPorIdentificadorTopFivePerfil(
  obrasDisponiveis: ObraLocal[],
  identificador: string,
) {
  const identificadorLimpo = identificador.trim();

  if (!identificadorLimpo) {
    return null;
  }

  return (
    obrasDisponiveis.find((obra) =>
      obterIdentificadoresObraPerfilBiblioteca(obra).includes(
        identificadorLimpo,
      ),
    ) || null
  );
}

function criarChaveCurtidaTopFivePerfil(perfilUserId: string) {
  return perfilUserId.trim().toLowerCase();
}

function normalizarCurtidasTopFiveLocais(valor: unknown) {
  const curtidasNormalizadas: Record<string, string[]> = {};

  if (!valor || typeof valor !== "object" || Array.isArray(valor)) {
    return curtidasNormalizadas;
  }

  Object.entries(valor as Record<string, unknown>).forEach(([perfilId, curtidas]) => {
    if (!perfilId.trim() || !Array.isArray(curtidas)) {
      return;
    }

    curtidasNormalizadas[criarChaveCurtidaTopFivePerfil(perfilId)] = Array.from(
      new Set(
        curtidas
          .filter((usuarioId): usuarioId is string =>
            typeof usuarioId === "string" && Boolean(usuarioId.trim()),
          )
          .map((usuarioId) => usuarioId.trim().toLowerCase()),
      ),
    );
  });

  return curtidasNormalizadas;
}

function carregarCurtidasTopFiveLocais(
  perfilUserId: string,
  usuarioId = "",
) {
  const chavePerfil = criarChaveCurtidaTopFivePerfil(perfilUserId);
  const usuarioIdNormalizado = usuarioId.trim().toLowerCase();

  if (!chavePerfil || !usuarioIdNormalizado) {
    return { total: 0, curtiu: false };
  }

  try {
    const curtidasJson = carregarJsonUsuarioPerfilAutor(
      TOP_FIVE_LIKES_STORAGE_KEY,
      usuarioIdNormalizado,
    );
    const curtidasPorPerfil = normalizarCurtidasTopFiveLocais(curtidasJson);
    const curtidasPerfil = curtidasPorPerfil[chavePerfil] || [];

    return {
      total: curtidasPerfil.length,
      curtiu: Boolean(
        usuarioIdNormalizado && curtidasPerfil.includes(usuarioIdNormalizado),
      ),
    };
  } catch {
    return { total: 0, curtiu: false };
  }
}

function salvarCurtidaTopFiveLocal(
  perfilUserId: string,
  usuarioId: string,
  curtir: boolean,
) {
  const chavePerfil = criarChaveCurtidaTopFivePerfil(perfilUserId);
  const usuarioIdNormalizado = usuarioId.trim().toLowerCase();

  if (!chavePerfil || !usuarioIdNormalizado) {
    return;
  }

  try {
    const curtidasJson = carregarJsonUsuarioPerfilAutor(
      TOP_FIVE_LIKES_STORAGE_KEY,
      usuarioIdNormalizado,
    );
    const curtidasPorPerfil = normalizarCurtidasTopFiveLocais(curtidasJson);
    const curtidasAtuais = curtidasPorPerfil[chavePerfil] || [];
    const curtidasSemUsuario = curtidasAtuais.filter(
      (curtidaUsuarioId) => curtidaUsuarioId !== usuarioIdNormalizado,
    );

    curtidasPorPerfil[chavePerfil] = curtir
      ? [...curtidasSemUsuario, usuarioIdNormalizado]
      : curtidasSemUsuario;

    salvarJsonUsuarioPerfilAutor(
      TOP_FIVE_LIKES_STORAGE_KEY,
      usuarioIdNormalizado,
      curtidasPorPerfil,
    );
  } catch {
    // Curtida local é fallback e não deve travar o perfil.
  }
}

async function carregarCurtidasTopFivePerfil(
  perfilUserId: string,
  usuarioId = "",
) {
  const estadoLocal = carregarCurtidasTopFiveLocais(perfilUserId, usuarioId);
  const perfilUserIdLimpo = perfilUserId.trim();
  const usuarioIdLimpo = usuarioId.trim();

  if (!idAutorSupabaseValido(perfilUserIdLimpo)) {
    return estadoLocal;
  }

  try {
    const { count, error } = await supabase
      .from("top5_curtidas")
      .select("perfil_user_id", { count: "exact", head: true })
      .eq("perfil_user_id", perfilUserIdLimpo);

    if (error) {
      return estadoLocal;
    }

    let curtiu = estadoLocal.curtiu;

    if (usuarioIdLimpo && idAutorSupabaseValido(usuarioIdLimpo)) {
      const { data: minhaCurtida, error: erroMinhaCurtida } = await supabase
        .from("top5_curtidas")
        .select("perfil_user_id")
        .eq("perfil_user_id", perfilUserIdLimpo)
        .eq("usuario_id", usuarioIdLimpo)
        .limit(1)
        .maybeSingle();

      if (!erroMinhaCurtida) {
        curtiu = estadoLocal.curtiu || Boolean(minhaCurtida);
      }
    }

    return {
      total: Math.max(count ?? 0, estadoLocal.total),
      curtiu,
    };
  } catch {
    return estadoLocal;
  }
}

async function salvarCurtidaTopFiveSupabase(
  perfilUserId: string,
  usuarioId: string,
  curtir: boolean,
) {
  const perfilUserIdLimpo = perfilUserId.trim();
  const usuarioIdLimpo = usuarioId.trim();

  if (
    !idAutorSupabaseValido(perfilUserIdLimpo) ||
    !idAutorSupabaseValido(usuarioIdLimpo)
  ) {
    return false;
  }

  try {
    const { error: erroDelete } = await supabase
      .from("top5_curtidas")
      .delete()
      .eq("perfil_user_id", perfilUserIdLimpo)
      .eq("usuario_id", usuarioIdLimpo);

    if (erroDelete) {
      return false;
    }

    if (!curtir) {
      return true;
    }

    const { error: erroInsert } = await supabase
      .from("top5_curtidas")
      .insert({
        perfil_user_id: perfilUserIdLimpo,
        usuario_id: usuarioIdLimpo,
      });

    return !erroInsert;
  } catch {
    return false;
  }
}

function obterTempoAtividadeBibliotecaPerfil(obra: ObraLocal) {
  const tempos = [
    obterTimestampData(obra.ultimaLeituraEm),
    obterTimestampData(obra.criadaEm),
    ...obra.capitulos.map((capitulo) =>
      Math.max(
        obterTimestampData(capitulo.lidoEm),
        obterTimestampData(capitulo.criadoEm),
      ),
    ),
  ];

  return Math.max(0, ...tempos);
}

function obterCapituloBibliotecaPerfil(obra: ObraLocal) {
  return (
    obra.capitulos.find((capitulo) => capitulo.salvo) ||
    encontrarCapituloParaContinuar(obra) ||
    obra.capitulos.find((capitulo) => capitulo.lido) ||
    obra.capitulos[0] ||
    null
  );
}


function converterItensDiarioParaBiblioteca(
  itens: DiarioPerfilItem[],
  prefixo: string,
): ItemBibliotecaPerfil[] {
  const itensPorObra = new Map<string, ItemBibliotecaPerfil>();

  [...itens]
    .sort(
      (itemA, itemB) =>
        obterTimestampData(itemB.data) - obterTimestampData(itemA.data),
    )
    .forEach((item) => {
      const obra = item.obra;

      if (!obra) {
        return;
      }

      const chaveObra =
        obra.id.trim() ||
        obra.slug.trim() ||
        normalizarTexto(obra.titulo);

      if (!chaveObra || itensPorObra.has(chaveObra)) {
        return;
      }

      const capitulo =
        item.tipo === "lendo"
          ? encontrarCapituloParaContinuar(obra)
          : obterCapituloBibliotecaPerfil(obra);
      const numeroCapitulo = capitulo
        ? obra.capitulos.findIndex(
            (capituloObra) => capituloObra.id === capitulo.id,
          ) + 1
        : 0;

      itensPorObra.set(chaveObra, {
        chave: `${prefixo}-${item.chave}`,
        obra,
        capitulo,
        numeroCapitulo: Math.max(0, numeroCapitulo),
        tempoAtividade:
          obterTimestampData(item.data) ||
          obterTempoAtividadeBibliotecaPerfil(obra),
        tipoDiario: item.tipo,
        descricao: item.descricao,
      });
    });

  return Array.from(itensPorObra.values()).sort(
    (itemA, itemB) => itemB.tempoAtividade - itemA.tempoAtividade,
  );
}

function converterCapitulosSalvosParaBiblioteca(
  obrasDisponiveis: ObraLocal[],
): ItemBibliotecaPerfil[] {
  const itens: ItemBibliotecaPerfil[] = [];

  obrasDisponiveis.forEach((obra) => {
    obra.capitulos.forEach((capitulo, capituloIndex) => {
      if (!capitulo.salvo) {
        return;
      }

      itens.push({
        chave: `salvo-${obra.id || obra.slug}-${capitulo.id}`,
        obra,
        capitulo,
        numeroCapitulo: capituloIndex + 1,
        tempoAtividade:
          obterTimestampData(capitulo.lidoEm) ||
          obterTimestampData(capitulo.criadoEm) ||
          obterTempoAtividadeBibliotecaPerfil(obra),
        tipoDiario: "quero_ler",
        descricao: "Capítulo salvo na Biblioteca",
      });
    });
  });

  return itens.sort(
    (itemA, itemB) => itemB.tempoAtividade - itemA.tempoAtividade,
  );
}

function mesclarItensBibliotecaPerfil(
  ...listas: ItemBibliotecaPerfil[][]
): ItemBibliotecaPerfil[] {
  const itensPorChave = new Map<string, ItemBibliotecaPerfil>();

  listas.flat().forEach((item) => {
    const chave =
      item.capitulo?.id.trim()
        ? `${item.obra.id || item.obra.slug}::${item.capitulo.id}`
        : item.obra.id || item.obra.slug || normalizarTexto(item.obra.titulo);

    if (!chave || itensPorChave.has(chave)) {
      return;
    }

    itensPorChave.set(chave, item);
  });

  return Array.from(itensPorChave.values()).sort(
    (itemA, itemB) => itemB.tempoAtividade - itemA.tempoAtividade,
  );
}


function criarCapaBibliotecaPerfilStyle(capa: string, desktop: boolean): CSSProperties {
  const baseStyle = desktop
    ? profileLibraryCoverDesktopStyle
    : profileLibraryCoverStyle;

  if (!capa) {
    return baseStyle;
  }

  return {
    ...baseStyle,
    background: "var(--historietas-perfil-bg-deep, #04000A)",
    backgroundImage: `url(${capa})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
  };
}


function criarCoverStyle(capa: string): CSSProperties {
  if (!capa) {
    return coverStyle;
  }

  return {
    ...coverStyle,
    backgroundImage: `linear-gradient(180deg, rgba(0,0,0,0.02) 0%, rgba(0,0,0,0.24) 100%), url(${capa})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
  };
}

function criarCoverStyleDesktop(capa: string): CSSProperties {
  return {
    ...criarCoverStyle(capa),
    minHeight: "180px",
    borderRadius: "20px",
  };
}

function criarCapaGridPerfilAutor(
  capa: string,
  desktop: boolean,
): CSSProperties {
  const estiloBase = desktop
    ? desktopProfileWorkCoverStyle
    : profileWorkCoverStyle;

  if (!capa) {
    return estiloBase;
  }

  return {
    ...estiloBase,
    backgroundImage: `url(${capa})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
  };
}

function criarCapaDestaquePerfilAutor(capa: string): CSSProperties {
  if (!capa) {
    return authorHighlightCoverStyle;
  }

  return {
    ...authorHighlightCoverStyle,
    backgroundImage: `url(${capa})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
  };
}

function criarCapaMiniCardDiarioPerfilStyle(capa: string): CSSProperties {
  if (!capa) {
    return diarySummaryCoverStyle;
  }

  return {
    ...diarySummaryCoverStyle,
    backgroundImage: `url(${capa})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
  };
}

type SupabaseObraRow = Record<string, unknown>;
type SupabaseCapituloRow = Record<string, unknown>;

function pegarTexto(valor: unknown, fallback = "") {
  return typeof valor === "string" && valor.trim() ? valor.trim() : fallback;
}

function normalizarPerfilUsuarioSupabase(
  row: Record<string, unknown> | null,
  userIdFallback: string,
  nomeFallback: string,
): PerfilUsuarioRemoto {
  const userId =
    pegarTexto(row?.user_id) ||
    pegarTexto(row?.id) ||
    userIdFallback.trim();

  const nome =
    pegarTexto(row?.nome) ||
    pegarTexto(row?.nome_usuario) ||
    pegarTexto(row?.username) ||
    pegarTexto(row?.display_name) ||
    pegarTexto(row?.apelido) ||
    nomeFallback.trim() ||
    "Usuário";

  const username = normalizarUsernamePerfilAutor(pegarTexto(row?.username));

  const avatar =
    pegarTexto(row?.avatar_url) ||
    pegarTexto(row?.avatar) ||
    pegarTexto(row?.foto_url) ||
    pegarTexto(row?.imagem_url) ||
    pegarTexto(row?.photo_url);

  const bio =
    pegarTexto(row?.bio) ||
    pegarTexto(row?.sobre) ||
    pegarTexto(row?.descricao) ||
    "Perfil de leitor no Historietas.";

  const sobreBio =
    pegarTexto(row?.sobre_bio) ||
    pegarTexto(row?.sobreBio) ||
    pegarTexto(row?.sobre) ||
    pegarTexto(row?.descricao) ||
    bio;

  return {
    userId,
    nome: nome.slice(0, 80),
    username,
    avatar,
    bio: bio.slice(0, BIO_MAX_LENGTH),
    sobreBio: sobreBio.slice(0, SOBRE_BIO_MAX_LENGTH),
    criadoEm: pegarTexto(row?.created_at ?? row?.criado_em),
  };
}

async function carregarPerfilUsuarioSupabase(
  userId: string,
  nomeFallback: string,
): Promise<PerfilUsuarioRemoto | null> {
  const userIdLimpo = userId.trim();

  if (!userIdLimpo || !idAutorSupabaseValido(userIdLimpo)) {
    return null;
  }

  const selecoesPerfil = [
    "id,user_id,nome,avatar_url,bio,sobre_bio,criado_em",
    "id,user_id,nome,avatar_url,bio,sobre_bio",
    "id,user_id,nome,avatar_url,bio",
  ];

  async function buscarPerfilPorCampo(campo: "user_id" | "id") {
    for (const selecao of selecoesPerfil) {
      try {
        const { data, error } = await supabase
          .from("profiles")
          .select(selecao)
          .eq(campo, userIdLimpo)
          .limit(1)
          .maybeSingle();

        if (error) {
          continue;
        }

        if (data && typeof data === "object" && !Array.isArray(data)) {
          const perfilBase = data as Record<string, unknown>;

          try {
            const { data: usernameData, error: usernameError } = await supabase
              .from("profiles")
              .select("username")
              .eq(campo, userIdLimpo)
              .limit(1)
              .maybeSingle();

            if (
              !usernameError &&
              usernameData &&
              typeof usernameData === "object" &&
              !Array.isArray(usernameData)
            ) {
              return {
                ...perfilBase,
                username: pegarTexto(
                  (usernameData as Record<string, unknown>).username,
                ),
              };
            }
          } catch {
            // Username é opcional em bancos antigos.
          }

          return perfilBase;
        }

        return null;
      } catch {
        // Tenta uma seleção mais compatível ou o próximo identificador.
      }
    }

    return null;
  }

  const perfilPorUserId = await buscarPerfilPorCampo("user_id");
  const perfilEncontrado =
    perfilPorUserId || (await buscarPerfilPorCampo("id"));

  return normalizarPerfilUsuarioSupabase(
    perfilEncontrado,
    userIdLimpo,
    nomeFallback,
  );
}

async function salvarPerfilUsuarioSupabase({
  userId,
  nome,
  perfil,
  username,
}: {
  userId: string;
  nome: string;
  perfil: PerfilAutorSalvo;
  username?: string | null;
}) {
  const userIdLimpo = userId.trim();

  if (!userIdLimpo || !idAutorSupabaseValido(userIdLimpo)) {
    return { ok: false, erro: "ID de usuário inválido para salvar perfil." };
  }

  const atualizadoEm = new Date().toISOString();
  const payloadPerfilBase: Record<string, unknown> = {
    nome: nome.trim() || "Usuário",
    avatar_url: perfil.avatar,
    bio: perfil.bio.slice(0, BIO_MAX_LENGTH),
    sobre_bio: perfil.sobreBio.slice(0, SOBRE_BIO_MAX_LENGTH),
    atualizado_em: atualizadoEm,
  };
  const usernameNormalizado =
    username === undefined
      ? undefined
      : username === null
        ? null
        : normalizarUsernamePerfilAutor(username);

  function erroIndicaUsernameAusente(mensagem: string) {
    const mensagemNormalizada = mensagem.toLowerCase();

    return (
      mensagemNormalizada.includes("username") &&
      (
        mensagemNormalizada.includes("column") ||
        mensagemNormalizada.includes("schema cache") ||
        mensagemNormalizada.includes("does not exist") ||
        mensagemNormalizada.includes("could not find")
      )
    );
  }

  try {
    let perfilId = "";

    try {
      const { data: perfilPorUserId, error: erroUserId } = await supabase
        .from("profiles")
        .select("id")
        .eq("user_id", userIdLimpo)
        .limit(1)
        .maybeSingle();

      if (
        !erroUserId &&
        perfilPorUserId &&
        typeof perfilPorUserId === "object" &&
        !Array.isArray(perfilPorUserId)
      ) {
        perfilId = pegarTexto(
          (perfilPorUserId as Record<string, unknown>).id,
        );
      }
    } catch {
      // Bancos antigos podem não possuir user_id.
    }

    if (!perfilId) {
      const { data: perfilPorId, error: erroId } = await supabase
        .from("profiles")
        .select("id")
        .eq("id", userIdLimpo)
        .limit(1)
        .maybeSingle();

      if (
        !erroId &&
        perfilPorId &&
        typeof perfilPorId === "object" &&
        !Array.isArray(perfilPorId)
      ) {
        perfilId = pegarTexto(
          (perfilPorId as Record<string, unknown>).id,
        );
      }
    }

    async function persistirPerfil(incluirUsername: boolean) {
      const payloadAtualizacao: Record<string, unknown> = {
        ...payloadPerfilBase,
      };

      if (incluirUsername && usernameNormalizado !== undefined) {
        payloadAtualizacao.username = usernameNormalizado;
      }

      if (perfilId) {
        return supabase
          .from("profiles")
          .update(payloadAtualizacao)
          .eq("id", perfilId);
      }

      return supabase.from("profiles").insert({
        id: userIdLimpo,
        user_id: userIdLimpo,
        ...payloadAtualizacao,
      });
    }

    let { error } = await persistirPerfil(true);

    if (
      error &&
      usernameNormalizado !== undefined &&
      erroIndicaUsernameAusente(error.message || "")
    ) {
      ({ error } = await persistirPerfil(false));
    }

    return {
      ok: !error,
      erro: error?.message || "",
    };
  } catch (error) {
    return {
      ok: false,
      erro:
        error instanceof Error
          ? error.message
          : "Erro inesperado ao salvar perfil.",
    };
  }
}

async function sincronizarNomeAutorObrasSupabase(userId: string, nome: string) {
  const userIdLimpo = userId.trim();
  const nomeLimpo = nome.trim();

  if (!userIdLimpo || !nomeLimpo || !idAutorSupabaseValido(userIdLimpo)) {
    return { ok: false, erro: "Dados insuficientes para sincronizar obras." };
  }

  try {
    const { error } = await supabase
      .from("obras")
      .update({
        autor: nomeLimpo,
        atualizado_em: new Date().toISOString(),
      })
      .eq("user_id", userIdLimpo);

    if (error) {
      return { ok: false, erro: error.message };
    }

    return { ok: true, erro: "" };
  } catch (error) {
    return {
      ok: false,
      erro: error instanceof Error ? error.message : "Erro inesperado ao sincronizar obras.",
    };
  }
}

function limparNomeArquivoAvatarPerfil(nome: string) {
  const extensao = nome.split(".").pop()?.toLowerCase().replace(/[^a-z0-9]/g, "") || "png";
  const base = nome
    .replace(/\.[^.]+$/, "")
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 50);

  return `${base || "avatar"}.${extensao}`;
}

async function enviarAvatarPerfilUsuarioSupabase({
  userId,
  arquivo,
}: {
  userId: string;
  arquivo: File;
}) {
  const userIdLimpo = userId.trim();

  if (!userIdLimpo || !idAutorSupabaseValido(userIdLimpo)) {
    return { ok: false, url: "", erro: "ID de usuário inválido para enviar avatar." };
  }

  try {
    const nomeSeguro = limparNomeArquivoAvatarPerfil(arquivo.name);
    const caminho = `${userIdLimpo}/${Date.now()}-${nomeSeguro}`;

    const { error } = await supabase.storage
      .from(AVATAR_STORAGE_BUCKET)
      .upload(caminho, arquivo, {
        cacheControl: "3600",
        contentType: arquivo.type || "image/png",
        upsert: true,
      });

    if (error) {
      return { ok: false, url: "", erro: error.message };
    }

    const { data } = supabase.storage
      .from(AVATAR_STORAGE_BUCKET)
      .getPublicUrl(caminho);

    const publicUrl = data.publicUrl || "";

    if (!publicUrl) {
      return { ok: false, url: "", erro: "Storage não retornou URL pública do avatar." };
    }

    return { ok: true, url: publicUrl, erro: "" };
  } catch (error) {
    return {
      ok: false,
      url: "",
      erro: error instanceof Error ? error.message : "Erro inesperado ao enviar avatar.",
    };
  }
}

function criarPerfilUsuarioRemotoComoAutor(
  perfilUsuario: PerfilUsuarioRemoto,
): AutorPerfil {
  return {
    autorId: perfilUsuario.userId,
    nome: perfilUsuario.nome,
    obras: [],
    totalCapitulos: 0,
    totalCurtidas: 0,
    totalComentarios: 0,
    totalPublicadas: 0,
  };
}

function pegarNumero(valor: unknown, fallback = 0) {
  return typeof valor === "number" && Number.isFinite(valor) ? valor : fallback;
}

function pegarBooleano(valor: unknown, fallback = false) {
  return typeof valor === "boolean" ? valor : fallback;
}

function pegarTagsSupabase(valor: unknown): string[] {
  if (Array.isArray(valor)) {
    const tags = valor
      .filter(
        (tag): tag is string => typeof tag === "string" && Boolean(tag.trim()),
      )
      .map((tag) => tag.trim());

    return tags.length > 0 ? tags : ["sem tags"];
  }

  if (typeof valor === "string" && valor.trim()) {
    const tags = valor
      .split(",")
      .map((tag) => tag.trim())
      .filter(Boolean);

    return tags.length > 0 ? tags : ["sem tags"];
  }

  return ["sem tags"];
}

function normalizarCategoriaArquivo(
  tipo: string,
): ArquivoObraLocal["categoria"] {
  const tipoNormalizado = tipo.toLowerCase();

  if (tipoNormalizado.startsWith("image/")) {
    return "imagem";
  }

  if (tipoNormalizado.includes("pdf") || tipoNormalizado.includes("document")) {
    return "documento";
  }

  if (
    tipoNormalizado.startsWith("text/") ||
    tipoNormalizado.includes("markdown")
  ) {
    return "texto";
  }

  return "outro";
}

function criarArquivoObraSupabase(
  row: SupabaseObraRow,
): ArquivoObraLocal | null {
  const conteudo = pegarTexto(
    row.arquivo_url ??
      row.arquivoUrl ??
      row.arquivo_conteudo ??
      row.arquivoObra,
  );

  if (!conteudo) {
    return null;
  }

  const tipo = pegarTexto(row.arquivo_tipo ?? row.arquivoTipo, "outro");

  return {
    nome: pegarTexto(row.arquivo_nome ?? row.arquivoNome, "arquivo-da-obra"),
    tipo,
    tamanho: pegarNumero(row.arquivo_tamanho ?? row.arquivoTamanho, 0),
    conteudo,
    categoria: normalizarCategoriaArquivo(tipo),
    criadoEm: pegarTexto(
      row.arquivo_criado_em ?? row.arquivoCriadoEm ?? row.created_at,
    ),
  };
}

function normalizarObraSupabase(
  row: SupabaseObraRow,
  index: number,
): ObraLocal {
  const titulo = pegarTexto(row.titulo, `Obra ${index + 1}`);
  const slug = pegarTexto(row.slug, criarSlugBase(titulo));

  return {
    id: pegarTexto(row.id, `supabase-${index + 1}`),
    titulo,
    autorId: pegarTexto(row.user_id ?? row.autor_id ?? row.autorId, ""),
    autor: pegarTexto(
      row.autor ?? row.nome_autor ?? row.autor_nome,
      "Autor não informado",
    ),
    genero: pegarTexto(row.genero, "Não informado"),
    formato: pegarTexto(row.formato, "Não informado"),
    classificacaoIndicativa: pegarTexto(
      row.classificacao_indicativa ?? row.classificacaoIndicativa,
      "Não informada",
    ),
    sinopse: pegarTexto(row.sinopse, "Nenhuma sinopse informada."),
    tags: pegarTagsSupabase(row.tags),
    capa: pegarTexto(row.capa_url ?? row.capaUrl ?? row.capa, ""),
    capaNome: pegarTexto(row.capa_nome ?? row.capaNome, ""),
    arquivoObra: criarArquivoObraSupabase(row),
    publicado: pegarBooleano(row.publicado, false),
    capitulos: [],
    criadaEm: pegarTexto(row.created_at ?? row.criada_em ?? row.criadaEm, ""),
    ultimoCapituloLidoId: "",
    ultimaLeituraEm: "",
    progressoLeitura: 0,
    visualizacoes: normalizarNumeroPerfilAutor(
      row.visualizacoes ??
        row.views ??
        row.visualizacoes_total ??
        row.total_visualizacoes ??
        row.totalVisualizacoes,
    ),
    slug,
    link: `/obra/${slug}`,
  };
}

function normalizarCapituloSupabase(
  row: SupabaseCapituloRow,
  capituloIndex: number,
  obraIndex: number,
): CapituloLocal & { obraId: string } {
  return {
    id: pegarTexto(
      row.id,
      `capitulo-supabase-${obraIndex + 1}-${capituloIndex + 1}`,
    ),
    titulo: pegarTexto(row.titulo, `Capítulo ${capituloIndex + 1}`),
    texto: "",
    curtiu: false,
    salvo: false,
    comentario: "",
    criadoEm: pegarTexto(row.created_at ?? row.criado_em ?? row.criadoEm, ""),
    lido: false,
    lidoEm: "",
    obraId: pegarTexto(row.obra_id ?? row.obraId, ""),
  };
}

function mesclarObrasPorIdSlug(
  obrasBase: ObraLocal[],
  obrasNovas: ObraLocal[],
) {
  const mapa = new Map<string, ObraLocal>();

  [...obrasBase, ...obrasNovas].forEach((obra) => {
    const chave = obra.id || obra.slug || criarSlugBase(obra.titulo);
    const existente = mapa.get(chave);

    if (!existente) {
      mapa.set(chave, obra);
      return;
    }

    mapa.set(chave, {
      ...existente,
      ...obra,
      capitulos:
        obra.capitulos.length > 0 ? obra.capitulos : existente.capitulos,
      arquivoObra: obra.arquivoObra || existente.arquivoObra,
      capa: obra.capa || existente.capa,
      capaNome: obra.capaNome || existente.capaNome,
      visualizacoes: Math.max(existente.visualizacoes, obra.visualizacoes),
      ultimaLeituraEm: obra.ultimaLeituraEm || existente.ultimaLeituraEm,
      ultimoCapituloLidoId:
        obra.ultimoCapituloLidoId || existente.ultimoCapituloLidoId,
    });
  });

  return Array.from(mapa.values());
}

function aplicarInteracoesNasObras(
  obrasParaAtualizar: ObraLocal[],
  idsCapitulosCurtidos: Set<string>,
  idsCapitulosSalvos: Set<string>,
  comentariosPorCapitulo: Map<string, string>,
  progressoPorCapitulo: Map<string, string>,
  progressoCarregado: boolean,
) {
  return obrasParaAtualizar.map((obra) => {
    let ultimoCapituloLidoId = progressoCarregado
      ? ""
      : obra.ultimoCapituloLidoId;
    let ultimaLeituraEm = progressoCarregado ? "" : obra.ultimaLeituraEm;

    const capitulos = obra.capitulos.map((capitulo) => {
      const lidoEmRemoto = progressoPorCapitulo.get(capitulo.id) || "";
      const lido = progressoCarregado
        ? Boolean(lidoEmRemoto)
        : Boolean(lidoEmRemoto) || capitulo.lido;
      const lidoEm = lido
        ? lidoEmRemoto || capitulo.lidoEm
        : "";

      if (lido && lidoEm) {
        const tempoAtual = obterTimestampData(lidoEm);
        const tempoAnterior = obterTimestampData(ultimaLeituraEm);

        if (tempoAtual >= tempoAnterior) {
          ultimoCapituloLidoId = capitulo.id;
          ultimaLeituraEm = lidoEm;
        }
      }

      return {
        ...capitulo,
        curtiu: capitulo.curtiu || idsCapitulosCurtidos.has(capitulo.id),
        salvo: capitulo.salvo || idsCapitulosSalvos.has(capitulo.id),
        comentario:
          comentariosPorCapitulo.get(capitulo.id) || capitulo.comentario,
        lido,
        lidoEm,
      };
    });

    return {
      ...obra,
      capitulos,
      ultimoCapituloLidoId,
      ultimaLeituraEm,
      progressoLeitura: calcularProgressoLeitura(capitulos),
    };
  });
}

type UsuariosPorChavePerfilAutor = Record<string, string[]>;

function adicionarUsuarioUnicoPerfilAutor(
  usuariosPorChave: Map<string, Set<string>>,
  chave: string,
  userId: string,
) {
  const chaveLimpa = chave.trim();
  const userIdLimpo = userId.trim();

  if (!chaveLimpa || !userIdLimpo) {
    return;
  }

  const usuarios = usuariosPorChave.get(chaveLimpa) || new Set<string>();

  usuarios.add(userIdLimpo);
  usuariosPorChave.set(chaveLimpa, usuarios);
}

function converterUsuariosPerfilAutor(
  usuariosPorChave: Map<string, Set<string>>,
): UsuariosPorChavePerfilAutor {
  return Array.from(usuariosPorChave.entries()).reduce<
    UsuariosPorChavePerfilAutor
  >((resultado, [chave, usuarios]) => {
    resultado[chave] = Array.from(usuarios);

    return resultado;
  }, {});
}

function combinarUsuariosPerfilAutor(
  ...fontes: UsuariosPorChavePerfilAutor[]
): UsuariosPorChavePerfilAutor {
  const usuariosCombinados = new Map<string, Set<string>>();

  fontes.forEach((fonte) => {
    Object.entries(fonte).forEach(([chave, usuarios]) => {
      usuarios.forEach((userId) => {
        adicionarUsuarioUnicoPerfilAutor(
          usuariosCombinados,
          chave,
          userId,
        );
      });
    });
  });

  return converterUsuariosPerfilAutor(usuariosCombinados);
}

function contarUsuariosPerfilAutor(
  usuariosPorChave: UsuariosPorChavePerfilAutor,
) {
  return Object.entries(usuariosPorChave).reduce<Record<string, number>>(
    (contagens, [chave, usuarios]) => {
      contagens[chave] = new Set(
        usuarios.map((userId) => userId.trim()).filter(Boolean),
      ).size;

      return contagens;
    },
    {},
  );
}

function mapearUsuariosCapitulosParaObrasPerfilAutor(
  usuariosPorCapitulo: UsuariosPorChavePerfilAutor,
  obraIdPorCapitulo: Record<string, string>,
) {
  const usuariosPorObra = new Map<string, Set<string>>();

  Object.entries(usuariosPorCapitulo).forEach(([capituloId, usuarios]) => {
    const obraId = obraIdPorCapitulo[capituloId]?.trim() || "";

    usuarios.forEach((userId) => {
      adicionarUsuarioUnicoPerfilAutor(
        usuariosPorObra,
        obraId,
        userId,
      );
    });
  });

  return converterUsuariosPerfilAutor(usuariosPorObra);
}

function somarContagensCapitulosPerfilAutor(
  obra: Pick<ObraLocal, "capitulos">,
  contagensPorCapitulo: Record<string, number>,
) {
  return obra.capitulos.reduce((total, capitulo) => {
    const capituloId = capitulo.id.trim();

    if (!capituloId) {
      return total;
    }

    return total + normalizarNumeroPerfilAutor(contagensPorCapitulo[capituloId], 0);
  }, 0);
}

function obterTotalCurtidasObraPerfilAutor(
  obra: Pick<ObraLocal, "id" | "capitulos">,
  totais: TotaisInteracoesObrasPerfilAutor,
) {
  const obraId = obra.id.trim();
  const totalUsuariosUnicos = obraId
    ? normalizarNumeroPerfilAutor(totais.curtidasPorObra[obraId], 0)
    : 0;

  if (totalUsuariosUnicos > 0) {
    return totalUsuariosUnicos;
  }

  const totalCapitulos = somarContagensCapitulosPerfilAutor(
    obra,
    totais.curtidasPorCapitulo,
  );
  const totalLocal = obra.capitulos.filter((capitulo) => capitulo.curtiu).length;

  return Math.max(totalCapitulos, totalLocal);
}

function obterTotalComentariosObraPerfilAutor(
  obra: Pick<ObraLocal, "id" | "capitulos">,
  totais: TotaisInteracoesObrasPerfilAutor,
) {
  const obraId = obra.id.trim();
  const totalUsuariosUnicos = obraId
    ? normalizarNumeroPerfilAutor(totais.comentariosPorObra[obraId], 0)
    : 0;

  if (totalUsuariosUnicos > 0) {
    return totalUsuariosUnicos;
  }

  const totalCapitulos = somarContagensCapitulosPerfilAutor(
    obra,
    totais.comentariosPorCapitulo,
  );
  const totalLocal = obra.capitulos.filter((capitulo) =>
    capitulo.comentario.trim(),
  ).length;

  return Math.max(totalCapitulos, totalLocal);
}

function obterTotalSalvosObraPerfilAutor(
  obra: Pick<ObraLocal, "id" | "capitulos">,
  totais: TotaisInteracoesObrasPerfilAutor,
) {
  const obraId = obra.id.trim();
  const totalUsuariosUnicos = obraId
    ? normalizarNumeroPerfilAutor(totais.salvosPorObra[obraId], 0)
    : 0;

  if (totalUsuariosUnicos > 0) {
    return totalUsuariosUnicos;
  }

  const totalCapitulos = somarContagensCapitulosPerfilAutor(
    obra,
    totais.salvosPorCapitulo,
  );
  const totalLocal = obra.capitulos.filter((capitulo) => capitulo.salvo).length;

  return Math.max(totalCapitulos, totalLocal);
}

function obterTotalConcluidasObraPerfilAutor(
  obra: Pick<ObraLocal, "id">,
  totais: TotaisInteracoesObrasPerfilAutor,
) {
  const obraId = obra.id.trim();

  return obraId
    ? normalizarNumeroPerfilAutor(totais.concluidasPorObra[obraId], 0)
    : 0;
}

function obterIdsUnicosPerfilAutor(ids: string[]) {
  return Array.from(new Set(ids.map((id) => id.trim()).filter(Boolean)));
}

async function carregarUsuariosTabelaPerfilAutor(
  tabela: string,
  coluna: string,
  ids: string[],
): Promise<UsuariosPorChavePerfilAutor> {
  const idsUnicos = obterIdsUnicosPerfilAutor(ids);
  const usuariosPorChave = new Map<string, Set<string>>();

  if (idsUnicos.length === 0) {
    return {};
  }

  const tamanhoChunk = 80;
  const tamanhoPagina = 1000;

  for (
    let inicioChunk = 0;
    inicioChunk < idsUnicos.length;
    inicioChunk += tamanhoChunk
  ) {
    const idsChunk = idsUnicos.slice(inicioChunk, inicioChunk + tamanhoChunk);
    let inicioPagina = 0;

    while (true) {
      try {
        const { data, error } = await supabase
          .from(tabela)
          .select(`${coluna},user_id`)
          .in(coluna, idsChunk)
          .range(inicioPagina, inicioPagina + tamanhoPagina - 1);

        if (error || !Array.isArray(data) || data.length === 0) {
          break;
        }

        data.forEach((item: unknown) => {
          if (!item || typeof item !== "object" || Array.isArray(item)) {
            return;
          }

          const registro = item as Record<string, unknown>;
          const id = pegarTexto(registro[coluna]);
          const userId = pegarTexto(registro.user_id);

          adicionarUsuarioUnicoPerfilAutor(
            usuariosPorChave,
            id,
            userId,
          );
        });

        if (data.length < tamanhoPagina) {
          break;
        }

        inicioPagina += tamanhoPagina;
      } catch {
        break;
      }
    }
  }

  return converterUsuariosPerfilAutor(usuariosPorChave);
}

async function carregarTotaisInteracoesObrasPerfilAutor(
  obrasParaContar: ObraLocal[],
): Promise<TotaisInteracoesObrasPerfilAutor> {
  const obraIds = obterIdsUnicosPerfilAutor(
    obrasParaContar.map((obra) => obra.id),
  );
  const capituloIds = obterIdsUnicosPerfilAutor(
    obrasParaContar.flatMap((obra) =>
      obra.capitulos.map((capitulo) => capitulo.id),
    ),
  );
  const obraIdPorCapitulo = obrasParaContar.reduce<Record<string, string>>(
    (mapa, obra) => {
      const obraId = obra.id.trim();

      obra.capitulos.forEach((capitulo) => {
        const capituloId = capitulo.id.trim();

        if (obraId && capituloId) {
          mapa[capituloId] = obraId;
        }
      });

      return mapa;
    },
    {},
  );

  if (obraIds.length === 0 && capituloIds.length === 0) {
    return totaisInteracoesObrasPerfilVazio;
  }

  const [
    usuariosCurtidasCapitulos,
    usuariosComentariosCapitulos,
    usuariosSalvosCapitulos,
    usuariosCurtidasObras,
    usuariosComentariosObras,
    usuariosObrasSeguidas,
    usuariosObrasFavoritas,
    usuariosObrasConcluidas,
  ] = await Promise.all([
    carregarUsuariosTabelaPerfilAutor(
      "curtidas_capitulos",
      "capitulo_id",
      capituloIds,
    ),
    carregarUsuariosTabelaPerfilAutor(
      "comentarios_capitulos",
      "capitulo_id",
      capituloIds,
    ),
    carregarUsuariosTabelaPerfilAutor(
      "salvos_capitulos",
      "capitulo_id",
      capituloIds,
    ),
    carregarUsuariosTabelaPerfilAutor("obra_curtidas", "obra_id", obraIds),
    carregarUsuariosTabelaPerfilAutor("comentarios_obras", "obra_id", obraIds),
    carregarUsuariosTabelaPerfilAutor("seguindo_obras", "obra_id", obraIds),
    carregarUsuariosTabelaPerfilAutor("favoritos", "obra_id", obraIds),
    carregarUsuariosTabelaPerfilAutor("concluidas", "obra_id", obraIds),
  ]);

  const usuariosCurtidasCapitulosPorObra =
    mapearUsuariosCapitulosParaObrasPerfilAutor(
      usuariosCurtidasCapitulos,
      obraIdPorCapitulo,
    );
  const usuariosComentariosCapitulosPorObra =
    mapearUsuariosCapitulosParaObrasPerfilAutor(
      usuariosComentariosCapitulos,
      obraIdPorCapitulo,
    );
  const usuariosSalvosCapitulosPorObra =
    mapearUsuariosCapitulosParaObrasPerfilAutor(
      usuariosSalvosCapitulos,
      obraIdPorCapitulo,
    );

  const usuariosCurtidasPorObra = combinarUsuariosPerfilAutor(
    usuariosCurtidasObras,
    usuariosCurtidasCapitulosPorObra,
  );
  const usuariosComentariosPorObra = combinarUsuariosPerfilAutor(
    usuariosComentariosObras,
    usuariosComentariosCapitulosPorObra,
  );
  const usuariosSalvosPorObra = combinarUsuariosPerfilAutor(
    usuariosObrasSeguidas,
    usuariosObrasFavoritas,
    usuariosSalvosCapitulosPorObra,
  );

  return {
    curtidasPorObra: contarUsuariosPerfilAutor(usuariosCurtidasPorObra),
    comentariosPorObra: contarUsuariosPerfilAutor(
      usuariosComentariosPorObra,
    ),
    curtidasPorCapitulo: contarUsuariosPerfilAutor(
      usuariosCurtidasCapitulos,
    ),
    comentariosPorCapitulo: contarUsuariosPerfilAutor(
      usuariosComentariosCapitulos,
    ),
    salvosPorObra: contarUsuariosPerfilAutor(usuariosSalvosPorObra),
    salvosPorCapitulo: contarUsuariosPerfilAutor(
      usuariosSalvosCapitulos,
    ),
    concluidasPorObra: contarUsuariosPerfilAutor(
      usuariosObrasConcluidas,
    ),
  };
}

async function carregarObrasPublicadasSupabase() {
  try {
    const { data: obrasData, error: obrasError } = await supabase
      .from("obras")
      .select(
        "id,user_id,titulo,autor,genero,formato,classificacao_indicativa,sinopse,tags,capa_url,capa_nome,arquivo_url,arquivo_nome,arquivo_tipo,arquivo_tamanho,arquivo_categoria,publicado,visualizacoes,slug,criada_em,atualizado_em"
      )
      .eq("publicado", true)
      .order("criada_em", { ascending: false })
      .limit(80);

    if (obrasError || !Array.isArray(obrasData)) {
      return [];
    }

    const obrasSupabase = obrasData.map((obra, index) =>
      normalizarObraSupabase(obra as unknown as SupabaseObraRow, index),
    );

    const idsObras = obrasSupabase.map((obra) => obra.id).filter(Boolean);

    if (idsObras.length === 0) {
      return obrasSupabase;
    }

    try {
      const { data: capitulosData } = await supabase
        .from("capitulos")
        .select("id,obra_id,titulo,ordem,publicado,criado_em,atualizado_em")
        .in("obra_id", idsObras)
        .eq("publicado", true)
        .order("ordem", { ascending: true })
        .limit(600);

      if (Array.isArray(capitulosData)) {
        const capitulosPorObra = new Map<string, CapituloLocal[]>();

        capitulosData.forEach((capitulo, index) => {
          const capituloNormalizado = normalizarCapituloSupabase(
            capitulo as unknown as SupabaseCapituloRow,
            index,
            index,
          );

          if (!capituloNormalizado.obraId) {
            return;
          }

          const capitulosAtuais =
            capitulosPorObra.get(capituloNormalizado.obraId) || [];
          const { obraId: _obraId, ...capituloSemObraId } = capituloNormalizado;
          void _obraId;

          capitulosPorObra.set(capituloNormalizado.obraId, [
            ...capitulosAtuais,
            capituloSemObraId,
          ]);
        });

        return obrasSupabase.map((obra) => {
          const capitulos = capitulosPorObra.get(obra.id) || [];

          return {
            ...obra,
            capitulos,
            progressoLeitura: calcularProgressoLeitura(capitulos),
          };
        });
      }
    } catch {
      // Se capítulos falhar, a página continua mostrando as obras.
    }

    return obrasSupabase;
  } catch {
    return [];
  }
}

function coletarObraIdsRegistrosDiarioPerfil(
  registros: Record<string, unknown>[],
) {
  return registros
    .map((registro) => pegarTexto(registro.obra_id ?? registro.obraId))
    .filter(Boolean);
}

async function carregarObrasPublicadasPorIdsSupabase(obraIds: string[]) {
  const idsUnicos = Array.from(
    new Set(obraIds.map((obraId) => obraId.trim()).filter(Boolean)),
  );

  if (idsUnicos.length === 0) {
    return [] as ObraLocal[];
  }

  try {
    const { data: obrasData, error: obrasError } = await supabase
      .from("obras")
      .select(
        "id,user_id,titulo,autor,genero,formato,classificacao_indicativa,sinopse,tags,capa_url,capa_nome,arquivo_url,arquivo_nome,arquivo_tipo,arquivo_tamanho,arquivo_categoria,publicado,visualizacoes,slug,criada_em,atualizado_em"
      )
      .in("id", idsUnicos)
      .eq("publicado", true)
      .limit(Math.max(idsUnicos.length, 1));

    if (obrasError || !Array.isArray(obrasData)) {
      return [] as ObraLocal[];
    }

    const obrasSupabase = obrasData.map((obra, index) =>
      normalizarObraSupabase(obra as unknown as SupabaseObraRow, index),
    );
    const idsEncontrados = obrasSupabase.map((obra) => obra.id).filter(Boolean);

    if (idsEncontrados.length === 0) {
      return obrasSupabase;
    }

    try {
      const { data: capitulosData } = await supabase
        .from("capitulos")
        .select("id,obra_id,titulo,ordem,publicado,criado_em,atualizado_em")
        .in("obra_id", idsEncontrados)
        .eq("publicado", true)
        .order("ordem", { ascending: true })
        .limit(Math.max(idsEncontrados.length * 20, 1));

      if (Array.isArray(capitulosData)) {
        const capitulosPorObra = new Map<string, CapituloLocal[]>();

        capitulosData.forEach((capitulo, index) => {
          const capituloNormalizado = normalizarCapituloSupabase(
            capitulo as unknown as SupabaseCapituloRow,
            index,
            index,
          );

          if (!capituloNormalizado.obraId) {
            return;
          }

          const capitulosAtuais =
            capitulosPorObra.get(capituloNormalizado.obraId) || [];
          const { obraId: _obraId, ...capituloSemObraId } = capituloNormalizado;
          void _obraId;

          capitulosPorObra.set(capituloNormalizado.obraId, [
            ...capitulosAtuais,
            capituloSemObraId,
          ]);
        });

        return obrasSupabase.map((obra) => {
          const capitulos = capitulosPorObra.get(obra.id) || [];

          return {
            ...obra,
            capitulos,
            progressoLeitura: calcularProgressoLeitura(capitulos),
          };
        });
      }
    } catch {
      // Se capítulos falhar, a Biblioteca ainda mostra a obra salva.
    }

    return obrasSupabase;
  } catch {
    return [] as ObraLocal[];
  }
}

async function carregarIdsTabelaUsuario(
  tabela: string,
  colunaId: string,
  userId: string,
): Promise<string[]> {
  try {
    const { data, error } = await supabase
      .from(tabela)
      .select(colunaId)
      .eq("user_id", userId)
      .limit(1000);

    if (error || !Array.isArray(data)) {
      return [];
    }

    const ids: string[] = [];

    data.forEach((item: unknown) => {
      if (!item || typeof item !== "object" || Array.isArray(item)) {
        return;
      }

      const registro = item as Record<string, unknown>;
      const id = pegarTexto(registro[colunaId]);

      if (id) {
        ids.push(id);
      }
    });

    return ids;
  } catch {
    return [];
  }
}

async function carregarAutoresSeguidosSupabase(
  userId: string,
): Promise<string[]> {
  try {
    const { data, error } = await supabase
      .from("seguindo_autores")
      .select("autor")
      .eq("user_id", userId)
      .limit(1000);

    if (error || !Array.isArray(data)) {
      return [];
    }

    const autores: string[] = [];

    data.forEach((item: unknown) => {
      if (!item || typeof item !== "object" || Array.isArray(item)) {
        return;
      }

      const registro = item as Record<string, unknown>;
      const autor = normalizarNomeAutor(pegarTexto(registro.autor));

      if (autor) {
        autores.push(autor);
      }
    });

    return autores;
  } catch {
    return [];
  }
}

async function carregarInteracoesCapitulosSupabase(userId: string) {
  const curtidas = new Set(
    await carregarIdsTabelaUsuario("curtidas_capitulos", "capitulo_id", userId),
  );
  const salvos = new Set(
    await carregarIdsTabelaUsuario("salvos_capitulos", "capitulo_id", userId),
  );
  const comentarios = new Map<string, string>();
  const progresso = new Map<string, string>();
  let progressoCarregado = false;

  try {
    const { data } = await supabase
      .from("comentarios_capitulos")
      .select("capitulo_id, comentario, texto")
      .eq("user_id", userId)
      .limit(1000);

    if (Array.isArray(data)) {
      data.forEach((item) => {
        const registro = item as Record<string, unknown>;
        const capituloId = pegarTexto(registro.capitulo_id);
        const texto = pegarTexto(registro.comentario ?? registro.texto);

        if (capituloId && texto) {
          comentarios.set(capituloId, texto);
        }
      });
    }
  } catch {
    // Comentários continuam apenas localmente se houver erro.
  }

  try {
    const { data, error } = await supabase
      .from("progresso_leitura")
      .select("capitulo_id,lido,atualizado_em,criado_em")
      .eq("user_id", userId)
      .order("atualizado_em", { ascending: false })
      .limit(1000);

    if (!error && Array.isArray(data)) {
      progressoCarregado = true;

      data.forEach((item) => {
        const registro = item as Record<string, unknown>;
        const capituloId = pegarTexto(registro.capitulo_id);
        const registroLido =
          typeof registro.lido === "boolean" ? registro.lido : true;
        const lidoEm = pegarTexto(
          registro.atualizado_em ??
            registro.criado_em ??
            registro.updated_at ??
            registro.created_at,
        );

        if (capituloId && registroLido && lidoEm) {
          progresso.set(capituloId, lidoEm);
        }
      });
    }
  } catch {
    // Progresso continua apenas localmente se houver erro.
  }

  return {
    curtidas,
    salvos,
    comentarios,
    progresso,
    progressoCarregado,
  };
}

async function carregarEstadoUsuarioSupabase() {
  try {
    const { data } = await supabase.auth.getUser();
    const userId = data.user?.id || "";

    if (!userId) {
      return null;
    }

    const [favoritas, concluidas, obrasSeguidas, autoresSeguidos, interacoes] =
      await Promise.all([
        carregarIdsTabelaUsuario("favoritos", "obra_id", userId),
        carregarIdsTabelaUsuario("concluidas", "obra_id", userId),
        carregarIdsTabelaUsuario("seguindo_obras", "obra_id", userId),
        carregarAutoresSeguidosSupabase(userId),
        carregarInteracoesCapitulosSupabase(userId),
      ]);

    return {
      userId,
      favoritas,
      concluidas,
      obrasSeguidas,
      autoresSeguidos,
      interacoes,
    };
  } catch {
    return null;
  }
}

function obterDataRegistroDiario(registro: Record<string, unknown>) {
  return pegarTexto(
    registro.atualizado_em ??
      registro.updated_at ??
      registro.criado_em ??
      registro.created_at,
  );
}

function obterVisibilidadeRegistroDiario(
  registro: Record<string, unknown>,
  fallback: VisibilidadeDiarioPerfil,
) {
  const visibilidade = pegarTexto(registro.visibilidade, fallback);

  if (
    visibilidade === "publico" ||
    visibilidade === "parcial" ||
    visibilidade === "privado"
  ) {
    return visibilidade;
  }

  return fallback;
}

function registroDiarioPodeAparecer(
  registro: Record<string, unknown>,
  incluirPrivados: boolean,
  fallback: VisibilidadeDiarioPerfil,
) {
  if (incluirPrivados) {
    return true;
  }

  const visibilidade = obterVisibilidadeRegistroDiario(registro, fallback);

  return visibilidade === "publico" || visibilidade === "parcial";
}

function criarEstadoDiarioPerfilVazio(): Omit<DiarioPerfilEstado, "carregando"> {
  return {
    lendoAgora: [],
    queroLer: [],
    favoritas: [],
    concluidas: [],
    avaliacoes: [],
    reviews: [],
    atividades: [],
  };
}

const comunidadePerfilVazia: ComunidadePerfilEstado = {
  carregando: false,
  erro: "",
  totalPublicacoes: 0,
  totalTeorias: 0,
  totalReviews: 0,
  publicacoesRecentes: [],
};

function normalizarPublicacaoComunidadePerfil(
  registro: Record<string, unknown>,
): PublicacaoComunidadePerfil | null {
  const id = pegarTexto(registro.id);

  if (!id) {
    return null;
  }

  return {
    id,
    categoria: pegarTexto(registro.categoria, "Geral"),
    tipoPublicacao: pegarTexto(registro.tipo_publicacao, "Discussão"),
    temSpoiler: registro.tem_spoiler === true,
    texto: pegarTexto(registro.texto).slice(0, 700),
    obraRelacionada: pegarTexto(registro.obra_relacionada).slice(0, 120),
    criadoEm: pegarTexto(registro.criado_em),
  };
}

async function carregarComunidadePerfilSupabase(
  userId: string,
): Promise<Omit<ComunidadePerfilEstado, "carregando" | "erro">> {
  const userIdLimpo = userId.trim();

  if (!userIdLimpo || !idAutorSupabaseValido(userIdLimpo)) {
    return {
      totalPublicacoes: 0,
      totalTeorias: 0,
      totalReviews: 0,
      publicacoesRecentes: [],
    };
  }

  const [publicacoesResposta, teoriasResposta, reviewsResposta] =
    await Promise.all([
      supabase
        .from("comunidade_posts")
        .select(
          "id, categoria, tipo_publicacao, tem_spoiler, texto, obra_relacionada, criado_em",
          { count: "exact" },
        )
        .eq("autor_id", userIdLimpo)
        .order("criado_em", { ascending: false })
        .limit(12),
      supabase
        .from("comunidade_posts")
        .select("id", { count: "exact", head: true })
        .eq("autor_id", userIdLimpo)
        .eq("tipo_publicacao", "Teoria"),
      supabase
        .from("comunidade_posts")
        .select("id", { count: "exact", head: true })
        .eq("autor_id", userIdLimpo)
        .eq("tipo_publicacao", "Review"),
    ]);

  if (publicacoesResposta.error) {
    throw publicacoesResposta.error;
  }

  const publicacoesRecentes = (
    (publicacoesResposta.data || []) as unknown as Record<string, unknown>[]
  )
    .map((registro) => normalizarPublicacaoComunidadePerfil(registro))
    .filter(
      (publicacao): publicacao is PublicacaoComunidadePerfil =>
        Boolean(publicacao),
    );

  const totalTeoriasLocal = publicacoesRecentes.filter(
    (publicacao) => publicacao.tipoPublicacao === "Teoria",
  ).length;
  const totalReviewsLocal = publicacoesRecentes.filter(
    (publicacao) => publicacao.tipoPublicacao === "Review",
  ).length;

  return {
    totalPublicacoes:
      publicacoesResposta.count ?? publicacoesRecentes.length,
    totalTeorias: teoriasResposta.error
      ? totalTeoriasLocal
      : teoriasResposta.count ?? totalTeoriasLocal,
    totalReviews: reviewsResposta.error
      ? totalReviewsLocal
      : reviewsResposta.count ?? totalReviewsLocal,
    publicacoesRecentes,
  };
}

function criarHrefPublicacaoComunidadePerfil(postId: string) {
  return `/comunidade?post=${encodeURIComponent(postId.trim())}`;
}

function analisarEnquetePublicacaoComunidadePerfil(
  publicacao: PublicacaoComunidadePerfil,
) {
  const textoOriginal = publicacao.texto
    .replace(/\r\n?/g, "\n")
    .trim();
  const marcadoresOpcoes =
    textoOriginal.match(/op(?:ç|c)[aã]o\s+\d+\s*:/gi) || [];
  const ehEnquete =
    marcadoresOpcoes.length >= 2 ||
    /enquete/i.test(publicacao.tipoPublicacao) ||
    /enquete/i.test(publicacao.categoria) ||
    /^enquete\s*:/i.test(textoOriginal);
  const indicePrimeiraOpcao = textoOriginal.search(
    /op(?:ç|c)[aã]o\s+\d+\s*:/i,
  );
  const perguntaBase =
    indicePrimeiraOpcao >= 0
      ? textoOriginal.slice(0, indicePrimeiraOpcao)
      : textoOriginal.split("\n")[0] || "";
  const pergunta = perguntaBase
    .replace(/^enquete\s*:\s*/i, "")
    .replace(/\s+/g, " ")
    .trim();

  return {
    ehEnquete,
    pergunta: pergunta || "Enquete da comunidade",
    totalOpcoes: ehEnquete ? marcadoresOpcoes.length : 0,
  };
}

function criarResumoPublicacaoComunidadePerfil(
  publicacao: PublicacaoComunidadePerfil,
) {
  if (publicacao.temSpoiler) {
    return "Este post contém spoiler";
  }

  const enquete = analisarEnquetePublicacaoComunidadePerfil(publicacao);

  if (enquete.ehEnquete) {
    return enquete.pergunta;
  }

  const textoLimpo = publicacao.texto.replace(/\s+/g, " ").trim();

  if (!textoLimpo) {
    return "Publicação sem texto.";
  }

  return `${textoLimpo.slice(0, 150)}${textoLimpo.length > 150 ? "..." : ""}`;
}

function dataDiarioPerfilFormatada(dataIso: string) {
  if (!dataIso) {
    return "Data não informada";
  }

  const data = new Date(dataIso);

  if (Number.isNaN(data.getTime())) {
    return "Data não informada";
  }

  return data.toLocaleDateString(obterLocaleDocumentoPerfilAutor(), {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
}

function criarItemDiarioPerfil(
  tipo: DiarioPerfilItem["tipo"],
  obra: ObraLocal,
  data: string,
  descricao: string,
  complemento: Partial<
    Pick<DiarioPerfilItem, "nota" | "progresso" | "visibilidade">
  > = {},
): DiarioPerfilItem {
  return {
    chave: `${tipo}-${obra.id}-${data || obra.id}`,
    tipo,
    titulo: obra.titulo,
    descricao,
    data,
    obra,
    href: obra.link || `/obra/${obra.slug || criarSlugBase(obra.titulo)}`,
    ...complemento,
  };
}

function obterMetadataDiarioPerfil(registro: Record<string, unknown>) {
  const metadata = registro.metadata;

  if (!metadata || typeof metadata !== "object" || Array.isArray(metadata)) {
    return {} as Record<string, unknown>;
  }

  return metadata as Record<string, unknown>;
}

function obterHrefItemDiarioPerfil(item: DiarioPerfilItem) {
  if (item.href?.trim()) {
    return item.href;
  }

  if (item.obra) {
    return item.obra.link || `/obra/${item.obra.slug || criarSlugBase(item.obra.titulo)}`;
  }

  return "/comunidade";
}

function criarItemAtividadeDiarioPerfil(
  registro: Record<string, unknown>,
  obrasPorId: Map<string, ObraLocal>,
  obrasPorCapituloId: Map<string, ObraLocal>,
): DiarioPerfilItem | null {
  const tipoAtividade = pegarTexto(registro.tipo);
  const data = obterDataRegistroDiario(registro);
  const metadata = obterMetadataDiarioPerfil(registro);
  const obra = obterObraRegistroDiario(registro, obrasPorId, obrasPorCapituloId);
  const obraRelacionada = pegarTexto(
    registro.obra_relacionada ?? metadata.obra_relacionada,
  );
  const postId = pegarTexto(metadata.post_id);
  const texto = pegarTexto(registro.texto);
  const nota = Number(registro.nota);

  const tituloBase =
    obra?.titulo ||
    obraRelacionada ||
    (tipoAtividade === "publicou_review" ? "Review publicada" : "Atividade do Diário");

  let tipoItem: DiarioPerfilItem["tipo"] = "atividade";
  let descricao = "Atualizou o Diário.";
  const href = obra
    ? obra.link || `/obra/${obra.slug || criarSlugBase(obra.titulo)}`
    : postId
      ? `/comunidade?post=${encodeURIComponent(postId)}`
      : "/comunidade";

  if (tipoAtividade === "leu_capitulo") {
    tipoItem = "lendo";
    descricao = "Leu um capítulo.";
  } else if (tipoAtividade === "comecou_ler") {
    tipoItem = "lendo";
    descricao = "Começou a ler esta obra.";
  } else if (tipoAtividade === "concluiu_obra") {
    tipoItem = "concluida";
    descricao = "Concluiu esta obra.";
  } else if (tipoAtividade === "avaliou_obra") {
    tipoItem = "avaliacao";
    descricao = Number.isFinite(nota) && nota > 0
      ? `Avaliou com ${formatarMediaAvaliacaoAutor(nota).replace(".", ",")} estrelas.`
      : "Avaliou esta obra.";
  } else if (tipoAtividade === "favoritou_obra") {
    tipoItem = "favorita";
    descricao = "Favoritou esta obra.";
  } else if (tipoAtividade === "salvou_obra") {
    tipoItem = "quero_ler";
    descricao = "Salvou para acompanhar depois.";
  } else if (tipoAtividade === "publicou_review") {
    tipoItem = "review";
    descricao = texto
      ? `Publicou review: ${texto.slice(0, 90)}${texto.length > 90 ? "..." : ""}`
      : "Publicou uma review.";
  } else if (tipoAtividade === "criou_lista") {
    descricao = "Criou uma lista de leitura.";
  }

  return {
    chave: `atividade-${pegarTexto(registro.id) || tipoAtividade}-${data || tituloBase}`,
    tipo: tipoItem,
    titulo: tituloBase,
    descricao,
    data,
    obra,
    href,
    nota: Number.isFinite(nota) && nota > 0 ? nota : undefined,
    visibilidade: obterVisibilidadeRegistroDiario(
      registro,
      tipoAtividade === "publicou_review" ? "publico" : "privado",
    ),
  };
}

function ordenarItensDiarioPerfil(itens: DiarioPerfilItem[]) {
  return [...itens].sort(
    (itemA, itemB) =>
      obterTimestampData(itemB.data) - obterTimestampData(itemA.data),
  );
}

function montarMapaObrasDiario(obrasDisponiveis: ObraLocal[]) {
  const obrasPorId = new Map<string, ObraLocal>();
  const obrasPorCapituloId = new Map<string, ObraLocal>();

  obrasDisponiveis.forEach((obra) => {
    if (obra.id) {
      obrasPorId.set(obra.id, obra);
    }

    obra.capitulos.forEach((capitulo) => {
      if (capitulo.id) {
        obrasPorCapituloId.set(capitulo.id, obra);
      }
    });
  });

  return { obrasPorId, obrasPorCapituloId };
}

function obterObraRegistroDiario(
  registro: Record<string, unknown>,
  obrasPorId: Map<string, ObraLocal>,
  obrasPorCapituloId: Map<string, ObraLocal>,
) {
  const obraId = pegarTexto(registro.obra_id ?? registro.obraId);

  if (obraId && obrasPorId.has(obraId)) {
    return obrasPorId.get(obraId) || null;
  }

  const capituloId = pegarTexto(registro.capitulo_id ?? registro.capituloId);

  if (capituloId && obrasPorCapituloId.has(capituloId)) {
    return obrasPorCapituloId.get(capituloId) || null;
  }

  return null;
}

const CAMPOS_REGISTROS_DIARIO_PERFIL_AUTOR: Record<string, string> = {
  seguindo_obras: "obra_id,visibilidade,criado_em",
  favoritos: "obra_id,visibilidade,criado_em",
  concluidas: "obra_id,visibilidade,criado_em",
  obra_avaliacoes: "obra_id,nota,criado_em,atualizado_em",
  progresso_leitura: "obra_id,capitulo_id,lido,progresso,criado_em,atualizado_em",
  diario_atividades:
    "id,tipo,texto,nota,obra_id,capitulo_id,metadata,visibilidade,criado_em",
};

function obterCamposRegistrosDiarioPerfilAutor(tabela: string) {
  return CAMPOS_REGISTROS_DIARIO_PERFIL_AUTOR[tabela] || "id";
}

async function carregarRegistrosDiarioPerfil(tabela: string, userId: string) {
  try {
    const { data, error } = await supabase
      .from(tabela)
      .select(obterCamposRegistrosDiarioPerfilAutor(tabela))
      .eq("user_id", userId)
      .limit(1000);

    if (error) {
      console.warn(
        `Não consegui carregar ${tabela} no Diário/Biblioteca do perfil:`,
        error.message,
      );

      return [] as Record<string, unknown>[];
    }

    if (!Array.isArray(data)) {
      return [] as Record<string, unknown>[];
    }

    const registros: Record<string, unknown>[] = [];

    data.forEach((registro: unknown) => {
      if (!registro || typeof registro !== "object" || Array.isArray(registro)) {
        return;
      }

      registros.push(registro as Record<string, unknown>);
    });

    return registros;
  } catch {
    return [] as Record<string, unknown>[];
  }
}

function montarDiarioPerfilLocal(
  perfil: AutorPerfil,
  obrasFavoritasIds: string[],
  obrasConcluidasIds: string[],
  obrasSeguidasIds: string[],
  obrasDisponiveis: ObraLocal[] = perfil.obras,
): Omit<DiarioPerfilEstado, "carregando"> {
  const obrasBiblioteca = obrasDisponiveis.length > 0 ? obrasDisponiveis : perfil.obras;

  const lendoAgora = ordenarItensDiarioPerfil(
    obrasBiblioteca
      .filter(
        (obra) =>
          obra.progressoLeitura > 0 &&
          !colecaoTemObraPerfilBiblioteca(obrasConcluidasIds, obra),
      )
      .map((obra) =>
        criarItemDiarioPerfil(
          "lendo",
          obra,
          obra.ultimaLeituraEm || obra.criadaEm,
          `Leitura em andamento • ${obra.progressoLeitura}% concluída`,
          { progresso: obra.progressoLeitura, visibilidade: "privado" },
        ),
      ),
  );

  const favoritas = ordenarItensDiarioPerfil(
    obrasBiblioteca
      .filter((obra) => colecaoTemObraPerfilBiblioteca(obrasFavoritasIds, obra))
      .map((obra) =>
        criarItemDiarioPerfil(
          "favorita",
          obra,
          obra.ultimaLeituraEm || obra.criadaEm,
          "Obra favoritada no perfil",
          { visibilidade: "parcial" },
        ),
      ),
  );

  const concluidas = ordenarItensDiarioPerfil(
    obrasBiblioteca
      .filter((obra) => colecaoTemObraPerfilBiblioteca(obrasConcluidasIds, obra))
      .map((obra) =>
        criarItemDiarioPerfil(
          "concluida",
          obra,
          obra.ultimaLeituraEm || obra.criadaEm,
          "Obra marcada como concluída",
          { visibilidade: "parcial" },
        ),
      ),
  );

  const queroLer = ordenarItensDiarioPerfil(
    obrasBiblioteca
      .filter(
        (obra) =>
          colecaoTemObraPerfilBiblioteca(obrasSeguidasIds, obra) &&
          !colecaoTemObraPerfilBiblioteca(obrasConcluidasIds, obra),
      )
      .map((obra) =>
        criarItemDiarioPerfil(
          "quero_ler",
          obra,
          obra.ultimaLeituraEm || obra.criadaEm,
          "Adicionada para acompanhar depois",
          { visibilidade: "publico" },
        ),
      ),
  );

  const atividades = ordenarItensDiarioPerfil([
    ...lendoAgora,
    ...favoritas,
    ...concluidas,
    ...queroLer,
  ]).slice(0, 8);

  return {
    lendoAgora,
    queroLer,
    favoritas,
    concluidas,
    avaliacoes: [],
    reviews: [],
    atividades,
  };
}

type DiarioPerfilSemCarregando = Omit<DiarioPerfilEstado, "carregando">;

function criarChaveMesclaDiarioPerfil(item: DiarioPerfilItem) {
  const obraId = item.obra?.id || "";
  const capituloId = item.obra?.ultimoCapituloLidoId || "";

  return [item.tipo, obraId || item.chave, capituloId].join("::");
}

function criarChaveCardAtualDiarioPerfil(item: DiarioPerfilItem) {
  const obraId = item.obra?.id?.trim() || "";

  return [item.tipo, obraId || item.chave].join("::");
}

function mesclarItensDiarioPerfil(
  itensPrincipais: DiarioPerfilItem[],
  itensComplementares: DiarioPerfilItem[],
) {
  const mapa = new Map<string, DiarioPerfilItem>();

  [...itensComplementares, ...itensPrincipais].forEach((item) => {
    mapa.set(criarChaveCardAtualDiarioPerfil(item), item);
  });

  return ordenarItensDiarioPerfil(Array.from(mapa.values()));
}

function mesclarDiarioPerfilComLocal(
  diarioSupabase: DiarioPerfilSemCarregando,
  diarioLocal: DiarioPerfilSemCarregando,
): DiarioPerfilSemCarregando {
  const lendoAgora = mesclarItensDiarioPerfil(
    diarioSupabase.lendoAgora,
    diarioLocal.lendoAgora,
  );
  const queroLer = mesclarItensDiarioPerfil(
    diarioSupabase.queroLer,
    diarioLocal.queroLer,
  );
  const favoritas = mesclarItensDiarioPerfil(
    diarioSupabase.favoritas,
    diarioLocal.favoritas,
  );
  const concluidas = mesclarItensDiarioPerfil(
    diarioSupabase.concluidas,
    diarioLocal.concluidas,
  );
  const avaliacoes = mesclarItensDiarioPerfil(
    diarioSupabase.avaliacoes,
    diarioLocal.avaliacoes,
  );
  const reviews = mesclarItensDiarioPerfil(
    diarioSupabase.reviews,
    diarioLocal.reviews,
  );
  const atividades = ordenarItensDiarioPerfil(
    Array.from(
      new Map(
        [
          ...lendoAgora,
          ...queroLer,
          ...favoritas,
          ...concluidas,
          ...avaliacoes,
          ...reviews,
          ...diarioSupabase.atividades,
          ...diarioLocal.atividades,
        ].map((item) => [criarChaveMesclaDiarioPerfil(item), item]),
      ).values(),
    ),
  ).slice(0, 8);

  return {
    lendoAgora,
    queroLer,
    favoritas,
    concluidas,
    avaliacoes,
    reviews,
    atividades,
  };
}

async function carregarDiarioPerfilSupabase(
  userId: string,
  obrasDisponiveis: ObraLocal[],
  incluirPrivados: boolean,
  liberarConteudoDiario: boolean,
  liberarAtividades: boolean,
  obrasConcluidasIdsLocais: string[] = [],
): Promise<Omit<DiarioPerfilEstado, "carregando">> {
  const incluirItensDoDiario = incluirPrivados || liberarConteudoDiario;
  const incluirItensDasAtividades = incluirPrivados || liberarAtividades;
  const [seguindoObras, favoritos, concluidas, progresso] = await Promise.all([
    carregarRegistrosDiarioPerfil("seguindo_obras", userId),
    carregarRegistrosDiarioPerfil("favoritos", userId),
    carregarRegistrosDiarioPerfil("concluidas", userId),
    carregarRegistrosDiarioPerfil("progresso_leitura", userId),
  ]);

  const [avaliacoes, diarioAtividades] = await Promise.all([
    carregarRegistrosDiarioPerfil("obra_avaliacoes", userId),
    carregarRegistrosDiarioPerfil("diario_atividades", userId),
  ]);

  const capituloIdsSemObra = Array.from(
    new Set(
      progresso
        .filter(
          (registro) =>
            !pegarTexto(registro.obra_id ?? registro.obraId),
        )
        .map((registro) =>
          pegarTexto(registro.capitulo_id ?? registro.capituloId),
        )
        .filter(Boolean),
    ),
  );
  let obraIdPorCapituloSemObra = new Map<string, string>();

  if (capituloIdsSemObra.length > 0) {
    try {
      const { data, error } = await supabase
        .from("capitulos")
        .select("id,obra_id")
        .in("id", capituloIdsSemObra)
        .limit(capituloIdsSemObra.length);

      if (!error && Array.isArray(data)) {
        const paresCapituloObra: Array<[string, string]> = [];

        for (const registro of data) {
          const capituloId = pegarTexto(registro?.id);
          const obraId = pegarTexto(registro?.obra_id);

          if (capituloId && obraId) {
            paresCapituloObra.push([capituloId, obraId]);
          }
        }

        obraIdPorCapituloSemObra = new Map<string, string>(
          paresCapituloObra,
        );
      }
    } catch {
      // Mantém os registros originais caso o capítulo não possa ser resolvido.
    }
  }

  const progressoCompleto = progresso.map((registro) => {
    if (pegarTexto(registro.obra_id ?? registro.obraId)) {
      return registro;
    }

    const obraIdResolvido = obraIdPorCapituloSemObra.get(
      pegarTexto(registro.capitulo_id ?? registro.capituloId),
    );

    return obraIdResolvido
      ? { ...registro, obra_id: obraIdResolvido }
      : registro;
  });

  const idsObrasDiario = Array.from(
    new Set([
      ...coletarObraIdsRegistrosDiarioPerfil(seguindoObras),
      ...coletarObraIdsRegistrosDiarioPerfil(favoritos),
      ...coletarObraIdsRegistrosDiarioPerfil(concluidas),
      ...coletarObraIdsRegistrosDiarioPerfil(avaliacoes),
      ...coletarObraIdsRegistrosDiarioPerfil(progressoCompleto),
      ...coletarObraIdsRegistrosDiarioPerfil(diarioAtividades),
    ]),
  );
  const idsObrasDisponiveis = new Set(
    obrasDisponiveis.map((obra) => obra.id).filter(Boolean),
  );
  const idsObrasFaltantes = idsObrasDiario.filter(
    (obraId) => !idsObrasDisponiveis.has(obraId),
  );
  const obrasFaltantes = await carregarObrasPublicadasPorIdsSupabase(
    idsObrasFaltantes,
  );
  const obrasParaDiario = mesclarObrasPorIdSlug(
    obrasDisponiveis,
    obrasFaltantes,
  );
  const { obrasPorId, obrasPorCapituloId } =
    montarMapaObrasDiario(obrasParaDiario);

  const concluidasIds = new Set(
    concluidas
      .filter((registro) =>
        registroDiarioPodeAparecer(registro, incluirItensDoDiario, "parcial"),
      )
      .map((registro) => pegarTexto(registro.obra_id ?? registro.obraId))
      .filter(Boolean),
  );

  const progressoPorObra = new Map<
    string,
    {
      obra: ObraLocal;
      capitulosLidos: Map<string, string>;
      ultimoCapituloLidoId: string;
      ultimaLeituraEm: string;
      progressoInformado: number;
      visibilidade: VisibilidadeDiarioPerfil;
    }
  >();

  progressoCompleto.forEach((registro) => {
    if (!registroDiarioPodeAparecer(registro, incluirItensDoDiario, "privado")) {
      return;
    }

    const registroLido =
      typeof registro.lido === "boolean" ? registro.lido : true;

    if (!registroLido) {
      return;
    }

    const obra = obterObraRegistroDiario(
      registro,
      obrasPorId,
      obrasPorCapituloId,
    );

    if (
      !obra ||
      concluidasIds.has(obra.id) ||
      colecaoTemObraPerfilBiblioteca(obrasConcluidasIdsLocais, obra)
    ) {
      return;
    }

    const capituloId = pegarTexto(
      registro.capitulo_id ?? registro.capituloId,
    );
    const capituloPublicado = obra.capitulos.find(
      (capitulo) => capitulo.id === capituloId,
    );
    const data =
      obterDataRegistroDiario(registro) ||
      capituloPublicado?.lidoEm ||
      obra.ultimaLeituraEm ||
      obra.criadaEm;
    const grupoAtual = progressoPorObra.get(obra.id) || {
      obra,
      capitulosLidos: new Map<string, string>(),
      ultimoCapituloLidoId: "",
      ultimaLeituraEm: "",
      progressoInformado: 0,
      visibilidade: obterVisibilidadeRegistroDiario(
        registro,
        "privado",
      ),
    };

    if (capituloId) {
      grupoAtual.capitulosLidos.set(capituloId, data);
    }

    grupoAtual.progressoInformado = Math.max(
      grupoAtual.progressoInformado,
      pegarNumero(registro.progresso),
    );

    if (
      obterTimestampData(data) >=
      obterTimestampData(grupoAtual.ultimaLeituraEm)
    ) {
      grupoAtual.ultimoCapituloLidoId = capituloId;
      grupoAtual.ultimaLeituraEm = data;
      grupoAtual.visibilidade = obterVisibilidadeRegistroDiario(
        registro,
        "privado",
      );
    }

    progressoPorObra.set(obra.id, grupoAtual);
  });

  const lendoPorObra = new Map<string, DiarioPerfilItem>();

  progressoPorObra.forEach((grupo, obraId) => {
    const totalCapitulos = grupo.obra.capitulos.length;
    const capitulosLidosValidos = grupo.obra.capitulos.filter((capitulo) =>
      grupo.capitulosLidos.has(capitulo.id),
    ).length;
    const progressoCalculado = totalCapitulos
      ? Math.round((capitulosLidosValidos / totalCapitulos) * 100)
      : 0;
    const progressoObra =
      capitulosLidosValidos > 0
        ? progressoCalculado
        : Math.min(
            99,
            Math.max(1, Math.round(grupo.progressoInformado)),
          );

    if (progressoObra <= 0) {
      return;
    }

    const capitulos = grupo.obra.capitulos.map((capitulo) => {
      const lidoEm = grupo.capitulosLidos.get(capitulo.id) || "";

      return {
        ...capitulo,
        lido: Boolean(lidoEm),
        lidoEm,
      };
    });

    const obraComProgresso: ObraLocal = {
      ...grupo.obra,
      capitulos,
      ultimoCapituloLidoId: grupo.ultimoCapituloLidoId,
      ultimaLeituraEm: grupo.ultimaLeituraEm,
      progressoLeitura: progressoObra,
    };

    lendoPorObra.set(
      obraId,
      criarItemDiarioPerfil(
        "lendo",
        obraComProgresso,
        grupo.ultimaLeituraEm || grupo.obra.criadaEm,
        `Leitura em andamento • ${progressoObra}% concluída`,
        {
          progresso: progressoObra,
          visibilidade: grupo.visibilidade,
        },
      ),
    );
  });

  const lendoAgora = ordenarItensDiarioPerfil(Array.from(lendoPorObra.values()));

  const queroLer = ordenarItensDiarioPerfil(
    seguindoObras
      .filter((registro) =>
        registroDiarioPodeAparecer(registro, incluirItensDoDiario, "privado"),
      )
      .map((registro) => {
        const obra = obterObraRegistroDiario(registro, obrasPorId, obrasPorCapituloId);

        if (!obra || concluidasIds.has(obra.id)) {
          return null;
        }

        return criarItemDiarioPerfil(
          "quero_ler",
          obra,
          obterDataRegistroDiario(registro) || obra.criadaEm,
          "Adicionada para acompanhar depois",
          {
            visibilidade: obterVisibilidadeRegistroDiario(
              registro,
              "privado",
            ),
          },
        );
      })
      .filter((item): item is DiarioPerfilItem => Boolean(item)),
  );

  const favoritas = ordenarItensDiarioPerfil(
    favoritos
      .filter((registro) =>
        registroDiarioPodeAparecer(registro, incluirItensDoDiario, "parcial"),
      )
      .map((registro) => {
        const obra = obterObraRegistroDiario(registro, obrasPorId, obrasPorCapituloId);

        if (!obra) {
          return null;
        }

        return criarItemDiarioPerfil(
          "favorita",
          obra,
          obterDataRegistroDiario(registro) || obra.criadaEm,
          "Obra favoritada no Diário",
          {
            visibilidade: obterVisibilidadeRegistroDiario(
              registro,
              "parcial",
            ),
          },
        );
      })
      .filter((item): item is DiarioPerfilItem => Boolean(item)),
  );

  const concluidasItens = ordenarItensDiarioPerfil(
    concluidas
      .filter((registro) =>
        registroDiarioPodeAparecer(registro, incluirItensDoDiario, "parcial"),
      )
      .map((registro) => {
        const obra = obterObraRegistroDiario(registro, obrasPorId, obrasPorCapituloId);

        if (!obra) {
          return null;
        }

        return criarItemDiarioPerfil(
          "concluida",
          obra,
          obterDataRegistroDiario(registro) || obra.ultimaLeituraEm || obra.criadaEm,
          "Obra marcada como concluída",
          {
            visibilidade: obterVisibilidadeRegistroDiario(
              registro,
              "parcial",
            ),
          },
        );
      })
      .filter((item): item is DiarioPerfilItem => Boolean(item)),
  );

  const avaliacoesItens = ordenarItensDiarioPerfil(
    avaliacoes
      .filter((registro) =>
        registroDiarioPodeAparecer(registro, incluirItensDoDiario, "publico"),
      )
      .map((registro) => {
        const obra = obterObraRegistroDiario(registro, obrasPorId, obrasPorCapituloId);
        const nota = Number(registro.nota ?? registro.rating ?? registro.avaliacao);

        if (!obra || !Number.isFinite(nota) || nota <= 0) {
          return null;
        }

        return criarItemDiarioPerfil(
          "avaliacao",
          obra,
          obterDataRegistroDiario(registro) || obra.criadaEm,
          `Avaliou com ${formatarMediaAvaliacaoAutor(nota).replace(".", ",")} estrelas`,
          {
            nota,
            visibilidade: obterVisibilidadeRegistroDiario(
              registro,
              "publico",
            ),
          },
        );
      })
      .filter((item): item is DiarioPerfilItem => Boolean(item)),
  );

  const atividadesDoDiario = ordenarItensDiarioPerfil(
    diarioAtividades
      .filter((registro) =>
        registroDiarioPodeAparecer(registro, incluirItensDoDiario, "privado"),
      )
      .map((registro) =>
        criarItemAtividadeDiarioPerfil(registro, obrasPorId, obrasPorCapituloId),
      )
      .filter((item): item is DiarioPerfilItem => Boolean(item)),
  );
  const atividadesReais = ordenarItensDiarioPerfil(
    diarioAtividades
      .filter((registro) =>
        registroDiarioPodeAparecer(
          registro,
          incluirItensDasAtividades,
          "privado",
        ),
      )
      .map((registro) =>
        criarItemAtividadeDiarioPerfil(registro, obrasPorId, obrasPorCapituloId),
      )
      .filter((item): item is DiarioPerfilItem => Boolean(item)),
  );

  const reviews = atividadesDoDiario.filter((item) => item.tipo === "review");

  const atividades = ordenarItensDiarioPerfil([
    ...atividadesReais,
    ...lendoAgora,
    ...queroLer,
    ...favoritas,
    ...concluidasItens,
    ...avaliacoesItens,
  ]).slice(0, 12);

  return {
    lendoAgora,
    queroLer,
    favoritas,
    concluidas: concluidasItens,
    avaliacoes: avaliacoesItens,
    reviews,
    atividades,
  };
}

async function sincronizarTabelaUsuario(
  tabela: string,
  colunaId: string,
  idValor: string,
  ativo: boolean,
  visibilidade: VisibilidadeDiarioPerfil = "parcial",
) {
  try {
    const { data } = await supabase.auth.getUser();
    const userId = data.user?.id || "";

    if (!userId || !idValor) {
      return;
    }

    const { error: erroDelete } = await supabase
      .from(tabela)
      .delete()
      .eq("user_id", userId)
      .eq(colunaId, idValor);

    if (erroDelete) {
      throw erroDelete;
    }

    if (!ativo) {
      return;
    }

    const payloadBase = {
      user_id: userId,
      [colunaId]: idValor,
    };

    const { error: erroComVisibilidade } = await supabase.from(tabela).insert({
      ...payloadBase,
      visibilidade,
    });

    if (!erroComVisibilidade) {
      return;
    }

    const { error: erroSemVisibilidade } = await supabase
      .from(tabela)
      .insert(payloadBase);

    if (erroSemVisibilidade) {
      throw erroSemVisibilidade;
    }
  } catch (error) {
    console.warn(`Não consegui sincronizar ${tabela} no perfil:`, error);
    // A ação local permanece funcionando se o Supabase falhar.
  }
}

async function sincronizarAutorSeguidoSupabase(autor: string, ativo: boolean) {
  try {
    const { data } = await supabase.auth.getUser();
    const userId = data.user?.id || "";

    if (!userId || !autor) {
      return;
    }

    if (ativo) {
      await supabase.from("seguindo_autores").upsert(
        {
          user_id: userId,
          autor,
        },
        { onConflict: "user_id,autor" },
      );
      return;
    }

    await supabase
      .from("seguindo_autores")
      .delete()
      .eq("user_id", userId)
      .eq("autor", autor);
  } catch {
    // A ação local permanece funcionando se o Supabase falhar.
  }
}

async function contarSeguimentoUsuarioPerfil(
  coluna: "seguidor_id" | "seguido_id",
  userId: string,
) {
  if (!userId || !idAutorSupabaseValido(userId)) {
    return 0;
  }

  try {
    const { count, error } = await supabase
      .from("seguindo_usuarios")
      .select("id", { count: "exact", head: true })
      .eq(coluna, userId);

    if (error) {
      console.warn("Não consegui contar seguidores do perfil:", error.message);
      return 0;
    }

    return count || 0;
  } catch (error) {
    console.warn("Não consegui acessar seguidores do perfil:", error);
    return 0;
  }
}

async function carregarEstadoSeguimentoUsuarioPerfil(
  seguidorId: string,
  seguidoId: string,
) {
  if (!seguidoId || !idAutorSupabaseValido(seguidoId)) {
    return {
      seguindo: false,
      seguidoresTotal: 0,
      seguindoTotal: 0,
    };
  }

  const [seguidoresTotal, seguindoTotal] = await Promise.all([
    contarSeguimentoUsuarioPerfil("seguido_id", seguidoId),
    contarSeguimentoUsuarioPerfil("seguidor_id", seguidoId),
  ]);

  if (!seguidorId || !idAutorSupabaseValido(seguidorId) || seguidorId === seguidoId) {
    return {
      seguindo: false,
      seguidoresTotal,
      seguindoTotal,
    };
  }

  try {
    const { data, error } = await supabase
      .from("seguindo_usuarios")
      .select("seguidor_id")
      .eq("seguidor_id", seguidorId)
      .eq("seguido_id", seguidoId)
      .maybeSingle();

    if (error) {
      console.warn("Não consegui conferir se você segue este perfil:", error.message);
    }

    return {
      seguindo: !error && Boolean(data),
      seguidoresTotal,
      seguindoTotal,
    };
  } catch (error) {
    console.warn("Não consegui acessar o estado de seguimento do perfil:", error);

    return {
      seguindo: false,
      seguidoresTotal,
      seguindoTotal,
    };
  }
}

async function sincronizarUsuarioSeguidoSupabase(
  seguidorId: string,
  seguidoId: string,
  ativo: boolean,
): Promise<{ ok: boolean; erro: string }> {
  if (!seguidorId || !seguidoId) {
    return { ok: false, erro: "IDs de usuário ausentes." };
  }

  if (!idAutorSupabaseValido(seguidorId) || !idAutorSupabaseValido(seguidoId)) {
    return { ok: false, erro: "ID de usuário inválido para seguir perfil." };
  }

  if (seguidorId === seguidoId) {
    return { ok: false, erro: "Você não pode seguir o próprio perfil." };
  }

  try {
    const { error: erroDelete } = await supabase
      .from("seguindo_usuarios")
      .delete()
      .eq("seguidor_id", seguidorId)
      .eq("seguido_id", seguidoId);

    if (erroDelete) {
      const mensagem = erroDelete.message || "Erro ao limpar seguimento antigo.";
      console.warn("Não consegui limpar seguimento antigo do perfil:", mensagem, erroDelete);

      return { ok: false, erro: mensagem };
    }

    if (!ativo) {
      return { ok: true, erro: "" };
    }

    const { error: erroInsert } = await supabase.from("seguindo_usuarios").insert({
      seguidor_id: seguidorId,
      seguido_id: seguidoId,
    });

    if (erroInsert) {
      const mensagem = erroInsert.message || "Erro ao salvar seguimento.";
      console.warn("Não consegui seguir o perfil:", mensagem, erroInsert);

      return { ok: false, erro: mensagem };
    }

    return { ok: true, erro: "" };
  } catch (error) {
    const mensagem = error instanceof Error ? error.message : "Erro inesperado ao seguir perfil.";
    console.warn("Não consegui sincronizar seguimento do perfil:", error);

    return { ok: false, erro: mensagem };
  }
}


type NotificacaoSocialPerfilAutorPayload = {
  receptorId: string;
  tipo: string;
  titulo: string;
  mensagem: string;
  link: string;
  notificacaoId: string;
};

function avisarAtualizacaoNotificacoesPerfilAutor() {
  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new Event("historietas:notificacoes-atualizadas"),
    );
  }
}

async function removerNotificacoesSociaisPerfilAutor(
  receptorId: string,
  notificacaoIds: string[],
) {
  const receptorIdLimpo = receptorId.trim();
  const idsLimpos = Array.from(
    new Set(
      notificacaoIds
        .map((id) => id.trim())
        .filter(Boolean),
    ),
  );

  if (
    !receptorIdLimpo ||
    !idAutorSupabaseValido(receptorIdLimpo) ||
    idsLimpos.length === 0
  ) {
    return false;
  }

  try {
    const { error } = await supabase
      .from("notificacoes")
      .delete()
      .eq("user_id", receptorIdLimpo)
      .in("notificacao_id", idsLimpos);

    if (error) {
      console.warn(
        "Não consegui remover notificação social antiga:",
        error.message,
      );
      return false;
    }

    avisarAtualizacaoNotificacoesPerfilAutor();
    return true;
  } catch (error) {
    console.warn(
      "Não consegui remover notificação social antiga:",
      error,
    );
    return false;
  }
}

async function criarNotificacaoSocialPerfilAutor({
  receptorId,
  tipo,
  titulo,
  mensagem,
  link,
  notificacaoId,
}: NotificacaoSocialPerfilAutorPayload) {
  const receptorIdLimpo = receptorId.trim();
  const tipoLimpo = tipo.trim();
  const notificacaoIdLimpo = notificacaoId.trim();

  if (
    !receptorIdLimpo ||
    !idAutorSupabaseValido(receptorIdLimpo) ||
    !tipoLimpo ||
    !notificacaoIdLimpo
  ) {
    return false;
  }

  try {
    const { error } = await supabase.rpc("criar_notificacao_social", {
      p_user_id: receptorIdLimpo,
      p_tipo: tipoLimpo,
      p_titulo: titulo.trim() || "Nova notificação",
      p_mensagem: mensagem.trim() || "Você recebeu uma nova notificação.",
      p_link: link.trim() || "/notificacoes",
      p_notificacao_id: notificacaoIdLimpo,
      p_obra_id: null,
      p_capitulo_id: null,
    });

    if (error) {
      console.warn("Não consegui criar notificação social:", error.message);
      return false;
    }

    avisarAtualizacaoNotificacoesPerfilAutor();
    return true;
  } catch (error) {
    console.warn("Não consegui criar notificação social:", error);
    return false;
  }
}


type MenuPerfilIconeTipo =
  | "painel"
  | "notificacoes"
  | "configuracoes"
  | "link"
  | "sair"
  | "comunidade"
  | "denunciar"
  | "bloquear"
  | "explorar";

function CadeadoAvaliacaoDiarioIcone() {
  return (
    <svg
      width="23"
      height="25"
      viewBox="0 0 24 26"
      fill="none"
      aria-hidden="true"
      focusable="false"
    >
      <path
        fill="currentColor"
        d="M7 9V6.75C7 3.57 9.24 1 12 1s5 2.57 5 5.75V9h-2.75V6.75c0-1.55-1-2.8-2.25-2.8S9.75 5.2 9.75 6.75V9H7Z"
      />
      <rect
        x="3"
        y="8"
        width="18"
        height="16"
        rx="3.2"
        fill="currentColor"
      />
      <circle cx="12" cy="15" r="1.65" fill="rgba(0,0,0,0.88)" />
      <rect
        x="11.15"
        y="15.7"
        width="1.7"
        height="4"
        rx="0.85"
        fill="rgba(0,0,0,0.88)"
      />
    </svg>
  );
}

function MenuPerfilIcone({ tipo }: { tipo: MenuPerfilIconeTipo }) {
  const iconProps = {
    width: 22,
    height: 22,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2.1,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": true,
  } as const;

  if (tipo === "painel") {
    return (
      <svg {...iconProps}>
        <path d="M4 19V5" />
        <path d="M20 19H4" />
        <path d="M8 16V10" />
        <path d="M12 16V7" />
        <path d="M16 16v-4" />
      </svg>
    );
  }

  if (tipo === "notificacoes") {
    return (
      <svg {...iconProps}>
        <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" />
        <path d="M13.73 21a2 2 0 0 1-3.46 0" />
      </svg>
    );
  }

  if (tipo === "configuracoes") {
    return (
      <svg {...iconProps}>
        <path d="M12 15.2A3.2 3.2 0 1 0 12 8.8a3.2 3.2 0 0 0 0 6.4Z" />
        <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06A1.65 1.65 0 0 0 15 19.4a1.65 1.65 0 0 0-1 .6 1.65 1.65 0 0 0-.4 1.08V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 8.6 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-.6-1 1.65 1.65 0 0 0-1.08-.4H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 8.6a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-.6A1.65 1.65 0 0 0 10.4 3V3a2 2 0 1 1 4 0v.09A1.65 1.65 0 0 0 15.4 4.6a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9c.42.18.72.56.72 1v4c0 .44-.3.82-.72 1Z" />
      </svg>
    );
  }

  if (tipo === "link") {
    return (
      <svg {...iconProps}>
        <path d="M10 13a5 5 0 0 0 7.07 0l2.12-2.12a5 5 0 0 0-7.07-7.07L10.9 5.03" />
        <path d="M14 11a5 5 0 0 0-7.07 0L4.81 13.12a5 5 0 0 0 7.07 7.07l1.22-1.22" />
      </svg>
    );
  }

  if (tipo === "sair") {
    return (
      <svg {...iconProps}>
        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
        <path d="M16 17l5-5-5-5" />
        <path d="M21 12H9" />
      </svg>
    );
  }

  if (tipo === "comunidade") {
    return (
      <svg {...iconProps}>
        <path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z" />
      </svg>
    );
  }

  if (tipo === "denunciar") {
    return (
      <svg {...iconProps}>
        <path d="M12 3 3 7v6c0 5 3.8 7.6 9 8 5.2-.4 9-3 9-8V7l-9-4Z" />
        <path d="M12 8v5" />
        <path d="M12 17h.01" />
      </svg>
    );
  }

  if (tipo === "bloquear") {
    return (
      <svg {...iconProps}>
        <circle cx="12" cy="12" r="9" />
        <path d="m6.5 6.5 11 11" />
      </svg>
    );
  }

  return (
    <svg {...iconProps}>
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-3.5-3.5" />
    </svg>
  );
}


type DadosCompartilhamentoPerfilAutor = {
  title?: string;
  text?: string;
  url?: string;
};

type NavegadorCompartilhamentoPerfilAutor = Navigator & {
  share?: (data: DadosCompartilhamentoPerfilAutor) => Promise<void>;
  canShare?: (data: DadosCompartilhamentoPerfilAutor) => boolean;
};

function criarUrlAbsolutaCompartilhamentoPerfilAutor(href: string) {
  const hrefLimpo = href.trim();

  if (typeof window === "undefined") {
    return hrefLimpo;
  }

  try {
    return new URL(hrefLimpo || window.location.href, window.location.origin).toString();
  } catch {
    return window.location.href;
  }
}

async function copiarTextoComFallbackPerfilAutor(texto: string) {
  const textoLimpo = texto.trim();

  if (!textoLimpo || typeof window === "undefined" || typeof document === "undefined") {
    return false;
  }

  try {
    if (
      window.isSecureContext &&
      navigator.clipboard &&
      typeof navigator.clipboard.writeText === "function"
    ) {
      await navigator.clipboard.writeText(textoLimpo);
      return true;
    }
  } catch {
    // Continua para o fallback abaixo.
  }

  let campoTemporario: HTMLTextAreaElement | null = null;

  try {
    campoTemporario = document.createElement("textarea");
    campoTemporario.value = textoLimpo;
    campoTemporario.setAttribute("readonly", "true");
    campoTemporario.style.position = "fixed";
    campoTemporario.style.top = "-9999px";
    campoTemporario.style.left = "-9999px";
    campoTemporario.style.width = "1px";
    campoTemporario.style.height = "1px";
    campoTemporario.style.opacity = "0";

    document.body.appendChild(campoTemporario);
    campoTemporario.focus();
    campoTemporario.select();
    campoTemporario.setSelectionRange(0, campoTemporario.value.length);

    return document.execCommand("copy");
  } catch {
    return false;
  } finally {
    if (campoTemporario?.parentNode) {
      campoTemporario.parentNode.removeChild(campoTemporario);
    }
  }
}

function erroCompartilhamentoFoiCanceladoPerfilAutor(error: unknown) {
  if (!error || typeof error !== "object") {
    return false;
  }

  const nomeErro = "name" in error ? String((error as { name?: unknown }).name || "") : "";

  return nomeErro === "AbortError";
}

function LoadingSpinner({
  label = "Carregando",
  compacto = false,
}: {
  label?: string;
  compacto?: boolean;
}) {
  return (
    <div
      role="status"
      aria-live="polite"
      aria-label={label}
      style={compacto ? loadingInlineStyle : loadingPageStyle}
    >
      <span
        className="historietas-loading-spinner"
        style={compacto ? loadingSpinnerCompactStyle : loadingSpinnerStyle}
        aria-hidden="true"
      />
    </div>
  );
}

function PerfilAutorPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { language } = useHistorietasLanguage();
  const queryPerfilAtual = searchParams.toString();
  const [obras, setObras] = useState<ObraLocal[]>([]);
  const [totaisInteracoesObras, setTotaisInteracoesObras] =
    useState<TotaisInteracoesObrasPerfilAutor>(totaisInteracoesObrasPerfilVazio);
  const [autorSelecionado, setAutorSelecionado] = useState("");
  const [autorIdSelecionado, setAutorIdSelecionado] = useState("");
  const [autoresSeguidos, setAutoresSeguidos] = useState<string[]>([]);
  const [obrasFavoritas, setObrasFavoritas] = useState<string[]>([]);
  const [obrasConcluidas, setObrasConcluidas] = useState<string[]>([]);
  const [topFiveObraIds, setTopFiveObraIds] = useState<string[]>([]);
  const [topFiveCurtidasTotal, setTopFiveCurtidasTotal] = useState(0);
  const [topFiveCurtidoPorMim, setTopFiveCurtidoPorMim] = useState(false);
  const [topFiveCurtidaSalvando, setTopFiveCurtidaSalvando] = useState(false);
  const [mostrarDestaquesVisitante, setMostrarDestaquesVisitante] = useState(false);
  const [perfisAutoresSalvos, setPerfisAutoresSalvos] =
    useState<PerfisAutoresSalvos>({});
  const [avatarErro, setAvatarErro] = useState("");
  const [mensagemAcao, setMensagemAcao] = useState("");
  const [perfilUsuarioRemoto, setPerfilUsuarioRemoto] =
    useState<PerfilUsuarioRemoto | null>(null);
  const [usuarioIdLogado, setUsuarioIdLogado] = useState("");
  const [autenticacaoCarregada, setAutenticacaoCarregada] = useState(false);
  const [podeEditarPerfil, setPodeEditarPerfil] = useState(false);
  const [carregando, setCarregando] = useState(true);
  const [menuPerfilAberto, setMenuPerfilAberto] = useState(false);
  const [usernameCabecalhoVisivel, setUsernameCabecalhoVisivel] =
    useState(false);
  const [editorPerfilAberto, setEditorPerfilAberto] = useState(false);
  const [nomePerfilEditor, setNomePerfilEditor] = useState("");
  const [usernamePerfilEditor, setUsernamePerfilEditor] = useState("");
  const [bioPerfilEditor, setBioPerfilEditor] = useState("");
  const [avatarPerfilEditor, setAvatarPerfilEditor] = useState("");
  const [avatarNomePerfilEditor, setAvatarNomePerfilEditor] = useState("");
  const [avatarArquivoPerfilEditor, setAvatarArquivoPerfilEditor] =
    useState<File | null>(null);
  const [salvandoEditorPerfil, setSalvandoEditorPerfil] = useState(false);
  const [editorSobreAberto, setEditorSobreAberto] = useState(false);
  const [abaPerfil, setAbaPerfil] = useState<AbaPerfilAutor>(() =>
    normalizarAbaPerfilAutor(searchParams.get("aba")),
  );
  const [abaBibliotecaPerfil, setAbaBibliotecaPerfil] =
    useState<AbaBibliotecaPerfil>("tudo");
  const [obrasSeguidasBiblioteca, setObrasSeguidasBiblioteca] = useState<string[]>([]);
  const [versaoSincronizacaoBiblioteca, setVersaoSincronizacaoBiblioteca] =
    useState(0);
  const [obraMenuAbertoId, setObraMenuAbertoId] = useState("");
  const [bibliotecaMenuAbertoChave, setBibliotecaMenuAbertoChave] = useState("");
  const [avaliacaoAutor, setAvaliacaoAutor] =
    useState<AvaliacaoAutorPublica>(avaliacaoAutorVazia);
  const [avaliacaoDiario, setAvaliacaoDiario] =
    useState<AvaliacaoDiarioPublica>(avaliacaoDiarioVazia);
  const [diarioPerfil, setDiarioPerfil] =
    useState<DiarioPerfilEstado>(diarioPerfilVazio);
  const [comunidadePerfil, setComunidadePerfil] =
    useState<ComunidadePerfilEstado>(comunidadePerfilVazia);
  const [atividadeSobreAberta, setAtividadeSobreAberta] = useState(false);
  const [seguindoUsuarioPerfil, setSeguindoUsuarioPerfil] = useState(false);
  const [seguidoresUsuarioPerfilTotal, setSeguidoresUsuarioPerfilTotal] =
    useState(0);
  const [seguindoUsuarioPerfilTotal, setSeguindoUsuarioPerfilTotal] =
    useState(0);
  const [seguirUsuarioSalvando, setSeguirUsuarioSalvando] = useState(false);
  const [estadoRelacionamentoPerfil, setEstadoRelacionamentoPerfil] =
    useState<EstadoRelacionamentoPerfil>("nenhum");
  const [permissoesAbasPerfil, setPermissoesAbasPerfil] =
    useState<PermissoesAbasPerfil>(PERMISSOES_ABAS_PERFIL_PADRAO);
  const [privacidadePerfilCarregando, setPrivacidadePerfilCarregando] =
    useState(true);
  const [denunciaPerfilAberta, setDenunciaPerfilAberta] = useState(false);
  const [
    alvoDenunciaConteudoPerfil,
    setAlvoDenunciaConteudoPerfil,
  ] = useState<AlvoDenunciaConteudoPerfil>(null);
  const [estadoBloqueioPerfil, setEstadoBloqueioPerfil] =
    useState<EstadoBloqueioPerfil>({
      bloqueadoPorMim: false,
      bloqueadoPeloPerfil: false,
      existeBloqueio: false,
    });
  const [bloqueioPerfilSalvando, setBloqueioPerfilSalvando] =
    useState(false);
  const seguidoresTotalEstavelRef = useRef<Record<string, number>>({});
  const seguindoTotalEstavelRef = useRef<Record<string, number>>({});

  const avatarInputRef = useRef<HTMLInputElement | null>(null);
  const [isDesktop, setIsDesktop] = useState(false);
  const { pageThemeStyle } = useHistorietasTheme(pageStyle);
  const {
    usuarioId: usuarioNotificacoesId,
    notificacoesNaoLidas: notificacoesNaoLidasContexto,
  } = useNotificacoes();
  const [notificacoesNaoLidasPerfil, setNotificacoesNaoLidasPerfil] =
    useState<number | null>(null);
  const notificacoesNaoLidas =
    notificacoesNaoLidasPerfil ?? notificacoesNaoLidasContexto;

  useEffect(() => {
    if (!mensagemAcao) {
      return;
    }

    const timerMensagemAcao = window.setTimeout(() => {
      setMensagemAcao("");
    }, 3000);

    return () => {
      window.clearTimeout(timerMensagemAcao);
    };
  }, [mensagemAcao]);

  useEffect(() => {
    function atualizarTelaDesktop() {
      setIsDesktop(window.innerWidth >= 1024);
    }

    atualizarTelaDesktop();
    window.addEventListener("resize", atualizarTelaDesktop);

    return () => {
      window.removeEventListener("resize", atualizarTelaDesktop);
    };
  }, []);

  useEffect(() => {
    let componenteAtivo = true;

    async function carregarUsuarioAutenticadoPerfil() {
      try {
        const { data } = await supabase.auth.getUser();
        const userId = data.user?.id || "";

        if (componenteAtivo) {
          setUsuarioIdLogado(userId);
          setAutenticacaoCarregada(true);
        }
      } catch {
        if (componenteAtivo) {
          setUsuarioIdLogado("");
          setAutenticacaoCarregada(true);
        }
      }
    }

    void carregarUsuarioAutenticadoPerfil();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (componenteAtivo) {
        setUsuarioIdLogado(session?.user?.id || "");
        setAutenticacaoCarregada(true);
      }
    });

    return () => {
      componenteAtivo = false;
      subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    const userIdSeguro = (
      usuarioNotificacoesId || usuarioIdLogado
    ).trim();

    if (!idAutorSupabaseValido(userIdSeguro)) {
      setNotificacoesNaoLidasPerfil(null);
      return;
    }

    let cancelado = false;
    let timerAtualizacao: number | null = null;

    function limparTimerAtualizacao() {
      if (timerAtualizacao !== null) {
        window.clearTimeout(timerAtualizacao);
        timerAtualizacao = null;
      }
    }

    async function carregarContadorNotificacoesPerfil() {
      const [
        { data: notificacoesData, count: notificacoesCount, error: notificacoesError },
        { data: solicitacoesData, error: solicitacoesError },
      ] = await Promise.all([
        supabase
          .from("notificacoes")
          .select("notificacao_id", { count: "exact" })
          .eq("user_id", userIdSeguro)
          .eq("lida", false)
          .limit(1000),
        supabase
          .from("solicitacoes_seguidores")
          .select("solicitante_id")
          .eq("destinatario_id", userIdSeguro)
          .limit(1000),
      ]);

      if (cancelado) {
        return;
      }

      if (notificacoesError) {
        console.warn(
          "Não consegui atualizar o contador de notificações do perfil:",
          notificacoesError.message,
        );
        setNotificacoesNaoLidasPerfil(null);
        return;
      }

      const idsNotificacoesDiretas = new Set(
        (Array.isArray(notificacoesData) ? notificacoesData : [])
          .map((registro) => {
            const notificacaoId = (
              registro as { notificacao_id?: unknown }
            ).notificacao_id;

            return typeof notificacaoId === "string"
              ? notificacaoId.trim()
              : "";
          })
          .filter(Boolean),
      );

      let solicitacoesPendentesSemNotificacao = 0;

      if (!solicitacoesError && Array.isArray(solicitacoesData)) {
        const solicitantesPendentes = new Set(
          solicitacoesData
            .map((registro) => {
              const solicitanteId = (
                registro as { solicitante_id?: unknown }
              ).solicitante_id;

              return typeof solicitanteId === "string"
                ? solicitanteId.trim()
                : "";
            })
            .filter(Boolean),
        );

        solicitantesPendentes.forEach((solicitanteId) => {
          const notificacaoIdEsperado =
            `solicitacao-seguidor:${solicitanteId}:${userIdSeguro}`;

          if (!idsNotificacoesDiretas.has(notificacaoIdEsperado)) {
            solicitacoesPendentesSemNotificacao += 1;
          }
        });
      }

      const totalDiretas = Number(
        notificacoesCount ??
          (Array.isArray(notificacoesData) ? notificacoesData.length : 0),
      );
      const totalSeguro = Number.isFinite(totalDiretas)
        ? Math.max(
            0,
            Math.trunc(totalDiretas) + solicitacoesPendentesSemNotificacao,
          )
        : solicitacoesPendentesSemNotificacao;

      setNotificacoesNaoLidasPerfil(totalSeguro);
    }

    function agendarAtualizacaoContador() {
      limparTimerAtualizacao();

      timerAtualizacao = window.setTimeout(() => {
        timerAtualizacao = null;
        void carregarContadorNotificacoesPerfil();
      }, 180);
    }

    function atualizarAoRetomarPerfil() {
      if (document.visibilityState === "visible") {
        agendarAtualizacaoContador();
      }
    }

    void carregarContadorNotificacoesPerfil();

    const canalContador = supabase
      .channel(`perfil-autor-contador-notificacoes-${userIdSeguro}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "notificacoes",
          filter: `user_id=eq.${userIdSeguro}`,
        },
        agendarAtualizacaoContador,
      )
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "solicitacoes_seguidores",
          filter: `destinatario_id=eq.${userIdSeguro}`,
        },
        agendarAtualizacaoContador,
      )
      .subscribe();

    const intervaloAtualizacao = window.setInterval(() => {
      if (document.visibilityState === "visible") {
        agendarAtualizacaoContador();
      }
    }, 20000);

    window.addEventListener(
      "historietas:notificacoes-atualizadas",
      agendarAtualizacaoContador,
    );
    window.addEventListener("focus", agendarAtualizacaoContador);
    document.addEventListener("visibilitychange", atualizarAoRetomarPerfil);

    return () => {
      cancelado = true;
      limparTimerAtualizacao();
      window.clearInterval(intervaloAtualizacao);
      window.removeEventListener(
        "historietas:notificacoes-atualizadas",
        agendarAtualizacaoContador,
      );
      window.removeEventListener("focus", agendarAtualizacaoContador);
      document.removeEventListener(
        "visibilitychange",
        atualizarAoRetomarPerfil,
      );
      void supabase.removeChannel(canalContador);
    };
  }, [usuarioIdLogado, usuarioNotificacoesId]);

  useEffect(() => {
    let cancelado = false;

    async function carregarTotaisReaisPerfil() {
      if (obras.length === 0) {
        setTotaisInteracoesObras(totaisInteracoesObrasPerfilVazio);
        return;
      }

      const totaisReais = await carregarTotaisInteracoesObrasPerfilAutor(obras);

      if (!cancelado) {
        setTotaisInteracoesObras(totaisReais);
      }
    }

    void carregarTotaisReaisPerfil();

    return () => {
      cancelado = true;
    };
  }, [obras]);


  useEffect(() => {
    let componenteAtivo = true;

    async function carregarPerfilAutor() {
      const params = new URLSearchParams(queryPerfilAtual);
      const autorParam = params.get("autor") || "";
      const autorIdParam =
        params.get("autorId") || params.get("id") || params.get("userId") || "";
      const abaParam = normalizarAbaPerfilAutor(params.get("aba"));
      setAbaPerfil(abaParam);
      setAutorSelecionado(autorParam.trim());
      setAutorIdSelecionado(autorIdParam.trim());
      setPodeEditarPerfil(false);

      let obrasNormalizadas: ObraLocal[] = [];
      let autoresSeguidosNormalizados: string[] = [];
      let obrasFavoritasNormalizadas: string[] = [];
      let obrasConcluidasNormalizadas: string[] = [];
      let obrasSeguidasBibliotecaNormalizadas: string[] = [];
      let perfilUsuarioRemotoCarregado: PerfilUsuarioRemoto | null = null;

      const obrasSupabase = await carregarObrasPublicadasSupabase();
      const estadoUsuarioSupabase = await carregarEstadoUsuarioSupabase();
      const usuarioIdAtual = estadoUsuarioSupabase?.userId || "";

      if (usuarioIdAtual) {
        try {
          const obrasSalvasJson = carregarJsonUsuarioPerfilAutor(
            STORAGE_KEY,
            usuarioIdAtual,
          );

          obrasNormalizadas = Array.isArray(obrasSalvasJson)
            ? (obrasSalvasJson as ObraSalva[]).map((obra, index) =>
                normalizarObra(obra, index),
              )
            : [];

          const autoresSeguidosJson = carregarJsonUsuarioPerfilAutor(
            AUTHOR_FOLLOW_STORAGE_KEY,
            usuarioIdAtual,
          );

          autoresSeguidosNormalizados = Array.isArray(autoresSeguidosJson)
            ? autoresSeguidosJson
                .filter(
                  (autor): autor is string =>
                    typeof autor === "string" && Boolean(autor.trim()),
                )
                .map((autor) => normalizarNomeAutor(autor))
            : [];

          obrasFavoritasNormalizadas = carregarListaIdsPerfilBiblioteca(
            FAVORITES_STORAGE_KEY,
            usuarioIdAtual,
          );

          obrasConcluidasNormalizadas = carregarListaIdsPerfilBiblioteca(
            COMPLETED_STORAGE_KEY,
            usuarioIdAtual,
          );

          obrasSeguidasBibliotecaNormalizadas =
            carregarListaIdsPerfilBiblioteca(
              LIBRARY_FOLLOW_STORAGE_KEY,
              usuarioIdAtual,
            );
        } catch {
          obrasNormalizadas = [];
          autoresSeguidosNormalizados = [];
          obrasFavoritasNormalizadas = [];
          obrasConcluidasNormalizadas = [];
          obrasSeguidasBibliotecaNormalizadas = [];
        }
      }

      const perfilUsuarioIdParaBuscar =
        autorIdParam.trim() || usuarioIdAtual;

      perfilUsuarioRemotoCarregado = await carregarPerfilUsuarioSupabase(
        perfilUsuarioIdParaBuscar,
        autorParam.trim(),
      );

      const obrasLocaisDoUsuario = filtrarObrasLocaisDoUsuarioPerfilAutor(
        obrasNormalizadas,
        usuarioIdAtual,
      );

      let obrasMescladas = mesclarObrasPorIdSlug(
        obrasLocaisDoUsuario,
        obrasSupabase,
      );

      if (estadoUsuarioSupabase) {
        obrasFavoritasNormalizadas = Array.from(
          new Set([
            ...obrasFavoritasNormalizadas,
            ...estadoUsuarioSupabase.favoritas,
          ]),
        );
        obrasConcluidasNormalizadas = Array.from(
          new Set([
            ...obrasConcluidasNormalizadas,
            ...estadoUsuarioSupabase.concluidas,
          ]),
        );
        autoresSeguidosNormalizados = Array.from(
          new Set([
            ...autoresSeguidosNormalizados,
            ...estadoUsuarioSupabase.autoresSeguidos,
          ]),
        );
        obrasSeguidasBibliotecaNormalizadas = Array.from(
          new Set([
            ...obrasSeguidasBibliotecaNormalizadas,
            ...estadoUsuarioSupabase.obrasSeguidas,
          ]),
        );

        obrasMescladas = aplicarInteracoesNasObras(
          obrasMescladas,
          estadoUsuarioSupabase.interacoes.curtidas,
          estadoUsuarioSupabase.interacoes.salvos,
          estadoUsuarioSupabase.interacoes.comentarios,
          estadoUsuarioSupabase.interacoes.progresso,
          estadoUsuarioSupabase.interacoes.progressoCarregado,
        );
      }

      const idsBibliotecaLocal = Array.from(
        new Set([
          ...obrasFavoritasNormalizadas,
          ...obrasConcluidasNormalizadas,
          ...obrasSeguidasBibliotecaNormalizadas,
        ]),
      ).filter((obraId) => idObraSupabaseValido(obraId));

      if (idsBibliotecaLocal.length > 0) {
        const idsObrasCarregadas = new Set(
          obrasMescladas.map((obra) => obra.id).filter(Boolean),
        );
        const idsObrasBibliotecaFaltantes = idsBibliotecaLocal.filter(
          (obraId) => !idsObrasCarregadas.has(obraId),
        );

        if (idsObrasBibliotecaFaltantes.length > 0) {
          const obrasBibliotecaFaltantes =
            await carregarObrasPublicadasPorIdsSupabase(
              idsObrasBibliotecaFaltantes,
            );

          obrasMescladas = mesclarObrasPorIdSlug(
            obrasMescladas,
            obrasBibliotecaFaltantes,
          );
        }
      }

      if (usuarioIdAtual) {
        try {
          const obrasDoUsuarioParaPersistir = obrasMescladas.filter((obra) =>
            obraPertenceAoUsuarioPerfilAutor(obra, usuarioIdAtual),
          );
          const obrasParaPersistir = mesclarObrasLocalStoragePerfilAutor(
            obrasNormalizadas,
            obrasDoUsuarioParaPersistir,
            usuarioIdAtual,
          );

          salvarJsonUsuarioPerfilAutor(
            STORAGE_KEY,
            usuarioIdAtual,
            obrasParaPersistir,
          );

          salvarJsonUsuarioPerfilAutor(
            AUTHOR_FOLLOW_STORAGE_KEY,
            usuarioIdAtual,
            autoresSeguidosNormalizados,
          );
          salvarListaIdsPerfilBiblioteca(
            FAVORITES_STORAGE_KEY,
            usuarioIdAtual,
            obrasFavoritasNormalizadas,
          );
          salvarListaIdsPerfilBiblioteca(
            COMPLETED_STORAGE_KEY,
            usuarioIdAtual,
            obrasConcluidasNormalizadas,
          );
          salvarListaIdsPerfilBiblioteca(
            LIBRARY_FOLLOW_STORAGE_KEY,
            usuarioIdAtual,
            obrasSeguidasBibliotecaNormalizadas,
          );
        } catch {
          // Se o navegador bloquear localStorage, a página ainda usa o estado em memória.
        }
      }

      if (!componenteAtivo) {
        return;
      }

      setUsuarioIdLogado(estadoUsuarioSupabase?.userId || "");
      setPerfilUsuarioRemoto(perfilUsuarioRemotoCarregado);
      setObras(obrasMescladas);
      setAutoresSeguidos(autoresSeguidosNormalizados);
      setObrasFavoritas(obrasFavoritasNormalizadas);
      setObrasConcluidas(obrasConcluidasNormalizadas);
      setObrasSeguidasBiblioteca(obrasSeguidasBibliotecaNormalizadas);
      setPerfisAutoresSalvos(carregarPerfisAutores(usuarioIdAtual));
      setCarregando(false);
    }

    void carregarPerfilAutor();

    return () => {
      componenteAtivo = false;
    };
  }, [queryPerfilAtual]);

  const perfisAutores = useMemo<AutorPerfil[]>(() => {
    const mapa = new Map<
      string,
      { autorId: string; nome: string; obras: ObraLocal[] }
    >();

    obras.forEach((obra) => {
      const nomeAutor = obra.autor.trim() || "Autor não informado";
      const autorId = obra.autorId.trim();
      const chaveAutor = criarChaveAutorPerfil(autorId, nomeAutor);
      const autorExistente = mapa.get(chaveAutor);

      if (autorExistente) {
        mapa.set(chaveAutor, {
          ...autorExistente,
          autorId: autorExistente.autorId || autorId,
          obras: [...autorExistente.obras, obra],
        });
        return;
      }

      mapa.set(chaveAutor, {
        autorId,
        nome: nomeAutor,
        obras: [obra],
      });
    });

    return Array.from(mapa.values())
      .map((grupoAutor) => {
        const obrasDoAutor = grupoAutor.obras;

        const totalCapitulos = obrasDoAutor.reduce(
          (total, obra) => total + obra.capitulos.length,
          0,
        );

        const totalCurtidas = obrasDoAutor.reduce(
          (total, obra) =>
            total + obterTotalCurtidasObraPerfilAutor(
              obra,
              totaisInteracoesObras,
            ),
          0,
        );

        const totalComentarios = obrasDoAutor.reduce(
          (total, obra) =>
            total + obterTotalComentariosObraPerfilAutor(
              obra,
              totaisInteracoesObras,
            ),
          0,
        );

        return {
          autorId: grupoAutor.autorId,
          nome: grupoAutor.nome,
          obras: obrasDoAutor,
          totalCapitulos,
          totalPublicadas: obrasDoAutor.filter((obra) => obra.publicado).length,
          totalCurtidas,
          totalComentarios,
        };
      })
      .sort((autorA, autorB) => autorA.nome.localeCompare(autorB.nome));
  }, [obras, totaisInteracoesObras]);

  const perfilUsuarioRemotoComoAutor = useMemo(() => {
    if (!perfilUsuarioRemoto?.userId) {
      return null;
    }

    return criarPerfilUsuarioRemotoComoAutor(perfilUsuarioRemoto);
  }, [perfilUsuarioRemoto]);

  const perfilAtual = useMemo(() => {
    if (!autorSelecionado && !autorIdSelecionado) {
      return null;
    }

    const autorIdNormalizado = autorIdSelecionado.trim().toLowerCase();

    if (autorIdNormalizado) {
      const perfilPorId = perfisAutores.find(
        (perfil) => perfil.autorId.trim().toLowerCase() === autorIdNormalizado,
      );

      if (perfilPorId) {
        return perfilPorId;
      }

      if (
        perfilUsuarioRemotoComoAutor &&
        perfilUsuarioRemotoComoAutor.autorId.trim().toLowerCase() ===
          autorIdNormalizado
      ) {
        return perfilUsuarioRemotoComoAutor;
      }
    }

    const autorNormalizado = normalizarNomeAutor(autorSelecionado);

    return (
      perfisAutores.find(
        (perfil) => normalizarNomeAutor(perfil.nome) === autorNormalizado,
      ) || null
    );
  }, [
    perfisAutores,
    autorSelecionado,
    autorIdSelecionado,
    perfilUsuarioRemotoComoAutor,
  ]);

  const autorNaoEncontrado = Boolean(
    (autorSelecionado || autorIdSelecionado) && !perfilAtual,
  );

  const perfilDoUsuarioLogado = useMemo(() => {
    const usuarioIdNormalizado = usuarioIdLogado.trim().toLowerCase();

    if (!usuarioIdNormalizado) {
      return null;
    }

    return (
      perfisAutores.find(
        (perfil) =>
          perfil.autorId.trim().toLowerCase() === usuarioIdNormalizado,
      ) ||
      (perfilUsuarioRemotoComoAutor?.autorId.trim().toLowerCase() ===
      usuarioIdNormalizado
        ? perfilUsuarioRemotoComoAutor
        : null)
    );
  }, [perfisAutores, usuarioIdLogado, perfilUsuarioRemotoComoAutor]);

  const perfilSemParametro =
    !autorSelecionado.trim() && !autorIdSelecionado.trim();
  const perfilSemLoginSemParametro =
    perfilSemParametro && !usuarioIdLogado.trim();

  const perfilParaMostrar =
    autorSelecionado || autorIdSelecionado
      ? perfilAtual
      : perfilSemLoginSemParametro
        ? null
        : perfilDoUsuarioLogado || perfilUsuarioRemotoComoAutor || null;

  useEffect(() => {
    const perfilAutorId = perfilParaMostrar?.autorId?.trim() || "";
    const topFiveUserId = perfilAutorId || usuarioIdLogado.trim();

    function atualizarTopFivePerfil() {
      setTopFiveObraIds(carregarTopFivePerfilAutor(topFiveUserId));
    }

    atualizarTopFivePerfil();

    if (typeof window === "undefined") {
      return;
    }

    function atualizarQuandoVoltarParaTela() {
      if (document.visibilityState !== "hidden") {
        atualizarTopFivePerfil();
      }
    }

    window.addEventListener("focus", atualizarTopFivePerfil);
    window.addEventListener("storage", atualizarTopFivePerfil);
    document.addEventListener("visibilitychange", atualizarQuandoVoltarParaTela);

    return () => {
      window.removeEventListener("focus", atualizarTopFivePerfil);
      window.removeEventListener("storage", atualizarTopFivePerfil);
      document.removeEventListener(
        "visibilitychange",
        atualizarQuandoVoltarParaTela,
      );
    };
  }, [perfilParaMostrar?.autorId, usuarioIdLogado]);

  useEffect(() => {
    setMostrarDestaquesVisitante(false);
  }, [perfilParaMostrar?.autorId]);

  useEffect(() => {
    const perfilAutorId = perfilParaMostrar?.autorId?.trim() || "";

    if (!perfilAutorId) {
      setTopFiveCurtidasTotal(0);
      setTopFiveCurtidoPorMim(false);
      return;
    }

    let cancelado = false;

    async function atualizarCurtidasTopFive() {
      const estadoLocal = carregarCurtidasTopFiveLocais(
        perfilAutorId,
        usuarioIdLogado,
      );

      setTopFiveCurtidasTotal(estadoLocal.total);
      setTopFiveCurtidoPorMim(estadoLocal.curtiu);

      const estadoRemoto = await carregarCurtidasTopFivePerfil(
        perfilAutorId,
        usuarioIdLogado,
      );

      if (cancelado) {
        return;
      }

      setTopFiveCurtidasTotal(estadoRemoto.total);
      setTopFiveCurtidoPorMim(estadoRemoto.curtiu);
    }

    void atualizarCurtidasTopFive();

    if (typeof window === "undefined") {
      return () => {
        cancelado = true;
      };
    }

    window.addEventListener("focus", atualizarCurtidasTopFive);
    window.addEventListener("storage", atualizarCurtidasTopFive);

    return () => {
      cancelado = true;
      window.removeEventListener("focus", atualizarCurtidasTopFive);
      window.removeEventListener("storage", atualizarCurtidasTopFive);
    };
  }, [perfilParaMostrar?.autorId, usuarioIdLogado]);

  const perfilPertenceAoUsuario = useMemo(() => {
    const usuarioIdNormalizado = usuarioIdLogado.trim().toLowerCase();
    const autorIdPerfilNormalizado =
      perfilParaMostrar?.autorId.trim().toLowerCase() || "";
    const autorIdUrlNormalizado = autorIdSelecionado.trim().toLowerCase();
    const perfilSemParametro =
      !autorSelecionado.trim() && !autorIdSelecionado.trim();

    return Boolean(
      usuarioIdNormalizado &&
        (perfilSemParametro ||
          autorIdPerfilNormalizado === usuarioIdNormalizado ||
          autorIdUrlNormalizado === usuarioIdNormalizado),
    );
  }, [perfilParaMostrar, autorIdSelecionado, autorSelecionado, usuarioIdLogado]);

  const perfilBloqueadoEntreUsuarios =
    !perfilPertenceAoUsuario && estadoBloqueioPerfil.existeBloqueio;
  const obrasPerfilVisivel =
    perfilPertenceAoUsuario ||
    (!perfilBloqueadoEntreUsuarios &&
      !privacidadePerfilCarregando &&
      permissoesAbasPerfil.obras);
  const sobrePerfilVisivel =
    perfilPertenceAoUsuario ||
    (!perfilBloqueadoEntreUsuarios &&
      !privacidadePerfilCarregando &&
      permissoesAbasPerfil.sobre);
  const diarioPerfilVisivel =
    perfilPertenceAoUsuario ||
    (!perfilBloqueadoEntreUsuarios &&
      !privacidadePerfilCarregando &&
      permissoesAbasPerfil.diario);
  const comunidadePerfilVisivel =
    perfilPertenceAoUsuario ||
    (!perfilBloqueadoEntreUsuarios &&
      !privacidadePerfilCarregando &&
      permissoesAbasPerfil.comunidade);
  const bibliotecaPerfilVisivel =
    perfilPertenceAoUsuario ||
    (!perfilBloqueadoEntreUsuarios &&
      !privacidadePerfilCarregando &&
      permissoesAbasPerfil.biblioteca);
  const atividadesPerfilVisivel =
    perfilPertenceAoUsuario ||
    (!perfilBloqueadoEntreUsuarios &&
      !privacidadePerfilCarregando &&
      permissoesAbasPerfil.atividades);
  const totalAbasPerfilVisiveis =
    (obrasPerfilVisivel ? 1 : 0) +
    (diarioPerfilVisivel ? 1 : 0) +
    (comunidadePerfilVisivel ? 1 : 0) +
    (sobrePerfilVisivel ? 1 : 0) +
    (bibliotecaPerfilVisivel ? 1 : 0);
  const conteudoPrivadoBloqueado = Boolean(
    !perfilPertenceAoUsuario &&
      !privacidadePerfilCarregando &&
      totalAbasPerfilVisiveis === 0,
  );
  const primeiraAbaPerfilVisivel: AbaPerfilAutor | null = obrasPerfilVisivel
    ? "obras"
    : diarioPerfilVisivel
      ? "diario"
      : comunidadePerfilVisivel
        ? "comunidade"
        : sobrePerfilVisivel
          ? "sobre"
          : bibliotecaPerfilVisivel
            ? "biblioteca"
            : null;

  useEffect(() => {
    setPodeEditarPerfil(perfilPertenceAoUsuario);
  }, [perfilPertenceAoUsuario]);

  useEffect(() => {
    const userIdPerfil = perfilParaMostrar?.autorId.trim() || "";
    let cancelado = false;

    async function carregarPrivacidadePerfil() {
      setPrivacidadePerfilCarregando(true);

      if (!userIdPerfil || !idAutorSupabaseValido(userIdPerfil)) {
        if (!cancelado) {
          setPermissoesAbasPerfil(
            perfilPertenceAoUsuario
              ? PERMISSOES_ABAS_PERFIL_PROPRIO
              : PERMISSOES_ABAS_PERFIL_PADRAO,
          );
          setPrivacidadePerfilCarregando(false);
        }

        return;
      }

      const preferencias = await carregarPreferenciasPrivacidade(userIdPerfil, {
        usarFallbackLocal: perfilPertenceAoUsuario,
      });
      const permissoes = perfilPertenceAoUsuario
        ? PERMISSOES_ABAS_PERFIL_PROPRIO
        : await carregarPermissoesAbasPerfil(userIdPerfil, preferencias);

      if (!cancelado) {
        setPermissoesAbasPerfil(permissoes);
        setPrivacidadePerfilCarregando(false);
      }
    }

    void carregarPrivacidadePerfil();

    return () => {
      cancelado = true;
    };
  }, [
    perfilParaMostrar?.autorId,
    perfilPertenceAoUsuario,
    estadoRelacionamentoPerfil,
  ]);

  useEffect(() => {
    const userIdPerfil = perfilParaMostrar?.autorId.trim() || "";
    let cancelado = false;

    if (
      !comunidadePerfilVisivel ||
      !userIdPerfil ||
      !idAutorSupabaseValido(userIdPerfil)
    ) {
      setComunidadePerfil(comunidadePerfilVazia);
      return;
    }

    setComunidadePerfil({
      ...comunidadePerfilVazia,
      carregando: true,
    });

    async function carregarComunidadePerfil() {
      try {
        const comunidadeCarregada =
          await carregarComunidadePerfilSupabase(userIdPerfil);

        if (!cancelado) {
          setComunidadePerfil({
            carregando: false,
            erro: "",
            ...comunidadeCarregada,
          });
        }
      } catch (error) {
        console.warn(
          "Não consegui carregar as publicações da Comunidade deste perfil:",
          error,
        );

        if (!cancelado) {
          setComunidadePerfil({
            ...comunidadePerfilVazia,
            erro: "Não foi possível carregar as publicações deste perfil agora.",
          });
        }
      }
    }

    void carregarComunidadePerfil();

    return () => {
      cancelado = true;
    };
  }, [perfilParaMostrar?.autorId, comunidadePerfilVisivel]);

  useEffect(() => {
    const abaAtualVisivel =
      (abaPerfil === "obras" && obrasPerfilVisivel) ||
      (abaPerfil === "diario" && diarioPerfilVisivel) ||
      (abaPerfil === "comunidade" && comunidadePerfilVisivel) ||
      (abaPerfil === "sobre" && sobrePerfilVisivel) ||
      (abaPerfil === "biblioteca" && bibliotecaPerfilVisivel);

    if (!abaAtualVisivel && primeiraAbaPerfilVisivel) {
      setAbaPerfil(primeiraAbaPerfilVisivel);
    }
  }, [
    abaPerfil,
    obrasPerfilVisivel,
    diarioPerfilVisivel,
    comunidadePerfilVisivel,
    sobrePerfilVisivel,
    bibliotecaPerfilVisivel,
    primeiraAbaPerfilVisivel,
  ]);

  useEffect(() => {
    const perfilUserId = perfilParaMostrar?.autorId.trim() || "";
    const usuarioAtualId = usuarioIdLogado.trim();
    let cancelado = false;

    if (
      !perfilUserId ||
      !usuarioAtualId ||
      perfilUserId === usuarioAtualId ||
      !idAutorSupabaseValido(perfilUserId)
    ) {
      setEstadoBloqueioPerfil({
        bloqueadoPorMim: false,
        bloqueadoPeloPerfil: false,
        existeBloqueio: false,
      });
      return;
    }

    async function carregarBloqueioPerfil() {
      const estado = await carregarEstadoBloqueioPerfil(perfilUserId);

      if (!cancelado) {
        setEstadoBloqueioPerfil(estado);
      }
    }

    void carregarBloqueioPerfil();

    return () => {
      cancelado = true;
    };
  }, [perfilParaMostrar?.autorId, usuarioIdLogado]);

  useEffect(() => {
    const perfilUserId = perfilParaMostrar?.autorId.trim() || "";
    const usuarioAtualId = usuarioIdLogado.trim();

    if (!perfilUserId || !idAutorSupabaseValido(perfilUserId)) {
      setSeguindoUsuarioPerfil(false);
      setEstadoRelacionamentoPerfil("nenhum");
      return;
    }

    let cancelado = false;

    async function carregarSeguimentoUsuario() {
      const [estadoSeguimento, estadoRelacionamento] = await Promise.all([
        carregarEstadoSeguimentoUsuarioPerfil(
          usuarioAtualId,
          perfilUserId,
        ),
        usuarioAtualId && idAutorSupabaseValido(usuarioAtualId)
          ? carregarEstadoRelacionamentoPerfil(
              perfilUserId,
              usuarioAtualId,
            )
          : Promise.resolve<EstadoRelacionamentoPerfil>("nenhum"),
      ]);

      if (cancelado) {
        return;
      }

      const seguindoConfirmado =
        estadoRelacionamento === "seguindo" || estadoSeguimento.seguindo;
      const estadoSeguro =
        perfilUserId === usuarioAtualId
          ? "proprio_perfil"
          : seguindoConfirmado
            ? "seguindo"
            : estadoRelacionamento;
      const seguidoresMinimoPorEstadoAtual = seguindoConfirmado ? 1 : 0;
      const seguidoresTotalSeguro = Math.max(
        estadoSeguimento.seguidoresTotal,
        seguidoresMinimoPorEstadoAtual,
        seguidoresTotalEstavelRef.current[perfilUserId] || 0,
      );
      const seguindoTotalSeguro = estadoSeguimento.seguindoTotal;

      seguidoresTotalEstavelRef.current[perfilUserId] = seguidoresTotalSeguro;
      seguindoTotalEstavelRef.current[perfilUserId] = seguindoTotalSeguro;

      setEstadoRelacionamentoPerfil(estadoSeguro);
      setSeguindoUsuarioPerfil(seguindoConfirmado);
      setSeguidoresUsuarioPerfilTotal(seguidoresTotalSeguro);
      setSeguindoUsuarioPerfilTotal(seguindoTotalSeguro);
    }

    void carregarSeguimentoUsuario();

    return () => {
      cancelado = true;
    };
  }, [perfilParaMostrar?.autorId, usuarioIdLogado]);

  const autorChavePerfil = perfilParaMostrar
    ? criarChaveAutorPerfil(perfilParaMostrar.autorId, perfilParaMostrar.nome)
    : "";
  const autorNormalizadoParaSeguir = perfilParaMostrar
    ? normalizarNomeAutor(perfilParaMostrar.nome)
    : "";

  const seguindoAutor = Boolean(
    autorChavePerfil &&
    (autoresSeguidos.includes(autorChavePerfil) ||
      autoresSeguidos.includes(autorNormalizadoParaSeguir)),
  );
  const perfilUserIdParaSeguir = perfilParaMostrar?.autorId.trim() || "";
  const podeUsarSeguimentoUsuario = Boolean(
    perfilUserIdParaSeguir && idAutorSupabaseValido(perfilUserIdParaSeguir),
  );
  const chaveSeguimentoPerfil =
    perfilUserIdParaSeguir || autorChavePerfil || autorNormalizadoParaSeguir;
  const seguindoPerfilAtual = podeUsarSeguimentoUsuario
    ? estadoRelacionamentoPerfil === "seguindo" || seguindoUsuarioPerfil
    : seguindoAutor;
  const solicitacaoSeguimentoPendente = Boolean(
    podeUsarSeguimentoUsuario &&
      estadoRelacionamentoPerfil === "solicitado",
  );
  const seguidoresTotal = useMemo(() => {
    const totalMinimoPorSeguimentoAtual =
      seguindoPerfilAtual || seguindoUsuarioPerfil || seguindoAutor ? 1 : 0;
    const totalAtual = podeUsarSeguimentoUsuario
      ? Math.max(
          seguidoresUsuarioPerfilTotal,
          totalMinimoPorSeguimentoAtual,
        )
      : seguindoAutor
        ? 1
        : 0;

    if (!chaveSeguimentoPerfil) {
      return totalAtual;
    }

    const ultimoTotalValido =
      seguidoresTotalEstavelRef.current[chaveSeguimentoPerfil] || 0;
    const totalSeguro = Math.max(totalAtual, ultimoTotalValido);

    seguidoresTotalEstavelRef.current[chaveSeguimentoPerfil] = totalSeguro;

    return totalSeguro;
  }, [
    chaveSeguimentoPerfil,
    podeUsarSeguimentoUsuario,
    seguidoresUsuarioPerfilTotal,
    seguindoPerfilAtual,
    seguindoUsuarioPerfil,
    seguindoAutor,
  ]);
  const seguindoTotalPerfil = useMemo(() => {
    if (podeUsarSeguimentoUsuario) {
      seguindoTotalEstavelRef.current[chaveSeguimentoPerfil] =
        seguindoUsuarioPerfilTotal;

      return seguindoUsuarioPerfilTotal;
    }

    return podeEditarPerfil ? autoresSeguidos.length : 0;
  }, [
    chaveSeguimentoPerfil,
    podeUsarSeguimentoUsuario,
    seguindoUsuarioPerfilTotal,
    podeEditarPerfil,
    autoresSeguidos.length,
  ]);
  const seguidoresPerfilHref = podeEditarPerfil
    ? "/seguindo?conteudo=seguidores"
    : criarHrefListaSeguimentoPerfilAutor(
        "seguidores",
        perfilParaMostrar,
      );
  const seguindoPerfilHref = podeEditarPerfil
    ? "/seguindo?conteudo=pessoas"
    : criarHrefListaSeguimentoPerfilAutor(
        "seguindo",
        perfilParaMostrar,
      );
  const obrasSeguidasPerfilHref = "/seguindo?conteudo=obras";
  const obrasConcluidasPerfilPorObrasDoAutor = perfilParaMostrar
    ? perfilParaMostrar.obras.reduce((total, obra) => {
        const totalConcluidasReais = obterTotalConcluidasObraPerfilAutor(
          obra,
          totaisInteracoesObras,
        );
        const concluidaLocal = colecaoTemObraPerfilBiblioteca(
          obrasConcluidas,
          obra,
        )
          ? 1
          : 0;

        return total + Math.max(totalConcluidasReais, concluidaLocal);
      }, 0)
    : 0;
  const perfilSalvoAutor = autorChavePerfil
    ? perfisAutoresSalvos[autorChavePerfil] ||
      perfisAutoresSalvos[autorNormalizadoParaSeguir] || {
        avatar: "",
        avatarNome: "",
        bio: "",
        sobreBio: "",
        mostrarDestaques: false,
      }
    : {
        avatar: "",
        avatarNome: "",
        bio: "",
        sobreBio: "",
        mostrarDestaques: false,
      };
  const perfilUsuarioRemotoAtivo =
    perfilUsuarioRemoto &&
    perfilParaMostrar &&
    perfilUsuarioRemoto.userId.trim().toLowerCase() ===
      perfilParaMostrar.autorId.trim().toLowerCase()
      ? perfilUsuarioRemoto
      : null;
  const bioPadraoAutor = perfilParaMostrar
    ? criarBioAutor(perfilParaMostrar)
    : "";
  const bioAutorPersonalizada =
    perfilSalvoAutor.bio.trim() || perfilUsuarioRemotoAtivo?.bio.trim() || "";
  const bioAutor = bioAutorPersonalizada || bioPadraoAutor;
  const bioSobrePersonalizada =
    perfilSalvoAutor.sobreBio.trim() ||
    perfilUsuarioRemotoAtivo?.sobreBio.trim() ||
    "";
  const bioSobreAutor = bioSobrePersonalizada || bioAutor;
  const bioSobreAutorEhPadrao =
    bioSobreAutor.trim() === "Perfil de leitor no Historietas.";
  const bioSobreAutorExibido = bioSobreAutorEhPadrao
    ? traduzirTextoPerfilAutor(bioSobreAutor, language)
    : bioSobreAutor;
  const autorHandlePerfil = perfilParaMostrar
    ? criarHandlePerfilAutor(
        perfilParaMostrar.nome,
        perfilParaMostrar.autorId,
        perfilUsuarioRemotoAtivo?.username || "",
      )
    : "@autor.historietas";
  const avatarAutor = perfilSalvoAutor.avatar || perfilUsuarioRemotoAtivo?.avatar || "";
  const entradaHistorietasPerfil = formatarEntradaHistorietasPerfilAutor(
    perfilUsuarioRemotoAtivo?.criadoEm || "",
  );

  useEffect(() => {
    setUsernameCabecalhoVisivel(false);
  }, [perfilParaMostrar?.autorId]);

  useEffect(() => {
    if (!editorPerfilAberto || !podeEditarPerfil || !perfilParaMostrar) {
      return;
    }

    setNomePerfilEditor(
      perfilUsuarioRemotoAtivo?.nome || perfilParaMostrar.nome || "",
    );
    setUsernamePerfilEditor(perfilUsuarioRemotoAtivo?.username || "");
    setBioPerfilEditor(bioAutorPersonalizada);
    setAvatarPerfilEditor(avatarAutor);
    setAvatarNomePerfilEditor(perfilSalvoAutor.avatarNome || "");
    setAvatarArquivoPerfilEditor(null);
    setAvatarErro("");
  }, [
    editorPerfilAberto,
    podeEditarPerfil,
    perfilParaMostrar?.autorId,
    perfilParaMostrar?.nome,
    perfilParaMostrar,
    perfilUsuarioRemotoAtivo?.nome,
    perfilUsuarioRemotoAtivo?.username,
    bioAutorPersonalizada,
    avatarAutor,
    perfilSalvoAutor.avatarNome,
  ]);

  const caracteresRestantesBio = BIO_MAX_LENGTH - bioAutorPersonalizada.length;
  const caracteresRestantesBioSobre =
    SOBRE_BIO_MAX_LENGTH - bioSobrePersonalizada.length;
  const autorPodeReceberAvaliacao = Boolean(
    perfilParaMostrar && perfilParaMostrar.obras.length > 0,
  );
  const perfilUsaAvaliacaoDiario = Boolean(
    perfilParaMostrar && perfilParaMostrar.obras.length === 0,
  );
  const avaliacaoDiarioPrivada = Boolean(
    perfilUsaAvaliacaoDiario &&
      avaliacaoDiario.carregado &&
      !avaliacaoDiario.mostrar,
  );
  const avaliacaoDiarioResumoVisivel = Boolean(
    perfilUsaAvaliacaoDiario &&
      (
        avaliacaoDiarioPrivada ||
        podeEditarPerfil ||
        avaliacaoDiario.visivel
      ),
  );
  const avaliacaoResumoPerfilVisivel =
    autorPodeReceberAvaliacao || avaliacaoDiarioResumoVisivel;
  const avaliacaoResumoPerfil = autorPodeReceberAvaliacao
    ? avaliacaoAutor
    : avaliacaoDiario;
  const avaliacaoResumoEhDiario = !autorPodeReceberAvaliacao;

  const obrasDoPerfilFiltradas = useMemo(() => {
    if (!perfilParaMostrar) {
      return [];
    }

    return [...perfilParaMostrar.obras].sort(
      (obraA, obraB) =>
        obterTimestampData(obraB.criadaEm) - obterTimestampData(obraA.criadaEm),
    );
  }, [perfilParaMostrar]);

  const obrasEmDestaque = useMemo(() => {
    if (topFiveObraIds.length === 0) {
      return [] as ObraLocal[];
    }

    const obrasDisponiveis = mesclarObrasPorIdSlug(
      obras,
      perfilParaMostrar?.obras || [],
    );
    const obrasSelecionadas = new Map<string, ObraLocal>();

    topFiveObraIds.forEach((obraId) => {
      const obraEncontrada = encontrarObraPorIdentificadorTopFivePerfil(
        obrasDisponiveis,
        obraId,
      );

      if (!obraEncontrada) {
        return;
      }

      const chaveObra =
        obraEncontrada.id.trim() ||
        obraEncontrada.slug.trim() ||
        normalizarTexto(obraEncontrada.titulo);

      if (chaveObra && !obrasSelecionadas.has(chaveObra)) {
        obrasSelecionadas.set(chaveObra, obraEncontrada);
      }
    });

    return Array.from(obrasSelecionadas.values()).slice(0, TOP_FIVE_MAXIMO);
  }, [obras, perfilParaMostrar?.obras, topFiveObraIds]);

  const destaquesPerfilVisivel =
    obrasPerfilVisivel &&
    (podeEditarPerfil
      ? perfilSalvoAutor.mostrarDestaques
      : mostrarDestaquesVisitante);

  async function alternarCurtidaTopFivePerfil() {
    const perfilAutorId = perfilParaMostrar?.autorId?.trim() || "";
    const usuarioId = usuarioIdLogado.trim();

    if (!perfilAutorId) {
      return;
    }

    if (!usuarioId) {
      setMensagemAcao("Entre para curtir o TOP 5 deste perfil.");
      return;
    }

    if (topFiveCurtidaSalvando) {
      return;
    }

    const proximaCurtida = !topFiveCurtidoPorMim;

    setTopFiveCurtidaSalvando(true);
    setTopFiveCurtidoPorMim(proximaCurtida);
    setTopFiveCurtidasTotal((totalAtual) =>
      Math.max(0, totalAtual + (proximaCurtida ? 1 : -1)),
    );
    salvarCurtidaTopFiveLocal(perfilAutorId, usuarioId, proximaCurtida);

    const salvouRemoto = await salvarCurtidaTopFiveSupabase(
      perfilAutorId,
      usuarioId,
      proximaCurtida,
    );

    if (salvouRemoto) {
      const estadoAtualizado = await carregarCurtidasTopFivePerfil(
        perfilAutorId,
        usuarioId,
      );

      setTopFiveCurtidasTotal(estadoAtualizado.total);
      setTopFiveCurtidoPorMim(estadoAtualizado.curtiu);
    }

    setTopFiveCurtidaSalvando(false);
  }

  useEffect(() => {
    const perfilAtual = perfilParaMostrar;

    if (!perfilAtual) {
      setDiarioPerfil(diarioPerfilVazio);
      return;
    }

    const perfilDiario = perfilAtual;
    let cancelado = false;

    async function carregarDiarioPerfil() {
      const userIdPerfil = perfilDiario.autorId.trim();
      const bibliotecaUsaUsuarioLogado =
        bibliotecaPerfilVisivel &&
        abaPerfil === "biblioteca" &&
        Boolean(usuarioIdLogado.trim());
      const userIdFonteDiario = bibliotecaUsaUsuarioLogado
        ? usuarioIdLogado.trim()
        : userIdPerfil;

      const estaVendoProprioPerfil =
        Boolean(usuarioIdLogado.trim()) &&
        userIdPerfil === usuarioIdLogado.trim();

      const incluirItensPrivados =
        bibliotecaUsaUsuarioLogado ||
        podeEditarPerfil ||
        estaVendoProprioPerfil;

      setDiarioPerfil({
        ...diarioPerfilVazio,
        carregando: true,
      });

      const diarioLocal = incluirItensPrivados
        ? montarDiarioPerfilLocal(
            perfilDiario,
            obrasFavoritas,
            obrasConcluidas,
            obrasSeguidasBiblioteca,
            obras,
          )
        : criarEstadoDiarioPerfilVazio();

      if (!userIdFonteDiario || !idAutorSupabaseValido(userIdFonteDiario)) {
        if (!cancelado) {
          setDiarioPerfil({
            carregando: false,
            ...diarioLocal,
          });
        }

        return;
      }

      const diarioSupabase = await carregarDiarioPerfilSupabase(
        userIdFonteDiario,
        obras,
        incluirItensPrivados,
        diarioPerfilVisivel,
        atividadesPerfilVisivel,
        obrasConcluidas,
      );
      const diarioSemFiltro = incluirItensPrivados
        ? mesclarDiarioPerfilComLocal(diarioSupabase, diarioLocal)
        : diarioSupabase;
      const diarioFinal = incluirItensPrivados
        ? diarioSemFiltro
        : aplicarPermissoesAbasAoDiario(
            diarioSemFiltro,
            permissoesAbasPerfil,
          );

      if (!cancelado) {
        setDiarioPerfil({
          carregando: false,
          ...diarioFinal,
        });
      }
    }

    void carregarDiarioPerfil();

    return () => {
      cancelado = true;
    };
  }, [
    perfilParaMostrar,
    obras,
    obrasFavoritas,
    obrasConcluidas,
    obrasSeguidasBiblioteca,
    podeEditarPerfil,
    bibliotecaPerfilVisivel,
    abaPerfil,
    usuarioIdLogado,
    versaoSincronizacaoBiblioteca,
    permissoesAbasPerfil,
  ]);

  const itensDiarioTudo = useMemo(() => {
    const prioridadeTipos: Record<DiarioPerfilItem["tipo"], number> = {
      lendo: 0,
      concluida: 1,
      quero_ler: 2,
      favorita: 3,
      avaliacao: 4,
      review: 5,
      atividade: 6,
    };
    const itens = [
      ...diarioPerfil.lendoAgora,
      ...diarioPerfil.queroLer,
      ...diarioPerfil.favoritas,
      ...diarioPerfil.concluidas,
      ...diarioPerfil.avaliacoes,
      ...diarioPerfil.reviews,
      ...diarioPerfil.atividades,
    ];
    const itensPorObra = new Map<string, DiarioPerfilResumoItem>();

    itens.forEach((item) => {
      const obra = item.obra;

      if (!obra) {
        return;
      }

      const chaveObra = (
        obra.id ||
        obra.slug ||
        criarSlugBase(obra.titulo)
      )
        .trim()
        .toLowerCase();

      if (!chaveObra) {
        return;
      }

      const existente = itensPorObra.get(chaveObra);

      if (!existente) {
        itensPorObra.set(chaveObra, {
          ...item,
          tipos: [item.tipo],
        });
        return;
      }

      const tipos = Array.from(
        new Set([...existente.tipos, item.tipo]),
      ).sort(
        (tipoA, tipoB) =>
          prioridadeTipos[tipoA] - prioridadeTipos[tipoB],
      );
      const itemMaisRecente =
        obterTimestampData(item.data) >
        obterTimestampData(existente.data);
      const base = itemMaisRecente ? item : existente;

      itensPorObra.set(chaveObra, {
        ...base,
        tipo: tipos[0] || base.tipo,
        tipos,
      });
    });

    return Array.from(itensPorObra.values()).sort(
      (itemA, itemB) =>
        obterTimestampData(itemB.data) -
        obterTimestampData(itemA.data),
    );
  }, [diarioPerfil]);

  useEffect(() => {
    if (!perfilParaMostrar || !autorPodeReceberAvaliacao) {
      setAvaliacaoAutor(avaliacaoAutorVazia);
      return;
    }

    const perfilAtualAutor = perfilParaMostrar;
    const notaLocal = perfilPertenceAoUsuario
      ? 0
      : obterAvaliacaoAutorLocal(
          perfilAtualAutor,
          usuarioIdLogado,
        );

    if (perfilPertenceAoUsuario && usuarioIdLogado.trim()) {
      salvarAvaliacaoAutorLocal(
        perfilAtualAutor,
        0,
        usuarioIdLogado,
      );
    }

    setAvaliacaoAutor({
      media: notaLocal > 0 ? notaLocal : 0,
      total: notaLocal > 0 ? 1 : 0,
      minhaNota: notaLocal,
      carregado: true,
      salvando: false,
    });

    const autorId = perfilAtualAutor.autorId.trim();

    if (!autorId || !idAutorSupabaseValido(autorId)) {
      return;
    }

    let cancelado = false;

    async function carregarAvaliacaoRealAutor() {
      try {
        const { data: usuarioData } = await supabase.auth.getUser();
        const userId = usuarioData.user?.id || "";

        const { data: avaliacoesData, error: erroAvaliacoes } = await supabase
          .from("autor_avaliacoes")
          .select("user_id,nota")
          .eq("autor_id", autorId)
          .limit(1000);

        if (erroAvaliacoes || !Array.isArray(avaliacoesData)) {
          return;
        }

        const notas = avaliacoesData
          .filter((avaliacao) => {
            const avaliadorId =
              typeof (avaliacao as { user_id?: unknown }).user_id === "string"
                ? String((avaliacao as { user_id?: unknown }).user_id).trim()
                : "";

            return (
              !avaliadorId ||
              avaliadorId.toLowerCase() !== autorId.toLowerCase()
            );
          })
          .map((avaliacao) => Number((avaliacao as { nota?: unknown }).nota))
          .filter((nota) => Number.isFinite(nota) && nota >= 0.5 && nota <= 5);
        const total = notas.length;
        const media =
          total > 0
            ? notas.reduce((soma, nota) => soma + nota, 0) / total
            : 0;
        const usuarioEhDonoDoPerfil = Boolean(
          userId &&
            userId.trim().toLowerCase() === autorId.toLowerCase(),
        );
        let minhaNota = usuarioEhDonoDoPerfil ? 0 : notaLocal;

        if (userId && !usuarioEhDonoDoPerfil) {
          const { data: minhaAvaliacao } = await supabase
            .from("autor_avaliacoes")
            .select("nota")
            .eq("autor_id", autorId)
            .eq("user_id", userId)
            .maybeSingle();

          const notaUsuario = Number(
            (minhaAvaliacao as { nota?: unknown } | null)?.nota,
          );

          if (Number.isFinite(notaUsuario) && notaUsuario >= 0.5 && notaUsuario <= 5) {
            minhaNota = Math.round(notaUsuario * 2) / 2;
          }
        }

        if (cancelado) {
          return;
        }

        setAvaliacaoAutor((avaliacaoAtual) => {
          if (
            avaliacaoAtual.salvando ||
            avaliacaoAtual.minhaNota !== notaLocal
          ) {
            return {
              ...avaliacaoAtual,
              carregado: true,
            };
          }

          return {
            media,
            total,
            minhaNota,
            carregado: true,
            salvando: false,
          };
        });
      } catch {
        if (!cancelado) {
          setAvaliacaoAutor((avaliacaoAtual) => ({
            ...avaliacaoAtual,
            carregado: true,
            salvando: false,
          }));
        }
      }
    }

    void carregarAvaliacaoRealAutor();

    return () => {
      cancelado = true;
    };
  }, [
    perfilParaMostrar,
    autorPodeReceberAvaliacao,
    usuarioIdLogado,
    perfilPertenceAoUsuario,
  ]);

  useEffect(() => {
    if (!perfilParaMostrar || !perfilUsaAvaliacaoDiario) {
      setAvaliacaoDiario(avaliacaoDiarioVazia);
      return;
    }

    const diarioUserId = (
      perfilUsuarioRemotoAtivo?.userId || perfilParaMostrar.autorId
    ).trim();

    if (!diarioUserId || !idAutorSupabaseValido(diarioUserId)) {
      setAvaliacaoDiario({
        ...avaliacaoDiarioVazia,
        carregado: true,
        visivel: podeEditarPerfil,
      });
      return;
    }

    let cancelado = false;

    setAvaliacaoDiario((avaliacaoAtual) => ({
      ...avaliacaoAtual,
      carregado: false,
      salvando: false,
    }));

    async function carregarAvaliacaoRealDiario() {
      try {
        const { data, error } = await supabase.rpc(
          "carregar_avaliacao_diario",
          { p_diario_user_id: diarioUserId },
        );

        if (error) {
          throw error;
        }

        if (!cancelado) {
          setAvaliacaoDiario((avaliacaoAtual) =>
            normalizarAvaliacaoDiarioPerfil(data, avaliacaoAtual),
          );
        }
      } catch {
        if (!cancelado) {
          setAvaliacaoDiario({
            ...avaliacaoDiarioVazia,
            carregado: true,
            visivel: podeEditarPerfil,
          });
        }
      }
    }

    void carregarAvaliacaoRealDiario();

    return () => {
      cancelado = true;
    };
  }, [
    perfilParaMostrar?.autorId,
    perfilUsuarioRemotoAtivo?.userId,
    perfilUsaAvaliacaoDiario,
    podeEditarPerfil,
    usuarioIdLogado,
  ]);

  const generosPrincipaisPerfil = useMemo(() => {
    if (!perfilParaMostrar) {
      return [] as string[];
    }

    const contagemGeneros = new Map<string, number>();

    perfilParaMostrar.obras.forEach((obra) => {
      const genero = formatarGeneroPerfilAutor(obra.genero);

      if (!genero || genero === "Não informado") {
        return;
      }

      contagemGeneros.set(genero, (contagemGeneros.get(genero) || 0) + 1);
    });

    return Array.from(contagemGeneros.entries())
      .sort((generoA, generoB) => {
        if (generoA[1] !== generoB[1]) {
          return generoB[1] - generoA[1];
        }

        return generoA[0].localeCompare(generoB[0]);
      })
      .slice(0, 5)
      .map(([genero]) => genero);
  }, [perfilParaMostrar]);

  const totalVisualizacoesPerfil = perfilParaMostrar
    ? perfilParaMostrar.obras.reduce(
        (total, obra) => total + normalizarNumeroPerfilAutor(obra.visualizacoes),
        0,
      )
    : 0;
  const totalRascunhosPerfil = perfilParaMostrar
    ? Math.max(0, perfilParaMostrar.obras.length - perfilParaMostrar.totalPublicadas)
    : 0;
  const totalObrasSemCapitulosPerfil = perfilParaMostrar
    ? perfilParaMostrar.obras.filter((obra) => obra.capitulos.length === 0).length
    : 0;

  const obraMenuAberta = useMemo(() => {
    if (!obraMenuAbertoId) {
      return null;
    }

    return (
      obrasDoPerfilFiltradas.find((obra) => obra.id === obraMenuAbertoId) ||
      null
    );
  }, [obraMenuAbertoId, obrasDoPerfilFiltradas]);


  const itensBibliotecaQueroLer = useMemo(() => {
    if (!bibliotecaPerfilVisivel) {
      return [] as ItemBibliotecaPerfil[];
    }

    return converterItensDiarioParaBiblioteca(
      diarioPerfil.queroLer,
      "quero-ler",
    );
  }, [bibliotecaPerfilVisivel, diarioPerfil.queroLer]);

  const itensBibliotecaLendoAgora = useMemo(() => {
    if (!bibliotecaPerfilVisivel) {
      return [] as ItemBibliotecaPerfil[];
    }

    return converterItensDiarioParaBiblioteca(
      diarioPerfil.lendoAgora,
      "lendo-agora",
    );
  }, [bibliotecaPerfilVisivel, diarioPerfil.lendoAgora]);

  const itensBibliotecaFavoritas = useMemo(() => {
    if (!bibliotecaPerfilVisivel) {
      return [] as ItemBibliotecaPerfil[];
    }

    return converterItensDiarioParaBiblioteca(
      diarioPerfil.favoritas,
      "favorita",
    );
  }, [bibliotecaPerfilVisivel, diarioPerfil.favoritas]);

  const itensBibliotecaConcluidas = useMemo(() => {
    if (!bibliotecaPerfilVisivel) {
      return [] as ItemBibliotecaPerfil[];
    }

    return converterItensDiarioParaBiblioteca(
      diarioPerfil.concluidas,
      "concluida",
    );
  }, [bibliotecaPerfilVisivel, diarioPerfil.concluidas]);

  const itensBibliotecaHistorico = useMemo(() => {
    if (!bibliotecaPerfilVisivel) {
      return [] as ItemBibliotecaPerfil[];
    }

    const atividadesLeitura = diarioPerfil.atividades.filter(
      (item) => item.tipo === "lendo",
    );

    return converterItensDiarioParaBiblioteca(
      atividadesLeitura,
      "historico",
    );
  }, [bibliotecaPerfilVisivel, diarioPerfil.atividades]);

  const itensBibliotecaSalvos = useMemo(() => {
    if (!bibliotecaPerfilVisivel) {
      return [] as ItemBibliotecaPerfil[];
    }

    return converterCapitulosSalvosParaBiblioteca(obras);
  }, [bibliotecaPerfilVisivel, obras]);

  const obrasSeguidasPerfilTotal = useMemo(() => {
    const totalPorObrasCarregadas = obras.filter((obra) =>
      colecaoTemObraPerfilBiblioteca(obrasSeguidasBiblioteca, obra),
    ).length;

    return Math.max(totalPorObrasCarregadas, itensBibliotecaQueroLer.length);
  }, [obras, obrasSeguidasBiblioteca, itensBibliotecaQueroLer.length]);

  const obrasConcluidasPerfilTotal = useMemo(() => {
    const totalPorObrasCarregadas = obras.filter((obra) =>
      colecaoTemObraPerfilBiblioteca(obrasConcluidas, obra),
    ).length;

    return Math.max(
      obrasConcluidasPerfilPorObrasDoAutor,
      totalPorObrasCarregadas,
      itensBibliotecaConcluidas.length,
    );
  }, [
    obras,
    obrasConcluidas,
    obrasConcluidasPerfilPorObrasDoAutor,
    itensBibliotecaConcluidas.length,
  ]);

  const itensBibliotecaAtivos = useMemo(() => {
    if (abaBibliotecaPerfil === "quero-ler") {
      return itensBibliotecaQueroLer;
    }

    if (abaBibliotecaPerfil === "lendo-agora") {
      return itensBibliotecaLendoAgora;
    }

    if (abaBibliotecaPerfil === "favoritas") {
      return itensBibliotecaFavoritas;
    }

    if (abaBibliotecaPerfil === "concluidas") {
      return itensBibliotecaConcluidas;
    }

    if (abaBibliotecaPerfil === "salvos") {
      return itensBibliotecaSalvos;
    }

    if (abaBibliotecaPerfil === "historico") {
      return itensBibliotecaHistorico;
    }

    return mesclarItensBibliotecaPerfil(
      itensBibliotecaQueroLer,
      itensBibliotecaLendoAgora,
      itensBibliotecaFavoritas,
      itensBibliotecaConcluidas,
      itensBibliotecaSalvos,
      itensBibliotecaHistorico,
    );
  }, [
    abaBibliotecaPerfil,
    itensBibliotecaConcluidas,
    itensBibliotecaFavoritas,
    itensBibliotecaHistorico,
    itensBibliotecaLendoAgora,
    itensBibliotecaQueroLer,
    itensBibliotecaSalvos,
  ]);

  const bibliotecaMenuAberto = useMemo(() => {
    if (!bibliotecaMenuAbertoChave) {
      return null;
    }

    return (
      itensBibliotecaAtivos.find(
        (item) => item.chave === bibliotecaMenuAbertoChave,
      ) || null
    );
  }, [bibliotecaMenuAbertoChave, itensBibliotecaAtivos]);

  const rotuloBibliotecaAtiva =
    abaBibliotecaPerfil === "tudo"
      ? "todos os itens"
      : abaBibliotecaPerfil === "quero-ler"
        ? "quero ler"
        : abaBibliotecaPerfil === "lendo-agora"
          ? "lendo agora"
          : abaBibliotecaPerfil === "favoritas"
            ? "na lista"
            : abaBibliotecaPerfil === "concluidas"
              ? "concluídas"
              : abaBibliotecaPerfil === "salvos"
                ? "capítulos salvos"
                : "histórico";

  const containerAtualStyle = isDesktop
    ? desktopContainerStyle
    : containerStyle;
  const heroAtualStyle = isDesktop ? desktopHeroBoxStyle : heroBoxStyle;
  const authorTopRowAtualStyle = isDesktop
    ? desktopAuthorTopRowStyle
    : authorTopRowStyle;
  const avatarButtonAtualStyle = isDesktop
    ? desktopAvatarButtonStyle
    : avatarButtonStyle;
  const avatarDisplayAtualStyle = isDesktop
    ? desktopAvatarDisplayStyle
    : avatarDisplayStyle;
  const titleAtualStyle = isDesktop ? desktopTitleStyle : titleStyle;
  const descriptionAtualStyle = isDesktop
    ? desktopDescriptionStyle
    : descriptionStyle;
  const sectionHeaderAtualStyle = isDesktop
    ? desktopSectionHeaderStyle
    : sectionHeaderStyle;
  const filterBoxAtualStyle = isDesktop
    ? desktopFilterBoxStyle
    : filterBoxStyle;
  const filterGridAtualStyle = isDesktop
    ? desktopFilterGridStyle
    : filterGridStyle;
  const clearFilterButtonAtualStyle = isDesktop
    ? desktopClearFilterButtonStyle
    : clearFilterButtonStyle;
  const worksGridAtualStyle = isDesktop
    ? desktopWorksGridStyle
    : worksGridStyle;
  const workCardAtualStyle = isDesktop ? desktopWorkCardStyle : workCardStyle;
  const workContentAtualStyle = isDesktop
    ? desktopWorkContentStyle
    : workContentStyle;
  const workTitleAtualStyle = isDesktop
    ? desktopWorkTitleStyle
    : workTitleStyle;
  const workTextAtualStyle = isDesktop ? desktopWorkTextStyle : workTextStyle;
  const workActionsGridAtualStyle = isDesktop
    ? desktopWorkActionsGridStyle
    : workActionsGridStyle;
  const avatarActionsAtualStyle = isDesktop
    ? desktopAvatarActionsStyle
    : avatarActionsStyle;
  const avatarSmallButtonAtualStyle = isDesktop
    ? desktopAvatarSmallButtonStyle
    : avatarSmallButtonStyle;
  const avatarRemoveButtonAtualStyle = isDesktop
    ? desktopAvatarRemoveButtonStyle
    : avatarRemoveButtonStyle;
  const profileStatsAtualStyle = isDesktop
    ? desktopProfileStatsStyle
    : profileStatsStyle;
  const profileActionsAtualStyle = isDesktop
    ? desktopProfileActionsStyle
    : profileActionsStyle;
  const profileVisitorActionsAtualStyle = isDesktop
    ? desktopProfileVisitorActionsStyle
    : profileVisitorActionsStyle;
  const menuSheetAtualStyle = isDesktop
    ? desktopMenuSheetStyle
    : menuSheetStyle;
  const comunidadeAutorBusca = encodeURIComponent(
    perfilParaMostrar?.nome || "",
  );
  const comunidadeAutorHref = comunidadeAutorBusca
    ? `/comunidade?busca=${comunidadeAutorBusca}`
    : "/comunidade";
  const comunidadeAutorTeoriasHref = comunidadeAutorBusca
    ? `${comunidadeAutorHref}&tipo=Teoria`
    : "/comunidade?tipo=Teoria";
  const comunidadeAutorReviewsHref = comunidadeAutorBusca
    ? `${comunidadeAutorHref}&tipo=Review`
    : "/comunidade?tipo=Review";

  function selecionarAbaPerfil(novaAba: AbaPerfilAutor) {
    setAbaPerfil(novaAba);

    if (typeof window === "undefined") {
      return;
    }

    const params = new URLSearchParams(window.location.search);
    params.set("aba", novaAba);

    const query = params.toString();
    const novaUrl = `${window.location.pathname}${
      query ? `?${query}` : ""
    }${window.location.hash}`;

    window.history.replaceState(window.history.state, "", novaUrl);
  }

  async function usuarioEstaLogado() {
    try {
      const { data } = await supabase.auth.getUser();

      return Boolean(data.user);
    } catch {
      return false;
    }
  }

  function avisarLoginNecessario(mensagem: string) {
    setMensagemAcao(mensagem);
    router.push(criarLoginHrefPerfilAutor());
  }

  function abrirEditorPerfil() {
    setMenuPerfilAberto(false);
    setEditorPerfilAberto(true);
  }

  function fecharEditorPerfil() {
    if (salvandoEditorPerfil) {
      return;
    }

    setEditorPerfilAberto(false);
    setAvatarErro("");

    if (avatarInputRef.current) {
      avatarInputRef.current.value = "";
    }
  }

  function salvarPerfilAutor(novoPerfil: PerfilAutorSalvo) {
    if (!autorChavePerfil) {
      return;
    }

    const perfilNormalizado = {
      avatar: novoPerfil.avatar,
      avatarNome: novoPerfil.avatarNome,
      bio: novoPerfil.bio.slice(0, BIO_MAX_LENGTH),
      sobreBio: novoPerfil.sobreBio.slice(0, SOBRE_BIO_MAX_LENGTH),
      mostrarDestaques: novoPerfil.mostrarDestaques === true,
    };

    const novosPerfis = {
      ...perfisAutoresSalvos,
      [autorChavePerfil]: perfilNormalizado,
    };

    if (usuarioIdLogado.trim()) {
      salvarJsonUsuarioPerfilAutor(
        AUTHOR_PROFILE_STORAGE_KEY,
        usuarioIdLogado,
        novosPerfis,
      );
    }

    setPerfisAutoresSalvos(novosPerfis);

    const perfilUserId = perfilParaMostrar?.autorId.trim() || "";

    if (
      podeEditarPerfil &&
      perfilUserId &&
      usuarioIdLogado &&
      perfilUserId.toLowerCase() === usuarioIdLogado.trim().toLowerCase()
    ) {
      const nomePerfil = perfilParaMostrar?.nome || perfilUsuarioRemotoAtivo?.nome || "Usuário";

      setPerfilUsuarioRemoto({
        userId: perfilUserId,
        nome: nomePerfil,
        username: perfilUsuarioRemotoAtivo?.username || "",
        avatar: perfilNormalizado.avatar,
        bio: perfilNormalizado.bio,
        sobreBio: perfilNormalizado.sobreBio,
        criadoEm: perfilUsuarioRemotoAtivo?.criadoEm || "",
      });

      void salvarPerfilUsuarioSupabase({
        userId: perfilUserId,
        nome: nomePerfil,
        perfil: perfilNormalizado,
        username: perfilUsuarioRemotoAtivo?.username || undefined,
      }).then((resultado) => {
        if (!resultado.ok && resultado.erro) {
          setMensagemAcao(`Perfil salvo neste aparelho. Supabase: ${resultado.erro}`);
        }
      });
    }
  }

  async function salvarEdicaoPerfilAutor() {
    const perfilUserId = perfilParaMostrar?.autorId.trim() || "";
    const usuarioIdAtual = usuarioIdLogado.trim();

    if (
      !podeEditarPerfil ||
      !perfilParaMostrar ||
      !perfilUserId ||
      !usuarioIdAtual ||
      perfilUserId.toLowerCase() !== usuarioIdAtual.toLowerCase()
    ) {
      setMensagemAcao("Não foi possível confirmar este perfil para edição.");
      return;
    }

    const nomeFinal = nomePerfilEditor
      .trim()
      .replace(/\s+/g, " ")
      .slice(0, 80);
    const usernameDigitado = usernamePerfilEditor.trim();
    const usernameFinal = usernameDigitado
      ? normalizarUsernamePerfilAutor(usernameDigitado)
      : "";

    if (nomeFinal.length < 3) {
      setMensagemAcao("O nome do perfil precisa ter pelo menos 3 caracteres.");
      return;
    }

    if (usernameDigitado && usernameFinal.length < 3) {
      setMensagemAcao("O @username precisa ter pelo menos 3 caracteres.");
      return;
    }

    setSalvandoEditorPerfil(true);
    setMensagemAcao("Salvando perfil...");

    let avatarFinal = avatarPerfilEditor;
    let avisoAvatar = "";

    if (avatarArquivoPerfilEditor) {
      const resultadoUpload = await enviarAvatarPerfilUsuarioSupabase({
        userId: perfilUserId,
        arquivo: avatarArquivoPerfilEditor,
      });

      if (resultadoUpload.ok && resultadoUpload.url) {
        avatarFinal = resultadoUpload.url;
      } else {
        avisoAvatar =
          " A imagem ficou salva neste aparelho, mas não foi enviada ao Storage.";
      }
    }

    const perfilFinal: PerfilAutorSalvo = {
      avatar: avatarFinal,
      avatarNome: avatarFinal ? avatarNomePerfilEditor : "",
      bio: bioPerfilEditor.slice(0, BIO_MAX_LENGTH),
      sobreBio: bioSobrePersonalizada,
      mostrarDestaques: perfilSalvoAutor.mostrarDestaques,
    };

    const resultadoPerfil = await salvarPerfilUsuarioSupabase({
      userId: perfilUserId,
      nome: nomeFinal,
      perfil: perfilFinal,
      username: usernameFinal || null,
    });

    if (!resultadoPerfil.ok) {
      const erroPerfil = resultadoPerfil.erro.toLowerCase();

      if (
        erroPerfil.includes("profiles_username_unique") ||
        erroPerfil.includes("duplicate key") ||
        erroPerfil.includes("unique")
      ) {
        setMensagemAcao("Esse @username já está em uso.");
        setSalvandoEditorPerfil(false);
        return;
      }
    }

    const resultadoObras = resultadoPerfil.ok
      ? await sincronizarNomeAutorObrasSupabase(perfilUserId, nomeFinal)
      : { ok: false, erro: "" };

    const novosPerfis = {
      ...perfisAutoresSalvos,
      [autorChavePerfil]: perfilFinal,
    };

    salvarJsonUsuarioPerfilAutor(
      AUTHOR_PROFILE_STORAGE_KEY,
      usuarioIdAtual,
      novosPerfis,
    );
    setPerfisAutoresSalvos(novosPerfis);

    setPerfilUsuarioRemoto({
      userId: perfilUserId,
      nome: nomeFinal,
      username: usernameFinal,
      avatar: avatarFinal,
      bio: perfilFinal.bio,
      sobreBio: perfilFinal.sobreBio,
      criadoEm: perfilUsuarioRemotoAtivo?.criadoEm || "",
    });

    setObras((obrasAtuais) =>
      obrasAtuais.map((obra) =>
        obraPertenceAoUsuarioPerfilAutor(obra, perfilUserId)
          ? { ...obra, autor: nomeFinal }
          : obra,
      ),
    );

    try {
      const obrasSalvasJson = carregarJsonUsuarioPerfilAutor(
        STORAGE_KEY,
        perfilUserId,
      );
      const obrasSalvasNormalizadas = Array.isArray(obrasSalvasJson)
        ? (obrasSalvasJson as ObraSalva[]).map((obra, index) =>
            normalizarObra(obra, index),
          )
        : [];
      const obrasLocaisAtualizadas = obrasSalvasNormalizadas.map((obra) =>
        obraPertenceAoUsuarioPerfilAutor(obra, perfilUserId)
          ? { ...obra, autor: nomeFinal }
          : obra,
      );

      salvarJsonUsuarioPerfilAutor(
        STORAGE_KEY,
        perfilUserId,
        obrasLocaisAtualizadas,
      );
    } catch {
      // O perfil continua atualizado em memória se o armazenamento local falhar.
    }

    setAvatarPerfilEditor(avatarFinal);
    setAvatarArquivoPerfilEditor(null);
    setEditorPerfilAberto(false);
    setSalvandoEditorPerfil(false);

    if (avatarInputRef.current) {
      avatarInputRef.current.value = "";
    }

    if (!resultadoPerfil.ok) {
      setMensagemAcao(
        `Perfil salvo neste aparelho. Supabase: ${resultadoPerfil.erro}${avisoAvatar}`,
      );
      return;
    }

    if (!resultadoObras.ok) {
      setMensagemAcao(
        `Perfil atualizado. Não consegui sincronizar o nome nas obras.${avisoAvatar}`,
      );
      return;
    }

    setMensagemAcao(`Perfil atualizado.${avisoAvatar}`);
  }

  function atualizarBioSobreAutor(novaBioSobre: string) {
    salvarPerfilAutor({
      avatar: avatarAutor,
      avatarNome: perfilSalvoAutor.avatarNome,
      bio: bioAutorPersonalizada,
      sobreBio: novaBioSobre.slice(0, SOBRE_BIO_MAX_LENGTH),
      mostrarDestaques: perfilSalvoAutor.mostrarDestaques,
    });
  }

  function alternarDestaquesPerfil() {
    salvarPerfilAutor({
      avatar: avatarAutor,
      avatarNome: perfilSalvoAutor.avatarNome,
      bio: bioAutorPersonalizada,
      sobreBio: bioSobrePersonalizada,
      mostrarDestaques: !perfilSalvoAutor.mostrarDestaques,
    });
  }

  async function avaliarAutor(nota: number) {
    if (!perfilParaMostrar || !autorPodeReceberAvaliacao || nota < 0 || nota > 5) {
      return;
    }

    if (perfilPertenceAoUsuario) {
      return;
    }

    let userId = "";

    try {
      const { data } = await supabase.auth.getUser();
      userId = data.user?.id || "";
    } catch {
      userId = "";
    }

    if (!userId) {
      avisarLoginNecessario("Entre na sua conta para avaliar este autor.");
      return;
    }

    const autorId = perfilParaMostrar.autorId.trim();

    if (
      autorId &&
      userId.trim().toLowerCase() === autorId.toLowerCase()
    ) {
      return;
    }

    const notaNormalizada = nota <= 0 ? 0 : Math.round(nota * 2) / 2;
    const proximaAvaliacao = calcularProximaAvaliacaoAutor(
      avaliacaoAutor,
      notaNormalizada,
    );

    setAvaliacaoAutor(proximaAvaliacao);
    setMensagemAcao("");
    salvarAvaliacaoAutorLocal(
      perfilParaMostrar,
      notaNormalizada,
      usuarioIdLogado,
    );

    if (!autorId || !idAutorSupabaseValido(autorId)) {
      setAvaliacaoAutor((avaliacaoAtual) => ({
        ...avaliacaoAtual,
        salvando: false,
      }));
      return;
    }

    try {
      const resposta =
        notaNormalizada > 0
          ? await supabase.from("autor_avaliacoes").upsert(
              {
                autor_id: autorId,
                user_id: userId,
                nota: notaNormalizada,
                atualizado_em: new Date().toISOString(),
              },
              { onConflict: "autor_id,user_id" },
            )
          : await supabase
              .from("autor_avaliacoes")
              .delete()
              .eq("autor_id", autorId)
              .eq("user_id", userId);

      if (resposta.error) {
        throw resposta.error;
      }

      setAvaliacaoAutor((avaliacaoAtual) => ({
        ...avaliacaoAtual,
        salvando: false,
      }));
      setMensagemAcao("");
    } catch {
      setAvaliacaoAutor((avaliacaoAtual) => ({
        ...avaliacaoAtual,
        carregado: true,
        salvando: false,
      }));
      setMensagemAcao("");
    }
  }

  async function avaliarDiarioPerfil(nota: number) {
    if (
      !perfilParaMostrar ||
      !perfilUsaAvaliacaoDiario ||
      nota < 0 ||
      nota > 5 ||
      avaliacaoDiario.salvando
    ) {
      return;
    }

    if (perfilPertenceAoUsuario) {
      return;
    }

    let userId = "";

    try {
      const { data } = await supabase.auth.getUser();
      userId = data.user?.id || "";
    } catch {
      userId = "";
    }

    if (!userId) {
      avisarLoginNecessario("Entre na sua conta para avaliar este Diário.");
      return;
    }

    if (!avaliacaoDiario.visivel || !avaliacaoDiario.podeAvaliar) {
      setMensagemAcao("Este Diário não está disponível para avaliação.");
      return;
    }

    const diarioUserId = (
      perfilUsuarioRemotoAtivo?.userId || perfilParaMostrar.autorId
    ).trim();

    if (!diarioUserId || !idAutorSupabaseValido(diarioUserId)) {
      setMensagemAcao("Este Diário não está disponível para avaliação.");
      return;
    }

    if (userId.trim().toLowerCase() === diarioUserId.toLowerCase()) {
      return;
    }

    const notaNormalizada =
      nota <= 0 ? 0 : Math.max(0.5, Math.min(5, Math.round(nota * 2) / 2));
    const avaliacaoAnterior = avaliacaoDiario;
    const avaliacaoOtimista = calcularProximaAvaliacaoAutor(
      avaliacaoDiario,
      notaNormalizada,
    );

    setAvaliacaoDiario((avaliacaoAtual) => ({
      ...avaliacaoAtual,
      ...avaliacaoOtimista,
      salvando: true,
    }));
    setMensagemAcao("");

    try {
      const nomeRpc =
        notaNormalizada > 0
          ? "salvar_avaliacao_diario"
          : "remover_avaliacao_diario";
      const parametros =
        notaNormalizada > 0
          ? {
              p_diario_user_id: diarioUserId,
              p_nota: notaNormalizada,
            }
          : { p_diario_user_id: diarioUserId };
      const { data, error } = await supabase.rpc(nomeRpc, parametros);

      if (error) {
        throw error;
      }

      setAvaliacaoDiario((avaliacaoAtual) =>
        normalizarAvaliacaoDiarioPerfil(data, avaliacaoAtual),
      );
      setMensagemAcao("");
    } catch {
      setAvaliacaoDiario({
        ...avaliacaoAnterior,
        carregado: true,
        salvando: false,
      });
      setMensagemAcao("Este Diário não está disponível para avaliação.");
    }
  }

  function selecionarAvatarAutor(event: ChangeEvent<HTMLInputElement>) {
    const arquivo = event.target.files?.[0];

    setAvatarErro("");

    if (!arquivo) {
      return;
    }

    if (!arquivo.type.startsWith("image/")) {
      setAvatarErro("Escolha uma imagem válida.");
      event.target.value = "";
      return;
    }

    if (arquivo.size > AVATAR_MAX_SIZE) {
      setAvatarErro("A imagem precisa ter no máximo 1 MB.");
      event.target.value = "";
      return;
    }

    const leitor = new FileReader();

    leitor.onload = () => {
      const resultado = typeof leitor.result === "string" ? leitor.result : "";

      if (!resultado) {
        setAvatarErro("Não consegui carregar essa imagem.");
        return;
      }

      setAvatarPerfilEditor(resultado);
      setAvatarNomePerfilEditor(arquivo.name);
      setAvatarArquivoPerfilEditor(arquivo);
      setAvatarErro("");
    };

    leitor.onerror = () => {
      setAvatarErro("Não consegui carregar essa imagem.");
    };

    leitor.readAsDataURL(arquivo);
  }

  function removerAvatarAutor() {
    setAvatarPerfilEditor("");
    setAvatarNomePerfilEditor("");
    setAvatarArquivoPerfilEditor(null);
    setAvatarErro("");

    if (avatarInputRef.current) {
      avatarInputRef.current.value = "";
    }
  }

  async function compartilharLinkPerfilAutor({
    url,
    titulo,
    texto,
    mensagemCompartilhado,
    mensagemCopiado,
    mensagemErro,
  }: {
    url: string;
    titulo: string;
    texto: string;
    mensagemCompartilhado: string;
    mensagemCopiado: string;
    mensagemErro: string;
  }) {
    const urlFinal = criarUrlAbsolutaCompartilhamentoPerfilAutor(url);
    const dadosCompartilhamento: DadosCompartilhamentoPerfilAutor = {
      title: titulo,
      text: texto,
      url: urlFinal,
    };
    const navegadorCompartilhamento =
      navigator as NavegadorCompartilhamentoPerfilAutor;

    if (typeof navegadorCompartilhamento.share === "function") {
      try {
        if (
          !navegadorCompartilhamento.canShare ||
          navegadorCompartilhamento.canShare(dadosCompartilhamento)
        ) {
          await navegadorCompartilhamento.share(dadosCompartilhamento);
          setMensagemAcao(mensagemCompartilhado);
          return;
        }
      } catch (error) {
        if (erroCompartilhamentoFoiCanceladoPerfilAutor(error)) {
          return;
        }
      }
    }

    const linkCopiado = await copiarTextoComFallbackPerfilAutor(urlFinal);

    setMensagemAcao(linkCopiado ? mensagemCopiado : mensagemErro);
  }

  async function copiarLinkPerfil() {
    setMenuPerfilAberto(false);

    const nomePerfil = perfilParaMostrar?.nome || "este autor";
    const usernamePerfil = perfilUsuarioRemotoAtivo?.username
      ? ` (@${perfilUsuarioRemotoAtivo.username})`
      : "";

    await compartilharLinkPerfilAutor({
      url: window.location.href,
      titulo: `${nomePerfil} no HISTORIETAS`,
      texto: `Confira o perfil de ${nomePerfil}${usernamePerfil} no HISTORIETAS.`,
      mensagemCompartilhado: "Compartilhamento do perfil aberto.",
      mensagemCopiado: "",
      mensagemErro:
        "Não consegui compartilhar nem copiar o link do perfil neste navegador.",
    });
  }

  async function copiarUsernameCabecalho() {
    const usernameCompleto = autorHandlePerfil.startsWith("@")
      ? autorHandlePerfil
      : `@${autorHandlePerfil}`;
    const copiado = await copiarTextoComFallbackPerfilAutor(usernameCompleto);

    if (!copiado) {
      setMensagemAcao("Não foi possível copiar o username agora.");
    }
  }

  function abrirDenunciaPerfil() {
    if (podeEditarPerfil || !perfilParaMostrar) {
      return;
    }

    const perfilDenunciadoId = perfilParaMostrar.autorId.trim();

    if (!perfilDenunciadoId || !idAutorSupabaseValido(perfilDenunciadoId)) {
      setMensagemAcao("Não foi possível identificar este perfil.");
      return;
    }

    setMenuPerfilAberto(false);
    setMensagemAcao("");
    setDenunciaPerfilAberta(true);
  }

  function abrirDenunciaConteudoPerfil(
    alvoTipo: Extract<TipoAlvoDenuncia, "post" | "obra">,
    alvoId: string,
    alvoTitulo: string,
  ) {
    if (podeEditarPerfil) {
      return;
    }

    const alvoIdLimpo = alvoId.trim();

    if (!alvoIdLimpo || !idObraSupabaseValido(alvoIdLimpo)) {
      setMensagemAcao("Não foi possível identificar este conteúdo.");
      return;
    }

    setObraMenuAbertoId("");
    setMensagemAcao("");
    setAlvoDenunciaConteudoPerfil({
      alvoTipo,
      alvoId: alvoIdLimpo,
      alvoTitulo: alvoTitulo.trim() || "Conteúdo",
    });
  }

  async function alternarBloqueioPerfil() {
    if (
      podeEditarPerfil ||
      !perfilParaMostrar ||
      bloqueioPerfilSalvando
    ) {
      return;
    }

    const perfilUserId = perfilParaMostrar.autorId.trim();

    if (!perfilUserId || !idAutorSupabaseValido(perfilUserId)) {
      setMensagemAcao("Não foi possível identificar este perfil.");
      return;
    }

    let usuarioAtualId = usuarioIdLogado.trim();

    if (!usuarioAtualId) {
      try {
        const { data } = await supabase.auth.getUser();
        usuarioAtualId = data.user?.id?.trim() || "";
      } catch {
        usuarioAtualId = "";
      }
    }

    if (!usuarioAtualId) {
      setMenuPerfilAberto(false);
      avisarLoginNecessario(
        "Entre na sua conta para bloquear este usuário.",
      );
      return;
    }

    if (usuarioAtualId === perfilUserId) {
      setMensagemAcao("Você não pode bloquear o próprio perfil.");
      return;
    }

    const desbloquear = estadoBloqueioPerfil.bloqueadoPorMim;
    const nomePerfil = perfilParaMostrar.nome || "este usuário";
    const confirmou = window.confirm(
      desbloquear
        ? `Desbloquear ${nomePerfil}?`
        : `Bloquear ${nomePerfil}? Vocês deixarão de se seguir e não poderão interagir entre si.`,
    );

    if (!confirmou) {
      return;
    }

    setMenuPerfilAberto(false);
    setMensagemAcao("");
    setBloqueioPerfilSalvando(true);

    const resultado = desbloquear
      ? await desbloquearUsuario(perfilUserId)
      : await bloquearUsuario(perfilUserId);

    setBloqueioPerfilSalvando(false);

    if (!resultado.ok) {
      setMensagemAcao(
        resultado.erro ||
          (desbloquear
            ? "Não foi possível desbloquear este usuário."
            : "Não foi possível bloquear este usuário."),
      );
      return;
    }

    setEstadoBloqueioPerfil(resultado.estado);

    if (!desbloquear) {
      setSeguindoUsuarioPerfil(false);
      setEstadoRelacionamentoPerfil("nenhum");
      setPermissoesAbasPerfil({
        obras: false,
        sobre: false,
        diario: false,
        comunidade: false,
        biblioteca: false,
        atividades: false,
      });
    }

    setMensagemAcao(
      desbloquear
        ? `${nomePerfil} foi desbloqueado.`
        : `${nomePerfil} foi bloqueado.`,
    );
  }

  async function compartilharObraPerfilAutor(obra: ObraLocal) {
    setObraMenuAbertoId("");

    const obraHref =
      obra.link || `/obra/${obra.slug || criarSlugBase(obra.titulo)}`;

    await compartilharLinkPerfilAutor({
      url: obraHref,
      titulo: obra.titulo || "Obra na Historietas",
      texto: `Veja ${obra.titulo} na Historietas.`,
      mensagemCompartilhado: "Compartilhamento da obra aberto.",
      mensagemCopiado: "Link da obra copiado.",
      mensagemErro: "Não consegui compartilhar nem copiar o link da obra neste navegador.",
    });
  }

  async function sairDaConta() {
    setMenuPerfilAberto(false);

    try {
      await supabase.auth.signOut();
    } catch {
      // Mesmo se o Supabase falhar, leva o usuário para a tela de login.
    }

    router.push("/login");
  }

  async function alternarSeguirAutor() {
    if (!perfilParaMostrar || seguirUsuarioSalvando) {
      return;
    }

    setMensagemAcao("");

    let userIdAtual = usuarioIdLogado;

    try {
      const { data } = await supabase.auth.getUser();
      userIdAtual = data.user?.id || "";

      if (userIdAtual && userIdAtual !== usuarioIdLogado) {
        setUsuarioIdLogado(userIdAtual);
      }
    } catch {
      userIdAtual = usuarioIdLogado;
    }

    if (!userIdAtual) {
      avisarLoginNecessario("Entre na sua conta para seguir perfis.");
      return;
    }

    const userIdPerfil = perfilParaMostrar.autorId.trim();

    if (
      userIdPerfil &&
      idAutorSupabaseValido(userIdPerfil) &&
      idAutorSupabaseValido(userIdAtual)
    ) {
      if (userIdPerfil === userIdAtual) {
        setMensagemAcao("Este é o seu perfil.");
        return;
      }

      const estadoAnterior = estadoRelacionamentoPerfil;
      const seguindoAntes =
        estadoAnterior === "seguindo" || seguindoUsuarioPerfil;
      const notificacaoSolicitacaoId =
        `solicitacao-seguidor:${userIdAtual}:${userIdPerfil}`;
      const notificacaoSeguidorId =
        `seguir-usuario:${userIdAtual}:${userIdPerfil}`;

      setSeguirUsuarioSalvando(true);

      try {
        const resultado =
          estadoAnterior === "solicitado"
            ? await cancelarSolicitacaoSeguidor(userIdPerfil)
            : seguindoAntes
              ? await deixarDeSeguirUsuario(userIdPerfil)
              : await solicitarOuSeguirUsuario(userIdPerfil);

        if (!resultado.ok) {
          setMensagemAcao(
            resultado.erro || "Não consegui atualizar este seguimento agora.",
          );
          return;
        }

        const novoEstado = resultado.estado;
        const seguindoDepois = novoEstado === "seguindo";

        setEstadoRelacionamentoPerfil(novoEstado);
        setSeguindoUsuarioPerfil(seguindoDepois);

        if (seguindoAntes !== seguindoDepois) {
          setSeguidoresUsuarioPerfilTotal((totalAtual) => {
            const proximoTotal = seguindoDepois
              ? totalAtual + 1
              : Math.max(0, totalAtual - 1);

            seguidoresTotalEstavelRef.current[userIdPerfil] = proximoTotal;

            return proximoTotal;
          });
        }

        if (novoEstado === "seguindo" && !seguindoAntes) {
          const nomeSeguidor =
            perfilDoUsuarioLogado?.nome.trim() || "Um leitor";
          const linkSeguidor = criarPerfilAutorHref(nomeSeguidor, userIdAtual);

          await removerNotificacoesSociaisPerfilAutor(
            userIdPerfil,
            [notificacaoSolicitacaoId],
          );
          await criarNotificacaoSocialPerfilAutor({
            receptorId: userIdPerfil,
            tipo: "novo-seguidor",
            titulo: "Novo seguidor",
            mensagem: `${nomeSeguidor} começou a seguir você.`,
            link: linkSeguidor,
            notificacaoId: notificacaoSeguidorId,
          });
        } else if (novoEstado === "solicitado") {
          const nomeSolicitante =
            perfilDoUsuarioLogado?.nome.trim() || "Um leitor";
          const linkSolicitante = criarPerfilAutorHref(
            nomeSolicitante,
            userIdAtual,
          );

          await removerNotificacoesSociaisPerfilAutor(
            userIdPerfil,
            [notificacaoSeguidorId],
          );
          await criarNotificacaoSocialPerfilAutor({
            receptorId: userIdPerfil,
            tipo: "solicitacao-seguidor",
            titulo: "Nova solicitação de seguidor",
            mensagem: `${nomeSolicitante} pediu para seguir você.`,
            link: linkSolicitante,
            notificacaoId: notificacaoSolicitacaoId,
          });
        } else if (estadoAnterior === "solicitado") {
          await removerNotificacoesSociaisPerfilAutor(
            userIdPerfil,
            [notificacaoSolicitacaoId],
          );
        } else if (seguindoAntes && !seguindoDepois) {
          await removerNotificacoesSociaisPerfilAutor(
            userIdPerfil,
            [notificacaoSeguidorId, notificacaoSolicitacaoId],
          );
        }

        setMensagemAcao(
          novoEstado === "seguindo"
            ? "Perfil adicionado aos seus seguindo."
            : novoEstado === "solicitado"
              ? "Sua solicitação foi enviada."
              : estadoAnterior === "solicitado"
                ? "Solicitação cancelada."
                : "Perfil removido dos seus seguindo.",
        );
        return;
      } catch (error) {
        setMensagemAcao(
          error instanceof Error
            ? error.message
            : "Não consegui atualizar este seguimento agora.",
        );
        return;
      } finally {
        setSeguirUsuarioSalvando(false);
      }
    }

    const autorNormalizado = normalizarNomeAutor(perfilParaMostrar.nome);
    const autorChaveSeguir = criarChaveAutorPerfil(
      perfilParaMostrar.autorId,
      perfilParaMostrar.nome,
    );
    const proximoEstadoSeguindo = !seguindoAutor;
    const autoresSeguidosSemAutorAtual = autoresSeguidos.filter((autor) => {
      return autor !== autorChaveSeguir && autor !== autorNormalizado;
    });

    const novosAutoresSeguidos = proximoEstadoSeguindo
      ? Array.from(new Set([...autoresSeguidosSemAutorAtual, autorChaveSeguir]))
      : autoresSeguidosSemAutorAtual;

    salvarJsonUsuarioPerfilAutor(
      AUTHOR_FOLLOW_STORAGE_KEY,
      usuarioIdLogado,
      novosAutoresSeguidos,
    );

    setAutoresSeguidos(novosAutoresSeguidos);
    void sincronizarAutorSeguidoSupabase(
      autorNormalizado,
      proximoEstadoSeguindo,
    );
  }

  async function alternarFavoritoObra(obraId: string) {
    setMensagemAcao("");

    const logado = await usuarioEstaLogado();

    if (!logado) {
      avisarLoginNecessario("Entre na sua conta para adicionar obras à lista.");
      return;
    }

    const obraAlvo = obras.find((obra) => obra.id === obraId) || null;
    const jaFavorita = obraAlvo
      ? colecaoTemObraPerfilBiblioteca(obrasFavoritas, obraAlvo)
      : obrasFavoritas.includes(obraId);
    const proximoEstadoFavorito = !jaFavorita;

    const novasObrasFavoritas = obraAlvo
      ? proximoEstadoFavorito
        ? Array.from(new Set([...obrasFavoritas, obraAlvo.id]))
        : removerObraDaColecaoPerfilBiblioteca(obrasFavoritas, obraAlvo)
      : proximoEstadoFavorito
        ? Array.from(new Set([...obrasFavoritas, obraId]))
        : obrasFavoritas.filter((id) => id !== obraId);

    salvarListaIdsPerfilBiblioteca(
      FAVORITES_STORAGE_KEY,
      usuarioIdLogado,
      novasObrasFavoritas,
    );

    setObrasFavoritas(novasObrasFavoritas);
    await sincronizarTabelaUsuario(
      "favoritos",
      "obra_id",
      obraId,
      proximoEstadoFavorito,
      "parcial",
    );
    setVersaoSincronizacaoBiblioteca((versaoAtual) => versaoAtual + 1);
  }

  async function alternarConcluidoObra(obraId: string) {
    setMensagemAcao("");

    const logado = await usuarioEstaLogado();

    if (!logado) {
      avisarLoginNecessario("Entre na sua conta para concluir obras.");
      return;
    }

    const obraAlvo = obras.find((obra) => obra.id === obraId) || null;
    const jaConcluida = obraAlvo
      ? colecaoTemObraPerfilBiblioteca(obrasConcluidas, obraAlvo)
      : obrasConcluidas.includes(obraId);
    const proximoEstadoConcluido = !jaConcluida;

    const novasObrasConcluidas = obraAlvo
      ? proximoEstadoConcluido
        ? Array.from(new Set([...obrasConcluidas, obraAlvo.id]))
        : removerObraDaColecaoPerfilBiblioteca(obrasConcluidas, obraAlvo)
      : proximoEstadoConcluido
        ? Array.from(new Set([...obrasConcluidas, obraId]))
        : obrasConcluidas.filter((id) => id !== obraId);

    salvarListaIdsPerfilBiblioteca(
      COMPLETED_STORAGE_KEY,
      usuarioIdLogado,
      novasObrasConcluidas,
    );

    setObrasConcluidas(novasObrasConcluidas);
    await sincronizarTabelaUsuario(
      "concluidas",
      "obra_id",
      obraId,
      proximoEstadoConcluido,
      "parcial",
    );
    setVersaoSincronizacaoBiblioteca((versaoAtual) => versaoAtual + 1);
  }


  function salvarObrasBibliotecaPerfil(novasObras: ObraLocal[]) {
    setObras(novasObras);

    try {
      salvarJsonUsuarioPerfilAutor(
        STORAGE_KEY,
        usuarioIdLogado,
        novasObras,
      );
    } catch {
      // A tela continua usando o estado em memória se o localStorage falhar.
    }
  }

  async function alternarSalvoCapituloBibliotecaPerfil(
    obraId: string,
    capituloId: string,
    ativo?: boolean,
  ) {
    setMensagemAcao("");

    const logado = await usuarioEstaLogado();

    if (!logado) {
      avisarLoginNecessario("Entre na sua conta para atualizar a Biblioteca.");
      return;
    }

    let proximoEstadoSalvo = false;

    const novasObras = obras.map((obra) => {
      if (obra.id !== obraId) {
        return obra;
      }

      return {
        ...obra,
        capitulos: obra.capitulos.map((capitulo) => {
          if (capitulo.id !== capituloId) {
            return capitulo;
          }

          proximoEstadoSalvo =
            typeof ativo === "boolean" ? ativo : !capitulo.salvo;

          return {
            ...capitulo,
            salvo: proximoEstadoSalvo,
          };
        }),
      };
    });

    salvarObrasBibliotecaPerfil(novasObras);

    void sincronizarTabelaUsuario(
      "salvos_capitulos",
      "capitulo_id",
      capituloId,
      proximoEstadoSalvo,
      "privado",
    );

    setMensagemAcao(
      proximoEstadoSalvo
        ? "Capítulo salvo na Biblioteca."
        : "Capítulo removido dos salvos.",
    );
  }

  async function alternarObraSeguindoBibliotecaPerfil(obra: ObraLocal, ativo?: boolean) {
    setMensagemAcao("");

    const logado = await usuarioEstaLogado();

    if (!logado) {
      avisarLoginNecessario("Entre na sua conta para atualizar a Biblioteca.");
      return;
    }

    const jaSegue = colecaoTemObraPerfilBiblioteca(obrasSeguidasBiblioteca, obra);
    const proximoEstadoSeguindo = typeof ativo === "boolean" ? ativo : !jaSegue;
    const listaAtualizada = proximoEstadoSeguindo
      ? Array.from(new Set([...obrasSeguidasBiblioteca, obra.id]))
      : removerObraDaColecaoPerfilBiblioteca(obrasSeguidasBiblioteca, obra);

    salvarListaIdsPerfilBiblioteca(
      LIBRARY_FOLLOW_STORAGE_KEY,
      usuarioIdLogado,
      listaAtualizada,
    );
    setObrasSeguidasBiblioteca(listaAtualizada);

    await sincronizarTabelaUsuario(
      "seguindo_obras",
      "obra_id",
      obra.id,
      proximoEstadoSeguindo,
      "publico",
    );
    setVersaoSincronizacaoBiblioteca((versaoAtual) => versaoAtual + 1);

    setMensagemAcao(
      proximoEstadoSeguindo
        ? "Obra adicionada ao Quero ler."
        : "Obra removida do Quero ler.",
    );
  }

  async function removerHistoricoLeituraBibliotecaPerfil(obra: ObraLocal) {
    setMensagemAcao("");

    const logado = await usuarioEstaLogado();

    if (!logado) {
      avisarLoginNecessario("Entre na sua conta para limpar o histórico.");
      return;
    }

    const novasObras = obras.map((obraAtual) => {
      if (obraAtual.id !== obra.id) {
        return obraAtual;
      }

      return {
        ...obraAtual,
        ultimoCapituloLidoId: "",
        ultimaLeituraEm: "",
        progressoLeitura: 0,
        capitulos: obraAtual.capitulos.map((capitulo) => ({
          ...capitulo,
          lido: false,
          lidoEm: "",
        })),
      };
    });

    salvarObrasBibliotecaPerfil(novasObras);

    try {
      const { data } = await supabase.auth.getUser();
      const userId = data.user?.id || usuarioIdLogado;

      if (userId && idObraSupabaseValido(obra.id)) {
        await Promise.all([
          supabase
            .from("progresso_leitura")
            .delete()
            .eq("user_id", userId)
            .eq("obra_id", obra.id),
          supabase
            .from("diario_atividades")
            .delete()
            .eq("user_id", userId)
            .eq("obra_id", obra.id)
            .in("tipo", ["comecou_ler", "leu_capitulo"]),
        ]);
      }
    } catch (error) {
      console.warn("Não consegui limpar o histórico remoto da obra:", error);
    }

    setVersaoSincronizacaoBiblioteca((versaoAtual) => versaoAtual + 1);
    setMensagemAcao("Histórico de leitura removido.");
  }

  async function removerItemBibliotecaPerfil(item: ItemBibliotecaPerfil) {
    if (
      item.capitulo?.salvo &&
      (abaBibliotecaPerfil === "tudo" || abaBibliotecaPerfil === "salvos")
    ) {
      await alternarSalvoCapituloBibliotecaPerfil(
        item.obra.id,
        item.capitulo.id,
        false,
      );
      return;
    }

    if (
      abaBibliotecaPerfil === "tudo" &&
      item.tipoDiario === "quero_ler" &&
      colecaoTemObraPerfilBiblioteca(obrasSeguidasBiblioteca, item.obra)
    ) {
      await alternarObraSeguindoBibliotecaPerfil(item.obra, false);
      return;
    }

    if (
      abaBibliotecaPerfil === "tudo" &&
      item.tipoDiario === "favorita" &&
      colecaoTemObraPerfilBiblioteca(obrasFavoritas, item.obra)
    ) {
      await alternarFavoritoObra(item.obra.id);
      return;
    }

    if (
      abaBibliotecaPerfil === "tudo" &&
      item.tipoDiario === "concluida" &&
      colecaoTemObraPerfilBiblioteca(obrasConcluidas, item.obra)
    ) {
      await alternarConcluidoObra(item.obra.id);
      return;
    }

    if (abaBibliotecaPerfil === "quero-ler") {
      await alternarObraSeguindoBibliotecaPerfil(item.obra, false);
      return;
    }

    if (abaBibliotecaPerfil === "favoritas") {
      if (colecaoTemObraPerfilBiblioteca(obrasFavoritas, item.obra)) {
        await alternarFavoritoObra(item.obra.id);
      }
      return;
    }

    if (abaBibliotecaPerfil === "concluidas") {
      if (colecaoTemObraPerfilBiblioteca(obrasConcluidas, item.obra)) {
        await alternarConcluidoObra(item.obra.id);
      }
      return;
    }

    if (abaBibliotecaPerfil === "salvos" && item.capitulo) {
      await alternarSalvoCapituloBibliotecaPerfil(
        item.obra.id,
        item.capitulo.id,
        false,
      );
      return;
    }

    await removerHistoricoLeituraBibliotecaPerfil(item.obra);
  }

  function renderizarMiniCardDiarioPerfil(
    item: DiarioPerfilResumoItem,
  ) {
    const obra = item.obra;

    if (!obra) {
      return null;
    }

    const parametrosLista = new URLSearchParams({
      modo: "perfil",
      origem: "diario",
      categoria: "tudo",
      obra: obra.id,
    });
    const perfilIdLista = perfilParaMostrar?.autorId.trim() || "";

    if (perfilIdLista) {
      parametrosLista.set("usuario", perfilIdLista);
    }

    const hrefLista = `/listas?${parametrosLista.toString()}`;

    return (
      <Link
        key={obra.id || item.chave}
        href={hrefLista}
        style={diarySummaryCardLinkStyle}
        aria-label={`Abrir ${obra.titulo} na página Listas`}
        title={`Ver ${obra.titulo} nas Listas`}
      >
        <div
          style={criarCapaMiniCardDiarioPerfilStyle(obra.capa)}
          aria-hidden="true"
        />

        <strong
          data-historietas-user-content="true"
          style={diarySummaryCardTitleStyle}
        >
          {obra.titulo}
        </strong>

      </Link>
    );
  }

  function renderizarItemBibliotecaPerfil(item: ItemBibliotecaPerfil) {
    const obraHref =
      item.obra.link ||
      `/obra/${item.obra.slug || criarSlugBase(item.obra.titulo)}`;
    const capituloHref = item.capitulo
      ? criarHrefLeituraCapituloPerfilAutor(
          item.obra,
          item.capitulo,
          item.numeroCapitulo || 1,
        )
      : obraHref;
    const totalCurtidasBiblioteca = obterTotalCurtidasObraPerfilAutor(
      item.obra,
      totaisInteracoesObras,
    );
    const totalComentariosBiblioteca = obterTotalComentariosObraPerfilAutor(
      item.obra,
      totaisInteracoesObras,
    );
    const visualizacoesBiblioteca = compactarNumeroPerfilAutor(
      item.obra.visualizacoes || 0,
    );

    return (
      <article
        key={item.chave}
        style={isDesktop ? desktopDiaryVisualCardStyle : diaryVisualCardStyle}
      >
        <Link
          href={capituloHref}
          style={diaryVisualCoverLinkStyle}
          aria-label={`Abrir ${item.obra.titulo}`}
        >
          <div style={criarCapaGridPerfilAutor(item.obra.capa, isDesktop)}>
            <div style={diaryCardCoverOverlayStyle}>
              <strong data-historietas-user-content="true" style={diaryCardCoverTitleStyle}>{item.obra.titulo}</strong>

              <span style={diaryCardCoverMetaStyle}>
                <span>👁 {visualizacoesBiblioteca}</span>
                <span>
                  <span style={diaryCardHeartMetaStyle}>❤️</span>{" "}
                  {totalCurtidasBiblioteca}
                </span>
                <span>
                  <span style={diaryCardCommentMetaStyle}>💬</span>{" "}
                  {totalComentariosBiblioteca}
                </span>
              </span>
            </div>
          </div>
        </Link>

        <div style={profileWorkMenuAnchorStyle}>
          <button
            type="button"
            onClick={() =>
              setBibliotecaMenuAbertoChave((chaveAtual) =>
                chaveAtual === item.chave ? "" : item.chave,
              )
            }
            style={profileWorkDotsButtonStyle}
            aria-label={`Abrir opções de ${item.obra.titulo}`}
            aria-expanded={bibliotecaMenuAbertoChave === item.chave}
          >
            ⋮
          </button>
        </div>
      </article>
    );
  }

  function renderizarAtividadeRecenteSobrePerfil() {
    return (
      <section style={diaryTimelineStyle}>
        <div style={diaryCollapsibleHeaderStyle}>
          <strong style={diarySectionTitleStyle}>Atividade recente</strong>

          <button
            type="button"
            onClick={() =>
              setAtividadeSobreAberta((valorAtual) => !valorAtual)
            }
            style={diaryToggleButtonStyle}
            aria-label={
              atividadeSobreAberta
                ? "Ocultar atividade recente"
                : "Abrir atividade recente"
            }
            aria-expanded={atividadeSobreAberta}
          >
            <span>{atividadeSobreAberta ? "Ocultar" : "Abrir"}</span>
            <span style={diaryToggleButtonIconStyle}>
              {atividadeSobreAberta ? "↑" : "↓"}
            </span>
          </button>
        </div>

        {atividadeSobreAberta &&
          (diarioPerfil.carregando ? (
            <LoadingSpinner label="Carregando atividades" compacto />
          ) : diarioPerfil.atividades.length === 0 ? (
            <div style={diaryEmptyStateStyle}>
              Nenhuma atividade recente para mostrar.
            </div>
          ) : (
            <div style={diaryTimelineListStyle}>
              {diarioPerfil.atividades.slice(0, 8).map((item) => (
                <Link
                  key={`timeline-${item.chave}`}
                  href={obterHrefItemDiarioPerfil(item)}
                  style={diaryTimelineItemStyle}
                >
                  <span style={diaryTimelineDotStyle} aria-hidden="true" />
                  <span style={diaryTimelineTextStyle}>
                    <strong data-historietas-user-content="true">{item.titulo}</strong>
                    {" — "}
                    {item.descricao}
                  </span>
                  <span style={diaryTimelineDateStyle}>
                    {dataDiarioPerfilFormatada(item.data)}
                  </span>
                </Link>
              ))}
            </div>
          ))}
      </section>
    );
  }


  if (carregando) {
    return (
      <main style={pageThemeStyle}>
        <style>{`${historietasThemeCss}${perfilAutorThemeCss}`}</style>

        {isDesktop && (
          <div style={desktopTopWaterFadeStyle} aria-hidden="true" />
        )}
        {!isDesktop && (
          <div style={mobileTopWaterFadeStyle} aria-hidden="true" />
        )}
        <section style={isDesktop ? desktopContainerStyle : containerStyle}>
          <LoadingSpinner label="Carregando perfil" />
        </section>
      </main>
    );
  }

  if (autorNaoEncontrado) {
    return (
      <main style={pageThemeStyle}>
        <style>{`${historietasThemeCss}${perfilAutorThemeCss}`}</style>

        {isDesktop && (
          <div style={desktopTopWaterFadeStyle} aria-hidden="true" />
        )}
        {!isDesktop && (
          <div style={mobileTopWaterFadeStyle} aria-hidden="true" />
        )}

        <section style={isDesktop ? desktopContainerStyle : containerStyle}>
          <p
            style={{
              margin: "10px 0 0",
              color: "#FFFFFF",
              fontSize: "12px",
              fontWeight: 800,
              textAlign: "center",
            }}
          >
            Perfil não encontrado
          </p>
        </section>
      </main>
    );
  }

  if (!perfilParaMostrar) {
    return (
      <main style={pageThemeStyle}>
        <style>{`${historietasThemeCss}${perfilAutorThemeCss}`}</style>

        {isDesktop && (
          <div style={desktopTopWaterFadeStyle} aria-hidden="true" />
        )}
        {!isDesktop && (
          <div style={mobileTopWaterFadeStyle} aria-hidden="true" />
        )}

        <section style={isDesktop ? desktopContainerStyle : containerStyle}>
          <p
            style={{
              margin: "10px 0 0",
              color: "#FFFFFF",
              fontSize: "12px",
              fontWeight: 800,
              textAlign: "center",
            }}
          >
            {perfilSemLoginSemParametro
              ? "Entre para acessar seu perfil"
              : "Nenhum autor encontrado"}
          </p>
        </section>
      </main>
    );
  }

  return (
    <main style={pageThemeStyle}>
      <style>{`${historietasThemeCss}${perfilAutorThemeCss}`}</style>

      {isDesktop && <div style={desktopTopWaterFadeStyle} aria-hidden="true" />}
      {!isDesktop && <div style={mobileTopWaterFadeStyle} aria-hidden="true" />}
      <section style={containerAtualStyle}>
        <header
          style={
            isDesktop ? profileHeaderDesktopStyle : profileHeaderStyle
          }
        >
          <div style={profileHeaderLogoStyle}>
            <button
              type="button"
              onClick={() =>
                setUsernameCabecalhoVisivel((visivel) => !visivel)
              }
              style={logoMarkButtonStyle}
              aria-label={
                usernameCabecalhoVisivel
                  ? "Esconder username"
                  : "Mostrar username"
              }
              aria-expanded={usernameCabecalhoVisivel}
            >
              <span style={logoMarkStyle} aria-hidden="true">
                @
              </span>
            </button>

            {usernameCabecalhoVisivel ? (
              <button
                type="button"
                onClick={copiarUsernameCabecalho}
                style={logoTextButtonStyle}
                aria-label={`Copiar ${autorHandlePerfil}`}
                title="Copiar username"
              >
                <span
                  data-historietas-user-content="true"
                  data-historietas-i18n-ignore="true"
                  style={logoTextStyle}
                >
                  {autorHandlePerfil.replace(/^@/, "")}
                </span>
              </button>
            ) : null}
          </div>

          <button
            type="button"
            onClick={() => setMenuPerfilAberto(true)}
            style={profileMenuButtonStyle}
            aria-label="Abrir menu do perfil"
            aria-expanded={menuPerfilAberto}
          >
            <span style={profileMenuIconStyle} aria-hidden="true">
              <span style={profileMenuIconLineStyle} />
              <span style={profileMenuIconLineStyle} />
              <span style={profileMenuIconLineStyle} />
            </span>
          </button>
        </header>

        {menuPerfilAberto && (
          <div
            style={menuOverlayStyle}
            role="presentation"
            onClick={() => setMenuPerfilAberto(false)}
          >
            <section
              style={menuSheetAtualStyle}
              role="dialog"
              aria-label="Menu do perfil"
              onClick={(event) => event.stopPropagation()}
            >
              <div style={menuHeaderStyle}>
                <div style={menuTitleBlockStyle}>
                  <strong data-historietas-user-content="true" style={menuTitleStyle}>
                    {perfilParaMostrar.nome}
                  </strong>
                  {!podeEditarPerfil ? (
                    <span style={menuSubtitleStyle}>Ações do perfil</span>
                  ) : null}
                </div>

                <button
                  type="button"
                  onClick={() => setMenuPerfilAberto(false)}
                  style={menuCloseButtonStyle}
                  aria-label="Fechar menu"
                >
                  ×
                </button>
              </div>

              <div style={menuListStyle}>
                {podeEditarPerfil ? (
                  <>
                    <span style={menuSectionTitleStyle}>Conta e sistema</span>

                    <Link
                      href="/painel-autor"
                      style={menuItemStyle}
                      onClick={() => setMenuPerfilAberto(false)}
                    >
                      <span style={menuItemIconStyle}>
                        <MenuPerfilIcone tipo="painel" />
                      </span>
                      <strong style={menuItemTextStyle}>Painel do Autor</strong>
                      <span style={menuChevronStyle}>›</span>
                    </Link>

                    <Link
                      href="/notificacoes"
                      style={menuItemStyle}
                      onClick={() => setMenuPerfilAberto(false)}
                      aria-label={
                        notificacoesNaoLidas > 0
                          ? `Notificações: ${notificacoesNaoLidas} não lidas`
                          : "Notificações"
                      }
                    >
                      <span style={menuItemIconStyle}>
                        <MenuPerfilIcone tipo="notificacoes" />
                      </span>
                      <span style={menuNotificationLabelStyle}>
                        <strong style={menuItemTextStyle}>Notificações</strong>

                        {notificacoesNaoLidas > 0 ? (
                          <span
                            style={menuNotificationBadgeStyle}
                            aria-label={`${notificacoesNaoLidas > 99 ? "99+" : notificacoesNaoLidas} notificações não lidas`}
                          >
                            {notificacoesNaoLidas > 99
                              ? "99+"
                              : notificacoesNaoLidas}
                          </span>
                        ) : null}
                      </span>

                      <span style={menuNotificationRightStyle}>
                        <span style={menuChevronStyle}>›</span>
                      </span>
                    </Link>

                    <Link
                      href="/configuracoes"
                      style={menuItemStyle}
                      onClick={() => setMenuPerfilAberto(false)}
                    >
                      <span style={menuItemIconStyle}>
                        <MenuPerfilIcone tipo="configuracoes" />
                      </span>
                      <strong style={menuItemTextStyle}>
                        Configurações e atividade
                      </strong>
                      <span style={menuChevronStyle}>›</span>
                    </Link>

                    <button
                      type="button"
                      onClick={() => void copiarLinkPerfil()}
                      style={menuItemStyle}
                    >
                      <span style={menuItemIconStyle}>
                        <MenuPerfilIcone tipo="link" />
                      </span>
                      <strong style={menuItemTextStyle}>
                        Copiar link do perfil
                      </strong>
                      <span style={menuChevronStyle}>›</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => void sairDaConta()}
                      style={menuDangerItemStyle}
                    >
                      <span style={menuItemIconStyle}>
                        <MenuPerfilIcone tipo="sair" />
                      </span>
                      <strong style={menuItemTextStyle}>Sair da conta</strong>
                      <span style={menuChevronStyle}>›</span>
                    </button>
                  </>
                ) : (
                  <>
                    <span style={menuSectionTitleStyle}>Perfil</span>

                    <button
                      type="button"
                      onClick={() => void copiarLinkPerfil()}
                      style={menuItemStyle}
                    >
                      <span style={menuItemIconStyle}><MenuPerfilIcone tipo="link" /></span>
                      <strong style={menuItemTextStyle}>
                        Copiar link do perfil
                      </strong>
                      <span style={menuChevronStyle}>›</span>
                    </button>

                    <Link
                      href={comunidadeAutorHref}
                      style={menuItemStyle}
                      onClick={() => setMenuPerfilAberto(false)}
                    >
                      <span style={menuItemIconStyle}><MenuPerfilIcone tipo="comunidade" /></span>
                      <strong style={menuItemTextStyle}>
                        Comunidade do autor
                      </strong>
                      <span style={menuChevronStyle}>›</span>
                    </Link>

                    <button
                      type="button"
                      onClick={abrirDenunciaPerfil}
                      style={menuDangerItemStyle}
                    >
                      <span style={menuItemIconStyle}>
                        <MenuPerfilIcone tipo="denunciar" />
                      </span>
                      <strong style={menuItemTextStyle}>
                        Denunciar perfil
                      </strong>
                      <span style={menuChevronStyle}>›</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => void alternarBloqueioPerfil()}
                      disabled={bloqueioPerfilSalvando}
                      style={
                        estadoBloqueioPerfil.bloqueadoPorMim
                          ? menuItemStyle
                          : menuDangerItemStyle
                      }
                    >
                      <span style={menuItemIconStyle}>
                        <MenuPerfilIcone tipo="bloquear" />
                      </span>
                      <strong style={menuItemTextStyle}>
                        {bloqueioPerfilSalvando
                          ? estadoBloqueioPerfil.bloqueadoPorMim
                            ? "Desbloqueando..."
                            : "Bloqueando..."
                          : estadoBloqueioPerfil.bloqueadoPorMim
                            ? "Desbloquear usuário"
                            : "Bloquear usuário"}
                      </strong>
                      <span style={menuChevronStyle}>›</span>
                    </button>

                    <div style={menuDividerStyle} />
                    <span style={menuSectionTitleStyle}>Descoberta</span>

                    <Link
                      href="/explorar"
                      style={menuItemStyle}
                      onClick={() => setMenuPerfilAberto(false)}
                    >
                      <span style={menuItemIconStyle}><MenuPerfilIcone tipo="explorar" /></span>
                      <strong style={menuItemTextStyle}>
                        Explorar outras obras
                      </strong>
                      <span style={menuChevronStyle}>›</span>
                    </Link>
                  </>
                )}
              </div>
            </section>
          </div>
        )}

        {podeEditarPerfil && editorPerfilAberto && (
          <div
            style={menuOverlayStyle}
            role="presentation"
            onClick={fecharEditorPerfil}
          >
            <section
              style={menuSheetAtualStyle}
              role="dialog"
              aria-modal="true"
              aria-label="Editar perfil"
              onClick={(event) => event.stopPropagation()}
            >
              <div style={menuHeaderStyle}>
                <div style={menuTitleBlockStyle}>
                  <strong style={menuTitleStyle}>Editar perfil</strong>
                  <span style={menuSubtitleStyle}>
                    Atualize suas informações públicas
                  </span>
                </div>

                <button
                  type="button"
                  onClick={fecharEditorPerfil}
                  disabled={salvandoEditorPerfil}
                  style={menuCloseButtonStyle}
                  aria-label="Fechar edição do perfil"
                >
                  ×
                </button>
              </div>

              <div style={profileEditorSheetContentStyle}>
                <div style={profileEditorAvatarBlockStyle}>
                  <div style={profileEditorAvatarPreviewStyle}>
                    {avatarPerfilEditor ? (
                      <img
                        src={avatarPerfilEditor}
                        alt="Prévia da imagem do perfil"
                        style={avatarImageStyle}
                      />
                    ) : (
                      <span>
                        {(nomePerfilEditor || perfilParaMostrar.nome)
                          .charAt(0)
                          .toUpperCase()}
                      </span>
                    )}
                  </div>

                  <div style={avatarActionsAtualStyle}>
                    <button
                      type="button"
                      onClick={() => avatarInputRef.current?.click()}
                      disabled={salvandoEditorPerfil}
                      style={avatarSmallButtonAtualStyle}
                    >
                      {avatarPerfilEditor ? "Trocar imagem" : "Colocar imagem"}
                    </button>

                    {avatarPerfilEditor && (
                      <button
                        type="button"
                        onClick={removerAvatarAutor}
                        disabled={salvandoEditorPerfil}
                        style={avatarRemoveButtonAtualStyle}
                      >
                        Remover
                      </button>
                    )}
                  </div>

                  {avatarErro && (
                    <span style={avatarErrorStyle}>{avatarErro}</span>
                  )}
                </div>

                <label style={profileEditorSheetFieldStyle}>
                  <span style={profileEditorSheetLabelStyle}>
                    Nome de usuário
                  </span>

                  <input
                    value={nomePerfilEditor}
                    onChange={(event) =>
                      setNomePerfilEditor(event.target.value.slice(0, 80))
                    }
                    onKeyDown={(event) => {
                      if (event.key === "Enter") {
                        event.preventDefault();
                        void salvarEdicaoPerfilAutor();
                      }
                    }}
                    placeholder="Digite seu nome"
                    maxLength={80}
                    disabled={salvandoEditorPerfil}
                    style={profileEditorSheetInputStyle}
                    type="text"
                  />
                </label>

                <label style={profileEditorSheetFieldStyle}>
                  <span style={profileEditorSheetLabelStyle}>
                    @username público
                  </span>

                  <input
                    value={usernamePerfilEditor}
                    onChange={(event) =>
                      setUsernamePerfilEditor(
                        normalizarUsernamePerfilAutor(event.target.value),
                      )
                    }
                    onKeyDown={(event) => {
                      if (event.key === "Enter") {
                        event.preventDefault();
                        void salvarEdicaoPerfilAutor();
                      }
                    }}
                    placeholder="Digite seu username"
                    maxLength={30}
                    disabled={salvandoEditorPerfil}
                    style={profileEditorSheetInputStyle}
                    type="text"
                  />
                </label>

                <label style={profileEditorSheetFieldStyle}>
                  <span style={profileEditorSheetLabelStyle}>Biografia</span>

                  <textarea
                    value={bioPerfilEditor}
                    onChange={(event) =>
                      setBioPerfilEditor(
                        event.target.value.slice(0, BIO_MAX_LENGTH),
                      )
                    }
                    placeholder={bioPadraoAutor}
                    maxLength={BIO_MAX_LENGTH}
                    disabled={salvandoEditorPerfil}
                    style={profileEditorSheetTextareaStyle}
                  />
                </label>

                <span style={bioCounterStyle}>
                  {BIO_MAX_LENGTH - bioPerfilEditor.length} caracteres
                </span>

                <div style={profileEditorSheetActionsStyle}>
                  <button
                    type="button"
                    onClick={fecharEditorPerfil}
                    disabled={salvandoEditorPerfil}
                    style={profileEditorCancelButtonStyle}
                  >
                    Cancelar
                  </button>

                  <button
                    type="button"
                    onClick={() => void salvarEdicaoPerfilAutor()}
                    disabled={salvandoEditorPerfil}
                    style={profileEditorSaveButtonStyle}
                  >
                    {salvandoEditorPerfil ? "Salvando..." : "Salvar"}
                  </button>
                </div>
              </div>
            </section>
          </div>
        )}

        <DenunciaModal
          aberto={
            denunciaPerfilAberta &&
            !podeEditarPerfil &&
            Boolean(perfilParaMostrar)
          }
          alvoTipo="perfil"
          alvoId={perfilParaMostrar?.autorId || ""}
          alvoTitulo={perfilParaMostrar?.nome || "Perfil"}
          alvoUrl={
            perfilParaMostrar?.autorId
              ? `/perfil-autor?userId=${encodeURIComponent(
                  perfilParaMostrar.autorId
                )}`
              : ""
          }
          onFechar={() => setDenunciaPerfilAberta(false)}
          onEnviada={() => {
            setDenunciaPerfilAberta(false);
            setMensagemAcao("Denúncia enviada para análise.");
          }}
        />

        <DenunciaModal
          aberto={
            Boolean(alvoDenunciaConteudoPerfil) &&
            !podeEditarPerfil
          }
          alvoTipo={alvoDenunciaConteudoPerfil?.alvoTipo || "post"}
          alvoId={alvoDenunciaConteudoPerfil?.alvoId || ""}
          alvoTitulo={
            alvoDenunciaConteudoPerfil?.alvoTitulo || "Conteúdo"
          }
          onFechar={() => setAlvoDenunciaConteudoPerfil(null)}
          onEnviada={() => {
            setAlvoDenunciaConteudoPerfil(null);
            setMensagemAcao("Denúncia enviada para análise.");
          }}
        />

        <section style={heroAtualStyle}>
          <div style={authorTopRowAtualStyle}>
            {podeEditarPerfil ? (
              <button
                type="button"
                onClick={abrirEditorPerfil}
                style={avatarButtonAtualStyle}
                aria-label="Editar perfil"
              >
                {avatarAutor ? (
                  <img
                    src={avatarAutor}
                    alt={`Imagem de ${perfilParaMostrar.nome}`}
                    style={avatarImageStyle}
                  />
                ) : (
                  <span>{perfilParaMostrar.nome.charAt(0)}</span>
                )}
              </button>
            ) : (
              <div style={avatarDisplayAtualStyle}>
                {avatarAutor ? (
                  <img
                    src={avatarAutor}
                    alt={`Imagem de ${perfilParaMostrar.nome}`}
                    style={avatarImageStyle}
                  />
                ) : (
                  <span>{perfilParaMostrar.nome.charAt(0)}</span>
                )}
              </div>
            )}

            <div style={authorHeaderInfoStyle}>
              <div style={profileNameRowStyle}>
                <h1 data-historietas-user-content="true" className="historietas-theme-title" style={titleAtualStyle}>
                  {perfilParaMostrar.nome}
                </h1>
              </div>

              <div
                style={
                  avaliacaoResumoPerfilVisivel
                    ? {
                        ...profileStatsAtualStyle,
                        gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
                      }
                    : profileStatsAtualStyle
                }
              >
                <Link
                  href={obrasSeguidasPerfilHref}
                  style={profileStatLinkStyle}
                  aria-label={`Abrir obras seguidas por ${perfilParaMostrar.nome}`}
                >
                  <strong style={profileStatWorksNumberStyle}>
                    {obrasSeguidasPerfilTotal}
                  </strong>
                  <span style={profileStatWorksLabelStyle}>
                    {language === "en" ? (
                      <>
                        <span>works</span>
                        <span>followed</span>
                      </>
                    ) : language === "es" ? (
                      <>
                        <span>obras</span>
                        <span>seguidas</span>
                      </>
                    ) : (
                      <>
                        <span>obras</span>
                        <span>seguidas</span>
                      </>
                    )}
                  </span>
                </Link>

                <Link
                  href={seguidoresPerfilHref}
                  style={profileStatLinkStyle}
                  aria-label={`Abrir lista de seguidores de ${perfilParaMostrar.nome}`}
                >
                  <strong style={profileStatNumberStyle}>
                    {seguidoresTotal}
                  </strong>
                  <span style={profileStatLabelStyle}>seguidores</span>
                </Link>

                <Link
                  href={seguindoPerfilHref}
                  style={profileStatLinkStyle}
                  aria-label={`Abrir lista de perfis que ${perfilParaMostrar.nome} segue`}
                >
                  <strong style={profileStatNumberStyle}>
                    {seguindoTotalPerfil}
                  </strong>
                  <span style={profileStatLabelStyle}>seguindo</span>
                </Link>

                {avaliacaoResumoPerfilVisivel && (
                  <div
                    style={profileRatingStatItemStyle}
                    aria-label={
                      avaliacaoResumoEhDiario
                        ? "Avaliação do Diário"
                        : "Avaliação do autor"
                    }
                  >
                    {avaliacaoResumoEhDiario && avaliacaoDiarioPrivada ? (
                      <span
                        style={profileRatingPrivateLockStyle}
                        title="Avaliação do Diário privada"
                        aria-label="Avaliação do Diário privada"
                      >
                        <CadeadoAvaliacaoDiarioIcone />
                      </span>
                    ) : (
                      <>
                        <strong style={profileRatingNumberStyle}>
                          {formatarMediaAvaliacaoAutor(
                            avaliacaoResumoPerfil.media,
                          )}
                        </strong>

                        <span style={profileRatingStackedMetaStyle}>
                          <span
                            style={profileRatingMiniStarsStyle}
                            aria-label={`Média ${formatarMediaAvaliacaoAutor(
                              avaliacaoResumoPerfil.media,
                            )} de 5`}
                          >
                            {NOTAS_AVALIACAO_AUTOR.map((estrela) => (
                              <span
                                key={`${
                                  avaliacaoResumoEhDiario ? "diario" : "autor"
                                }-media-topo-${estrela}`}
                                style={profileRatingMiniStarVisualStyle}
                                aria-hidden="true"
                              >
                                <span style={profileRatingMiniStarBaseStyle}>★</span>
                                <span
                                  style={{
                                    ...profileRatingMiniStarFillStyle,
                                    width: obterPreenchimentoEstrelaAutor(
                                      estrela,
                                      avaliacaoResumoPerfil.media,
                                    ),
                                  }}
                                >
                                  ★
                                </span>
                              </span>
                            ))}
                          </span>

                          <span style={profileRatingTotalStyle}>
                            {avaliacaoResumoEhDiario
                              ? formatarTotalAvaliacoesDiario(
                                  avaliacaoResumoPerfil.total,
                                  language,
                                )
                              : formatarTotalAvaliacoesAutor(
                                  avaliacaoResumoPerfil.total,
                                  language,
                                )}
                          </span>
                        </span>
                      </>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div style={authorTextBlockStyle}>
            {bioAutorPersonalizada ? (
              <p data-historietas-user-content="true" style={descriptionAtualStyle}>{bioAutorPersonalizada}</p>
            ) : podeEditarPerfil ? (
              <button
                type="button"
                onClick={abrirEditorPerfil}
                style={profileAddBioButtonStyle}
              >
                + Adicionar biografia
              </button>
            ) : (
              <p style={descriptionAtualStyle}>{bioAutor}</p>
            )}
          </div>

          <div
            style={
              podeEditarPerfil
                ? profileActionsAtualStyle
                : profileVisitorActionsAtualStyle
            }
          >
            {podeEditarPerfil ? (
              <>
                <button
                  type="button"
                  onClick={abrirEditorPerfil}
                  style={profilePrimaryButtonStyle}
                >
                  Editar perfil
                </button>

                <button
                  type="button"
                  onClick={() => void copiarLinkPerfil()}
                  style={profilePrimaryButtonStyle}
                >
                  Compartilhar
                </button>

                <button
                  type="button"
                  onClick={alternarDestaquesPerfil}
                  style={profilePrimaryButtonStyle}
                >
                  {perfilSalvoAutor.mostrarDestaques
                    ? "Ocultar destaques"
                    : "Mostrar destaques"}
                </button>
              </>
            ) : (
              <>
                {!estadoBloqueioPerfil.existeBloqueio && (
                <button
                  type="button"
                  onClick={() => void alternarSeguirAutor()}
                  disabled={seguirUsuarioSalvando}
                  aria-label={
                    solicitacaoSeguimentoPendente
                      ? "Cancelar solicitação"
                      : seguindoPerfilAtual
                        ? "Deixar de seguir"
                        : "Seguir"
                  }
                  title={
                    solicitacaoSeguimentoPendente
                      ? "Cancelar solicitação"
                      : undefined
                  }
                  style={{
                    ...(seguindoPerfilAtual || solicitacaoSeguimentoPendente
                      ? profileActiveButtonStyle
                      : profilePrimaryButtonStyle),
                    opacity: seguirUsuarioSalvando ? 0.58 : 1,
                    cursor: seguirUsuarioSalvando ? "not-allowed" : "pointer",
                  }}
                >
                  {seguirUsuarioSalvando
                    ? "..."
                    : solicitacaoSeguimentoPendente
                      ? "Solicitado"
                      : seguindoPerfilAtual
                        ? "Seguindo"
                        : "Seguir"}
                </button>
                )}

                <button
                  type="button"
                  onClick={() => void copiarLinkPerfil()}
                  style={profileSecondaryButtonStyle}
                >
                  Compartilhar
                </button>

                {obrasPerfilVisivel && (
                  <button
                    type="button"
                    onClick={() =>
                      setMostrarDestaquesVisitante((valorAtual) => !valorAtual)
                    }
                    style={profileSecondaryButtonStyle}
                  >
                    {mostrarDestaquesVisitante
                      ? "Ocultar destaque"
                      : "Mostrar destaque"}
                  </button>
                )}
              </>
            )}
          </div>

          {mensagemAcao && (
            <div
              style={profileActionToastStyle}
              role="status"
              aria-live="polite"
            >
              {mensagemAcao}
            </div>
          )}

          {podeEditarPerfil && (
            <input
              ref={avatarInputRef}
              type="file"
              accept="image/*"
              onChange={selecionarAvatarAutor}
              style={hiddenInputStyle}
            />
          )}

        </section>

        {destaquesPerfilVisivel &&
          (obrasEmDestaque.length > 0 || podeEditarPerfil || mostrarDestaquesVisitante) && (
            <section
              style={isDesktop ? desktopAuthorHighlightsStyle : authorHighlightsStyle}
              aria-label="TOP 5"
            >
              <div style={authorHighlightsHeaderStyle}>
                <div style={authorHighlightsTitleGroupStyle}>
                  <strong style={authorHighlightsTitleStyle}>TOP 5</strong>

                  {podeEditarPerfil && obrasEmDestaque.length > 0 && (
                    <button
                      type="button"
                      data-historietas-top-five-like="true"
                      onClick={() => void alternarCurtidaTopFivePerfil()}
                      disabled={topFiveCurtidaSalvando}
                      style={{
                        ...(topFiveCurtidoPorMim
                          ? authorHighlightsLikeButtonActiveStyle
                          : authorHighlightsLikeButtonStyle),
                        opacity: topFiveCurtidaSalvando ? 0.58 : 1,
                        cursor: topFiveCurtidaSalvando
                          ? "not-allowed"
                          : "pointer",
                      }}
                      aria-pressed={topFiveCurtidoPorMim}
                      aria-label={`${
                        topFiveCurtidoPorMim
                          ? "Remover curtida do TOP 5"
                          : "Curtir TOP 5"
                      }. ${compactarNumeroPerfilAutor(topFiveCurtidasTotal)} ${
                        topFiveCurtidasTotal === 1 ? "curtida" : "curtidas"
                      }`}
                    >
                      <svg
                        viewBox="0 0 24 24"
                        aria-hidden="true"
                        style={{
                          ...authorHighlightsLikeHeartIconStyle,
                          animation: topFiveCurtidoPorMim
                            ? "historietas-perfil-heart-pop 260ms ease-out"
                            : "none",
                        }}
                      >
                        <path
                          d="M20.7 5.3c-1.8-1.9-4.7-1.9-6.5 0L12 7.6 9.8 5.3c-1.8-1.9-4.7-1.9-6.5 0-1.8 1.9-1.8 5 0 6.9L12 21l8.7-8.8c1.8-1.9 1.8-5 0-6.9Z"
                          fill={
                            topFiveCurtidoPorMim
                              ? "var(--historietas-perfil-danger, #EF4444)"
                              : "none"
                          }
                          stroke={
                            topFiveCurtidoPorMim
                              ? "var(--historietas-perfil-danger, #EF4444)"
                              : "#FFFFFF"
                          }
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                      <span style={authorHighlightsLikeCountStyle}>{compactarNumeroPerfilAutor(topFiveCurtidasTotal)}</span>
                    </button>
                  )}
                </div>

                <div style={authorHighlightsHeaderActionsStyle}>
                  {podeEditarPerfil ? (
                    <Link
                      href="/perfil-autor/top-5"
                      style={authorHighlightsTopFiveButtonStyle}
                      aria-label="Montar ou editar TOP 5"
                    >
                      +
                    </Link>
                  ) : (
                    obrasEmDestaque.length > 0 && (
                      <button
                        type="button"
                        data-historietas-top-five-like="true"
                      onClick={() => void alternarCurtidaTopFivePerfil()}
                        disabled={topFiveCurtidaSalvando}
                        style={{
                        ...(topFiveCurtidoPorMim
                          ? authorHighlightsLikeButtonActiveStyle
                          : authorHighlightsLikeButtonStyle),
                        opacity: topFiveCurtidaSalvando ? 0.58 : 1,
                        cursor: topFiveCurtidaSalvando
                          ? "not-allowed"
                          : "pointer",
                      }}
                        aria-pressed={topFiveCurtidoPorMim}
                      aria-label={`${
                        topFiveCurtidoPorMim
                          ? "Remover curtida do TOP 5"
                          : "Curtir TOP 5"
                      }. ${compactarNumeroPerfilAutor(topFiveCurtidasTotal)} ${
                        topFiveCurtidasTotal === 1 ? "curtida" : "curtidas"
                      }`}
                      >
                        <svg
                        viewBox="0 0 24 24"
                        aria-hidden="true"
                        style={{
                          ...authorHighlightsLikeHeartIconStyle,
                          animation: topFiveCurtidoPorMim
                            ? "historietas-perfil-heart-pop 260ms ease-out"
                            : "none",
                        }}
                      >
                        <path
                          d="M20.7 5.3c-1.8-1.9-4.7-1.9-6.5 0L12 7.6 9.8 5.3c-1.8-1.9-4.7-1.9-6.5 0-1.8 1.9-1.8 5 0 6.9L12 21l8.7-8.8c1.8-1.9 1.8-5 0-6.9Z"
                          fill={
                            topFiveCurtidoPorMim
                              ? "var(--historietas-perfil-danger, #EF4444)"
                              : "none"
                          }
                          stroke={
                            topFiveCurtidoPorMim
                              ? "var(--historietas-perfil-danger, #EF4444)"
                              : "#FFFFFF"
                          }
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                        <span style={authorHighlightsLikeCountStyle}>{compactarNumeroPerfilAutor(topFiveCurtidasTotal)}</span>
                      </button>
                    )
                  )}
                </div>
              </div>

              {obrasEmDestaque.length === 0 ? (
                podeEditarPerfil ? (
                  <p
                    style={{
                      ...emptyTextStyle,
                      textAlign: "center",
                      fontWeight: 800,
                    }}
                  >
                    Monte seu TOP 5 para destacar suas obras favoritas.
                  </p>
                ) : (
                  <p
                    style={{
                      ...emptyTextStyle,
                      textAlign: "center",
                      fontWeight: 800,
                    }}
                  >
                    {`${perfilParaMostrar.nome} nao montou top 5`}
                  </p>
                )
              ) : (
                <div style={isDesktop ? desktopAuthorHighlightsListStyle : authorHighlightsListStyle}>
                  {obrasEmDestaque.map((obra) => {
                    const obraHref =
                      obra.link || `/obra/${obra.slug || criarSlugBase(obra.titulo)}`;
                    return (
                      <Link
                        key={`destaque-${obra.id}`}
                        href={obraHref}
                        style={authorHighlightItemStyle}
                        aria-label={obra.titulo}
                      >
                        <div style={criarCapaDestaquePerfilAutor(obra.capa)} />
                      </Link>
                    );
                  })}
                </div>
              )}
          </section>
        )}

        {autenticacaoCarregada &&
          autorPodeReceberAvaliacao &&
          !perfilPertenceAoUsuario && (
          <section
            style={isDesktop ? desktopAuthorRatingBoxStyle : authorRatingBoxStyle}
            aria-label="Avaliação do autor"
          >
            <div style={authorRatingHeaderStyle}>
              <span style={authorRatingTitleStyle}>AVALIE ESTE AUTOR</span>
            </div>

            <div style={authorRatingStarsRowStyle}>
              {NOTAS_AVALIACAO_AUTOR.map((estrela) => {
                const preenchimentoEstrela = obterPreenchimentoEstrelaAutor(
                  estrela,
                  avaliacaoAutor.minhaNota,
                );
                const proximaNota = obterProximaNotaAvaliacaoAutor(
                  estrela,
                  avaliacaoAutor.minhaNota,
                );

                return (
                  <button
                    key={`avaliacao-autor-${estrela}`}
                    type="button"
                    onClick={() => void avaliarAutor(proximaNota)}
                    style={
                      preenchimentoEstrela === "0%"
                        ? authorRatingStarButtonStyle
                        : authorRatingStarActiveStyle
                    }
                    aria-label={`Avaliar autor com ${proximaNota
                      .toString()
                      .replace(".", ",")} estrela${proximaNota === 1 ? "" : "s"}`}
                  >
                    <span style={authorRatingStarVisualStyle} aria-hidden="true">
                      <span style={authorRatingStarBaseStyle}>★</span>
                      <span
                        style={{
                          ...authorRatingStarFillStyle,
                          width: preenchimentoEstrela,
                        }}
                      >
                        ★
                      </span>
                    </span>
                  </button>
                );
              })}
            </div>
          </section>
        )}

        {autenticacaoCarregada &&
          perfilUsaAvaliacaoDiario &&
          !perfilPertenceAoUsuario &&
          avaliacaoDiario.visivel &&
          avaliacaoDiario.podeAvaliar && (
            <section
              style={isDesktop ? desktopAuthorRatingBoxStyle : authorRatingBoxStyle}
              aria-label="Avaliação do Diário"
            >
              <div style={authorRatingHeaderStyle}>
                <span style={authorRatingTitleStyle}>AVALIE ESTE DIÁRIO</span>
              </div>

              <div style={authorRatingStarsRowStyle}>
                {NOTAS_AVALIACAO_AUTOR.map((estrela) => {
                  const preenchimentoEstrela = obterPreenchimentoEstrelaAutor(
                    estrela,
                    avaliacaoDiario.minhaNota,
                  );
                  const proximaNota = obterProximaNotaAvaliacaoAutor(
                    estrela,
                    avaliacaoDiario.minhaNota,
                  );

                  return (
                    <button
                      key={`avaliacao-diario-perfil-${estrela}`}
                      type="button"
                      onClick={() => void avaliarDiarioPerfil(proximaNota)}
                      disabled={avaliacaoDiario.salvando}
                      style={{
                        ...(preenchimentoEstrela === "0%"
                          ? authorRatingStarButtonStyle
                          : authorRatingStarActiveStyle),
                        opacity: avaliacaoDiario.salvando ? 0.58 : 1,
                      }}
                      aria-label={`Avaliar Diário com ${proximaNota
                        .toString()
                        .replace(".", ",")} estrela${proximaNota === 1 ? "" : "s"}`}
                    >
                      <span style={authorRatingStarVisualStyle} aria-hidden="true">
                        <span style={authorRatingStarBaseStyle}>★</span>
                        <span
                          style={{
                            ...authorRatingStarFillStyle,
                            width: preenchimentoEstrela,
                          }}
                        >
                          ★
                        </span>
                      </span>
                    </button>
                  );
                })}
              </div>
            </section>
          )}

        {totalAbasPerfilVisiveis > 0 && (
          <div
            role="tablist"
            style={{
              ...profileTabsStyle,
              gridTemplateColumns: `repeat(${totalAbasPerfilVisiveis}, minmax(0, 1fr))`,
            }}
            aria-label="Seções do perfil"
          >
            {obrasPerfilVisivel && (
              <button
                type="button"
                onClick={() => selecionarAbaPerfil("obras")}
                style={
                  abaPerfil === "obras"
                    ? profileTabActiveStyle
                    : profileTabStyle
                }
              >
                Obras
              </button>
            )}

            {diarioPerfilVisivel && (
              <button
                type="button"
                onClick={() => selecionarAbaPerfil("diario")}
                style={
                  abaPerfil === "diario"
                    ? profileTabActiveStyle
                    : profileTabStyle
                }
              >
                Diário
              </button>
            )}

            {comunidadePerfilVisivel && (
              <button
                type="button"
                onClick={() => selecionarAbaPerfil("comunidade")}
                style={
                  abaPerfil === "comunidade"
                    ? profileTabActiveStyle
                    : profileTabStyle
                }
              >
                Comunidade
              </button>
            )}

            {sobrePerfilVisivel && (
              <button
                type="button"
                onClick={() => selecionarAbaPerfil("sobre")}
                style={
                  abaPerfil === "sobre"
                    ? profileTabActiveStyle
                    : profileTabStyle
                }
              >
                Sobre
              </button>
            )}

            {bibliotecaPerfilVisivel && (
              <button
                type="button"
                onClick={() => selecionarAbaPerfil("biblioteca")}
                style={
                  abaPerfil === "biblioteca"
                    ? profileTabActiveStyle
                    : profileTabStyle
                }
              >
                Biblioteca
              </button>
            )}

          </div>
        )}

        {conteudoPrivadoBloqueado && (
          <section
            style={privateProfileNoticeStyle}
            aria-label="Conteúdo privado"
          >
            <span style={privateProfileLockStyle} aria-hidden="true">
              🔒
            </span>
            <div style={privateProfileNoticeTextBlockStyle}>
              <strong style={privateProfileNoticeTitleStyle}>
                {perfilBloqueadoEntreUsuarios
                  ? "Perfil bloqueado"
                  : "Conteúdo privado"}
              </strong>
              <p style={privateProfileNoticeTextStyle}>
                {perfilBloqueadoEntreUsuarios
                  ? "O conteúdo deste perfil está oculto porque existe um bloqueio entre vocês."
                  : "Este autor manteve todas as seções do perfil privadas."}
              </p>
            </div>
          </section>
        )}

        {abaPerfil === "biblioteca" && bibliotecaPerfilVisivel && (
          <section
            style={
              isDesktop
                ? desktopProfileLibrarySectionStyle
                : profileLibrarySectionStyle
            }
          >
            <div
              style={
                isDesktop
                  ? desktopProfileLibraryTabsStyle
                  : profileLibraryTabsStyle
              }
            >
              {[
                ["tudo", "Tudo"],
                ["quero-ler", "Quero ler"],
                ["favoritas", "Na lista"],
                ["salvos", "Salvos"],
                ["lendo-agora", "Lendo"],
                ["concluidas", "Concluídas"],
                ["historico", "Histórico"],
              ].map(([valor, rotulo]) => (
                <button
                  key={valor}
                  type="button"
                  onClick={() => setAbaBibliotecaPerfil(valor as AbaBibliotecaPerfil)}
                  style={
                    abaBibliotecaPerfil === valor
                      ? profileLibraryTabActiveStyle
                      : profileLibraryTabStyle
                  }
                >
                  {rotulo}
                </button>
              ))}
            </div>

            {diarioPerfil.carregando ? (
              <LoadingSpinner label="Carregando biblioteca" compacto />
            ) : itensBibliotecaAtivos.length === 0 ? (
              <div style={emptyMiniBoxStyle}>
                Sua Biblioteca ainda não tem itens em {rotuloBibliotecaAtiva}.
              </div>
            ) : (
              <div
                style={
                  isDesktop
                    ? desktopProfileWorksGridStyle
                    : profileWorksGridStyle
                }
              >
                {itensBibliotecaAtivos.map((item) =>
                  renderizarItemBibliotecaPerfil(item),
                )}
              </div>
            )}
          </section>
        )}

        {abaPerfil === "diario" && diarioPerfilVisivel && (
          <section style={isDesktop ? desktopDiaryBoxStyle : diaryBoxStyle}>
            <div style={diaryTitleToolbarStyle}>
              <h2 style={diaryMainTitleStyle}>
                {podeEditarPerfil
                  ? "Meu Diário"
                  : `Diário de ${perfilParaMostrar.nome}`}
              </h2>

              <Link
                href={`/listas?modo=perfil&origem=diario&categoria=tudo${
                  perfilParaMostrar?.autorId.trim()
                    ? `&usuario=${encodeURIComponent(
                        perfilParaMostrar.autorId.trim(),
                      )}`
                    : ""
                }`}
                style={diaryMainReadingLinkStyle}
                aria-label="Abrir tudo na página Listas"
                title="Ver tudo"
              >
                +
              </Link>
            </div>

            <section style={diarySummarySectionStyle}>
              {diarioPerfil.carregando ? (
                <LoadingSpinner label="Carregando diário" compacto />
              ) : itensDiarioTudo.length === 0 ? (
                <div style={diaryEmptyStateStyle}>
                  {podeEditarPerfil
                    ? "Suas obras e atividades de leitura aparecerão aqui."
                    : "Este perfil ainda não compartilhou itens no Diário."}
                </div>
              ) : (
                <div
                  style={
                    isDesktop
                      ? desktopDiarySummaryGridStyle
                      : diarySummaryGridStyle
                  }
                >
                  {itensDiarioTudo.map((item) =>
                    renderizarMiniCardDiarioPerfil(item),
                  )}
                </div>
              )}
            </section>
          </section>
        )}

        {abaPerfil === "comunidade" && comunidadePerfilVisivel && (
          <section
            style={
              isDesktop
                ? desktopAuthorCommunityBoxStyle
                : authorCommunityBoxStyle
            }
          >
            <div style={authorCommunityIntroStyle}>
              <h2 style={authorCommunityTitleStyle}>
                {language === "en"
                  ? `${perfilParaMostrar.nome}'s Community`
                  : language === "es"
                    ? `Comunidad de ${perfilParaMostrar.nome}`
                    : `Comunidade de ${perfilParaMostrar.nome}`}
              </h2>
            </div>

            {comunidadePerfil.carregando ? (
              <LoadingSpinner
                label="Carregando publicações da Comunidade"
                compacto
              />
            ) : (
              <>
                <div
                  style={
                    isDesktop
                      ? desktopAuthorCommunityGridStyle
                      : authorCommunityGridStyle
                  }
                >
                  <Link
                    href={comunidadeAutorHref}
                    style={authorCommunityCardStyle}
                    aria-label={`Abrir publicações de ${perfilParaMostrar.nome} na comunidade`}
                  >
                    <strong style={authorCommunityCardNumberStyle}>
                      {compactarNumeroPerfilAutor(
                        comunidadePerfil.totalPublicacoes,
                      )}
                    </strong>
                    <span style={authorCommunityCardTitleStyle}>
                      PUBLICAÇÕES
                    </span>
                    <span style={authorCommunityCardTextStyle}>
                      posts do perfil
                    </span>
                  </Link>

                  <Link
                    href={comunidadeAutorTeoriasHref}
                    style={authorCommunityCardStyle}
                    aria-label={`Abrir teorias de ${perfilParaMostrar.nome} na comunidade`}
                  >
                    <strong style={authorCommunityCardNumberStyle}>
                      {compactarNumeroPerfilAutor(comunidadePerfil.totalTeorias)}
                    </strong>
                    <span style={authorCommunityCardTitleStyle}>TEORIAS</span>
                    <span style={authorCommunityCardTextStyle}>discussões</span>
                  </Link>

                  <Link
                    href={comunidadeAutorReviewsHref}
                    style={authorCommunityCardStyle}
                    aria-label={`Abrir reviews de ${perfilParaMostrar.nome} na comunidade`}
                  >
                    <strong style={authorCommunityCardNumberStyle}>
                      {compactarNumeroPerfilAutor(comunidadePerfil.totalReviews)}
                    </strong>
                    <span style={authorCommunityCardTitleStyle}>REVIEWS</span>
                    <span style={authorCommunityCardTextStyle}>opiniões</span>
                  </Link>
                </div>

                {comunidadePerfil.erro ? (
                  <div style={authorCommunityPreviewStyle}>
                    <span style={authorCommunityPreviewIconStyle}>!</span>

                    <div style={authorCommunityPreviewTextBlockStyle}>
                      <strong style={authorCommunityPreviewTitleStyle}>
                        Comunidade indisponível
                      </strong>
                      <p style={authorCommunityPreviewTextStyle}>
                        {comunidadePerfil.erro}
                      </p>
                    </div>
                  </div>
                ) : comunidadePerfil.publicacoesRecentes.length === 0 ? (
                  <div style={authorCommunityPreviewStyle}>
                    <span style={authorCommunityPreviewIconStyle}>💬</span>

                    <div style={authorCommunityPreviewTextBlockStyle}>
                      <strong style={authorCommunityPreviewTitleStyle}>
                        {podeEditarPerfil
                          ? "Sua comunidade ainda está vazia"
                          : "Nenhuma publicação por aqui ainda"}
                      </strong>

                      <p style={authorCommunityPreviewTextStyle}>
                        {podeEditarPerfil
                          ? "Publique avisos, bastidores, teorias e chamadas para aproximar leitores das suas obras."
                          : `Quando ${perfilParaMostrar.nome} publicar posts, teorias ou reviews, eles aparecerão nesta área.`}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div style={authorCommunityPostsBlockStyle}>
                    <strong style={authorCommunityPostsTitleStyle}>
                      Publicações recentes
                    </strong>

                    <div
                      style={
                        isDesktop
                          ? desktopAuthorCommunityPostsListStyle
                          : authorCommunityPostsListStyle
                      }
                    >
                      {comunidadePerfil.publicacoesRecentes.map(
                        (publicacao) => (
                          <article
                            key={publicacao.id}
                            style={authorCommunityPostWrapperStyle}
                          >
                            <Link
                              href={criarHrefPublicacaoComunidadePerfil(
                                publicacao.id,
                              )}
                              style={{
                                ...authorCommunityPostStyle,
                                paddingBottom: podeEditarPerfil
                                  ? "10px"
                                  : "42px",
                              }}
                              aria-label={`Abrir ${publicacao.tipoPublicacao} na Comunidade`}
                            >
                              <span style={authorCommunityPostHeaderStyle}>
                                <strong style={authorCommunityPostTypeStyle}>
                                  {publicacao.tipoPublicacao}
                                </strong>
                                <span style={authorCommunityPostDateStyle}>
                                  {dataDiarioPerfilFormatada(
                                    publicacao.criadoEm,
                                  )}
                                </span>
                              </span>

                              <span style={authorCommunityPostBodyStyle}>
                                <span
                                  data-historietas-user-content="true"
                                  style={authorCommunityPostTextStyle}
                                >
                                  {criarResumoPublicacaoComunidadePerfil(
                                    publicacao,
                                  )}
                                </span>

                                {analisarEnquetePublicacaoComunidadePerfil(
                                  publicacao,
                                ).totalOpcoes >= 2 && (
                                  <span
                                    style={authorCommunityPostPollInfoStyle}
                                  >
                                    Enquete
                                    <span aria-hidden="true">•</span>
                                    {
                                      analisarEnquetePublicacaoComunidadePerfil(
                                        publicacao,
                                      ).totalOpcoes
                                    }{" "}
                                    opções
                                  </span>
                                )}
                              </span>

                              {publicacao.obraRelacionada && (
                                <span style={authorCommunityPostWorkStyle}>
                                  <span>OBRA</span>
                                  <strong data-historietas-user-content="true">
                                    {publicacao.obraRelacionada}
                                  </strong>
                                </span>
                              )}
                            </Link>

                            {!podeEditarPerfil && (
                              <button
                                type="button"
                                style={authorCommunityPostReportButtonStyle}
                                onClick={() =>
                                  abrirDenunciaConteudoPerfil(
                                    "post",
                                    publicacao.id,
                                    criarResumoPublicacaoComunidadePerfil(
                                      publicacao,
                                    ),
                                  )
                                }
                                aria-label="Denunciar publicação"
                              >
                                Denunciar
                              </button>
                            )}
                          </article>
                        ),
                      )}
                    </div>
                  </div>
                )}
              </>
            )}
          </section>
        )}

        {abaPerfil === "sobre" && sobrePerfilVisivel && (
          <section style={profileAboutBoxStyle}>
            <div style={profileAboutHeroStyle}>
              <h2 style={profileAboutTitleStyle}>
                Sobre {perfilParaMostrar.nome}
              </h2>

              <div style={profileAboutTextRowStyle}>
                <p
                  data-historietas-user-content={
                    bioSobreAutorEhPadrao ? undefined : "true"
                  }
                  style={profileAboutTextStyle}
                >
                  {bioSobreAutorExibido}
                </p>

                {podeEditarPerfil && (
                  <button
                    type="button"
                    onClick={() => setEditorSobreAberto((aberto) => !aberto)}
                    style={profileAboutEditButtonStyle}
                    aria-label="Editar sinopse do Sobre"
                  >
                    ✎
                  </button>
                )}
              </div>

              {podeEditarPerfil && editorSobreAberto && (
                <div style={profileAboutEditorStyle}>
                  <textarea
                    value={perfilSalvoAutor.sobreBio}
                    onChange={(event) => atualizarBioSobreAutor(event.target.value)}
                    placeholder={bioAutor}
                    maxLength={SOBRE_BIO_MAX_LENGTH}
                    style={profileAboutTextareaStyle}
                  />

                  <span style={profileAboutCounterStyle}>
                    {caracteresRestantesBioSobre} caracteres
                  </span>
                </div>
              )}
            </div>

            <div style={profileAboutContentGridStyle}>
              <section style={profileAboutPanelStyle}>
                <strong style={profileAboutPanelTitleStyle}>Especialidades</strong>

                <div style={profileAboutChipsStyle}>
                  {(generosPrincipaisPerfil.length > 0
                    ? generosPrincipaisPerfil
                    : ["Histórias variadas"]
                  ).map((genero) => (
                    <span key={`sobre-genero-${genero}`} style={profileAboutChipStyle}>
                      {genero}
                    </span>
                  ))}
                </div>
              </section>

              <section style={profileAboutPanelStyle}>
                <strong style={profileAboutPanelTitleStyle}>Números do perfil</strong>

                <div style={profileAboutMetricsGridStyle}>
                  <div style={profileAboutMetricCardStyle}>
                    <strong style={profileAboutMetricNumberStyle}>
                      {compactarNumeroPerfilAutor(perfilParaMostrar.totalPublicadas)}
                    </strong>
                    <span style={profileAboutMetricLabelStyle}>publicadas</span>
                  </div>

                  <div style={profileAboutMetricCardStyle}>
                    <strong style={profileAboutMetricNumberStyle}>
                      {compactarNumeroPerfilAutor(perfilParaMostrar.totalCapitulos)}
                    </strong>
                    <span style={profileAboutMetricLabelStyle}>capítulos</span>
                  </div>

                  <div style={profileAboutMetricCardStyle}>
                    <strong style={profileAboutMetricNumberStyle}>
                      {compactarNumeroPerfilAutor(perfilParaMostrar.totalCurtidas)}
                    </strong>
                    <span style={profileAboutMetricLabelStyle}>curtidas</span>
                  </div>

                  <div style={profileAboutMetricCardStyle}>
                    <strong style={profileAboutMetricNumberStyle}>
                      {compactarNumeroPerfilAutor(totalVisualizacoesPerfil)}
                    </strong>
                    <span style={profileAboutMetricLabelStyle}>visualizações</span>
                  </div>
                </div>
              </section>

              <section style={profileAboutPanelStyle}>
                <strong style={profileAboutPanelTitleStyle}>Atividade</strong>

                <div style={profileAboutRowsStyle}>
                  <span style={profileAboutRowStyle}>
                    obras no perfil
                    <strong>{perfilParaMostrar.obras.length}</strong>
                  </span>
                  <span style={profileAboutRowStyle}>
                    rascunhos em desenvolvimento
                    <strong>{totalRascunhosPerfil}</strong>
                  </span>
                  <span style={profileAboutRowStyle}>
                    comentários recebidos
                    <strong>{perfilParaMostrar.totalComentarios}</strong>
                  </span>
                  <span style={profileAboutRowStyle}>
                    concluídas por leitores
                    <strong>{obrasConcluidasPerfilTotal}</strong>
                  </span>
                  {totalObrasSemCapitulosPerfil > 0 && (
                    <span style={profileAboutRowStyle}>
                      sem capítulos ainda
                      <strong>{totalObrasSemCapitulosPerfil}</strong>
                    </span>
                  )}
                </div>
              </section>
            </div>

            <p style={profileAboutMemberSinceStyle}>
              Na Historietas desde {entradaHistorietasPerfil}
            </p>

            {atividadesPerfilVisivel &&
              renderizarAtividadeRecenteSobrePerfil()}
          </section>
        )}

        {abaPerfil === "obras" && obrasPerfilVisivel && (
          <section style={profileWorksSectionStyle}>
            {obrasDoPerfilFiltradas.length === 0 ? (
              <div style={emptyMiniBoxStyle}>
                {perfilParaMostrar.obras.length === 0
                  ? podeEditarPerfil
                    ? "Você ainda não publicou obras. Seu perfil continua ativo como leitor, com Diário e Comunidade."
                    : "Este perfil ainda não publicou obras. O Diário e a Comunidade continuam disponíveis."
                  : "Nenhuma obra encontrada."}
              </div>
            ) : (
              <div
                style={
                  isDesktop
                    ? desktopProfileWorksGridStyle
                    : profileWorksGridStyle
                }
              >
                {obrasDoPerfilFiltradas.map((obra) => {
                  const obraHref =
                    obra.link ||
                    `/obra/${obra.slug || criarSlugBase(obra.titulo)}`;
                  const ultimoCapitulo =
                    encontrarCapituloParaContinuar(obra) ||
                    obra.capitulos[obra.capitulos.length - 1] ||
                    null;
                  const numeroUltimoCapitulo = ultimoCapitulo
                    ? obra.capitulos.findIndex(
                        (capitulo) => capitulo.id === ultimoCapitulo.id,
                      ) + 1
                    : 0;
                  const capituloHref = ultimoCapitulo
                    ? criarHrefLeituraCapituloPerfilAutor(
                        obra,
                        ultimoCapitulo,
                        numeroUltimoCapitulo || 1,
                      )
                    : "";
                  const obraFavorita = colecaoTemObraPerfilBiblioteca(obrasFavoritas, obra);
                  const obraConcluida = colecaoTemObraPerfilBiblioteca(obrasConcluidas, obra);
                  const totalCurtidas = obterTotalCurtidasObraPerfilAutor(
                    obra,
                    totaisInteracoesObras,
                  );
                  const totalComentarios = obterTotalComentariosObraPerfilAutor(
                    obra,
                    totaisInteracoesObras,
                  );
                  const visualizacoesObra = compactarNumeroPerfilAutor(
                    obra.visualizacoes,
                  );
                  const menuObraAberto = obraMenuAbertoId === obra.id;

                  return (
                    <article key={obra.id} style={profileWorkCardStyle}>
                      <Link href={obraHref} style={profileWorkCoverLinkStyle}>
                        <div
                          style={criarCapaGridPerfilAutor(obra.capa, isDesktop)}
                        >
                          <div style={profileWorkCoverOverlayStyle}>
                            <strong data-historietas-user-content="true" style={profileWorkCoverTitleStyle}>
                              {obra.titulo}
                            </strong>

                            <span style={diaryCardCoverMetaStyle}>
                              <span>👁 {visualizacoesObra}</span>
                              <span>
                                <span style={diaryCardHeartMetaStyle}>❤️</span>{" "}
                                {totalCurtidas}
                              </span>
                              <span>
                                <span style={diaryCardCommentMetaStyle}>💬</span>{" "}
                                {totalComentarios}
                              </span>
                            </span>
                          </div>
                        </div>
                      </Link>

                      <div style={profileWorkMenuAnchorStyle}>
                        <button
                          type="button"
                          onClick={() =>
                            setObraMenuAbertoId((idAtual) =>
                              idAtual === obra.id ? "" : obra.id,
                            )
                          }
                          style={profileWorkDotsButtonStyle}
                          aria-label={`Abrir opções de ${obra.titulo}`}
                          aria-expanded={menuObraAberto}
                        >
                          ⋮
                        </button>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
          </section>
        )}

        {obraMenuAberta &&
          (() => {
            const obra = obraMenuAberta;
            const ultimoCapitulo =
              encontrarCapituloParaContinuar(obra) ||
              obra.capitulos[obra.capitulos.length - 1] ||
              null;
            const numeroUltimoCapitulo = ultimoCapitulo
              ? obra.capitulos.findIndex(
                  (capitulo) => capitulo.id === ultimoCapitulo.id,
                ) + 1
              : 0;
            const capituloHref = ultimoCapitulo
              ? criarHrefLeituraCapituloPerfilAutor(
                  obra,
                  ultimoCapitulo,
                  numeroUltimoCapitulo || 1,
                )
              : "";
            const obraFavorita = colecaoTemObraPerfilBiblioteca(obrasFavoritas, obra);
            const obraConcluida = colecaoTemObraPerfilBiblioteca(obrasConcluidas, obra);
            const totalCurtidas = obterTotalCurtidasObraPerfilAutor(
              obra,
              totaisInteracoesObras,
            );
            const totalComentarios = obterTotalComentariosObraPerfilAutor(
              obra,
              totaisInteracoesObras,
            );
            const totalSalvos = obterTotalSalvosObraPerfilAutor(
              obra,
              totaisInteracoesObras,
            );
            const visualizacoesObra = compactarNumeroPerfilAutor(
              obra.visualizacoes,
            );
            const formatoObra = formatarFormatoPerfilAutor(obra.formato);
            const tagPrincipalObra = obterTagPrincipalPerfilAutor(obra);
            const metaObraSheet = [
              formatarGeneroPerfilAutor(obra.genero),
              formatoObra,
              tagPrincipalObra,
              mostrarClassificacao(obra) ? obra.classificacaoIndicativa : "",
            ]
              .filter(Boolean)
              .map((item) => traduzirTextoPerfilAutor(item, language))
              .join(" • ");
            const metricasObraSheet = [
              `👁 ${visualizacoesObra}`,
              `❤️ ${totalCurtidas}`,
              `💬 ${totalComentarios}`,
              `🔖 ${totalSalvos}`,
              `📚 ${obra.capitulos.length}`,
            ]
              .filter(Boolean)
              .join(" • ");

            return (
              <div
                style={workActionSheetOverlayStyle}
                role="presentation"
                onClick={() => setObraMenuAbertoId("")}
              >
                <section
                  style={workActionSheetStyle}
                  role="dialog"
                  aria-label={`Ações da obra ${obra.titulo}`}
                  onClick={(event) => event.stopPropagation()}
                >
                  <div style={workActionSheetHandleStyle} aria-hidden="true" />

                  <div style={workActionSheetHeaderStyle}>
                    <div style={workActionSheetTextBlockStyle}>
                      <strong data-historietas-user-content="true" style={workActionSheetTitleStyle}>
                        {obra.titulo}
                      </strong>

                      <span style={workActionSheetAuthorStyle}>
                        Por {obra.autor}
                      </span>

                      <span style={workActionSheetMetaStyle}>
                        {metaObraSheet}
                      </span>

                      <span style={workActionSheetMetricsStyle}>
                        {metricasObraSheet}
                      </span>
                    </div>
                  </div>

                  <div style={workActionSheetActionsStyle}>
                    {ultimoCapitulo && (
                      <Link
                        href={capituloHref}
                        onClick={() => setObraMenuAbertoId("")}
                        style={workActionSheetItemStyle}
                      >
                        Ler
                      </Link>
                    )}

                    {!podeEditarPerfil && (
                      <>
                        <button
                          type="button"
                          onClick={() => {
                            setObraMenuAbertoId("");
                            void alternarFavoritoObra(obra.id);
                          }}
                          style={
                            obraFavorita
                              ? workActionSheetItemActiveStyle
                              : workActionSheetItemStyle
                          }
                        >
                          <span>
                            {obraFavorita
                              ? "Remover da lista"
                              : "Adicionar à lista"}
                          </span>
                          <span style={criarProfileSelectionDotStyle(obraFavorita)}>
                            {obraFavorita ? "✓" : ""}
                          </span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setObraMenuAbertoId("");
                            void alternarConcluidoObra(obra.id);
                          }}
                          style={
                            obraConcluida
                              ? workActionSheetItemActiveStyle
                              : workActionSheetItemStyle
                          }
                        >
                          <span>
                            {obraConcluida
                              ? "Marcar como não concluída"
                              : "Concluir"}
                          </span>
                          <span style={criarProfileSelectionDotStyle(obraConcluida)}>
                            {obraConcluida ? "✓" : ""}
                          </span>
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            abrirDenunciaConteudoPerfil(
                              "obra",
                              obra.id,
                              obra.titulo,
                            )
                          }
                          style={workActionSheetDangerItemStyle}
                        >
                          Denunciar obra
                        </button>
                      </>
                    )}

                    <button
                      type="button"
                      onClick={() => void compartilharObraPerfilAutor(obra)}
                      style={workActionSheetItemStyle}
                    >
                      Compartilhar
                    </button>
                  </div>
                </section>
              </div>
            );
          })()}

        {bibliotecaMenuAberto &&
          (() => {
            const item = bibliotecaMenuAberto;
            const obra = item.obra;
            const obraHref =
              obra.link || `/obra/${obra.slug || criarSlugBase(obra.titulo)}`;
            const capituloHref = item.capitulo
              ? criarHrefLeituraCapituloPerfilAutor(
                  obra,
                  item.capitulo,
                  item.numeroCapitulo || 1,
                )
              : obraHref;
            const obraFavorita = colecaoTemObraPerfilBiblioteca(
              obrasFavoritas,
              obra,
            );
            const obraConcluida = colecaoTemObraPerfilBiblioteca(
              obrasConcluidas,
              obra,
            );
            const obraNoQueroLer = colecaoTemObraPerfilBiblioteca(
              obrasSeguidasBiblioteca,
              obra,
            );
            const totalCapitulos = obra.capitulos.length;
            const progresso = Math.max(
              0,
              Math.min(100, Math.round(obra.progressoLeitura || 0)),
            );
            const metaSheet = `${
              item.tipoDiario === "lendo"
                ? "Lendo"
                : item.tipoDiario === "favorita"
                  ? "Favorita"
                  : item.tipoDiario === "concluida"
                    ? "Concluída"
                    : item.tipoDiario === "quero_ler"
                      ? "Quero ler"
                      : "Biblioteca"
            } • ${
              item.capitulo
                ? `Capítulo ${item.numeroCapitulo || 1} de ${totalCapitulos || 1}`
                : totalCapitulos > 0
                  ? `${totalCapitulos} ${totalCapitulos === 1 ? "capítulo" : "capítulos"}`
                  : "Obra"
            } • ${progresso}% concluído`;

            return (
              <div
                style={workActionSheetOverlayStyle}
                role="presentation"
                onClick={() => setBibliotecaMenuAbertoChave("")}
              >
                <section
                  style={workActionSheetStyle}
                  role="dialog"
                  aria-label={`Ações da Biblioteca ${obra.titulo}`}
                  onClick={(event) => event.stopPropagation()}
                >
                  <div style={workActionSheetHandleStyle} aria-hidden="true" />

                  <div style={workActionSheetHeaderStyle}>
                    <div style={workActionSheetTextBlockStyle}>
                      <strong data-historietas-user-content="true" style={workActionSheetTitleStyle}>
                        {obra.titulo}
                      </strong>
                      <span style={workActionSheetMetaStyle}>{metaSheet}</span>
                    </div>
                  </div>

                  <div style={workActionSheetActionsStyle}>
                    <Link
                      href={capituloHref}
                      onClick={() => setBibliotecaMenuAbertoChave("")}
                      style={workActionSheetItemStyle}
                    >
                      Ler capítulo
                    </Link>

                    <button
                      type="button"
                      onClick={() => {
                        setBibliotecaMenuAbertoChave("");
                        void alternarObraSeguindoBibliotecaPerfil(
                          obra,
                          !obraNoQueroLer,
                        );
                      }}
                      style={
                        obraNoQueroLer
                          ? workActionSheetItemActiveStyle
                          : workActionSheetItemStyle
                      }
                    >
                      <span>
                        {obraNoQueroLer ? "Remover do Quero ler" : "Quero ler"}
                      </span>
                      <span style={criarProfileSelectionDotStyle(obraNoQueroLer)}>
                        {obraNoQueroLer ? "✓" : ""}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setBibliotecaMenuAbertoChave("");
                        void alternarFavoritoObra(obra.id);
                      }}
                      style={
                        obraFavorita
                          ? workActionSheetItemActiveStyle
                          : workActionSheetItemStyle
                      }
                    >
                      <span>
                        {obraFavorita ? "Remover favorita" : "Favoritar"}
                      </span>
                      <span style={criarProfileSelectionDotStyle(obraFavorita)}>
                        {obraFavorita ? "✓" : ""}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setBibliotecaMenuAbertoChave("");
                        void alternarConcluidoObra(obra.id);
                      }}
                      style={
                        obraConcluida
                          ? workActionSheetItemActiveStyle
                          : workActionSheetItemStyle
                      }
                    >
                      <span>
                        {obraConcluida ? "Marcar como não concluída" : "Concluir"}
                      </span>
                      <span style={criarProfileSelectionDotStyle(obraConcluida)}>
                        {obraConcluida ? "✓" : ""}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setBibliotecaMenuAbertoChave("");
                        void removerItemBibliotecaPerfil(item);
                      }}
                      style={workActionSheetItemStyle}
                    >
                      {abaBibliotecaPerfil === "lendo-agora"
                        ? "Parar leitura"
                        : abaBibliotecaPerfil === "historico"
                          ? "Limpar histórico"
                          : "Remover"}
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setBibliotecaMenuAbertoChave("");
                        void compartilharObraPerfilAutor(obra);
                      }}
                      style={workActionSheetItemStyle}
                    >
                      Compartilhar
                    </button>
                  </div>
                </section>
              </div>
            );
          })()}

      </section>
    </main>
  );
}

export default function PerfilAutorPage() {
  return (
    <>
      <PerfilAutorLanguageBridge />
      <Suspense
      fallback={
        <main style={pageStyle}>
          <style>{`${historietasThemeCss}${perfilAutorThemeCss}`}</style>
          <LoadingSpinner label="Carregando perfil" />
        </main>
      }
    >
      <PerfilAutorPageContent />
      </Suspense>
    </>
  );
}

const workActionSheetOverlayStyle: CSSProperties = {
  position: "fixed",
  left: 0,
  right: 0,
  top: 0,
  bottom: 0,
  height: "100dvh",
  zIndex: 9998,
  display: "flex",
  alignItems: "flex-end",
  justifyContent: "center",
  background: "rgba(0,0,0,0.68)",
  padding: 0,
  boxSizing: "border-box",
  overscrollBehavior: "none",
  touchAction: "none",
};

const workActionSheetStyle: CSSProperties = {
  position: "fixed",
  left: "50%",
  bottom: 0,
  transform: "translateX(-50%)",
  width: "min(820px, 100%)",
  maxHeight: "calc(100dvh - 190px)",
  overflowX: "hidden",
  overflowY: "auto",
  overscrollBehavior: "contain",
  borderRadius: "24px 24px 0 0",
  background: "var(--historietas-perfil-bg-page, #070212)",
  border: "none",
  borderBottom: "0",
  boxShadow: "0 -18px 50px rgba(0,0,0,0.38)",
  padding: "8px 0 calc(18px + env(safe-area-inset-bottom))",
  display: "grid",
  gap: 0,
  boxSizing: "border-box",
  touchAction: "none",
};

const workActionSheetHandleStyle: CSSProperties = {
  width: "72px",
  height: "5px",
  borderRadius: "999px",
  background: "rgba(244,244,245,0.62)",
  justifySelf: "center",
  margin: "0 auto 12px",
};

const workActionSheetHeaderStyle: CSSProperties = {
  display: "grid",
  justifyItems: "center",
  gap: "4px",
  minWidth: 0,
  padding: "0 24px 12px",
  boxSizing: "border-box",
  borderBottom: "none",
};

const workActionSheetTextBlockStyle: CSSProperties = {
  display: "grid",
  justifyItems: "center",
  gap: "4px",
  minWidth: 0,
  width: "100%",
};

const workActionSheetTitleStyle: CSSProperties = {
  color: "#FFFFFF",
  fontSize: "21px",
  fontWeight: 950,
  lineHeight: 1.1,
  letterSpacing: "-0.04em",
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
  textAlign: "center",
  maxWidth: "100%",
};

const workActionSheetAuthorStyle: CSSProperties = {
  color: "#FFFFFF",
  fontSize: "12px",
  fontWeight: 850,
  lineHeight: 1.2,
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
  textAlign: "center",
  maxWidth: "100%",
};

const workActionSheetMetaStyle: CSSProperties = {
  color: "rgba(255,255,255,0.72)",
  fontSize: "12px",
  fontWeight: 850,
  lineHeight: 1.2,
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
  textAlign: "center",
  maxWidth: "100%",
};

const workActionSheetMetricsStyle: CSSProperties = {
  ...workActionSheetMetaStyle,
  color: "#FFFFFF",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  flexWrap: "wrap",
  gap: "6px 10px",
  whiteSpace: "normal",
  overflow: "visible",
  textOverflow: "clip",
};


const workActionSheetActionsStyle: CSSProperties = {
  display: "grid",
  gap: 0,
  borderRadius: 0,
  border: "none",
  borderTop: "none",
  background: "transparent",
  overflow: "hidden",
};

function criarProfileSelectionDotStyle(ativo: boolean): CSSProperties {
  return {
    width: "23px",
    height: "23px",
    marginLeft: "auto",
    borderRadius: "999px",
    border: ativo
      ? "2px solid #FFFFFF"
      : "2.5px solid rgba(161,161,170,0.72)",
    background: ativo ? "#FFFFFF" : "transparent",
    color: ativo ? "#111111" : "transparent",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    boxSizing: "border-box",
    flex: "0 0 auto",
    fontSize: "15px",
    lineHeight: 1,
    fontWeight: 900,
  };
}

const workActionSheetItemStyle: CSSProperties = {
  appearance: "none",
  WebkitAppearance: "none",
  width: "100%",
  minHeight: "44px",
  display: "flex",
  alignItems: "center",
  justifyContent: "flex-start",
  gap: "14px",
  border: "none",
  borderBottom: "none",
  borderRadius: 0,
  background: "transparent",
  color: "#FFFFFF",
  textDecoration: "none",
  padding: "0 30px",
  fontSize: "18px",
  fontWeight: 650,
  lineHeight: 1,
  letterSpacing: "-0.035em",
  fontFamily: "inherit",
  textAlign: "left",
  cursor: "pointer",
  boxSizing: "border-box",
  whiteSpace: "nowrap",
};

const workActionSheetDangerItemStyle: CSSProperties = {
  ...workActionSheetItemStyle,
  color: "#FDA4AF",
};

const workActionSheetItemActiveStyle: CSSProperties = {
  ...workActionSheetItemStyle,
  fontWeight: 900,
  background: "transparent",
  color: "#FFFFFF",
};

const workActionSheetCancelButtonStyle: CSSProperties = {
  ...workActionSheetItemStyle,
  justifyContent: "center",
  textAlign: "center",
  background: "transparent",
  color: "rgba(255,255,255,0.58)",
};

const diarySummarySectionStyle: CSSProperties = {
  width: "100%",
  display: "grid",
  gap: "12px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const diarySummaryGridStyle: CSSProperties = {
  width: "100%",
  display: "grid",
  gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
  alignItems: "start",
  rowGap: "6px",
  columnGap: "10px",
  minWidth: 0,
  maxWidth: "100%",
  padding: "2px 0 0",
  boxSizing: "border-box",
};

const desktopDiarySummaryGridStyle: CSSProperties = {
  ...diarySummaryGridStyle,
  gridTemplateColumns: "repeat(6, minmax(0, 1fr))",
  columnGap: "12px",
  rowGap: "18px",
  padding: "4px 0 0",
};

// Teste: tipografia dos cards de obras igual à do card principal da Home.
const homeCardTitleTypographyStyle: CSSProperties = {
  fontFamily:
    'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  fontWeight: 500,
  letterSpacing: "-0.01em",
};

const homeCardMetaTypographyStyle: CSSProperties = {
  fontFamily:
    'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  fontWeight: 450,
  lineHeight: 1.25,
};

const homeCardStatsTypographyStyle: CSSProperties = {
  fontFamily:
    'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  fontWeight: 850,
};

const diarySummaryCardLinkStyle: CSSProperties = {
  display: "grid",
  gridTemplateRows: "auto auto",
  justifyItems: "center",
  alignContent: "start",
  gap: "6px",
  minWidth: 0,
  width: "100%",
  color: "var(--historietas-text-primary, #FFFFFF)",
  textDecoration: "none",
  border: "none",
  background: "transparent",
  boxSizing: "border-box",
  WebkitTapHighlightColor: "transparent",
};

const diarySummaryCoverStyle: CSSProperties = {
  width: "100%",
  aspectRatio: "3 / 4",
  borderRadius: "12px",
  overflow: "hidden",
  background:
    "linear-gradient(135deg, var(--historietas-perfil-surface, #08030F) 0%, var(--historietas-perfil-bg-deep, #04000A) 100%)",
  backgroundSize: "cover",
  backgroundPosition: "center",
  border: "none",
  boxShadow: "none",
  boxSizing: "border-box",
};

const diarySummaryCardTitleStyle: CSSProperties = {
  width: "100%",
  minWidth: 0,
  minHeight: "28px",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "10.5px",
  lineHeight: 1.3,
  ...homeCardTitleTypographyStyle,
  textAlign: "center",
  overflow: "hidden",
  display: "-webkit-box",
  WebkitBoxOrient: "vertical",
  WebkitLineClamp: 2,
  overflowWrap: "anywhere",
};

const diaryVisualCardStyle: CSSProperties = {
  display: "grid",
  gap: 0,
  minWidth: 0,
  maxWidth: "100%",
  width: "100%",
  boxSizing: "border-box",
  overflow: "visible",
  position: "relative",
  border: "0",
  borderBottom: "0",
  outline: "none",
  boxShadow: "none",
  background: "transparent",
};

const desktopDiaryVisualCardStyle: CSSProperties = {
  ...diaryVisualCardStyle,
};

const diaryVisualCoverLinkStyle: CSSProperties = {
  display: "block",
  textDecoration: "none",
  textDecorationLine: "none",
  color: "var(--historietas-text-primary, #FFFFFF)",
  minWidth: 0,
  maxWidth: "100%",
  border: "0",
  borderBottom: "0",
  outline: "none",
  boxShadow: "none",
  background: "transparent",
  width: "100%",
};


const safeTextStyle: CSSProperties = {
  overflowWrap: "anywhere",
  wordBreak: "break-word",
};


const profileLibrarySectionStyle: CSSProperties = {
  display: "grid",
  gap: "14px",
  width: "100%",
  marginTop: "14px",
  minWidth: 0,
};

const desktopProfileLibrarySectionStyle: CSSProperties = {
  ...profileLibrarySectionStyle,
  gap: "18px",
  marginTop: "18px",
};


const profileLibraryTabsStyle: CSSProperties = {
  display: "flex",
  gap: "8px",
  overflowX: "auto",
  overflowY: "hidden",
  WebkitOverflowScrolling: "touch",
  scrollbarWidth: "none",
  padding: "0 2px 4px",
  minWidth: 0,
  maxWidth: "100%",
};

const desktopProfileLibraryTabsStyle: CSSProperties = {
  ...profileLibraryTabsStyle,
  width: "100%",
  justifyContent: "center",
  alignItems: "center",
  flexWrap: "wrap",
  overflowX: "visible",
  padding: "0 0 4px",
};

const profileLibraryTabStyle: CSSProperties = {
  flex: "0 0 auto",
  minHeight: "34px",
  borderRadius: "999px",
  border: "1px solid var(--historietas-border-soft, rgba(255,255,255,0.10))",
  background:
    "var(--historietas-bg-start, var(--historietas-perfil-bg-page, #070212))",
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "10.5px",
  fontWeight: 950,
  fontFamily: "inherit",
  cursor: "pointer",
  padding: "0 12px",
  boxSizing: "border-box",
  whiteSpace: "nowrap",
};

const profileLibraryTabActiveStyle: CSSProperties = {
  ...profileLibraryTabStyle,
  background:
    "var(--historietas-bg-start, var(--historietas-perfil-bg-page, #070212))",
  color: "var(--historietas-text-primary, #FFFFFF)",
  border: "1px solid rgba(255,255,255,0.14)",
};

const profileLibraryStatsGridStyle: CSSProperties = {
  display: "flex",
  gap: "8px",
  overflowX: "auto",
  overflowY: "hidden",
  scrollSnapType: "x mandatory",
  scrollbarWidth: "none",
  WebkitOverflowScrolling: "touch",
  marginTop: "4px",
  padding: "0 2px 2px",
  maxWidth: "100%",
  minWidth: 0,
};

const desktopProfileLibraryStatsGridStyle: CSSProperties = {
  ...profileLibraryStatsGridStyle,
  justifyContent: "center",
  overflowX: "visible",
  flexWrap: "wrap",
  gap: "8px",
  padding: 0,
};

const profileLibraryStatCardStyle: CSSProperties = {
  flex: "0 0 84px",
  scrollSnapAlign: "start",
  borderRadius: "11px",
  background: "var(--historietas-perfil-deep-72, rgba(4, 0, 10, 0.72))",
  border: "1px solid rgba(255,255,255,0.06)",
  padding: "4px 4px",
  minHeight: "46px",
  display: "grid",
  gap: "1px",
  alignContent: "center",
  justifyItems: "center",
  minWidth: 0,
  overflow: "hidden",
  color: "var(--historietas-text-primary, #FFFFFF)",
  cursor: "pointer",
  fontFamily: "inherit",
  textAlign: "center",
  appearance: "none",
  boxShadow: "none",
};

const profileLibraryStatCardActiveStyle: CSSProperties = {
  ...profileLibraryStatCardStyle,
  background: "var(--historietas-perfil-surface, #08030F)",
  border: "1px solid rgba(255,255,255,0.10)",
  color: "#FFFFFF",
  boxShadow: "none",
};

const profileLibraryStatNumberStyle: CSSProperties = {
  color: "#FFFFFF",
  fontSize: "16px",
  lineHeight: 1,
  fontWeight: 950,
  textAlign: "center",
  ...safeTextStyle,
};

const profileLibraryStatLabelStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "7.2px",
  lineHeight: 1.02,
  fontWeight: 950,
  textAlign: "center",
  textTransform: "uppercase",
  letterSpacing: "0.02em",
  ...safeTextStyle,
};

const profileLibrarySummaryTitleStyle: CSSProperties = {
  margin: "14px 0 2px",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "clamp(18px, 4.4vw, 24px)",
  lineHeight: 1.08,
  fontWeight: 950,
  textAlign: "center",
  letterSpacing: "-0.04em",
  ...safeTextStyle,
};

const profileLibraryListStyle: CSSProperties = {
  marginTop: "14px",
  display: "grid",
  gap: "12px",
  width: "100%",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const profileLibraryCardStyle: CSSProperties = {
  display: "grid",
  gap: "9px",
  padding: "11px",
  borderRadius: "22px",
  background: "var(--historietas-perfil-deep-72, rgba(4, 0, 10, 0.72))",
  border: "1px solid rgba(255,255,255,0.06)",
  color: "var(--historietas-text-primary, #FFFFFF)",
  textDecoration: "none",
  minWidth: 0,
  maxWidth: "100%",
  overflow: "hidden",
  boxShadow: "none",
  boxSizing: "border-box",
};


const profileLibraryBookActionGridStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "minmax(58px, 66px) minmax(0, 1fr) minmax(0, 1fr)",
  gridTemplateRows: "auto auto",
  gap: "5px",
  alignItems: "stretch",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const desktopProfileLibraryBookActionGridStyle: CSSProperties = {
  ...profileLibraryBookActionGridStyle,
  gridTemplateColumns: "minmax(76px, 88px) minmax(0, 1fr) minmax(0, 1fr)",
  gap: "6px",
};

const profileLibraryBookInfoActionGridStyle: CSSProperties = {
  display: "grid",
  alignContent: "start",
  gap: "4px",
  minWidth: 0,
  maxWidth: "100%",
  gridColumn: "2 / 4",
  gridRow: "1 / 2",
};

const desktopProfileLibraryBookInfoActionGridStyle: CSSProperties = {
  ...profileLibraryBookInfoActionGridStyle,
  gap: "5px",
};


const profileLibraryCoverLinkStyle: CSSProperties = {
  display: "block",
  textDecoration: "none",
  minWidth: 0,
  height: "100%",
};

const profileLibraryCoverStyle: CSSProperties = {
  gridColumn: "1 / 2",
  gridRow: "1 / 3",
  width: "100%",
  height: "100%",
  minHeight: 0,
  maxHeight: "none",
  aspectRatio: "auto",
  alignSelf: "stretch",
  borderRadius: "16px",
  position: "relative",
  overflow: "hidden",
  textDecoration: "none",
  background: "var(--historietas-perfil-bg-deep, #04000A)",
  backgroundImage: "linear-gradient(135deg, var(--historietas-perfil-surface, #08030F) 0%, var(--historietas-perfil-bg-deep, #04000A) 100%)",
  backgroundSize: "cover",
  backgroundPosition: "center",
  border: "1px solid rgba(255,255,255,0.08)",
  display: "block",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  boxShadow: "none",
};

const profileLibraryCoverDesktopStyle: CSSProperties = {
  ...profileLibraryCoverStyle,
  borderRadius: "16px",
};

const profileLibraryCardContentStyle: CSSProperties = {
  display: "grid",
  alignContent: "start",
  gap: "4px",
  minWidth: 0,
  maxWidth: "100%",
};

const profileLibraryBadgesRowStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: "4px",
  flexWrap: "wrap",
  minWidth: 0,
};

const profileLibraryChapterBadgeStyle: CSSProperties = {
  width: "fit-content",
  maxWidth: "100%",
  padding: "5px 8px",
  borderRadius: "999px",
  background: "rgba(255,255,255,0.06)",
  border: "1px solid rgba(255,255,255,0.08)",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "10px",
  lineHeight: 1,
  fontWeight: 900,
  whiteSpace: "normal",
  ...safeTextStyle,
};

const profileLibraryStatusStyle: CSSProperties = {
  ...profileLibraryChapterBadgeStyle,
  background: "rgba(255,255,255,0.035)",
  border: "1px solid rgba(255,255,255,0.07)",
  color: "rgba(255,255,255,0.62)",
};

const profileLibraryStatusActiveStyle: CSSProperties = {
  ...profileLibraryChapterBadgeStyle,
  background: "var(--historietas-perfil-success-spaced-12, rgba(34, 197, 94, 0.12))",
  border: "1px solid var(--historietas-perfil-success-spaced-22, rgba(34, 197, 94, 0.22))",
  color: "var(--historietas-perfil-success-soft, #86EFAC)",
  fontWeight: 950,
};

const profileLibraryTitleStyle: CSSProperties = {
  margin: 0,
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "20px",
  lineHeight: 1.05,
  fontWeight: 950,
  letterSpacing: "-0.03em",
  maxWidth: "100%",
  paddingBottom: "2px",
  display: "-webkit-box",
  WebkitLineClamp: 2,
  WebkitBoxOrient: "vertical",
  overflow: "hidden",
  ...safeTextStyle,
};

const profileLibraryMetaStyle: CSSProperties = {
  margin: 0,
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "10px",
  lineHeight: 1.25,
  fontWeight: 700,
  maxWidth: "100%",
  display: "-webkit-box",
  WebkitLineClamp: 1,
  WebkitBoxOrient: "vertical",
  overflow: "hidden",
  ...safeTextStyle,
};

const profileLibraryAuthorStyle: CSSProperties = {
  width: "fit-content",
  maxWidth: "100%",
  margin: 0,
  color: "var(--historietas-text-secondary, var(--historietas-perfil-lavender, #D8C8FF))",
  fontSize: "12px",
  fontWeight: 800,
  textDecoration: "none",
  borderBottom: "0",
  whiteSpace: "normal",
  ...safeTextStyle,
};

const profileLibraryPrimaryActionsStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
  gap: "8px",
  minWidth: 0,
};

const profileLibrarySecondaryActionsStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
  alignItems: "stretch",
  gap: "5px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  paddingTop: "1px",
  marginTop: 0,
};

const profileLibraryReadButtonStyle: CSSProperties = {
  minHeight: "34px",
  width: "100%",
  maxWidth: "100%",
  padding: "0 12px",
  borderRadius: "999px",
  background: "var(--historietas-perfil-surface, #08030F)",
  border: "1px solid rgba(255,255,255,0.10)",
  color: "#FFFFFF",
  fontSize: "13px",
  fontWeight: 950,
  lineHeight: 1.15,
  textDecoration: "none",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  boxSizing: "border-box",
  whiteSpace: "normal",
  boxShadow: "none",
  textAlign: "center",
  gridColumn: "2 / 3",
  gridRow: "2 / 3",
  ...safeTextStyle,
};

const profileLibraryViewButtonStyle: CSSProperties = {
  ...profileLibraryReadButtonStyle,
  background: "rgba(255,255,255,0.06)",
  border: "1px solid rgba(255,255,255,0.08)",
  color: "var(--historietas-text-secondary, #D4D4D8)",
  gridColumn: "3 / 4",
  gridRow: "2 / 3",
};

const profileLibraryListButtonStyle: CSSProperties = {
  minHeight: "34px",
  width: "100%",
  maxWidth: "100%",
  padding: "0 12px",
  borderRadius: "999px",
  border: "1px solid rgba(255,255,255,0.08)",
  background: "rgba(255,255,255,0.06)",
  color: "#FFFFFF",
  fontSize: "13px",
  fontWeight: 950,
  lineHeight: 1.15,
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  boxSizing: "border-box",
  whiteSpace: "normal",
  boxShadow: "none",
  textAlign: "center",
  cursor: "pointer",
  fontFamily: "inherit",
  ...safeTextStyle,
};

const profileLibraryListButtonActiveStyle: CSSProperties = {
  ...profileLibraryListButtonStyle,
  background: "rgba(255,255,255,0.06)",
  border: "1px solid rgba(255,255,255,0.12)",
};

const profileLibraryDoneButtonStyle: CSSProperties = {
  ...profileLibraryListButtonStyle,
  background: "var(--historietas-perfil-success-spaced-12, rgba(34, 197, 94, 0.12))",
  border: "1px solid var(--historietas-perfil-success-spaced-22, rgba(34, 197, 94, 0.22))",
  color: "var(--historietas-perfil-success-soft, #86EFAC)",
};

const profileLibraryDoneButtonActiveStyle: CSSProperties = {
  ...profileLibraryDoneButtonStyle,
  background: "var(--historietas-perfil-emerald-18, rgba(16,185,129,0.18))",
  border: "1px solid var(--historietas-perfil-emerald-38, rgba(16,185,129,0.38))",
};

const profileLibraryRemoveButtonStyle: CSSProperties = {
  ...profileLibraryListButtonStyle,
  background: "var(--historietas-perfil-danger-dark-spaced-28, rgba(127, 29, 29, 0.28))",
  border: "1px solid var(--historietas-perfil-danger-spaced-22, rgba(248, 113, 113, 0.22))",
  color: "var(--historietas-perfil-danger-soft, #FCA5A5)",
};

const mobileTopWaterFadeStyle: CSSProperties = {
  position: "absolute",
  top: 0,
  left: 0,
  right: 0,
  height: "min(520px, 72vh)",
  pointerEvents: "none",
  zIndex: 0,
  background: "transparent",
  opacity: 0,
};

const desktopTopWaterFadeStyle: CSSProperties = {
  position: "absolute",
  top: 0,
  left: 0,
  right: 0,
  height: "min(620px, 68vh)",
  pointerEvents: "none",
  zIndex: 0,
  background: "transparent",
  opacity: 0,
};

const perfilAutorThemeCss = `
  @keyframes historietas-perfil-heart-pop {
    0% { transform: scale(1); }
    45% { transform: scale(1.28); }
    100% { transform: scale(1); }
  }

  @media (prefers-reduced-motion: reduce) {
    [data-historietas-top-five-like="true"] svg {
      animation-duration: 1ms !important;
    }
  }

  html {
    --historietas-perfil-bg-page: #070212;
    --historietas-perfil-bg-deep: #04000A;
    --historietas-perfil-surface: #08030F;
    --historietas-perfil-surface-alt: #120B1C;
    --historietas-perfil-accent: #F97316;
    --historietas-perfil-accent-strong: #FB923C;
    --historietas-perfil-accent-soft: #FDBA74;
    --historietas-perfil-gold: #FBBF24;
    --historietas-perfil-danger-soft: #FCA5A5;
    --historietas-perfil-danger: #EF4444;
    --historietas-perfil-rose-soft: #FDA4AF;
    --historietas-perfil-rose: #FB7185;
    --historietas-perfil-success-soft: #86EFAC;
    --historietas-perfil-lavender-text: #DDD6FE;
    --historietas-perfil-purple-soft: #C084FC;
    --historietas-perfil-blue-soft: #7DD3FC;
    --historietas-perfil-lavender: #D8C8FF;
    --historietas-perfil-purple: #A78BFA;
    --historietas-perfil-secondary: #7C3AED;
    --historietas-perfil-accent-14: rgba(249,115,22,0.14);
    --historietas-perfil-rose-14: rgba(251,113,133,0.14);
    --historietas-perfil-success-14: rgba(34,197,94,0.14);
    --historietas-perfil-gold-14: rgba(251,191,36,0.14);
    --historietas-perfil-purple-soft-14: rgba(192,132,252,0.14);
    --historietas-perfil-blue-14: rgba(56,189,248,0.14);
    --historietas-perfil-secondary-18: rgba(124,58,237,0.18);
    --historietas-perfil-deep-72: rgba(4, 0, 10, 0.72);
    --historietas-perfil-success-spaced-12: rgba(34, 197, 94, 0.12);
    --historietas-perfil-success-spaced-22: rgba(34, 197, 94, 0.22);
    --historietas-perfil-emerald-18: rgba(16,185,129,0.18);
    --historietas-perfil-emerald-38: rgba(16,185,129,0.38);
    --historietas-perfil-danger-dark-spaced-28: rgba(127, 29, 29, 0.28);
    --historietas-perfil-danger-spaced-22: rgba(248, 113, 113, 0.22);
    --historietas-perfil-purple-dark-58: rgba(59, 7, 100, 0.58);
    --historietas-perfil-danger-42: rgba(248,113,113,0.42);
    --historietas-perfil-danger-dark-24: rgba(127,29,29,0.24);
    --historietas-perfil-danger-36: rgba(248,113,113,0.36);
    --historietas-perfil-danger-dark-34: rgba(127,29,29,0.34);
    --historietas-perfil-gold-spaced-34: rgba(251, 191, 36, 0.34);
    --historietas-perfil-surface-fade-0: rgba(8,5,13,0);
    --historietas-perfil-surface-fade-58: rgba(8,5,13,0.58);
    --historietas-perfil-surface-fade-92: rgba(8,5,13,0.92);
    --historietas-perfil-success-10: rgba(34,197,94,0.10);
    --historietas-perfil-success-22: rgba(34,197,94,0.22);
    --historietas-perfil-rose-dark-14: rgba(190,18,60,0.14);
    --historietas-perfil-rose-28: rgba(251,113,133,0.28);
    --historietas-perfil-surface-purple-92: rgba(18,8,31,0.92);
    --historietas-perfil-surface-purple-94: rgba(38,20,62,0.94);
  }

  @keyframes historietas-loading-spin {
    to {
      transform: rotate(360deg);
    }
  }

  @media (prefers-reduced-motion: reduce) {
    .historietas-loading-spinner {
      animation-duration: 1.4s !important;
    }
  }

  html[data-historietas-tema-visual="foco"] {
    --historietas-perfil-bg-page: #000000;
    --historietas-perfil-bg-deep: #000000;
    --historietas-perfil-surface: #050505;
    --historietas-perfil-surface-alt: #090909;
    --historietas-perfil-accent: #FFFFFF;
    --historietas-perfil-accent-strong: #FFFFFF;
    --historietas-perfil-accent-soft: #FFFFFF;
    --historietas-perfil-gold: #FFFFFF;
    --historietas-perfil-danger-soft: #FFFFFF;
    --historietas-perfil-danger: #FFFFFF;
    --historietas-perfil-rose-soft: #D4D4D8;
    --historietas-perfil-rose: #FFFFFF;
    --historietas-perfil-success-soft: #FFFFFF;
    --historietas-perfil-lavender-text: #FFFFFF;
    --historietas-perfil-purple-soft: #FFFFFF;
    --historietas-perfil-blue-soft: #D4D4D8;
    --historietas-perfil-lavender: #FFFFFF;
    --historietas-perfil-purple: #FFFFFF;
    --historietas-perfil-secondary: #A1A1AA;
    --historietas-perfil-accent-14: rgba(255,255,255,0.08);
    --historietas-perfil-rose-14: rgba(255,255,255,0.08);
    --historietas-perfil-success-14: rgba(255,255,255,0.08);
    --historietas-perfil-gold-14: rgba(255,255,255,0.08);
    --historietas-perfil-purple-soft-14: rgba(255,255,255,0.08);
    --historietas-perfil-blue-14: rgba(255,255,255,0.08);
    --historietas-perfil-secondary-18: rgba(255,255,255,0.08);
    --historietas-perfil-deep-72: rgba(0,0,0,0.72);
    --historietas-perfil-success-spaced-12: rgba(255,255,255,0.06);
    --historietas-perfil-success-spaced-22: rgba(255,255,255,0.10);
    --historietas-perfil-emerald-18: rgba(255,255,255,0.08);
    --historietas-perfil-emerald-38: rgba(255,255,255,0.18);
    --historietas-perfil-danger-dark-spaced-28: rgba(255,255,255,0.10);
    --historietas-perfil-danger-spaced-22: rgba(255,255,255,0.10);
    --historietas-perfil-purple-dark-58: rgba(255,255,255,0.14);
    --historietas-perfil-danger-42: rgba(255,255,255,0.24);
    --historietas-perfil-danger-dark-24: rgba(255,255,255,0.08);
    --historietas-perfil-danger-36: rgba(255,255,255,0.20);
    --historietas-perfil-danger-dark-34: rgba(255,255,255,0.12);
    --historietas-perfil-gold-spaced-34: rgba(255,255,255,0.18);
    --historietas-perfil-surface-fade-0: rgba(0,0,0,0);
    --historietas-perfil-surface-fade-58: rgba(0,0,0,0.58);
    --historietas-perfil-surface-fade-92: rgba(0,0,0,0.92);
    --historietas-perfil-success-10: rgba(255,255,255,0.06);
    --historietas-perfil-success-22: rgba(255,255,255,0.10);
    --historietas-perfil-rose-dark-14: rgba(255,255,255,0.08);
    --historietas-perfil-rose-28: rgba(255,255,255,0.14);
    --historietas-perfil-surface-purple-92: rgba(0,0,0,0.92);
    --historietas-perfil-surface-purple-94: rgba(5,5,5,0.94);
  }
`;

const pageStyle: CSSProperties = {
  position: "relative",
  minHeight: "100vh",
  width: "100%",
  maxWidth: "100vw",
  overflowX: "hidden",
  boxSizing: "border-box",
  background:
    "var(--historietas-bg-start, var(--historietas-perfil-bg-page, #070212))",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontFamily: "Inter, Poppins, Manrope, Arial, Helvetica, sans-serif",
};

const loadingPageStyle: CSSProperties = {
  width: "100%",
  minHeight: "calc(100dvh - 32px)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  boxSizing: "border-box",
};

const loadingInlineStyle: CSSProperties = {
  width: "100%",
  minHeight: "72px",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  boxSizing: "border-box",
};

const loadingSpinnerStyle: CSSProperties = {
  width: "30px",
  height: "30px",
  borderRadius: "999px",
  border: "3px solid rgba(255,255,255,0.20)",
  borderTopColor: "#FFFFFF",
  boxSizing: "border-box",
  animation: "historietas-loading-spin 0.78s linear infinite",
  flex: "0 0 auto",
};

const loadingSpinnerCompactStyle: CSSProperties = {
  ...loadingSpinnerStyle,
  width: "24px",
  height: "24px",
  borderWidth: "2.5px",
};

const containerStyle: CSSProperties = {
  position: "relative",
  width: "min(900px, calc(100% - 28px))",
  maxWidth: "100%",
  margin: "0 auto",
  padding: "16px 0 12px",
  boxSizing: "border-box",
  minWidth: 0,
};

const topStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  gap: "10px",
  flexWrap: "nowrap",
  marginBottom: "16px",
  minWidth: 0,
};

const logoStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: "7px",
  minWidth: 0,
  maxWidth: "min(100%, calc(100% - 96px))",
  color: "#FFFFFF",
  WebkitTextFillColor: "#FFFFFF",
  ...safeTextStyle,
};

const logoMarkButtonStyle: CSSProperties = {
  appearance: "none",
  WebkitAppearance: "none",
  padding: 0,
  border: "none",
  background: "transparent",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  flex: "0 0 auto",
  cursor: "pointer",
};

const logoTextButtonStyle: CSSProperties = {
  appearance: "none",
  WebkitAppearance: "none",
  padding: 0,
  border: "none",
  background: "transparent",
  display: "inline-flex",
  alignItems: "center",
  minWidth: 0,
  maxWidth: "100%",
  color: "#FFFFFF",
  WebkitTextFillColor: "#FFFFFF",
  cursor: "copy",
};

const logoMarkStyle: CSSProperties = {
  width: "34px",
  height: "34px",
  borderRadius: "12px",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  background: "var(--historietas-perfil-bg-deep, #04000A)",
  color: "#FFFFFF",
  WebkitTextFillColor: "#FFFFFF",
  fontSize: "21px",
  lineHeight: 1,
  fontWeight: 950,
  letterSpacing: 0,
  flex: "0 0 auto",
  border: "1px solid var(--historietas-perfil-purple-dark-58, rgba(59, 7, 100, 0.58))",
  boxShadow: "none",
};

const logoTextStyle: CSSProperties = {
  minWidth: 0,
  maxWidth: "min(58vw, 360px)",
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
  color: "#FFFFFF",
  WebkitTextFillColor: "#FFFFFF",
  background: "none",
  fontSize: "17px",
  lineHeight: 1,
  ...homeCardTitleTypographyStyle,
  textShadow: "none",
  ...safeTextStyle,
};

const profileHeaderStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "minmax(0, 1fr) 36px",
  alignItems: "center",
  gap: "8px",
  marginBottom: "12px",
  minWidth: 0,
};

const profileHeaderDesktopStyle: CSSProperties = {
  ...profileHeaderStyle,
  gridTemplateColumns: "minmax(0, 1fr) 36px",
};

const profileNotificationButtonStyle: CSSProperties = {
  position: "relative",
  width: "34px",
  height: "34px",
  borderRadius: "999px",
  border:
    "1px solid var(--historietas-border-soft, rgba(255,255,255,0.08))",
  background: "var(--historietas-surface-strong, var(--historietas-perfil-bg-deep, #04000A))",
  color: "var(--historietas-text-primary, #FFFFFF)",
  textDecoration: "none",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: "14px",
  lineHeight: 1,
  fontWeight: 950,
  boxShadow: "none",
};

const profileNotificationBadgeStyle: CSSProperties = {
  position: "absolute",
  top: "-7px",
  right: "-9px",
  minWidth: "18px",
  height: "18px",
  padding: "0 4px",
  borderRadius: "999px",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  border: "2px solid var(--historietas-bg-start, var(--historietas-perfil-bg-page, #070212))",
  background: "var(--historietas-perfil-danger, #EF4444)",
  color: "#FFFFFF",
  fontSize: "9px",
  lineHeight: 1,
  fontWeight: 950,
  letterSpacing: "-0.03em",
  boxShadow: "0 4px 12px rgba(0, 0, 0, 0.38)",
  pointerEvents: "none",
};

const profileHeaderLogoStyle: CSSProperties = {
  ...logoStyle,
};

const profileHeaderCenterStyle: CSSProperties = {
  display: "grid",
  justifyItems: "center",
  gap: "1px",
  minWidth: 0,
  textAlign: "center",
};

const profileHeaderHandleStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "12px",
  lineHeight: 1.1,
  fontWeight: 950,
  letterSpacing: "-0.02em",
  maxWidth: "100%",
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
};

const profileHeaderModeStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "8.6px",
  lineHeight: 1.1,
  fontWeight: 900,
  textTransform: "uppercase",
  letterSpacing: "0.08em",
  maxWidth: "100%",
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
};

const profileMenuButtonStyle: CSSProperties = {
  width: "32px",
  height: "32px",
  borderRadius: "999px",
  border: "1px solid transparent",
  background: "transparent",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "23px",
  lineHeight: 1,
  fontWeight: 950,
  fontFamily: "inherit",
  cursor: "pointer",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  boxSizing: "border-box",
  padding: 0,
};

const profileMenuIconStyle: CSSProperties = {
  width: "22px",
  display: "grid",
  gap: "4px",
};

const profileMenuIconLineStyle: CSSProperties = {
  display: "block",
  width: "100%",
  height: "2.5px",
  borderRadius: "999px",
  background: "currentColor",
};

const menuOverlayStyle: CSSProperties = {
  position: "fixed",
  inset: 0,
  zIndex: 9999,
  background: "rgba(0,0,0,0.62)",
  display: "flex",
  alignItems: "stretch",
  justifyContent: "flex-end",
  padding: 0,
  boxSizing: "border-box",
};

const menuSheetStyle: CSSProperties = {
  width: "min(360px, calc(100vw - 72px))",
  height: "100dvh",
  maxHeight: "100dvh",
  borderRadius: 0,
  border: "0",
  background: "var(--historietas-perfil-bg-page, #070212)",
  padding: "22px 16px calc(132px + env(safe-area-inset-bottom, 0px))",
  display: "grid",
  alignContent: "start",
  gap: "18px",
  boxSizing: "border-box",
  overflowY: "auto",
  overscrollBehavior: "contain",
};

const desktopMenuSheetStyle: CSSProperties = {
  ...menuSheetStyle,
  width: "360px",
  maxWidth: "calc(100vw - 80px)",
};

const menuHandleStyle: CSSProperties = {
  width: "42px",
  height: "4px",
  borderRadius: "999px",
  background: "var(--historietas-border-soft, rgba(255,255,255,0.20))",
  margin: "0 auto 4px",
};

const menuHeaderStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  gap: "12px",
  padding: "2px 0 4px",
  minWidth: 0,
};

const menuTitleBlockStyle: CSSProperties = {
  display: "grid",
  gap: "2px",
  minWidth: 0,
};

const menuTitleStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "14px",
  fontWeight: 950,
  lineHeight: 1.2,
  ...safeTextStyle,
};

const menuSubtitleStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "10px",
  fontWeight: 850,
  lineHeight: 1.25,
  ...safeTextStyle,
};

const menuCloseButtonStyle: CSSProperties = {
  width: "40px",
  height: "40px",
  borderRadius: "999px",
  border: "0",
  background: "rgba(255,255,255,0.075)",
  color: "#FFFFFF",
  fontSize: "20px",
  lineHeight: 1,
  fontWeight: 900,
  fontFamily: "inherit",
  cursor: "pointer",
};

const menuListStyle: CSSProperties = {
  display: "grid",
  gap: "8px",
  minWidth: 0,
  paddingBottom: "24px",
};

const menuSectionTitleStyle: CSSProperties = {
  marginTop: "8px",
  color: "rgba(255,255,255,0.52)",
  fontSize: "10px",
  lineHeight: 1.2,
  fontWeight: 900,
  textTransform: "uppercase",
  letterSpacing: "0.07em",
  ...safeTextStyle,
};

const menuDividerStyle: CSSProperties = {
  height: "1px",
  background: "rgba(255,255,255,0.075)",
  margin: "8px 0 4px",
};

const menuItemStyle: CSSProperties = {
  width: "100%",
  minHeight: "52px",
  borderRadius: "0",
  border: "0",
  background: "transparent",
  color: "#FFFFFF",
  textDecoration: "none",
  display: "grid",
  gridTemplateColumns: "32px minmax(0, 1fr) auto",
  alignItems: "center",
  gap: "10px",
  padding: "0",
  boxSizing: "border-box",
  fontFamily: "inherit",
  cursor: "pointer",
  textAlign: "left",
};

const menuDangerItemStyle: CSSProperties = {
  ...menuItemStyle,
  color: "var(--historietas-perfil-danger-soft, #FCA5A5)",
};

const menuItemIconStyle: CSSProperties = {
  width: "32px",
  height: "32px",
  borderRadius: "10px",
  background: "transparent",
  color: "rgba(255,255,255,0.82)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: "16px",
};

const menuItemTextStyle: CSSProperties = {
  fontSize: "15px",
  fontWeight: 900,
  lineHeight: 1.2,
  color: "inherit",
  ...safeTextStyle,
};

const menuChevronStyle: CSSProperties = {
  color: "rgba(255,255,255,0.52)",
  fontSize: "26px",
  lineHeight: 1,
  fontWeight: 700,
  textAlign: "right",
};

const menuNotificationLabelStyle: CSSProperties = {
  minWidth: 0,
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "flex-start",
  gap: "6px",
};

const menuNotificationRightStyle: CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "flex-end",
  gap: "6px",
  minWidth: 0,
};

const menuNotificationBadgeStyle: CSSProperties = {
  display: "inline",
  color: "var(--historietas-perfil-danger, #EF4444)",
  fontSize: "12px",
  lineHeight: 1,
  fontWeight: 950,
  letterSpacing: "-0.03em",
  pointerEvents: "none",
};

const menuCancelButtonStyle: CSSProperties = {
  minHeight: "40px",
  borderRadius: "999px",
  border: "1px solid var(--historietas-border-soft, rgba(255,255,255,0.10))",
  background: "transparent",
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "11px",
  fontWeight: 950,
  fontFamily: "inherit",
  cursor: "pointer",
};

const headerFollowButtonStyle: CSSProperties = {
  minHeight: "36px",
  padding: "0 14px",
  borderRadius: "999px",
  border:
    "1px solid rgba(255,255,255,0.10)",
  background: "var(--historietas-perfil-surface, #08030F)",
  color: "#FFFFFF",
  fontSize: "11px",
  fontWeight: 950,
  fontFamily: "inherit",
  cursor: "pointer",
  textAlign: "center",
  boxShadow: "none",
  flex: "0 0 auto",
  ...safeTextStyle,
};

const headerFollowingButtonStyle: CSSProperties = {
  ...headerFollowButtonStyle,
  background: "rgba(255,255,255,0.06)",
  border: "1px solid rgba(255,255,255,0.10)",
  color: "var(--historietas-text-primary, #FFFFFF)",
};

const heroBoxStyle: CSSProperties = {
  display: "grid",
  gap: "8px",
  padding: "4px 2px 8px",
  borderRadius: "0",
  background: "transparent",
  border: "0",
  boxShadow: "none",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  overflow: "visible",
};

const authorTopRowStyle: CSSProperties = {
  position: "relative",
  display: "grid",
  gridTemplateColumns: "76px minmax(0, 1fr)",
  alignItems: "center",
  justifyItems: "stretch",
  gap: "14px",
  minHeight: "76px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  overflow: "visible",
};

const authorHeaderInfoStyle: CSSProperties = {
  display: "grid",
  gridTemplateRows: "auto auto",
  alignContent: "center",
  gap: "6px",
  minWidth: 0,
  width: "100%",
  maxWidth: "100%",
  overflow: "visible",
  boxSizing: "border-box",
};

const authorTextBlockStyle: CSSProperties = {
  display: "grid",
  justifyItems: "start",
  gap: "2px",
  alignContent: "center",
  minWidth: 0,
  width: "100%",
  maxWidth: "100%",
  textAlign: "left",
};

const avatarBaseStyle: CSSProperties = {
  position: "relative",
  left: "auto",
  top: "auto",
  transform: "none",
  width: "76px",
  maxWidth: "76px",
  height: "76px",
  borderRadius: "20px",
  border: "1px solid var(--historietas-perfil-purple-dark-58, rgba(59, 7, 100, 0.58))",
  padding: 0,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  background: "var(--historietas-perfil-bg-deep, #04000A)",
  color: "#FFFFFF",
  fontSize: "24px",
  fontWeight: 950,
  overflow: "hidden",
  fontFamily: "inherit",
  boxSizing: "border-box",
  boxShadow: "none",
};

const avatarButtonStyle: CSSProperties = {
  ...avatarBaseStyle,
  cursor: "pointer",
};

const avatarDisplayStyle: CSSProperties = {
  ...avatarBaseStyle,
  cursor: "default",
};

const avatarImageStyle: CSSProperties = {
  width: "100%",
  height: "100%",
  objectFit: "cover",
  display: "block",
};

const hiddenInputStyle: CSSProperties = {
  display: "none",
};

const profileEditorSheetContentStyle: CSSProperties = {
  display: "grid",
  gap: "14px",
  minWidth: 0,
  maxWidth: "100%",
  paddingBottom: "24px",
  boxSizing: "border-box",
};

const profileEditorAvatarBlockStyle: CSSProperties = {
  display: "grid",
  justifyItems: "center",
  gap: "10px",
  minWidth: 0,
  padding: "6px 0 2px",
};

const profileEditorAvatarPreviewStyle: CSSProperties = {
  width: "88px",
  height: "88px",
  borderRadius: "24px",
  border: "1px solid rgba(255,255,255,0.10)",
  background: "var(--historietas-perfil-bg-deep, #04000A)",
  color: "#FFFFFF",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  overflow: "hidden",
  boxSizing: "border-box",
  fontSize: "30px",
  lineHeight: 1,
  fontWeight: 950,
};

const profileEditorSheetFieldStyle: CSSProperties = {
  display: "grid",
  gap: "7px",
  width: "100%",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const profileEditorSheetLabelStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "11px",
  lineHeight: 1.2,
  fontWeight: 900,
  textAlign: "left",
  ...safeTextStyle,
};

const profileEditorSheetInputStyle: CSSProperties = {
  width: "100%",
  minHeight: "44px",
  borderRadius: "14px",
  border: "1px solid rgba(255,255,255,0.10)",
  background: "var(--historietas-perfil-surface, #08030F)",
  color: "#FFFFFF",
  padding: "0 14px",
  outline: "none",
  fontSize: "13px",
  lineHeight: 1.2,
  fontWeight: 850,
  fontFamily: "inherit",
  textAlign: "left",
  boxSizing: "border-box",
  minWidth: 0,
  maxWidth: "100%",
  ...safeTextStyle,
};

const profileEditorSheetTextareaStyle: CSSProperties = {
  width: "100%",
  minHeight: "112px",
  resize: "vertical",
  borderRadius: "16px",
  border: "1px solid rgba(255,255,255,0.10)",
  background: "var(--historietas-perfil-surface, #08030F)",
  color: "#FFFFFF",
  padding: "12px 14px",
  outline: "none",
  fontSize: "13px",
  lineHeight: 1.45,
  fontWeight: 650,
  fontFamily: "inherit",
  boxSizing: "border-box",
  minWidth: 0,
  maxWidth: "100%",
  ...safeTextStyle,
};

const profileEditorSheetActionsStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "1fr 1fr",
  gap: "8px",
  minWidth: 0,
  marginTop: "4px",
};

const profileEditorCancelButtonStyle: CSSProperties = {
  minHeight: "44px",
  borderRadius: "999px",
  border: "1px solid rgba(255,255,255,0.10)",
  background: "rgba(255,255,255,0.06)",
  color: "#FFFFFF",
  fontSize: "12px",
  lineHeight: 1,
  fontWeight: 950,
  fontFamily: "inherit",
  cursor: "pointer",
};

const profileEditorSaveButtonStyle: CSSProperties = {
  ...profileEditorCancelButtonStyle,
  border: "1px solid #FFFFFF",
  background: "#FFFFFF",
  color: "#111111",
};

const avatarActionsStyle: CSSProperties = {
  display: "flex",
  flexWrap: "wrap",
  alignItems: "stretch",
  gap: "6px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const avatarSmallButtonStyle: CSSProperties = {
  flex: "1 1 118px",
  minHeight: "28px",
  maxWidth: "100%",
  padding: "0 9px",
  borderRadius: "999px",
  border: "1px solid rgba(255,255,255,0.10)",
  background: "var(--historietas-perfil-surface, #08030F)",
  color: "#FFFFFF",
  fontSize: "9px",
  fontWeight: 900,
  cursor: "pointer",
  fontFamily: "inherit",
  textAlign: "center",
  boxSizing: "border-box",
  whiteSpace: "normal",
  ...safeTextStyle,
};

const avatarRemoveButtonStyle: CSSProperties = {
  ...avatarSmallButtonStyle,
};

const avatarErrorStyle: CSSProperties = {
  color: "var(--historietas-perfil-danger-soft, #FCA5A5)",
  fontSize: "10px",
  fontWeight: 800,
  ...safeTextStyle,
};


const bioCounterStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "9px",
  fontWeight: 900,
  textAlign: "right",
  ...safeTextStyle,
};

const titleStyle: CSSProperties = {
  margin: 0,
  fontSize: "clamp(20px, 5.2vw, 27px)",
  lineHeight: 1.18,
  ...homeCardTitleTypographyStyle,
  maxWidth: "100%",
  minWidth: 0,
  paddingRight: "6px",
  paddingBottom: 0,
  overflow: "visible",
  textAlign: "left",
  background: "none",
  WebkitBackgroundClip: "initial",
  backgroundClip: "initial",
  WebkitTextFillColor: "#FFFFFF",
  color: "#FFFFFF",
  whiteSpace: "nowrap",
  wordBreak: "normal",
  overflowWrap: "normal",
};

const descriptionStyle: CSSProperties = {
  margin: 0,
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "10.5px",
  lineHeight: 1.4,
  fontWeight: 650,
  width: "min(520px, 100%)",
  maxWidth: "520px",
  display: "-webkit-box",
  WebkitLineClamp: 2,
  WebkitBoxOrient: "vertical",
  overflow: "hidden",
  textAlign: "left",
  ...safeTextStyle,
};

const profileNameRowStyle: CSSProperties = {
  width: "100%",
  display: "flex",
  alignItems: "center",
  justifyContent: "flex-start",
  gap: "6px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  overflow: "visible",
};


const profileAddBioButtonStyle: CSSProperties = {
  appearance: "none",
  WebkitAppearance: "none",
  width: "fit-content",
  maxWidth: "100%",
  minHeight: "28px",
  padding: "0 11px",
  borderRadius: "999px",
  border: "none",
  background: "rgba(255,255,255,0.06)",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "10px",
  lineHeight: 1.15,
  fontWeight: 900,
  fontFamily: "inherit",
  cursor: "pointer",
  textAlign: "left",
  ...safeTextStyle,
};

const profileStatsStyle: CSSProperties = {
  width: "100%",
  display: "grid",
  gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
  gap: "0",
  marginTop: 0,
  minWidth: 0,
  borderTop: "0",
  borderBottom: "0",
};

const desktopProfileStatsStyle: CSSProperties = {
  ...profileStatsStyle,
  width: "100%",
  margin: 0,
};

const profileStatItemStyle: CSSProperties = {
  minHeight: "39px",
  borderRadius: 0,
  background: "transparent",
  border: "0",
  display: "grid",
  alignContent: "center",
  justifyItems: "center",
  gap: "3px",
  padding: "4px 2px",
  boxSizing: "border-box",
  minWidth: 0,
};

const profileStatLinkStyle: CSSProperties = {
  ...profileStatItemStyle,
  color: "inherit",
  textDecoration: "none",
  cursor: "pointer",
};

const profileStatNumberStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "18.5px",
  lineHeight: 1,
  fontWeight: 950,
  textAlign: "center",
  ...safeTextStyle,
};

const profileStatWorksNumberStyle: CSSProperties = {
  ...profileStatNumberStyle,
  position: "relative",
  top: "5px",
};

const profileStatLabelStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "8.8px",
  lineHeight: 1.1,
  fontWeight: 850,
  textTransform: "none",
  letterSpacing: "0",
  textAlign: "center",
  ...safeTextStyle,
};

const profileStatStackedLabelStyle: CSSProperties = {
  ...profileStatLabelStyle,
  display: "grid",
  justifyItems: "center",
  gap: 0,
  whiteSpace: "nowrap",
};

const profileStatWorksLabelStyle: CSSProperties = {
  ...profileStatStackedLabelStyle,
  position: "relative",
  top: "5px",
};

const profileRatingStatItemStyle: CSSProperties = {
  ...profileStatItemStyle,
  gap: "3px",
};

const profileRatingPrivateLockStyle: CSSProperties = {
  width: "25px",
  height: "29px",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  color: "#FFFFFF",
  WebkitTextFillColor: "#FFFFFF",
  position: "relative",
  top: "-2px",
  lineHeight: 1,
  flex: "0 0 auto",
};

const profileRatingNumberStyle: CSSProperties = {
  ...profileStatNumberStyle,
  color: "var(--historietas-accent, var(--historietas-perfil-accent-soft, #FDBA74))",
  position: "relative",
  top: "5px",
};

const profileRatingStackedMetaStyle: CSSProperties = {
  display: "grid",
  gridTemplateRows: "10px 9.68px",
  alignItems: "center",
  justifyItems: "center",
  gap: 0,
  position: "relative",
  top: "5px",
  minWidth: 0,
  whiteSpace: "nowrap",
};

const profileRatingMiniStarsStyle: CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  gap: "1px",
  color: "var(--historietas-perfil-gold, #FBBF24)",
  fontSize: "10px",
  lineHeight: 1,
  letterSpacing: "-0.02em",
  position: "relative",
  top: "-1px",
  ...safeTextStyle,
};

const profileRatingMiniStarVisualStyle: CSSProperties = {
  position: "relative",
  width: "1em",
  height: "1em",
  display: "inline-block",
  lineHeight: 1,
  flex: "0 0 auto",
};

const profileRatingMiniStarBaseStyle: CSSProperties = {
  color: "var(--historietas-perfil-gold-spaced-34, rgba(251, 191, 36, 0.34))",
  position: "absolute",
  inset: 0,
  lineHeight: 1,
};

const profileRatingMiniStarFillStyle: CSSProperties = {
  color: "var(--historietas-perfil-gold, #FBBF24)",
  position: "absolute",
  inset: 0,
  overflow: "hidden",
  whiteSpace: "nowrap",
  lineHeight: 1,
};

const profileRatingTotalStyle: CSSProperties = {
  ...profileStatLabelStyle,
  fontSize: "7.8px",
  lineHeight: 1.1,
  whiteSpace: "nowrap",
};

const authorRatingBoxStyle: CSSProperties = {
  marginTop: "10px",
  padding: 0,
  borderRadius: 0,
  background: "transparent",
  border: "none",
  display: "grid",
  gap: "8px",
  minWidth: 0,
  boxSizing: "border-box",
};

const desktopAuthorRatingBoxStyle: CSSProperties = {
  ...authorRatingBoxStyle,
  width: "min(420px, 100%)",
  margin: "12px auto 0",
};

const authorRatingHeaderStyle: CSSProperties = {
  display: "grid",
  justifyItems: "center",
  gap: "3px",
  minWidth: 0,
  textAlign: "center",
};

const authorRatingTitleStyle: CSSProperties = {
  color: "#FFFFFF",
  WebkitTextFillColor: "#FFFFFF",
  fontSize: "10px",
  fontWeight: 950,
  letterSpacing: "0.075em",
  maxWidth: "100%",
  textAlign: "center",
  ...safeTextStyle,
};

const authorRatingMetaStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "8.8px",
  lineHeight: 1.1,
  fontWeight: 850,
  textAlign: "center",
  ...safeTextStyle,
};

const authorRatingStarsRowStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(5, minmax(0, 1fr))",
  gap: "6px",
  minWidth: 0,
  background: "transparent",
  boxShadow: "none",
  filter: "none",
  backdropFilter: "none",
  WebkitBackdropFilter: "none",
};

const authorRatingStarButtonStyle: CSSProperties = {
  minHeight: "auto",
  borderRadius: 0,
  border: "none",
  background: "transparent",
  color: "var(--historietas-perfil-gold-spaced-34, rgba(251, 191, 36, 0.34))",
  fontSize: "22px",
  fontWeight: 950,
  lineHeight: 1,
  cursor: "pointer",
  fontFamily: "inherit",
  boxShadow: "none",
  filter: "none",
  backdropFilter: "none",
  WebkitBackdropFilter: "none",
  padding: "0 2px",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
};

const authorRatingStarActiveStyle: CSSProperties = {
  ...authorRatingStarButtonStyle,
  border: "none",
  background: "transparent",
  color: "var(--historietas-perfil-gold, #FBBF24)",
  boxShadow: "none",
  filter: "none",
  backdropFilter: "none",
  WebkitBackdropFilter: "none",
};

const authorRatingStarVisualStyle: CSSProperties = {
  position: "relative",
  width: "1em",
  height: "1em",
  display: "inline-block",
  lineHeight: 1,
};

const authorRatingStarBaseStyle: CSSProperties = {
  color: "var(--historietas-perfil-gold-spaced-34, rgba(251, 191, 36, 0.34))",
  position: "absolute",
  inset: 0,
  lineHeight: 1,
};

const authorRatingStarFillStyle: CSSProperties = {
  color: "var(--historietas-perfil-gold, #FBBF24)",
  position: "absolute",
  inset: 0,
  overflow: "hidden",
  whiteSpace: "nowrap",
  lineHeight: 1,
};

const profileActionsStyle: CSSProperties = {
  width: "100%",
  display: "grid",
  gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
  gap: "7px",
  marginTop: "1px",
  minWidth: 0,
};

const desktopProfileActionsStyle: CSSProperties = {
  ...profileActionsStyle,
  width: "min(640px, 100%)",
  margin: "4px auto 0",
  gap: "10px",
};

const profileVisitorActionsStyle: CSSProperties = {
  ...profileActionsStyle,
  gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
};

const desktopProfileVisitorActionsStyle: CSSProperties = {
  ...desktopProfileActionsStyle,
  gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
};

const profileActionToastStyle: CSSProperties = {
  position: "fixed",
  left: "50%",
  bottom: "calc(92px + env(safe-area-inset-bottom))",
  transform: "translateX(-50%)",
  zIndex: 1400,
  width: "max-content",
  maxWidth: "calc(100vw - 32px)",
  minHeight: "38px",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  borderRadius: "999px",
  border: "1px solid var(--historietas-border-soft, rgba(255,255,255,0.14))",
  background: "var(--historietas-surface-strong, #120822)",
  color: "var(--historietas-text-primary, #FFFFFF)",
  boxShadow: "0 14px 34px rgba(0,0,0,0.38)",
  padding: "9px 14px",
  fontSize: "11px",
  lineHeight: 1.3,
  fontWeight: 900,
  textAlign: "center",
  pointerEvents: "none",
};

const profilePrimaryButtonStyle: CSSProperties = {
  minHeight: "34px",
  borderRadius: "999px",
  border: "1px solid rgba(255,255,255,0.10)",
  background: "var(--historietas-perfil-surface, #08030F)",
  color: "#FFFFFF",
  textDecoration: "none",
  fontSize: "10px",
  lineHeight: 1.15,
  fontWeight: 950,
  fontFamily: "inherit",
  cursor: "pointer",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  textAlign: "center",
  padding: "0 8px",
  boxSizing: "border-box",
  minWidth: 0,
  whiteSpace: "normal",
  ...safeTextStyle,
};

const profileSecondaryButtonStyle: CSSProperties = {
  ...profilePrimaryButtonStyle,
  border: profilePrimaryButtonStyle.border,
  background: profilePrimaryButtonStyle.background,
  color: profilePrimaryButtonStyle.color,
  boxShadow: "none",
};

const profileActiveButtonStyle: CSSProperties = {
  ...profilePrimaryButtonStyle,
  border: profilePrimaryButtonStyle.border,
  background: profilePrimaryButtonStyle.background,
  color: profilePrimaryButtonStyle.color,
  boxShadow: "none",
};

const authorHighlightsStyle: CSSProperties = {
  width: "100%",
  marginTop: "0",
  display: "grid",
  gap: "3px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  overflow: "visible",
};

const desktopAuthorHighlightsStyle: CSSProperties = {
  ...authorHighlightsStyle,
  marginTop: "0",
};

const authorHighlightsHeaderStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  gap: "8px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const authorHighlightsTitleGroupStyle: CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "flex-start",
  gap: "7px",
  minWidth: 0,
  flex: "1 1 auto",
};

const authorHighlightsTitleStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "12px",
  lineHeight: 1.1,
  fontWeight: 950,
  letterSpacing: "-0.02em",
  ...safeTextStyle,
};

const authorHighlightsHeaderActionsStyle: CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "flex-end",
  gap: "8px",
  flex: "0 0 auto",
};

const authorHighlightsLikeButtonStyle: CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  gap: "5px",
  minWidth: 0,
  height: "22px",
  padding: 0,
  border: "none",
  borderRadius: 0,
  background: "transparent",
  color: "var(--historietas-text-muted, rgba(255,255,255,0.76))",
  fontSize: "11px",
  lineHeight: 1,
  fontWeight: 850,
  cursor: "pointer",
  boxSizing: "border-box",
  WebkitTapHighlightColor: "transparent",
  ...safeTextStyle,
};

const authorHighlightsLikeButtonActiveStyle: CSSProperties = {
  ...authorHighlightsLikeButtonStyle,
  color: "var(--historietas-perfil-danger, #EF4444)",
};

const authorHighlightsLikeHeartIconStyle: CSSProperties = {
  width: "18px",
  height: "18px",
  display: "block",
  flex: "0 0 auto",
  transformOrigin: "center",
};

const authorHighlightsLikeCountStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "11px",
  lineHeight: 1,
  fontWeight: 850,
  ...safeTextStyle,
};

const authorHighlightsTopFiveButtonStyle: CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  padding: "0 2px",
  border: "none",
  borderRadius: 0,
  background: "transparent",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "22px",
  lineHeight: 1,
  fontWeight: 900,
  textDecoration: "none",
  boxSizing: "border-box",
  flex: "0 0 auto",
};

const authorHighlightsListStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(5, 70px)",
  alignItems: "start",
  justifyContent: "center",
  columnGap: "3px",
  rowGap: "0",
  width: "100%",
  maxWidth: "100%",
  minWidth: 0,
  boxSizing: "border-box",
  overflow: "visible",
  padding: "0",
  margin: 0,
  scrollSnapType: "none",
  scrollbarWidth: "none",
  msOverflowStyle: "none",
  touchAction: "pan-y",
  overscrollBehaviorX: "none",
};

const desktopAuthorHighlightsListStyle: CSSProperties = {
  ...authorHighlightsListStyle,
  gridTemplateColumns: "repeat(5, 70px)",
  justifyContent: "center",
  columnGap: "3px",
  rowGap: "0",
  width: "100%",
  maxWidth: "100%",
  padding: "0",
  margin: 0,
};

const authorHighlightItemStyle: CSSProperties = {
  flex: "0 0 70px",
  width: "70px",
  minWidth: "70px",
  maxWidth: "70px",
  scrollSnapAlign: "none",
  display: "grid",
  justifyItems: "stretch",
  gap: "0",
  textDecoration: "none",
  color: "var(--historietas-text-primary, #FFFFFF)",
  boxSizing: "border-box",
};

const authorHighlightCoverStyle: CSSProperties = {
  width: "100%",
  aspectRatio: "70 / 99",
  minHeight: "0",
  borderRadius: "16px",
  position: "relative",
  overflow: "hidden",
  background: "var(--historietas-perfil-surface, #08030F)",
  backgroundSize: "cover",
  backgroundPosition: "center",
  border: "none",
  boxShadow: "none",
  boxSizing: "border-box",
};

const profileTabsStyle: CSSProperties = {
  width: "100%",
  display: "grid",
  gridTemplateColumns: "repeat(5, minmax(0, 1fr))",
  alignItems: "end",
  gap: 0,
  margin: "4px 0 0",
  padding: 0,
  minWidth: 0,
  maxWidth: "100%",
  background: "none",
  backgroundColor: "transparent",
  backgroundImage: "none",
  border: "none",
  borderRadius: 0,
  boxShadow: "none",
  outline: "none",
  overflow: "visible",
};

const profileTabStyle: CSSProperties = {
  appearance: "none",
  WebkitAppearance: "none",
  minHeight: "34px",
  border: "none",
  borderBottom: "2px solid transparent",
  borderRadius: 0,
  background: "none",
  backgroundColor: "transparent",
  backgroundImage: "none",
  boxShadow: "none",
  outline: "none",
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "clamp(9px, 2.45vw, 10.5px)",
  fontWeight: 950,
  fontFamily: "inherit",
  cursor: "pointer",
  textAlign: "center",
  padding: "0 3px",
  boxSizing: "border-box",
  ...safeTextStyle,
  whiteSpace: "nowrap",
  wordBreak: "normal",
  overflowWrap: "normal",
};

const profileTabActiveStyle: CSSProperties = {
  ...profileTabStyle,
  color: "var(--historietas-text-primary, #FFFFFF)",
  borderBottom: "2px solid currentColor",
};

const profileAboutBoxStyle: CSSProperties = {
  marginTop: "10px",
  padding: "8px 2px",
  display: "grid",
  gap: "7px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  textAlign: "center",
};

const profileAboutTitleStyle: CSSProperties = {
  margin: 0,
  color: "#FFFFFF",
  fontSize: "16px",
  lineHeight: 1.15,
  fontWeight: 950,
  letterSpacing: "-0.035em",
  ...safeTextStyle,
};

const profileAboutTextStyle: CSSProperties = {
  margin: 0,
  width: "100%",
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "11px",
  lineHeight: 1.4,
  fontWeight: 650,
  textAlign: "center",
  ...safeTextStyle,
};

const profileAboutTextRowStyle: CSSProperties = {
  width: "min(560px, 100%)",
  margin: "0 auto",
  display: "grid",
  gridTemplateColumns: "minmax(0, 1fr)",
  justifyItems: "center",
  alignItems: "start",
  gap: "7px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  position: "relative",
};

const profileAboutEditButtonStyle: CSSProperties = {
  appearance: "none",
  WebkitAppearance: "none",
  width: "24px",
  height: "24px",
  borderRadius: "999px",
  border: "none",
  background: "transparent",
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "12px",
  lineHeight: 1,
  fontWeight: 950,
  cursor: "pointer",
  fontFamily: "inherit",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  flex: "0 0 auto",
  position: "absolute",
  top: "-2px",
  right: 0,
};

const profileAboutEditorStyle: CSSProperties = {
  width: "min(560px, 100%)",
  margin: "0 auto",
  display: "grid",
  gap: "5px",
  minWidth: 0,
};

const profileAboutTextareaStyle: CSSProperties = {
  width: "100%",
  minHeight: "104px",
  resize: "vertical",
  borderRadius: "16px",
  border: "1px solid rgba(255,255,255,0.10)",
  background: "var(--historietas-perfil-surface, #08030F)",
  color: "#FFFFFF",
  padding: "10px 11px",
  outline: "none",
  fontSize: "11px",
  lineHeight: 1.45,
  fontWeight: 650,
  fontFamily: "inherit",
  boxSizing: "border-box",
  minWidth: 0,
  maxWidth: "100%",
  ...safeTextStyle,
};

const profileAboutCounterStyle: CSSProperties = {
  color: "var(--historietas-accent, var(--historietas-perfil-accent-soft, #FDBA74))",
  fontSize: "9px",
  fontWeight: 900,
  textAlign: "right",
  ...safeTextStyle,
};

const profileAboutStatsStyle: CSSProperties = {
  display: "flex",
  flexWrap: "wrap",
  alignItems: "center",
  justifyContent: "center",
  gap: "8px",
  color: "var(--historietas-accent, var(--historietas-perfil-accent-soft, #FDBA74))",
  fontSize: "10px",
  lineHeight: 1.25,
  fontWeight: 900,
  ...safeTextStyle,
};


const profileAboutHeroStyle: CSSProperties = {
  display: "grid",
  gap: "7px",
  justifyItems: "center",
  minWidth: 0,
};

const profileAboutEyebrowStyle: CSSProperties = {
  color: "var(--historietas-text-accent, var(--historietas-perfil-accent-soft, #FDBA74))",
  fontSize: "9.5px",
  lineHeight: 1.2,
  fontWeight: 950,
  letterSpacing: "0.13em",
  textTransform: "uppercase",
};

const profileAboutContentGridStyle: CSSProperties = {
  display: "grid",
  gap: "12px",
  minWidth: 0,
};

const profileAboutPanelStyle: CSSProperties = {
  display: "grid",
  gap: "8px",
  minWidth: 0,
  padding: 0,
  border: "none",
  background: "transparent",
  boxShadow: "none",
  boxSizing: "border-box",
};

const profileAboutPanelTitleStyle: CSSProperties = {
  color: "#FFFFFF",
  fontSize: "12px",
  lineHeight: 1.2,
  fontWeight: 950,
  textAlign: "left",
  ...safeTextStyle,
};

const profileAboutChipsStyle: CSSProperties = {
  display: "flex",
  flexWrap: "wrap",
  gap: "8px",
  minWidth: 0,
  color: "var(--historietas-text-secondary, #D4D4D8)",
};

const profileAboutChipStyle: CSSProperties = {
  minHeight: "auto",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  padding: 0,
  borderRadius: 0,
  border: "none",
  background: "transparent",
  color: "var(--historietas-text-secondary, #E4E4E7)",
  fontSize: "10.5px",
  fontWeight: 900,
  ...safeTextStyle,
};

const profileAboutMetricsGridStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
  gap: "6px",
  minWidth: 0,
};

const profileAboutMetricCardStyle: CSSProperties = {
  minWidth: 0,
  minHeight: "42px",
  display: "grid",
  alignContent: "center",
  justifyItems: "center",
  gap: "3px",
  borderRadius: "12px",
  border: "1px solid var(--historietas-border-soft, rgba(255,255,255,0.08))",
  background: "rgba(255,255,255,0.04)",
  padding: "7px 4px",
  boxSizing: "border-box",
};

const profileAboutMetricNumberStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "13px",
  lineHeight: 1,
  fontWeight: 950,
  ...safeTextStyle,
};

const profileAboutMetricLabelStyle: CSSProperties = {
  color: "var(--historietas-text-muted, #A1A1AA)",
  fontSize: "8px",
  lineHeight: 1.2,
  fontWeight: 850,
  textTransform: "lowercase",
  ...safeTextStyle,
};

const profileAboutRowsStyle: CSSProperties = {
  display: "grid",
  gap: "7px",
  minWidth: 0,
};

const profileAboutRowStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  gap: "10px",
  minHeight: "24px",
  padding: "0 2px",
  borderRadius: 0,
  background: "transparent",
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "10.5px",
  lineHeight: 1.2,
  fontWeight: 800,
  textAlign: "left",
  ...safeTextStyle,
};

const profileAboutMemberSinceStyle: CSSProperties = {
  margin: "5px 0 0",
  color: "var(--historietas-text-muted, #A1A1AA)",
  fontSize: "10px",
  lineHeight: 1.25,
  fontWeight: 800,
  textAlign: "center",
  ...safeTextStyle,
};

const filtersToggleButtonStyle: CSSProperties = {
  width: "100%",
  minHeight: "38px",
  marginBottom: "10px",
  borderRadius: "999px",
  border: "1px solid var(--historietas-border-soft, rgba(255,255,255,0.10))",
  background: "rgba(255,255,255,0.06)",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "11px",
  fontWeight: 950,
  fontFamily: "inherit",
  cursor: "pointer",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  gap: "8px",
  padding: "0 14px",
  boxSizing: "border-box",
  textAlign: "center",
};

const filtersToggleIconStyle: CSSProperties = {
  color: "#FFFFFF",
  fontSize: "15px",
  lineHeight: 1,
  fontWeight: 950,
};

const statsBoxStyle: CSSProperties = {
  marginTop: "12px",
  display: "grid",
  gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
  gap: "8px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const statCardStyle: CSSProperties = {
  display: "grid",
  justifyItems: "center",
  alignContent: "center",
  gap: "3px",
  minHeight: "64px",
  borderRadius: "16px",
  padding: "7px 4px",
  background: "rgba(255,255,255,0.05)",
  border: "1px solid var(--historietas-border-soft, rgba(255,255,255,0.075))",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  overflow: "hidden",
};

const statNumberStyle: CSSProperties = {
  color: "var(--historietas-accent, var(--historietas-perfil-accent-soft, #FDBA74))",
  fontSize: "22px",
  lineHeight: 1,
  fontWeight: 950,
  textAlign: "center",
  ...safeTextStyle,
};

const statLabelStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "8.5px",
  fontWeight: 950,
  textTransform: "uppercase",
  letterSpacing: "0.06em",
  textAlign: "center",
  ...safeTextStyle,
};

const authorCommunityBoxStyle: CSSProperties = {
  marginTop: "10px",
  padding: 0,
  borderRadius: 0,
  background: "transparent",
  border: "none",
  display: "grid",
  justifyItems: "center",
  gap: "8px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  textAlign: "center",
};

const authorCommunityIntroStyle: CSSProperties = {
  width: "100%",
  display: "grid",
  justifyItems: "center",
  gap: "5px",
  minWidth: 0,
};

const authorCommunityEyebrowStyle: CSSProperties = {
  color: "var(--historietas-text-accent, var(--historietas-perfil-accent-soft, #FDBA74))",
  fontSize: "9px",
  lineHeight: 1,
  fontWeight: 950,
  textTransform: "uppercase",
  letterSpacing: "0.12em",
  textAlign: "center",
  ...safeTextStyle,
};

const authorCommunityTitleStyle: CSSProperties = {
  margin: 0,
  color: "#FFFFFF",
  fontSize: "15px",
  lineHeight: 1.08,
  fontWeight: 950,
  textAlign: "center",
  ...safeTextStyle,
};

const diaryMainTitleStyle: CSSProperties = {
  ...authorCommunityTitleStyle,
  color: "#FFFFFF",
};

const diaryTitleToolbarStyle: CSSProperties = {
  width: "100%",
  position: "relative",
  display: "grid",
  justifyItems: "center",
  alignItems: "center",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  textAlign: "center",
};

const diaryMainReadingLinkStyle: CSSProperties = {
  position: "absolute",
  right: 0,
  top: "50%",
  transform: "translateY(-50%)",
  width: "22px",
  height: "22px",
  border: "none",
  background: "transparent",
  color: "var(--historietas-text-primary, #FFFFFF)",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  padding: 0,
  boxSizing: "border-box",
  cursor: "pointer",
  fontFamily: "inherit",
  fontSize: "18px",
  lineHeight: 1,
  fontWeight: 900,
  textDecoration: "none",
};

const authorCommunityDescriptionStyle: CSSProperties = {
  margin: 0,
  maxWidth: "460px",
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "10.5px",
  lineHeight: 1.35,
  fontWeight: 750,
  textAlign: "center",
  ...safeTextStyle,
};

const authorCommunityGridStyle: CSSProperties = {
  width: "100%",
  display: "grid",
  gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
  gap: "5px",
  minWidth: 0,
};

const authorCommunityStatsGridStyle: CSSProperties = {
  width: "100%",
  display: "grid",
  gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
  gap: "5px",
  minWidth: 0,
};

const authorCommunityDividerStyle: CSSProperties = {
  width: "100%",
  height: "1px",
  margin: "2px 0",
  background:
    "linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.10) 50%, transparent 100%)",
};

const authorCommunityCardStyle: CSSProperties = {
  minHeight: "48px",
  padding: "6px 4px",
  borderRadius: "16px",
  background: "var(--historietas-perfil-surface, #08030F)",
  border: "1px solid rgba(255,255,255,0.08)",
  color: "var(--historietas-text-primary, #FFFFFF)",
  textDecoration: "none",
  display: "grid",
  justifyItems: "center",
  alignContent: "center",
  gap: "3px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  boxShadow: "none",
};

const authorCommunityCardNumberStyle: CSSProperties = {
  color: "#FFFFFF",
  fontSize: "14px",
  lineHeight: 1,
  fontWeight: 950,
  textAlign: "center",
  ...safeTextStyle,
};

const authorCommunityCardTitleStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "9px",
  lineHeight: 1,
  fontWeight: 950,
  letterSpacing: "0.055em",
  textAlign: "center",
  ...safeTextStyle,
};

const authorCommunityCardTextStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "7.5px",
  lineHeight: 1.1,
  fontWeight: 950,
  textTransform: "uppercase",
  letterSpacing: "0.035em",
  textAlign: "center",
  ...safeTextStyle,
};

const authorCommunityPreviewStyle: CSSProperties = {
  width: "100%",
  padding: "9px",
  borderRadius: "18px",
  background: "var(--historietas-perfil-surface, #08030F)",
  border: "1px solid rgba(255,255,255,0.08)",
  display: "grid",
  gridTemplateColumns: "28px minmax(0, 1fr)",
  alignItems: "center",
  gap: "8px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  textAlign: "left",
};

const authorCommunityPreviewIconStyle: CSSProperties = {
  width: "28px",
  height: "28px",
  borderRadius: "12px",
  background: "rgba(255,255,255,0.06)",
  border: "1px solid var(--historietas-border-soft, rgba(255,255,255,0.08))",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: "13px",
  lineHeight: 1,
  flexShrink: 0,
};

const authorCommunityPreviewTextBlockStyle: CSSProperties = {
  display: "grid",
  gap: "3px",
  minWidth: 0,
};

const authorCommunityPreviewTitleStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "11px",
  lineHeight: 1.15,
  fontWeight: 950,
  ...safeTextStyle,
};

const authorCommunityPreviewTextStyle: CSSProperties = {
  margin: 0,
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "9.2px",
  lineHeight: 1.28,
  fontWeight: 750,
  ...safeTextStyle,
};

const authorCommunityPostsBlockStyle: CSSProperties = {
  width: "100%",
  display: "grid",
  gap: "7px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const authorCommunityPostsTitleStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "11px",
  lineHeight: 1.1,
  fontWeight: 950,
  textAlign: "left",
  ...safeTextStyle,
};

const authorCommunityPostsListStyle: CSSProperties = {
  width: "100%",
  display: "grid",
  gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
  gap: "8px",
  minWidth: 0,
  maxWidth: "100%",
  alignItems: "stretch",
};

const authorCommunityPostWrapperStyle: CSSProperties = {
  position: "relative",
  minWidth: 0,
  maxWidth: "100%",
  height: "100%",
};

const authorCommunityPostStyle: CSSProperties = {
  minHeight: "118px",
  height: "100%",
  padding: "10px",
  borderRadius: "17px",
  background: "var(--historietas-perfil-surface, #08030F)",
  border: "1px solid rgba(255,255,255,0.08)",
  color: "var(--historietas-text-primary, #FFFFFF)",
  textDecoration: "none",
  display: "grid",
  gridTemplateRows: "auto minmax(0, 1fr) auto",
  alignContent: "stretch",
  gap: "7px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  textAlign: "left",
};

const authorCommunityPostReportButtonStyle: CSSProperties = {
  position: "absolute",
  right: "9px",
  bottom: "8px",
  minHeight: "27px",
  border: "1px solid rgba(251,113,133,0.28)",
  borderRadius: "999px",
  padding: "5px 9px",
  background: "rgba(159,18,57,0.16)",
  color: "#FDA4AF",
  font: "inherit",
  fontSize: "8px",
  lineHeight: 1,
  fontWeight: 900,
  cursor: "pointer",
  zIndex: 2,
};

const authorCommunityPostHeaderStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  gap: "8px",
  minWidth: 0,
  paddingBottom: "6px",
  borderBottom: "1px solid rgba(255,255,255,0.06)",
};

const authorCommunityPostTypeStyle: CSSProperties = {
  color: "var(--historietas-accent, var(--historietas-perfil-accent-soft, #FDBA74))",
  fontSize: "9px",
  lineHeight: 1,
  fontWeight: 950,
  textTransform: "uppercase",
  letterSpacing: "0.055em",
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
};

const authorCommunityPostDateStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "8px",
  lineHeight: 1,
  fontWeight: 800,
  flexShrink: 0,
};

const authorCommunityPostBodyStyle: CSSProperties = {
  minWidth: 0,
  display: "grid",
  alignContent: "start",
  gap: "6px",
  paddingTop: "1px",
};

const authorCommunityPostTextStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #F4F4F5)",
  fontSize: "10px",
  lineHeight: 1.38,
  fontWeight: 800,
  overflow: "hidden",
  display: "-webkit-box",
  WebkitLineClamp: 3,
  WebkitBoxOrient: "vertical",
  ...safeTextStyle,
};

const authorCommunityPostPollInfoStyle: CSSProperties = {
  width: "fit-content",
  maxWidth: "100%",
  display: "inline-flex",
  alignItems: "center",
  gap: "5px",
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "8px",
  lineHeight: 1.1,
  fontWeight: 850,
  whiteSpace: "nowrap",
};

const authorCommunityPostWorkStyle: CSSProperties = {
  marginTop: "auto",
  paddingTop: "6px",
  borderTop: "1px solid rgba(255,255,255,0.06)",
  display: "flex",
  alignItems: "center",
  gap: "5px",
  minWidth: 0,
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "8px",
  lineHeight: 1.1,
  fontWeight: 900,
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
};

const authorCommunityActionsStyle: CSSProperties = {
  width: "100%",
  display: "grid",
  gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
  gap: "6px",
  minWidth: 0,
};

const authorCommunityPrimaryActionStyle: CSSProperties = {
  gridColumn: "1 / -1",
  minHeight: "34px",
  padding: "0 14px",
  borderRadius: "999px",
  background: "var(--historietas-perfil-surface, #08030F)",
  border: "1px solid rgba(255,255,255,0.10)",
  color: "#FFFFFF",
  textDecoration: "none",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: "12px",
  lineHeight: 1,
  fontWeight: 950,
  textAlign: "center",
  boxShadow: "none",
  ...safeTextStyle,
};

const authorCommunitySecondaryActionStyle: CSSProperties = {
  minHeight: "30px",
  padding: "0 10px",
  borderRadius: "999px",
  background: "var(--historietas-perfil-surface, #08030F)",
  border: "1px solid rgba(255,255,255,0.10)",
  color: "#FFFFFF",
  textDecoration: "none",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: "10px",
  lineHeight: 1,
  fontWeight: 900,
  textAlign: "center",
  boxShadow: "none",
  ...safeTextStyle,
};

const authorCommunityStatNumberStyle: CSSProperties = {
  color: "var(--historietas-accent, var(--historietas-perfil-accent-soft, #FDBA74))",
  fontSize: "14.5px",
  lineHeight: 1,
  fontWeight: 950,
  textAlign: "center",
  ...safeTextStyle,
};

const authorCommunityStatTextStyle: CSSProperties = {
  ...authorCommunityCardTextStyle,
  fontSize: "9px",
};

const authorsBoxStyle: CSSProperties = {
  marginTop: "12px",
  padding: "12px",
  borderRadius: "22px",
  background: "var(--historietas-surface, var(--historietas-perfil-surface, #08030F))",
  border: "1px solid var(--historietas-border-soft, rgba(255,255,255,0.08))",
  display: "grid",
  gap: "9px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  overflow: "hidden",
};

const authorsListStyle: CSSProperties = {
  display: "flex",
  flexWrap: "wrap",
  gap: "7px",
  minWidth: 0,
  maxWidth: "100%",
};

const authorButtonStyle: CSSProperties = {
  flex: "1 1 132px",
  minHeight: "34px",
  maxWidth: "100%",
  padding: "0 11px",
  borderRadius: "999px",
  background: "rgba(255,255,255,0.06)",
  border: "1px solid var(--historietas-border-soft, rgba(255,255,255,0.10))",
  color: "var(--historietas-text-primary, #FFFFFF)",
  textDecoration: "none",
  fontSize: "11px",
  fontWeight: 900,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  textAlign: "center",
  boxSizing: "border-box",
  whiteSpace: "normal",
  ...safeTextStyle,
};

const activeAuthorButtonStyle: CSSProperties = {
  ...authorButtonStyle,
  background: "var(--historietas-perfil-surface, #08030F)",
  border:
    "1px solid rgba(255,255,255,0.10)",
  color: "var(--historietas-text-primary, #FFFFFF)",
};

const sectionStyle: CSSProperties = {
  marginTop: "16px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const sectionHeaderStyle: CSSProperties = {
  display: "grid",
  justifyItems: "center",
  marginBottom: "12px",
  minWidth: 0,
  textAlign: "center",
};

const miniTitleStyle: CSSProperties = {
  display: "inline-flex",
  color: "var(--historietas-accent, var(--historietas-perfil-accent-soft, #FDBA74))",
  fontSize: "13px",
  fontWeight: 950,
  letterSpacing: "0.09em",
  marginBottom: "4px",
  maxWidth: "100%",
  ...safeTextStyle,
};

const sectionTitleStyle: CSSProperties = {
  margin: 0,
  color: "var(--historietas-accent, var(--historietas-perfil-accent-soft, #FDBA74))",
  fontSize: "28px",
  lineHeight: 1.12,
  fontWeight: 950,
  letterSpacing: "-0.06em",
  maxWidth: "100%",
  textAlign: "center",
  ...safeTextStyle,
};

const sectionFilterTextStyle: CSSProperties = {
  margin: "6px auto 0",
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "12px",
  lineHeight: 1.5,
  fontWeight: 800,
  maxWidth: "100%",
  textAlign: "center",
  ...safeTextStyle,
};

const filterBoxStyle: CSSProperties = {
  display: "grid",
  gap: "8px",
  padding: "10px",
  marginBottom: "12px",
  borderRadius: "18px",
  background: "var(--historietas-surface, var(--historietas-perfil-surface, #08030F))",
  border: "1px solid var(--historietas-border-soft, rgba(255,255,255,0.08))",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  overflow: "hidden",
};

const filterInputStyle: CSSProperties = {
  width: "100%",
  minHeight: "40px",
  borderRadius: "999px",
  border: "1px solid var(--historietas-border-soft, rgba(255,255,255,0.08))",
  background: "var(--historietas-input-bg, var(--historietas-perfil-bg-deep, #04000A))",
  color: "var(--historietas-input-text, #FFFFFF)",
  padding: "0 13px",
  outline: "none",
  fontSize: "12px",
  fontWeight: 750,
  fontFamily: "inherit",
  textAlign: "center",
  boxSizing: "border-box",
  minWidth: 0,
};

const filterGridStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "1fr",
  gap: "8px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const filterSelectStyle: CSSProperties = {
  width: "100%",
  minHeight: "40px",
  borderRadius: "999px",
  border: "1px solid var(--historietas-border-soft, rgba(255,255,255,0.08))",
  background: "var(--historietas-input-bg, var(--historietas-perfil-bg-deep, #04000A))",
  color: "var(--historietas-input-text, #FFFFFF)",
  padding: "0 13px",
  outline: "none",
  fontSize: "12px",
  fontWeight: 750,
  fontFamily: "inherit",
  textAlign: "center",
  textAlignLast: "center",
  boxSizing: "border-box",
  minWidth: 0,
};

const clearFilterButtonStyle: CSSProperties = {
  width: "100%",
  minHeight: "40px",
  borderRadius: "999px",
  border: "1px solid var(--historietas-border-soft, rgba(255,255,255,0.11))",
  background: "rgba(255,255,255,0.06)",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "12px",
  fontWeight: 900,
  cursor: "pointer",
  fontFamily: "inherit",
  textAlign: "center",
  padding: "0 12px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  whiteSpace: "normal",
  ...safeTextStyle,
};

const profileWorksSectionStyle: CSSProperties = {
  marginTop: "10px",
  display: "grid",
  gap: "10px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const profileWorksToolbarStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  gap: "8px",
  flexWrap: "wrap",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const profileWorksSummaryStyle: CSSProperties = {
  margin: 0,
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "11px",
  lineHeight: 1.35,
  fontWeight: 850,
  minWidth: 0,
  ...safeTextStyle,
};

const profileWorksFilterButtonStyle: CSSProperties = {
  minHeight: "28px",
  padding: "0",
  borderRadius: 0,
  border: 0,
  background: "transparent",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "11px",
  fontWeight: 950,
  fontFamily: "inherit",
  cursor: "pointer",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  gap: "7px",
  boxSizing: "border-box",
};

const profileWorksGridStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
  columnGap: "10px",
  rowGap: "14px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const desktopProfileWorksGridStyle: CSSProperties = {
  ...profileWorksGridStyle,
  gridTemplateColumns: "repeat(6, minmax(0, 1fr))",
  columnGap: "12px",
  rowGap: "18px",
};

const profileWorkCardStyle: CSSProperties = {
  display: "grid",
  gap: 0,
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  overflow: "visible",
  position: "relative",
  border: "0",
  borderBottom: "0",
  outline: "none",
  boxShadow: "none",
  background: "transparent",
};

const profileWorkCoverLinkStyle: CSSProperties = {
  display: "block",
  textDecoration: "none",
  textDecorationLine: "none",
  color: "var(--historietas-text-primary, #FFFFFF)",
  minWidth: 0,
  maxWidth: "100%",
  border: "0",
  borderBottom: "0",
  outline: "none",
  boxShadow: "none",
  background: "transparent",
};

const profileWorkCoverStyle: CSSProperties = {
  width: "100%",
  aspectRatio: "3 / 4",
  minHeight: "180px",
  borderRadius: "18px",
  position: "relative",
  overflow: "hidden",
  background: "var(--historietas-perfil-surface, #08030F)",
  backgroundSize: "cover",
  backgroundPosition: "center",
  border: "0",
  outline: "none",
  boxSizing: "border-box",
  boxShadow: "none",
};

const desktopProfileWorkCoverStyle: CSSProperties = {
  ...profileWorkCoverStyle,
  minHeight: "240px",
  borderRadius: "20px",
};

const profileWorkCoverOverlayStyle: CSSProperties = {
  position: "absolute",
  left: 0,
  right: 0,
  bottom: 0,
  padding: "28px 42px 9px 10px",
  display: "grid",
  gap: "4px",
  background:
    "linear-gradient(180deg, var(--historietas-perfil-surface-fade-0, rgba(8,5,13,0)) 0%, var(--historietas-perfil-surface-fade-58, rgba(8,5,13,0.58)) 44%, var(--historietas-perfil-surface-fade-92, rgba(8,5,13,0.92)) 100%)",
  boxSizing: "border-box",
  zIndex: 1,
  minWidth: 0,
};

const profileWorkCoverTitleStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "13px",
  lineHeight: 1.06,
  ...homeCardTitleTypographyStyle,
  textShadow: "none",
  display: "-webkit-box",
  WebkitLineClamp: 2,
  WebkitBoxOrient: "vertical",
  overflow: "hidden",
  ...safeTextStyle,
};

const profileWorkCoverMetaStyle: CSSProperties = {
  color: "rgba(244,244,245,0.86)",
  fontSize: "9px",
  lineHeight: 1.18,
  ...homeCardStatsTypographyStyle,
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
  letterSpacing: "-0.01em",
  textShadow: "none",
  minWidth: 0,
};

const diaryCardCoverOverlayStyle: CSSProperties = {
  ...profileWorkCoverOverlayStyle,
  padding: "28px 42px 9px 10px",
  justifyItems: "start",
  textAlign: "left",
};

const diaryCardCoverTitleStyle: CSSProperties = {
  ...profileWorkCoverTitleStyle,
  width: "100%",
  textAlign: "left",
};

const diaryCardCoverMetaStyle: CSSProperties = {
  ...profileWorkCoverMetaStyle,
  width: "100%",
  display: "flex",
  alignItems: "center",
  justifyContent: "flex-start",
  gap: "10px",
  color: "#FFFFFF",
  textAlign: "left",
};

const diaryCardHeartMetaStyle: CSSProperties = {
  color: "var(--historietas-perfil-danger, #EF4444)",
  fontWeight: 950,
};

const diaryCardCommentMetaStyle: CSSProperties = {
  color: "rgba(255,255,255,0.92)",
  fontWeight: 950,
};

const profileWorkSmallActionHintStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "9px",
  lineHeight: 1.2,
  fontWeight: 850,
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
  minWidth: 0,
  letterSpacing: "-0.01em",
};

const profileWorkInfoStyle: CSSProperties = {
  display: "grid",
  gap: "3px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  padding: "0 1px",
};

const profileWorkTitleStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "12.75px",
  lineHeight: 1.08,
  ...homeCardTitleTypographyStyle,
  display: "-webkit-box",
  WebkitLineClamp: 2,
  WebkitBoxOrient: "vertical",
  overflow: "hidden",
  textDecoration: "none",
  ...safeTextStyle,
};

const profileWorkTitleLinkStyle: CSSProperties = {
  ...profileWorkTitleStyle,
};

const profileWorkMetaRowStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "minmax(0, 1fr) 22px",
  alignItems: "center",
  gap: "5px",
  minWidth: 0,
  maxWidth: "100%",
  position: "relative",
};

const profileWorkMetaStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "9.1px",
  ...homeCardMetaTypographyStyle,
  lineHeight: 1.2,
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
  minWidth: 0,
  letterSpacing: "-0.01em",
};

const profileWorkHeartMetaStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontWeight: 950,
};

const profileWorkHeartIconMetaStyle: CSSProperties = {
  color: "var(--historietas-perfil-danger, #EF4444)",
  fontWeight: 950,
};

const profileWorkViewsMetaStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontWeight: 950,
};

const profileWorkMenuAnchorStyle: CSSProperties = {
  position: "absolute",
  right: "8px",
  bottom: "8px",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  minWidth: "24px",
  height: "24px",
  zIndex: 8,
};

const profileWorkDotsButtonStyle: CSSProperties = {
  width: "24px",
  height: "24px",
  border: "none",
  borderRadius: 0,
  background: "transparent",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "21px",
  lineHeight: 1,
  fontWeight: 950,
  fontFamily: "inherit",
  cursor: "pointer",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  padding: 0,
  margin: 0,
  flexShrink: 0,
};

const profileWorkOptionsMenuStyle: CSSProperties = {
  position: "absolute",
  right: "calc(100% + 6px)",
  top: "4px",
  zIndex: 45,
  width: "184px",
  minWidth: "184px",
  maxWidth: "calc(100vw - 36px)",
  padding: "5px",
  borderRadius: "13px",
  border: "1px solid var(--historietas-border-soft, rgba(255,255,255,0.08))",
  background: "var(--historietas-perfil-bg-page, #070212)",
  boxShadow: "none",
  display: "flex",
  flexDirection: "column",
  alignItems: "stretch",
  justifyContent: "flex-start",
  gap: "1px",
  whiteSpace: "nowrap",
  boxSizing: "border-box",
  overflow: "visible",
};

const profileWorkMenuItemStyle: CSSProperties = {
  width: "100%",
  minWidth: 0,
  minHeight: "30px",
  border: "none",
  borderRadius: "9px",
  background: "transparent",
  color: "var(--historietas-text-primary, #FFFFFF)",
  textDecoration: "none",
  fontSize: "11.5px",
  lineHeight: 1,
  fontWeight: 850,
  fontFamily: "inherit",
  cursor: "pointer",
  display: "flex",
  alignItems: "center",
  justifyContent: "flex-start",
  textAlign: "left",
  whiteSpace: "nowrap",
  overflowWrap: "normal",
  wordBreak: "normal",
  overflow: "visible",
  textOverflow: "clip",
  padding: "0 9px",
  boxSizing: "border-box",
  flexShrink: 0,
};

const profileWorkMenuItemActiveStyle: CSSProperties = {
  ...profileWorkMenuItemStyle,
  color: "var(--historietas-accent, var(--historietas-perfil-accent-soft, #FDBA74))",
};

const profileWorkActionsCompactStyle: CSSProperties = {
  display: "none",
};

const profileWorkActionButtonStyle: CSSProperties = {
  minHeight: "21px",
  borderRadius: "999px",
  border: "1px solid var(--historietas-border-soft, rgba(255,255,255,0.10))",
  background: "var(--historietas-secondary-surface, rgba(255,255,255,0.05))",
  color: "var(--historietas-text-primary, #FFFFFF)",
  textDecoration: "none",
  fontSize: "8px",
  fontWeight: 950,
  fontFamily: "inherit",
  cursor: "pointer",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  textAlign: "center",
  padding: "0 7px",
  boxSizing: "border-box",
  ...safeTextStyle,
};

const profileWorkActionActiveStyle: CSSProperties = {
  ...profileWorkActionButtonStyle,
  background: "var(--historietas-accent, var(--historietas-perfil-accent, #F97316))",
  border:
    "1px solid rgba(255,255,255,0.10)",
  color: "#FFFFFF",
};

const profileWorkOwnerActionStyle: CSSProperties = {
  ...profileWorkActionButtonStyle,
  background: "rgba(255,255,255,0.06)",
  color: "var(--historietas-text-primary, #FFFFFF)",
};

const profileWorkActionDisabledStyle: CSSProperties = {
  ...profileWorkActionButtonStyle,
  opacity: 0.58,
  cursor: "default",
};

const worksGridStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "1fr",
  gap: "10px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const workCardStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "minmax(86px, 102px) minmax(0, 1fr)",
  alignItems: "stretch",
  gap: "10px",
  padding: "10px",
  borderRadius: "22px",
  background: "var(--historietas-surface, var(--historietas-perfil-surface, #08030F))",
  border: "1px solid var(--historietas-border-soft, rgba(255,255,255,0.08))",
  boxShadow: "none",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  overflow: "hidden",
};

const coverLinkStyle: CSSProperties = {
  display: "flex",
  alignSelf: "stretch",
  height: "100%",
  textDecoration: "none",
  color: "var(--historietas-text-primary, #FFFFFF)",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const coverStyle: CSSProperties = {
  width: "100%",
  height: "100%",
  minHeight: "132px",
  borderRadius: "17px",
  position: "relative",
  overflow: "hidden",
  background:
    "var(--historietas-perfil-surface, #08030F)",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const genreBadgeStyle: CSSProperties = {
  width: "fit-content",
  maxWidth: "100%",
  padding: "4px 6px",
  borderRadius: "999px",
  background:
    "rgba(255,255,255,0.06)",
  border:
    "1px solid rgba(255,255,255,0.08)",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "8px",
  fontWeight: 950,
  ...safeTextStyle,
};

const coverBottomStyle: CSSProperties = {
  position: "absolute",
  left: "10px",
  right: "10px",
  bottom: "10px",
  display: "flex",
  alignItems: "flex-end",
  justifyContent: "space-between",
  gap: "8px",
  minWidth: 0,
  maxWidth: "100%",
};

const coverNumberStyle: CSSProperties = {
  color: "#FFFFFF",
  fontSize: "37px",
  lineHeight: 0.85,
  fontWeight: 950,
  letterSpacing: "-0.08em",
  ...safeTextStyle,
};

const coverLabelStyle: CSSProperties = {
  color: "#FFFFFF",
  fontSize: "8px",
  fontWeight: 950,
  textTransform: "uppercase",
  letterSpacing: "0.06em",
  textAlign: "right",
  ...safeTextStyle,
};

const workContentStyle: CSSProperties = {
  display: "grid",
  alignContent: "start",
  gap: "7px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const statusRowStyle: CSSProperties = {
  display: "flex",
  flexWrap: "wrap",
  gap: "5px",
  minWidth: 0,
  maxWidth: "100%",
};

const publishedStatusStyle: CSSProperties = {
  width: "fit-content",
  maxWidth: "100%",
  padding: "4px 6px",
  borderRadius: "999px",
  background:
    "var(--historietas-perfil-success-10, rgba(34,197,94,0.10))",
  border:
    "1px solid var(--historietas-perfil-success-22, rgba(34,197,94,0.22))",
  color:
    "var(--historietas-perfil-success-soft, #86EFAC)",
  fontSize: "8px",
  fontWeight: 950,
  ...safeTextStyle,
};

const draftStatusStyle: CSSProperties = {
  ...publishedStatusStyle,
  background:
    "rgba(255,255,255,0.06)",
  border:
    "1px solid rgba(255,255,255,0.08)",
  color: "var(--historietas-accent, var(--historietas-perfil-accent-soft, #FDBA74))",
};

const formatBadgeStyle: CSSProperties = {
  ...publishedStatusStyle,
  background: "rgba(255,255,255,0.06)",
  border: "1px solid var(--historietas-border-soft, rgba(255,255,255,0.09))",
  color: "var(--historietas-text-primary, #E4E4E7)",
};

const classificationBadgeStyle: CSSProperties = {
  ...publishedStatusStyle,
  background:
    "rgba(255,255,255,0.06)",
  border:
    "1px solid rgba(255,255,255,0.08)",
  color: "var(--historietas-secondary, var(--historietas-perfil-lavender-text, #DDD6FE))",
};

const favoriteBadgeStyle: CSSProperties = {
  ...publishedStatusStyle,
  background:
    "rgba(255,255,255,0.06)",
  border:
    "1px solid rgba(255,255,255,0.08)",
  color: "var(--historietas-accent, var(--historietas-perfil-accent-soft, #FDBA74))",
};

const completedBadgeStyle: CSSProperties = {
  ...publishedStatusStyle,
  background:
    "var(--historietas-perfil-success-10, rgba(34,197,94,0.10))",
  border:
    "1px solid var(--historietas-perfil-success-22, rgba(34,197,94,0.22))",
  color:
    "var(--historietas-perfil-success-soft, #86EFAC)",
};

const workTitleStyle: CSSProperties = {
  margin: 0,
  fontSize: "22px",
  lineHeight: 1.12,
  ...homeCardTitleTypographyStyle,
  maxWidth: "100%",
  ...safeTextStyle,
};

const workTextStyle: CSSProperties = {
  margin: 0,
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "11px",
  ...homeCardMetaTypographyStyle,
  lineHeight: 1.4,
  maxWidth: "100%",
  display: "-webkit-box",
  WebkitLineClamp: 1,
  WebkitBoxOrient: "vertical",
  overflow: "hidden",
  ...safeTextStyle,
};

const workStatsStyle: CSSProperties = {
  display: "flex",
  flexWrap: "wrap",
  gap: "5px",
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "9px",
  ...homeCardStatsTypographyStyle,
  minWidth: 0,
  maxWidth: "100%",
};

const workProgressBoxStyle: CSSProperties = {
  display: "grid",
  gap: "5px",
  minWidth: 0,
  maxWidth: "100%",
};

const workProgressTrackStyle: CSSProperties = {
  height: "6px",
  borderRadius: "999px",
  overflow: "hidden",
  background: "rgba(255,255,255,0.06)",
};

const workProgressFillStyle: CSSProperties = {
  height: "100%",
  borderRadius: "999px",
  background:
    "linear-gradient(90deg, var(--historietas-accent, var(--historietas-perfil-accent, #F97316)) 0%, var(--historietas-secondary, var(--historietas-perfil-secondary, #7C3AED)) 100%)",
};

const workProgressTextStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "9px",
  fontWeight: 850,
  ...safeTextStyle,
};

const workActionsGridStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(108px, 1fr))",
  gap: "5px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const openButtonStyle: CSSProperties = {
  minHeight: "32px",
  borderRadius: "999px",
  border: "1px solid rgba(255,255,255,0.10)",
  background: "var(--historietas-perfil-surface, #08030F)",
  color: "#FFFFFF",
  textDecoration: "none",
  fontSize: "10px",
  fontWeight: 950,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  textAlign: "center",
  padding: "0 8px",
  lineHeight: 1.15,
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  whiteSpace: "normal",
  ...safeTextStyle,
};

const readButtonStyle: CSSProperties = {
  ...openButtonStyle,
  background: "var(--historietas-perfil-surface, #08030F)",
};

const smallButtonStyle: CSSProperties = {
  minHeight: "30px",
  borderRadius: "999px",
  border: "1px solid var(--historietas-border-soft, rgba(255,255,255,0.10))",
  background: "rgba(255,255,255,0.06)",
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "10px",
  fontWeight: 900,
  cursor: "pointer",
  fontFamily: "inherit",
  textAlign: "center",
  padding: "0 8px",
  lineHeight: 1.15,
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  whiteSpace: "normal",
  ...safeTextStyle,
};

const smallButtonActiveStyle: CSSProperties = {
  ...smallButtonStyle,
  border:
    "1px solid rgba(255,255,255,0.10)",
  background:
    "rgba(255,255,255,0.06)",
  color: "var(--historietas-accent, var(--historietas-perfil-accent-soft, #FDBA74))",
};

const desktopContainerStyle: CSSProperties = {
  ...containerStyle,
  width: "min(1180px, calc(100% - 48px))",
  padding: "24px 0 64px",
};

const desktopHeroBoxStyle: CSSProperties = {
  ...heroBoxStyle,
  padding: "15px 20px",
  borderRadius: "24px",
};

const desktopAuthorTopRowStyle: CSSProperties = {
  ...authorTopRowStyle,
  gridTemplateColumns: "132px minmax(0, 1fr)",
  gap: "22px",
  minHeight: "132px",
};

const desktopAvatarBaseStyle: CSSProperties = {
  ...avatarBaseStyle,
  width: "132px",
  maxWidth: "132px",
  height: "132px",
  borderRadius: "32px",
  fontSize: "54px",
};

const desktopAvatarButtonStyle: CSSProperties = {
  ...desktopAvatarBaseStyle,
  cursor: "pointer",
};

const desktopAvatarDisplayStyle: CSSProperties = {
  ...desktopAvatarBaseStyle,
  cursor: "default",
};

const desktopTitleStyle: CSSProperties = {
  ...titleStyle,
  fontSize: "clamp(31px, 3.4vw, 43px)",
  lineHeight: 1.18,
  paddingRight: "8px",
  paddingBottom: 0,
  overflow: "visible",
};

const desktopDescriptionStyle: CSSProperties = {
  ...descriptionStyle,
  fontSize: "14px",
  lineHeight: 1.58,
  width: "min(520px, 100%)",
  maxWidth: "520px",
  display: "block",
  WebkitLineClamp: "unset",
  overflow: "visible",
};

const desktopAvatarActionsStyle: CSSProperties = {
  ...avatarActionsStyle,
  maxWidth: "420px",
};

const desktopAvatarSmallButtonStyle: CSSProperties = {
  ...avatarSmallButtonStyle,
  flex: "0 0 auto",
  minWidth: "150px",
  minHeight: "34px",
  fontSize: "11px",
};

const desktopAvatarRemoveButtonStyle: CSSProperties = {
  ...desktopAvatarSmallButtonStyle,
};

const desktopStatsBoxStyle: CSSProperties = {
  ...statsBoxStyle,
  gridTemplateColumns: "repeat(6, minmax(0, 1fr))",
  gap: "10px",
  marginTop: "14px",
};

const desktopStatCardStyle: CSSProperties = {
  ...statCardStyle,
  minHeight: "82px",
  padding: "12px",
  borderRadius: "18px",
};

const desktopAuthorCommunityBoxStyle: CSSProperties = {
  ...authorCommunityBoxStyle,
  marginTop: "14px",
  gap: "9px",
};

const desktopAuthorCommunityGridStyle: CSSProperties = {
  ...authorCommunityGridStyle,
  gap: "8px",
};

const desktopAuthorCommunityPostsListStyle: CSSProperties = {
  ...authorCommunityPostsListStyle,
  gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
  gap: "10px",
};

const desktopAuthorCommunityStatsGridStyle: CSSProperties = {
  ...authorCommunityStatsGridStyle,
  gap: "8px",
};

const desktopAuthorCommunityActionsStyle: CSSProperties = {
  ...authorCommunityActionsStyle,
  gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
  gap: "8px",
};

const desktopAuthorsBoxStyle: CSSProperties = {
  ...authorsBoxStyle,
  padding: "16px",
  borderRadius: "24px",
};

const desktopAuthorsListStyle: CSSProperties = {
  ...authorsListStyle,
  alignItems: "center",
};

const desktopAuthorButtonStyle: CSSProperties = {
  ...authorButtonStyle,
  flex: "0 1 auto",
  minWidth: "150px",
  maxWidth: "260px",
};

const desktopActiveAuthorButtonStyle: CSSProperties = {
  ...desktopAuthorButtonStyle,
  background: "var(--historietas-perfil-surface, #08030F)",
  border:
    "1px solid rgba(255,255,255,0.10)",
  color: "#FFFFFF",
};

const desktopSectionHeaderStyle: CSSProperties = {
  ...sectionHeaderStyle,
  marginBottom: "14px",
};

const desktopFilterBoxStyle: CSSProperties = {
  ...filterBoxStyle,
  gridTemplateColumns: "minmax(280px, 1fr) minmax(360px, 0.9fr) auto",
  alignItems: "center",
  gap: "12px",
  padding: "14px",
};

const desktopFilterGridStyle: CSSProperties = {
  ...filterGridStyle,
  gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
};

const desktopClearFilterButtonStyle: CSSProperties = {
  ...clearFilterButtonStyle,
  width: "auto",
  minWidth: "150px",
};

const desktopWorksGridStyle: CSSProperties = {
  ...worksGridStyle,
  gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
  gap: "14px",
  alignItems: "stretch",
};

const desktopWorkCardStyle: CSSProperties = {
  ...workCardStyle,
  gridTemplateColumns: "minmax(126px, 146px) minmax(0, 1fr)",
  gap: "14px",
  padding: "12px",
  borderRadius: "24px",
  background: "var(--historietas-surface, var(--historietas-perfil-surface, #08030F))",
  boxShadow: "none",
};

const desktopWorkContentStyle: CSSProperties = {
  ...workContentStyle,
  gap: "9px",
};

const desktopWorkTitleStyle: CSSProperties = {
  ...workTitleStyle,
  fontSize: "26px",
  lineHeight: 1.12,
};

const desktopWorkTextStyle: CSSProperties = {
  ...workTextStyle,
  fontSize: "12px",
  lineHeight: 1.5,
  WebkitLineClamp: 2,
};

const desktopWorkActionsGridStyle: CSSProperties = {
  ...workActionsGridStyle,
  gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
  gap: "7px",
};

const diaryBoxStyle: CSSProperties = {
  width: "100%",
  marginTop: "8px",
  padding: "8px 0 138px",
  display: "grid",
  justifyItems: "stretch",
  alignItems: "stretch",
  gap: "8px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  textAlign: "center",
};


const diarySectionStyle: CSSProperties = {
  width: "100%",
  display: "grid",
  gap: "8px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const diaryCollapsibleHeaderStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  flexWrap: "wrap",
  gap: "9px",
  minWidth: 0,
  maxWidth: "100%",
  textAlign: "center",
};

const diaryToggleButtonStyle: CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  gap: "5px",
  minHeight: "auto",
  padding: 0,
  borderRadius: 0,
  border: "none",
  background: "transparent",
  color: "#FFFFFF",
  fontSize: "11px",
  lineHeight: 1,
  fontWeight: 950,
  letterSpacing: "0.01em",
  cursor: "pointer",
  boxSizing: "border-box",
  ...safeTextStyle,
};

const diaryToggleButtonIconStyle: CSSProperties = {
  color: "#FFFFFF",
  fontSize: "13px",
  lineHeight: 1,
  fontWeight: 950,
};

const diarySectionTitleStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "13px",
  lineHeight: 1.15,
  fontWeight: 950,
  textAlign: "center",
  ...safeTextStyle,
};

const diaryEmptyStateStyle: CSSProperties = {
  width: "100%",
  margin: "0",
  padding: "2px 0",
  background: "transparent",
  border: "0",
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "11px",
  lineHeight: 1.45,
  fontWeight: 750,
  textAlign: "center",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  ...safeTextStyle,
};

const diaryTimelineStyle: CSSProperties = {
  ...diarySectionStyle,
};

const diaryTimelineListStyle: CSSProperties = {
  display: "grid",
  gap: "6px",
  minWidth: 0,
  maxWidth: "100%",
};

const diaryTimelineItemStyle: CSSProperties = {
  display: "grid",
  gridTemplateColumns: "auto minmax(0, 1fr) auto",
  alignItems: "center",
  gap: "7px",
  padding: "8px 9px",
  borderRadius: "16px",
  background: "rgba(255,255,255,0.035)",
  border: "1px solid var(--historietas-border-soft, rgba(255,255,255,0.07))",
  color: "var(--historietas-text-primary, #FFFFFF)",
  textDecoration: "none",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
};

const diaryTimelineDotStyle: CSSProperties = {
  width: "7px",
  height: "7px",
  borderRadius: "999px",
  background: "var(--historietas-accent, var(--historietas-perfil-accent, #F97316))",
};

const diaryTimelineTextStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #D4D4D8)",
  fontSize: "10px",
  lineHeight: 1.25,
  fontWeight: 750,
  textAlign: "left",
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
  ...safeTextStyle,
};

const diaryTimelineDateStyle: CSSProperties = {
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "8px",
  lineHeight: 1,
  fontWeight: 850,
  textAlign: "right",
  whiteSpace: "nowrap",
  ...safeTextStyle,
};

const desktopDiaryBoxStyle: CSSProperties = {
  ...diaryBoxStyle,
  padding: "12px 12px 28px",
  gap: "10px",
};

const emptyBoxStyle: CSSProperties = {
  marginTop: "20px",
  borderRadius: "24px",
  background: "var(--historietas-surface, var(--historietas-perfil-surface, #08030F))",
  border: "1px dashed var(--historietas-border-soft, rgba(255,255,255,0.14))",
  padding: "22px",
  display: "grid",
  gap: "10px",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  overflow: "hidden",
};

const emptyTitleStyle: CSSProperties = {
  margin: 0,
  color: "var(--historietas-accent, var(--historietas-perfil-accent, #F97316))",
  fontSize: "28px",
  fontWeight: 950,
  letterSpacing: "-0.055em",
  ...safeTextStyle,
};

const emptyTextStyle: CSSProperties = {
  margin: 0,
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "12px",
  lineHeight: 1.55,
  fontWeight: 700,
  ...safeTextStyle,
};

const emptyButtonStyle: CSSProperties = {
  width: "100%",
  minHeight: "42px",
  padding: "0 14px",
  borderRadius: "999px",
  border: "1px solid rgba(255,255,255,0.10)",
  background: "var(--historietas-perfil-surface, #08030F)",
  color: "#FFFFFF",
  textDecoration: "none",
  fontSize: "12px",
  fontWeight: 950,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  textAlign: "center",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  whiteSpace: "normal",
  ...safeTextStyle,
};

const privateProfileNoticeStyle: CSSProperties = {
  width: "100%",
  margin: "12px 0 0",
  padding: "13px 14px",
  borderRadius: "16px",
  border:
    "1px solid var(--historietas-border-soft, rgba(255,255,255,0.1))",
  background:
    "var(--historietas-surface, var(--historietas-perfil-surface, #08030F))",
  display: "flex",
  alignItems: "center",
  gap: "11px",
  boxSizing: "border-box",
  minWidth: 0,
  maxWidth: "100%",
  boxShadow: "0 10px 28px rgba(0,0,0,0.16)",
};

const privateProfileLockStyle: CSSProperties = {
  width: "34px",
  height: "34px",
  borderRadius: "11px",
  background: "rgba(255,255,255,0.055)",
  border: "1px solid rgba(255,255,255,0.08)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  flexShrink: 0,
  fontSize: "15px",
  lineHeight: 1,
};

const privateProfileNoticeTextBlockStyle: CSSProperties = {
  display: "grid",
  gap: "2px",
  minWidth: 0,
};

const privateProfileNoticeTitleStyle: CSSProperties = {
  color: "var(--historietas-text-primary, #FFFFFF)",
  fontSize: "13px",
  lineHeight: 1.25,
  fontWeight: 900,
  ...safeTextStyle,
};

const privateProfileNoticeTextStyle: CSSProperties = {
  margin: 0,
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "10.5px",
  lineHeight: 1.45,
  fontWeight: 650,
  ...safeTextStyle,
};

const emptyMiniBoxStyle: CSSProperties = {
  borderRadius: "20px",
  padding: "16px",
  background: "var(--historietas-surface, var(--historietas-perfil-surface, #08030F))",
  border: "1px dashed var(--historietas-border-soft, rgba(255,255,255,0.14))",
  color: "var(--historietas-text-secondary, #A1A1AA)",
  fontSize: "12px",
  lineHeight: 1.55,
  fontWeight: 750,
  textAlign: "center",
  minWidth: 0,
  maxWidth: "100%",
  boxSizing: "border-box",
  ...safeTextStyle,
};