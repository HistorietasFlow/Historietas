-- 20260705_comunidade_interacoes_rls.sql
-- RLS das interações da Comunidade.
-- Garante leitura pública do feed e restringe escrita/remoção ao usuário logado dono do registro.

begin;

alter table if exists public.comunidade_posts enable row level security;
alter table if exists public.comunidade_comentarios enable row level security;
alter table if exists public.comunidade_curtidas enable row level security;
alter table if exists public.comunidade_comentario_curtidas enable row level security;
alter table if exists public.comunidade_enquete_votos enable row level security;

do $$
begin
  if to_regclass('public.comunidade_posts') is not null then
    drop policy if exists "comunidade_posts_select_publico" on public.comunidade_posts;
    drop policy if exists "comunidade_posts_insert_proprio" on public.comunidade_posts;
    drop policy if exists "comunidade_posts_update_proprio" on public.comunidade_posts;
    drop policy if exists "comunidade_posts_delete_proprio" on public.comunidade_posts;

    create policy "comunidade_posts_select_publico"
      on public.comunidade_posts
      for select
      using (true);

    create policy "comunidade_posts_insert_proprio"
      on public.comunidade_posts
      for insert
      to authenticated
      with check (
        auth.uid() is not null
        and autor_id = auth.uid()
      );

    create policy "comunidade_posts_update_proprio"
      on public.comunidade_posts
      for update
      to authenticated
      using (
        auth.uid() is not null
        and autor_id = auth.uid()
      )
      with check (
        auth.uid() is not null
        and autor_id = auth.uid()
      );

    create policy "comunidade_posts_delete_proprio"
      on public.comunidade_posts
      for delete
      to authenticated
      using (
        auth.uid() is not null
        and autor_id = auth.uid()
      );

    revoke all on public.comunidade_posts from public;
    grant select on public.comunidade_posts to anon, authenticated;
    grant insert, update, delete on public.comunidade_posts to authenticated;
  end if;
end $$;

do $$
begin
  if to_regclass('public.comunidade_comentarios') is not null then
    drop policy if exists "comunidade_comentarios_select_publico" on public.comunidade_comentarios;
    drop policy if exists "comunidade_comentarios_insert_proprio" on public.comunidade_comentarios;
    drop policy if exists "comunidade_comentarios_update_proprio" on public.comunidade_comentarios;
    drop policy if exists "comunidade_comentarios_delete_proprio" on public.comunidade_comentarios;

    create policy "comunidade_comentarios_select_publico"
      on public.comunidade_comentarios
      for select
      using (true);

    create policy "comunidade_comentarios_insert_proprio"
      on public.comunidade_comentarios
      for insert
      to authenticated
      with check (
        auth.uid() is not null
        and autor_id = auth.uid()
      );

    create policy "comunidade_comentarios_update_proprio"
      on public.comunidade_comentarios
      for update
      to authenticated
      using (
        auth.uid() is not null
        and autor_id = auth.uid()
      )
      with check (
        auth.uid() is not null
        and autor_id = auth.uid()
      );

    create policy "comunidade_comentarios_delete_proprio"
      on public.comunidade_comentarios
      for delete
      to authenticated
      using (
        auth.uid() is not null
        and autor_id = auth.uid()
      );

    revoke all on public.comunidade_comentarios from public;
    grant select on public.comunidade_comentarios to anon, authenticated;
    grant insert, update, delete on public.comunidade_comentarios to authenticated;
  end if;
end $$;

do $$
begin
  if to_regclass('public.comunidade_curtidas') is not null then
    drop policy if exists "comunidade_curtidas_select_publico" on public.comunidade_curtidas;
    drop policy if exists "comunidade_curtidas_insert_proprio" on public.comunidade_curtidas;
    drop policy if exists "comunidade_curtidas_delete_proprio" on public.comunidade_curtidas;

    create unique index if not exists comunidade_curtidas_post_usuario_uidx
      on public.comunidade_curtidas (post_id, usuario_id);

    create policy "comunidade_curtidas_select_publico"
      on public.comunidade_curtidas
      for select
      using (true);

    create policy "comunidade_curtidas_insert_proprio"
      on public.comunidade_curtidas
      for insert
      to authenticated
      with check (
        auth.uid() is not null
        and usuario_id = auth.uid()
      );

    create policy "comunidade_curtidas_delete_proprio"
      on public.comunidade_curtidas
      for delete
      to authenticated
      using (
        auth.uid() is not null
        and usuario_id = auth.uid()
      );

    revoke all on public.comunidade_curtidas from public;
    revoke update on public.comunidade_curtidas from anon;
    revoke update on public.comunidade_curtidas from authenticated;
    grant select on public.comunidade_curtidas to anon, authenticated;
    grant insert, delete on public.comunidade_curtidas to authenticated;
  end if;
end $$;

do $$
begin
  if to_regclass('public.comunidade_comentario_curtidas') is not null then
    drop policy if exists "comunidade_comentario_curtidas_select_publico" on public.comunidade_comentario_curtidas;
    drop policy if exists "comunidade_comentario_curtidas_insert_proprio" on public.comunidade_comentario_curtidas;
    drop policy if exists "comunidade_comentario_curtidas_delete_proprio" on public.comunidade_comentario_curtidas;

    create unique index if not exists comunidade_comentario_curtidas_comentario_usuario_uidx
      on public.comunidade_comentario_curtidas (comentario_id, usuario_id);

    create policy "comunidade_comentario_curtidas_select_publico"
      on public.comunidade_comentario_curtidas
      for select
      using (true);

    create policy "comunidade_comentario_curtidas_insert_proprio"
      on public.comunidade_comentario_curtidas
      for insert
      to authenticated
      with check (
        auth.uid() is not null
        and usuario_id = auth.uid()
      );

    create policy "comunidade_comentario_curtidas_delete_proprio"
      on public.comunidade_comentario_curtidas
      for delete
      to authenticated
      using (
        auth.uid() is not null
        and usuario_id = auth.uid()
      );

    revoke all on public.comunidade_comentario_curtidas from public;
    revoke update on public.comunidade_comentario_curtidas from anon;
    revoke update on public.comunidade_comentario_curtidas from authenticated;
    grant select on public.comunidade_comentario_curtidas to anon, authenticated;
    grant insert, delete on public.comunidade_comentario_curtidas to authenticated;
  end if;
end $$;

do $$
begin
  if to_regclass('public.comunidade_enquete_votos') is not null then
    drop policy if exists "comunidade_enquete_votos_select_publico" on public.comunidade_enquete_votos;
    drop policy if exists "comunidade_enquete_votos_insert_proprio" on public.comunidade_enquete_votos;
    drop policy if exists "comunidade_enquete_votos_update_proprio" on public.comunidade_enquete_votos;
    drop policy if exists "comunidade_enquete_votos_delete_proprio" on public.comunidade_enquete_votos;

    create unique index if not exists comunidade_enquete_votos_post_usuario_uidx
      on public.comunidade_enquete_votos (post_id, user_id);

    create policy "comunidade_enquete_votos_select_publico"
      on public.comunidade_enquete_votos
      for select
      using (true);

    create policy "comunidade_enquete_votos_insert_proprio"
      on public.comunidade_enquete_votos
      for insert
      to authenticated
      with check (
        auth.uid() is not null
        and user_id = auth.uid()
      );

    create policy "comunidade_enquete_votos_update_proprio"
      on public.comunidade_enquete_votos
      for update
      to authenticated
      using (
        auth.uid() is not null
        and user_id = auth.uid()
      )
      with check (
        auth.uid() is not null
        and user_id = auth.uid()
      );

    create policy "comunidade_enquete_votos_delete_proprio"
      on public.comunidade_enquete_votos
      for delete
      to authenticated
      using (
        auth.uid() is not null
        and user_id = auth.uid()
      );

    revoke all on public.comunidade_enquete_votos from public;
    grant select on public.comunidade_enquete_votos to anon, authenticated;
    grant insert, update, delete on public.comunidade_enquete_votos to authenticated;
  end if;
end $$;

commit;